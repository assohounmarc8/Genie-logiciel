<?php
// ============================================================
//  MONASSO — Site public (index.php)
//  Accueil + Adhésion sur une seule page
// ============================================================
require_once 'config.php';
session_start();

$db             = getDB();
$moyensPaiement = [];

try {
    $moyensPaiement = $db->query(
        "SELECT id, libelle FROM GPOTB_MOYEN_PAIEMENT WHERE actif = 1 ORDER BY id"
    )->fetchAll();
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MonAsso — Adhérez à votre organisation</title>
  <meta name="description" content="MonAsso : la plateforme de gestion pour associations, mutuelles et ONG d'Afrique de l'Ouest."/>
  <link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg"/>
  <link rel="apple-touch-icon" href="assets/img/logo-icon.svg"/>
  <meta property="og:title"       content="MonAsso — Adhérez à votre organisation"/>
  <meta property="og:description" content="La plateforme de gestion pour associations, mutuelles et ONG d'Afrique de l'Ouest."/>
  <meta property="og:image"       content="<?= SITE_URL ?>/assets/img/logo.svg"/>
  <meta name="theme-color" content="#1D9E75"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>"/>
</head>
<body>

<nav class="navbar" id="navbar">
  <div class="container nav-inner">
    <a href="index.php" class="nav-logo">
      <img src="assets/img/logo.svg" alt="MonAsso" height="40" class="logo-img"/>
    </a>
    <div class="nav-links" id="nav-links">
      <a href="#pour-qui">Pour qui ?</a>
      <a href="#comment">Comment ça marche ?</a>
      <a href="adhesion.php" class="btn-main nav-cta">
        <i class="ti ti-user-plus"></i> Adhérer maintenant
      </a>
      <a href="connexion.php" class="btn-main nav-cta">
        <i class="ti ti-login"></i> Se connecter
      </a>
      <a href="#" class="btn-main nav-cta" onclick="ouvrirModalDon(event)">
        <i class="ti ti-heart"></i> Faire un don
      </a>
    </div>
    <button class="burger" id="burger" aria-label="Ouvrir le menu">
      <i class="ti ti-menu-2"></i>
    </button>
  </div>
</nav>

<section class="hero">
  <div class="container hero-inner">
    <div class="hero-content">
      <div class="badge"><i class="ti ti-star"></i> Associations · Mutuelles · ONG</div>
      <h1>Gérez tout depuis MonAsso,<br><span class="green">adhérez à votre organisation</span></h1>
      <p>Inscrivez-vous en ligne en quelques minutes. Recevez vos identifiants par SMS et Email, puis accédez à l'espace membre pour gérer vos cotisations, tontines et événements.</p>
      <div class="hero-btns">
        <a href="adhesion.php" class="btn-main"><i class="ti ti-user-plus"></i> Adhérer maintenant</a>
        <a href="#comment" class="btn-outline">Comment ça marche ?</a>
      </div>
      <div class="hero-stats">
        <div class="stat"><span class="stat-num">500+</span><span class="stat-label">Organisations</span></div>
        <div class="stat"><span class="stat-num">12 000+</span><span class="stat-label">Membres actifs</span></div>
        <div class="stat"><span class="stat-num">8 pays</span><span class="stat-label">Afrique de l'Ouest</span></div>
      </div>
    </div>
    <div class="hero-services" id="fonctionnalites">
      <div class="feat-grid">
        <?php
        $feats = [
          ['ti-users',          'Gestion des membres',      'Fiches membres, statuts, ayants droit et liens familiaux centralisés.'],
          ['ti-refresh',        'Tontines',                 'Cycles hebdomadaires ou mensuels, suivi des mises et gains automatisé.'],
          ['ti-cash',           'Cotisations & paiements',  'Mobile Money, Wave, Orange Money et carte bancaire intégrés.'],
          ['ti-calendar-event', 'Événements',               'Mariages, naissances, décès — campagnes de solidarité en temps réel.'],
          ['ti-trophy',         'Opportunités',             'Financements, subventions et partenariats publiés pour vos membres.'],
          ['ti-shield-check',   'Sécurité & rôles',         'Interfaces dédiées : Président, Trésorier, Secrétaire, Contrôleur.'],
        ];
        foreach ($feats as [$icon, $title, $desc]): ?>
        <div class="feat-card">
          <div class="feat-icon"><i class="ti <?= $icon ?>"></i></div>
          <div class="feat-title"><?= $title ?></div>
          <p><?= $desc ?></p>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<section class="section-alt" id="pour-qui">
  <div class="container">
    <h2>Pour qui est MonAsso ?</h2>
    <p class="section-sub">Une plateforme adaptée à trois types de structures.</p>
    <div class="org-grid">
      <div class="org-card">
        <div class="org-icon">🤝</div>
        <h3>Mutuelles</h3>
        <p>Gérez les cotisations, remboursements et sinistres de vos adhérents avec rigueur.</p>
      </div>
      <div class="org-card">
        <div class="org-icon">🌿</div>
        <h3>Associations</h3>
        <p>Animez votre communauté et gérez vos membres à travers plusieurs pays.</p>
      </div>
      <div class="org-card">
        <div class="org-icon">🌍</div>
        <h3>ONG</h3>
        <p>Suivez vos bénéficiaires, gérez vos dons et publiez vos opportunités de financement.</p>
      </div>
    </div>
  </div>
</section>

<section class="section" id="comment">
  <div class="container">
    <h2>Comment ça marche ?</h2>
    <p class="section-sub">Rejoignez MonAsso en 4 étapes simples.</p>
    <div class="how-grid">
      <?php
      $steps = [
        ['Renseignez vos infos',          'Formulaire en ligne en tant que personne physique ou morale.'],
        ['Choisissez votre organisation', 'Sélectionnez la mutuelle, association ou ONG à rejoindre.'],
        ['Payez en ligne',                'Réglez vos frais via Mobile Money, Wave ou carte bancaire.'],
        ['Accédez à votre espace',        'Recevez votre identifiant par SMS et Email, connectez-vous.'],
      ];
      foreach ($steps as $i => [$title, $desc]): ?>
      <div class="how-step">
        <div class="how-num"><?= $i + 1 ?></div>
        <h4><?= $title ?></h4>
        <p><?= $desc ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section class="cta">
  <div class="container">
    <h2>Prêt à rejoindre MonAsso ?</h2>
    <p>Adhérez à votre organisation en quelques minutes.<br>Vos identifiants vous seront envoyés par SMS et Email.</p>
    <a href="adhesion.php" class="btn-white"><i class="ti ti-user-plus"></i> Commencer l'adhésion</a>
  </div>
</section>

<footer class="footer">
  <div class="container footer-inner">
    <img src="assets/img/logo-white.svg" alt="MonAsso" height="32" class="logo-img"/>
    <div class="footer-links">
      <a href="#">Mentions légales</a>
      <a href="#">Confidentialité</a>
      <a href="#">Contact</a>
    </div>
    <p>© <?= date('Y') ?> MonAsso. Tous droits réservés.</p>
  </div>
</footer>

<script>
  window.FRAIS_INSCRIPTION = <?= json_encode(FRAIS_INSCRIPTION, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>

<div class="modal-overlay" id="don-overlay">
  <div class="modal-box" id="don-box">
    <button type="button" class="modal-close" onclick="fermerModalDon()" aria-label="Fermer">
      <i class="ti ti-x"></i>
    </button>

    <div id="don-form-wrap">
      <h3><i class="ti ti-heart" style="color:var(--green)"></i> Faire un don</h3>
      <p class="section-sub" style="margin-bottom:20px;">Votre générosité soutient les actions solidaires des organisations MonAsso.</p>

      <div class="fg" style="margin-bottom:14px;">
        <label for="don_montant">Montant (FCFA) *</label>
        <input type="number" id="don_montant" min="100" placeholder="5000"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_nom">Nom *</label>
        <input type="text" id="don_nom" placeholder="KOUASSI Jean"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_tel">Téléphone *</label>
        <input type="tel" id="don_tel" placeholder="+225 07 00 00 00"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_email">Email</label>
        <input type="email" id="don_email" placeholder="jean@email.com"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_moyen">Moyen de paiement *</label>
        <select id="don_moyen">
          <option value="">-- Choisir --</option>
          <?php foreach ($moyensPaiement as $mp): ?>
          <option value="<?= $mp['id'] ?>"><?= htmlspecialchars($mp['libelle']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg" style="margin-bottom:18px;">
        <label><input type="checkbox" id="don_anonyme"/> Faire ce don anonymement</label>
      </div>

      <button type="button" class="btn-main btn-block" id="btn-don-valider" onclick="envoyerDon()">
        <i class="ti ti-heart"></i> Confirmer le don
      </button>
    </div>

    <div id="don-confirm" hidden style="text-align:center;">
      <div class="confirm-icon"><i class="ti ti-circle-check"></i></div>
      <h3>Merci pour votre don !</h3>
      <p>Votre générosité fait la différence. Un reçu vous sera envoyé si vous avez renseigné votre email.</p>
      <button type="button" class="btn-main" onclick="fermerModalDon()">Fermer</button>
    </div>
  </div>
</div>

<script src="app.js"></script>
</body>
</html>
