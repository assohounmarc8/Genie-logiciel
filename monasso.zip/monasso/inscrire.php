<?php
// ============================================================
//  MONASSO — inscrire.php (MySQL + PHPMailer)
// ============================================================
require_once 'config.php';
require_once 'libs/mailer.php';
require_once 'libs/upload.php';
header('Content-Type: application/json');

$input = $_POST;
$isMultipart = !empty($_POST['type']);

if (!$isMultipart) {
    $input = json_decode(file_get_contents('php://input'), true) ?? [];
}

if (empty($input['type'])) {
    echo json_encode(['success' => false, 'message' => 'Données invalides.']);
    exit;
}

$type = $input['type'];

if ($type === 'morale') {
    $requis = ['nom', 'tel', 'montant', 'pm_raison', 'pm_type_struct', 'pm_immat', 'pm_pays', 'pm_rep_nom', 'pm_rep_prenom', 'pm_fonction', 'email'];
} else {
    $requis = ['type', 'nom', 'tel', 'organisation', 'montant'];
}

foreach ($requis as $champ) {
    if (empty($input[$champ])) {
        echo json_encode(['success' => false, 'message' => "Champ manquant : $champ"]);
        exit;
    }
}

if ($type === 'morale' && empty($_FILES['reglement_pdf'])) {
    echo json_encode(['success' => false, 'message' => 'Le règlement intérieur (PDF) est obligatoire.']);
    exit;
}

try {
    $db = getDB();
    $org = null;
    $reglementPath = null;

    if ($type === 'morale') {
        $upload = enregistrerReglementPdf($_FILES['reglement_pdf']);
        if (!$upload['ok']) {
            echo json_encode(['success' => false, 'message' => $upload['message']]);
            exit;
        }
        $reglementPath = $upload['path'];

        $typeLibelle = mapperTypeOrganisation(trim($input['pm_type_struct']));
        $stmtType = $db->prepare('SELECT id, code_login FROM GPOTB_TYPE_ORGANISATION WHERE libelle = ?');
        $stmtType->execute([$typeLibelle]);
        $typeOrg = $stmtType->fetch();

        if (!$typeOrg) {
            echo json_encode(['success' => false, 'message' => 'Type d\'organisation invalide.']);
            exit;
        }

        $paysId = (int) $input['pm_pays'];
        $stmtPays = $db->prepare('SELECT id, code_login FROM GPOTB_PAYS WHERE id = ?');
        $stmtPays->execute([$paysId]);
        $pays = $stmtPays->fetch();

        if (!$pays) {
            echo json_encode(['success' => false, 'message' => 'Pays invalide.']);
            exit;
        }

        $raisonSociale = trim($input['pm_raison']);
        $emailOrg      = trim($input['email']);
        $telOrg        = trim($input['tel']);
        $dateCreation  = !empty($input['pm_date_creation']) ? $input['pm_date_creation'] : null;
        $immat         = trim($input['pm_immat']);

        $db->prepare("
            INSERT INTO GPOTB_ORGANISATION (
                type_organisation_id, pays_siege_id, nom, email, telephone,
                date_creation, numero_immatriculation, reglement_interieur_pdf, acces_actif
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        ")->execute([
            $typeOrg['id'],
            $paysId,
            $raisonSociale,
            $emailOrg,
            $telOrg,
            $dateCreation,
            $immat,
            $reglementPath,
        ]);

        $orgId = (int) $db->lastInsertId();
        $org = [
            'id'               => $orgId,
            'nom'              => $raisonSociale,
            'compteur_membres' => 0,
            'code_pays'        => $pays['code_login'],
            'code_type'        => $typeOrg['code_login'],
        ];
        $input['organisation'] = $orgId;
        $input['nom']    = strtoupper(trim($input['pm_rep_nom']));
        $input['prenom'] = ucfirst(strtolower(trim($input['pm_rep_prenom'])));
    } else {
        $stmt = $db->prepare("
            SELECT o.id, o.nom, o.compteur_membres,
                   p.code_login AS code_pays,
                   t.code_login AS code_type
            FROM GPOTB_ORGANISATION o
            JOIN GPOTB_PAYS p              ON p.id = o.pays_siege_id
            JOIN GPOTB_TYPE_ORGANISATION t ON t.id = o.type_organisation_id
            WHERE o.id = ? AND o.acces_actif = 1
        ");
        $stmt->execute([$input['organisation']]);
        $org = $stmt->fetch();

        if (!$org) {
            echo json_encode(['success' => false, 'message' => 'Organisation introuvable ou inactive.']);
            exit;
        }
    }

    $stmt = $db->prepare('SELECT id FROM GPOTB_MEMBRE WHERE telephone = ?');
    $stmt->execute([$input['tel']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ce numéro est déjà enregistré.']);
        exit;
    }

    $db->beginTransaction();

    $nom    = strtoupper(trim($input['nom']));
    $prenom = ucfirst(strtolower(trim($input['prenom'] ?? '')));
    $email  = trim($input['email'] ?? '') ?: null;
    $tel    = trim($input['tel']);

    $db->prepare("
        INSERT INTO GPOTB_MEMBRE (nom, prenom, telephone, email, acces_actif)
        VALUES (?, ?, ?, ?, 0)
    ")->execute([$nom, $prenom, $tel, $email]);
    $membre_id = $db->lastInsertId();

    $db->prepare("
        INSERT INTO GPOTB_ADHESION (membre_id, organisation_id, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $org['id']]);

    $db->prepare("
        INSERT INTO GPOTB_PAIEMENT_INSCRIPTION (membre_id, montant, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $input['montant']]);

    $nouveau_compteur = $org['compteur_membres'] + 1;
    $login = $org['code_pays'] . $org['code_type'] . str_pad($nouveau_compteur, 3, '0', STR_PAD_LEFT);

    $db->prepare('UPDATE GPOTB_ORGANISATION SET compteur_membres = compteur_membres + 1 WHERE id = ?')
       ->execute([$org['id']]);

    $chars    = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $mdp_temp = '';
    for ($i = 0; $i < 8; $i++) {
        $mdp_temp .= $chars[random_int(0, strlen($chars) - 1)];
    }

    $hash = password_hash($mdp_temp, PASSWORD_BCRYPT);
    $db->prepare("
        INSERT INTO GPOTB_UTILISATEUR (membre_id, login, mot_de_passe_hash, actif)
        VALUES (?, ?, ?, 1)
    ")->execute([$membre_id, $login, $hash]);

    $db->prepare('UPDATE GPOTB_MEMBRE SET acces_actif = 1 WHERE id = ?')->execute([$membre_id]);
    $db->prepare("
        UPDATE GPOTB_ADHESION SET statut = 'ACTIF'
        WHERE membre_id = ? AND organisation_id = ?
    ")->execute([$membre_id, $org['id']]);

    if ($type === 'morale') {
        $stmtPoste = $db->prepare('SELECT id FROM GPOTB_POSTE WHERE organisation_id = ? AND libelle = ?');
        $stmtPoste->execute([$org['id'], 'Président']);
        $poste = $stmtPoste->fetch();

        if (!$poste) {
            $db->prepare("
                INSERT INTO GPOTB_POSTE (organisation_id, libelle)
                VALUES (?, 'Président')
            ")->execute([$org['id']]);
            $posteId = (int) $db->lastInsertId();
        } else {
            $posteId = (int) $poste['id'];
        }

        $db->prepare("
            INSERT INTO GPOTB_MEMBRE_POSTE (membre_id, poste_id, organisation_id, actif)
            VALUES (?, ?, ?, 1)
        ")->execute([$membre_id, $posteId, $org['id']]);
    }

    $msg_sms = 'MonAsso : Bienvenue ! Login : ' . $login . ' | MDP : ' . $mdp_temp . '. Connectez-vous : ' . APP_URL . '/login.php';
    $db->prepare("
        INSERT INTO GPOTB_NOTIFICATION (membre_id, canal, destinataire, message, statut)
        VALUES (?, 'SMS', ?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $tel, $msg_sms]);

    $email_envoye = false;
    if ($email) {
        $sujet      = '✅ Vos identifiants MonAsso — ' . $org['nom'];
        $corps_html = templateBienvenue($prenom, $nom, $login, $mdp_temp, $org['nom'], $type);
        $email_envoye = envoyerEmail($email, "$prenom $nom", $sujet, $corps_html);

        $statut_notif = $email_envoye ? 'ENVOYE' : 'ECHEC';
        $db->prepare("
            INSERT INTO GPOTB_NOTIFICATION (membre_id, canal, destinataire, objet, message, statut, date_envoi)
            VALUES (?, 'EMAIL', ?, ?, ?, ?, NOW())
        ")->execute([
            $membre_id,
            $email,
            $sujet,
            "Identifiant : $login | MDP : $mdp_temp | Lien : " . APP_URL . '/login.php',
            $statut_notif
        ]);
    }

    $db->prepare("
        INSERT INTO GPOTB_TRANSACTION (organisation_id, membre_id, montant, type_flux, statut_paiement)
        VALUES (?, ?, ?, 'INSCRIPTION_MEMBRE', 'EN_ATTENTE')
    ")->execute([$org['id'], $membre_id, $input['montant']]);

    $db->commit();

    echo json_encode([
        'success'      => true,
        'login'        => $login,
        'org_nom'      => $org['nom'],
        'email_envoye' => $email_envoye,
        'message'      => 'Inscription réussie.',
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    error_log('[MonAsso] Erreur inscription : ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Veuillez réessayer.']);
}
