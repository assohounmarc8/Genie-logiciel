<?php
// ============================================================
//  MONASSO — Configuration générale (MySQL + WAMP)
// ============================================================

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'monasso');
define('DB_USER', 'root');
define('DB_PASS', '');          // WAMP : mot de passe vide par défaut

define('SITE_NAME', 'MonAsso');
define('SITE_URL',  'http://localhost/monasso-site');
define('APP_URL',   'http://localhost/monasso-site/app');

define('FRAIS_INSCRIPTION', 2000); // FCFA

define('UPLOAD_REGLEMENT_DIR', __DIR__ . '/uploads/reglements');
define('UPLOAD_REGLEMENT_MAX_BYTES', 5 * 1024 * 1024); // 5 Mo

// CinetPay
define('CINETPAY_APIKEY',    'VOTRE_API_KEY');
define('CINETPAY_SITE_ID',   'VOTRE_SITE_ID');
define('CINETPAY_NOTIFY_URL', SITE_URL . '/notify.php');
define('CINETPAY_RETURN_URL', SITE_URL . '/retour-paiement.php');

// Connexion PDO MySQL (singleton)
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

/**
 * Liste des pays du siège (auto-remplie si la table est vide).
 */
function getPaysList(): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    // Liste fixe et ordonnée des pays demandés (évite la création automatique de tables)
    $defaults = [
        ['BEN', 'Bénin',         'Ben'],
        ['NGA', 'Nigeria',       'Nga'],
        ['CIV', "Côte d'Ivoire", 'Civ'],
        ['MDG', 'Madagascar',    'Mdg'],
        ['BFA', 'Burkina Faso',  'Bfa'],
        ['MLI', 'Mali',          'Mal'],
    ];

    try {
        $db = getDB();
        // If the GPOTB_PAYS table exists and contains rows, prefer using it.
        $rows = $db->query('SELECT id, libelle, code_login FROM GPOTB_PAYS ORDER BY libelle')->fetchAll();
        if (!empty($rows)) {
            $cached = $rows;
            return $cached;
        }
    } catch (Throwable $e) {
        error_log('[MonAsso] getPaysList (fallback) : ' . $e->getMessage());
    }

    // Fallback : renvoyer la liste par défaut (IDs numériques simples)
    $cached = [];
    foreach ($defaults as $i => $row) {
        $cached[] = [
            'id'         => $i + 1,
            'libelle'    => $row[1],
            'code_login' => $row[2],
        ];
    }
    return $cached;
}

// ---- SMTP Gmail (PHPMailer) ----
define('MAIL_HOST',      'smtp.gmail.com');
define('MAIL_PORT',      587);
define('MAIL_USERNAME',  'votre.email@gmail.com');   // Votre adresse Gmail
define('MAIL_PASSWORD',  'xxxx xxxx xxxx xxxx');     // Mot de passe d'application Google (16 car.)
define('MAIL_FROM',      'votre.email@gmail.com');   // Expéditeur
define('MAIL_FROM_NAME', 'MonAsso');                 // Nom affiché dans la boite mail
