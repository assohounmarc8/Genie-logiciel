<?php
// ============================================================
//  MONASSO — adhesion.php (page d'adhésion dédiée)
// ============================================================
require_once 'config.php';
session_start();

$db            = getDB();
$organisations = [];
$pays          = [];
$sexes         = [];
$situations    = [];
$moyensPaiement = [];

try {
    $organisations = $db->query("
        SELECT o.id, o.nom, t.libelle AS type
        FROM GPOTB_ORGANISATION o
        JOIN GPOTB_TYPE_ORGANISATION t ON t.id = o.type_organisation_id
        WHERE o.acces_actif = TRUE
        ORDER BY t.libelle, o.nom
    ")->fetchAll();

    $pays = getPaysList();

    $sexes = $db->query(
        "SELECT id, libelle FROM GPOTB_SEXE ORDER BY id"
    )->fetchAll();

    $situations = $db->query(
        "SELECT id, libelle FROM GPOTB_SITUATION_MATRIMONIALE ORDER BY id"
    )->fetchAll();

    $moyensPaiement = $db->query(
        "SELECT id, libelle FROM GPOTB_MOYEN_PAIEMENT WHERE actif = 1 ORDER BY id"
    )->fetchAll();
} catch (Exception $e) {}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MonAsso — Adhérer à une organisation</title>
  <meta name="description" content="Rejoignez une mutuelle, association ou ONG sur MonAsso en quelques minutes."/>
  <link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg"/>
  <link rel="apple-touch-icon" href="assets/img/logo-icon.svg"/>
  <meta name="theme-color" content="#1D9E75"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>"/>
</head>
<body>

<nav class="navbar" id="navbar">
  <div class="container nav-inner">
    <a href="index.php" class="nav-logo">
      <img src="assets/img/logo.svg" alt="MonAsso" height="40" class="logo-img"/>
    </a>
    <div class="nav-links" id="nav-links">
      <a href="index.php#pour-qui">Pour qui ?</a>
      <a href="index.php#comment">Comment ça marche ?</a>
      <a href="#adherer" class="btn-main nav-cta">
        <i class="ti ti-user-plus"></i> Adhérer maintenant
      </a>
      <a href="connexion.php" class="btn-main nav-cta">
        <i class="ti ti-login"></i> Se connecter
      </a>
      <a href="#" class="btn-main nav-cta" onclick="ouvrirModalDon(event)">
        <i class="ti ti-heart"></i> Faire un don
      </a>
    </div>
    <button class="burger" id="burger" aria-label="Ouvrir le menu">
      <i class="ti ti-menu-2"></i>
    </button>
  </div>
</nav>

<section class="section-alt" id="adherer">
  <div class="container">
    <h2>Adhérer à une organisation</h2>
    <p class="section-sub">Remplissez le formulaire ci-dessous pour créer votre compte MonAsso.</p>

    <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>">
      <i class="ti ti-<?= $flash['type'] === 'success' ? 'circle-check' : 'alert-circle' ?>"></i>
      <?= htmlspecialchars($flash['message']) ?>
    </div>
    <?php endif; ?>

    <div class="stepper">
      <div class="step active" id="s1"><div class="snum" id="sn1">1</div><span>Informations</span></div>
      <div class="sep" id="sep1"></div>
      <div class="step" id="s2"><div class="snum" id="sn2">2</div><span>Paiement</span></div>
      <div class="sep" id="sep2"></div>
      <div class="step" id="s3"><div class="snum" id="sn3">3</div><span>Confirmation</span></div>
    </div>

    <div class="form-wrap">

      <div class="panel active" id="p1">

        <div class="type-switch">
          <button type="button" class="type-btn active" id="btn-phys" onclick="switchType('physique')">
            <i class="ti ti-user"></i>
            <div><strong>Personne physique</strong><small>Particulier, individu</small></div>
          </button>
          <button type="button" class="type-btn" id="btn-moral" onclick="switchType('morale')">
            <i class="ti ti-building"></i>
            <div><strong>Personne morale</strong><small>Entreprise, ONG, institution</small></div>
          </button>
        </div>

        <div id="form-physique">
          <p class="form-label-section">Informations personnelles</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pp_nom">Nom *</label>
              <input type="text" id="pp_nom" placeholder="KOUASSI" autocomplete="family-name"/>
            </div>
            <div class="fg">
              <label for="pp_prenom">Prénom *</label>
              <input type="text" id="pp_prenom" placeholder="Jean" autocomplete="given-name"/>
            </div>
            <div class="fg">
              <label for="pp_sexe">Sexe *</label>
              <select id="pp_sexe">
                <option value="">-- Choisir --</option>
                <?php foreach ($sexes as $s): ?>
                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="fg">
              <label for="pp_situation">Situation matrimoniale *</label>
              <select id="pp_situation">
                <option value="">-- Choisir --</option>
                <?php foreach ($situations as $sit): ?>
                <option value="<?= $sit['id'] ?>"><?= htmlspecialchars($sit['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="fg">
              <label for="pp_naissance">Date de naissance *</label>
              <input type="date" id="pp_naissance"/>
            </div>
            <div class="fg">
              <label for="pp_pays">Pays *</label>
              <select id="pp_pays">
                <option value="">-- Choisir --</option>
                <option value="CI">Côte d'Ivoire</option>
                <option value="BF">Burkina Faso</option>
                <option value="ML">Mali</option>
                <option value="NE">Niger</option>
                <option value="MG">Madagascar</option>
                <option value="BJ">Bénin</option>
                <?php foreach ($pays as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <p class="form-label-section">Coordonnées</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pp_tel">Téléphone *</label>
              <input type="tel" id="pp_tel" placeholder="+225 07 00 00 00" autocomplete="tel"/>
            </div>
            <div class="fg">
              <label for="pp_email">Email</label>
              <input type="email" id="pp_email" placeholder="jean@email.com" autocomplete="email"/>
            </div>
            <div class="fg full">
              <label for="pp_adresse">Adresse</label>
              <input type="text" id="pp_adresse" placeholder="Cocody, Abidjan"/>
            </div>
          </div>
        </div>

        <div id="form-morale" style="display:none;">
          <p class="form-label-section">Informations de la structure</p>
          <div class="form-grid">
            <div class="fg full">
              <label for="pm_raison">Raison sociale *</label>
              <input type="text" id="pm_raison" placeholder="SARL Kouassi & Associés"/>
            </div>
            <div class="fg">
              <label for="pm_type_struct">Type de structure *</label>
              <select id="pm_type_struct">
                <option value="">-- Choisir --</option>
                <option>Entreprise / Société</option>
                <option>ONG / Association existante</option>
                <option>Collectivité / Institution</option>
              </select>
            </div>
            <div class="fg">
              <label for="pm_immat">N° d'immatriculation *</label>
              <input type="text" id="pm_immat" placeholder="CI-ABJ-2020-B-00123"/>
            </div>
            <div class="fg">
              <label for="pm_date_creation">Date de création</label>
              <input type="date" id="pm_date_creation"/>
            </div>
            <div class="fg">
              <label for="pm_pays">Pays du siège *</label>
              <select id="pm_pays">
                <option value="">-- Choisir --</option>
                <option value="CI">Côte d'Ivoire</option>
                <option value="BF">Burkina Faso</option>
                <option value="ML">Mali</option>
                <option value="NE">Niger</option>
                <option value="MG">Madagascar</option>
                <option value="BJ">Bénin</option>
                <?php foreach ($pays as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <p class="form-label-section">Représentant légal</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pm_rep_nom">Nom *</label>
              <input type="text" id="pm_rep_nom" placeholder="KOUASSI"/>
            </div>
            <div class="fg">
              <label for="pm_rep_prenom">Prénom *</label>
              <input type="text" id="pm_rep_prenom" placeholder="Jean"/>
            </div>
            <div class="fg">
              <label for="pm_fonction">Fonction *</label>
              <input type="text" id="pm_fonction" placeholder="Directeur Général"/>
            </div>
            <div class="fg">
              <label for="pm_tel">Téléphone *</label>
              <input type="tel" id="pm_tel" placeholder="+225 07 00 00 00"/>
            </div>
            <div class="fg full">
              <label for="pm_email">Email *</label>
              <input type="email" id="pm_email" placeholder="contact@structure.com"/>
            </div>
          </div>

          <p class="form-label-section">Règlement intérieur</p>
          <div class="fg full">
            <label for="pm_reglement">Document PDF du règlement intérieur *</label>
            <div class="pdf-upload" id="pdf-upload-zone">
              <input type="file" id="pm_reglement" class="pdf-input-hidden" accept=".pdf,application/pdf"/>
              <div class="pdf-upload-inner" id="pdf-upload-inner">
                <i class="ti ti-file-type-pdf pdf-upload-icon"></i>
                <div>
                  <strong>Cliquez ou glissez votre PDF ici</strong>
                  <small>Format PDF uniquement — max. 5 Mo</small>
                </div>
              </div>
              <div class="pdf-file-preview" id="pdf-file-preview" hidden>
                <i class="ti ti-file-type-pdf"></i>
                <span id="pdf-file-name">—</span>
                <button type="button" class="pdf-remove" id="pdf-remove-btn" aria-label="Supprimer le fichier">
                  <i class="ti ti-x"></i>
                </button>
              </div>
            </div>
            <p class="pdf-hint"><i class="ti ti-info-circle"></i> Ce document sera associé à votre organisation sur MonAsso.</p>
          </div>
        </div>

        <div id="section-org-join">
        <p class="form-label-section">Organisation à rejoindre</p>
        <div class="form-grid">
          <div class="fg full">
            <label for="organisation_id">Organisation *</label>
            <select id="organisation_id">
              <option value="">-- Sélectionner une organisation --</option>
              <?php foreach ($organisations as $org): ?>
              <option value="<?= $org['id'] ?>"
                      data-type="<?= htmlspecialchars($org['type']) ?>">
                [<?= htmlspecialchars($org['type']) ?>] <?= htmlspecialchars($org['nom']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>
        </div>

        <div class="form-actions">
          <span class="form-note">* Champs obligatoires</span>
          <button type="button" class="btn-main" onclick="validerEtape1()">
            Continuer <i class="ti ti-arrow-right"></i>
          </button>
        </div>
      </div><div class="panel" id="p2">
        <div class="pay-layout">

          <div>
            <h3 class="pay-title">Moyen de paiement</h3>
            <div class="method-grid">
              <div class="method active" onclick="selMethod(this,'mobile')">
                <i class="ti ti-device-mobile"></i><span>Mobile Money</span>
              </div>
              <div class="method" onclick="selMethod(this,'wave')">
                <i class="ti ti-ripple"></i><span>Wave</span>
              </div>
              <div class="method" onclick="selMethod(this,'orange')">
                <i class="ti ti-phone"></i><span>Orange Money</span>
              </div>
              <div class="method" onclick="selMethod(this,'card')">
                <i class="ti ti-credit-card"></i><span>Carte bancaire</span>
              </div>
            </div>

            <div id="fields-mobile">
              <div class="fg">
                <label>Numéro *</label>
                <div class="phone-row">
                  <select id="indicatif">
                    <option value="+225">🇨🇮 +225</option>
                    <option value="+221">🇸🇳 +221</option>
                    <option value="+223">🇲🇱 +223</option>
                    <option value="+226">🇧🇫 +226</option>
                    <option value="+228">🇹🇬 +228</option>
                    <option value="+229">🇧🇯 +229</option>
                    <option value="+233">🇬🇭 +233</option>
                  </select>
                  <input type="tel" id="numero_mobile" placeholder="07 00 00 00 00"/>
                </div>
              </div>
              <div class="info-box">
                <i class="ti ti-info-circle"></i>
                Vous recevrez une demande de confirmation sur votre téléphone. Validez avec votre code secret pour finaliser.
              </div>
            </div>

            <div id="fields-card" style="display:none;">
              <div class="fg" style="margin-bottom:12px;">
                <label>Numéro de carte *</label>
                <input type="text" id="card_num" placeholder="0000 0000 0000 0000" maxlength="19"/>
              </div>
              <div class="fg" style="margin-bottom:12px;">
                <label>Titulaire *</label>
                <input type="text" id="card_holder" placeholder="KOUASSI Jean"/>
              </div>
              <div class="form-grid">
                <div class="fg"><label>Expiration *</label><input type="text" id="card_exp" placeholder="MM / AA"/></div>
                <div class="fg"><label>CVV *</label><input type="text" id="card_cvv" placeholder="000" maxlength="3"/></div>
              </div>
            </div>
          </div>

          <div>
            <h3 class="pay-title">Récapitulatif</h3>
            <div class="recap-card">
              <div class="recap-header">
                <div class="avatar-sm" id="recap-avatar">?</div>
                <div>
                  <div class="r-name" id="recap-nom">—</div>
                  <div class="r-sub"  id="recap-org">—</div>
                </div>
              </div>
              <div class="recap-row"><span>Frais MonAsso</span><span><?= number_format(FRAIS_INSCRIPTION,0,',',' ') ?> F</span></div>
              <div class="recap-row"><span>Cotisation</span><span id="r-cotisation">— F</span></div>
              <div class="recap-row total"><span>Total</span><span id="r-total">— F CFA</span></div>
              <div class="secure-row">
                <span><i class="ti ti-lock"></i> Sécurisé</span>
                <span><i class="ti ti-shield-check"></i> CinetPay</span>
              </div>
              <button type="button" class="btn-main btn-block" id="btn-payer" onclick="lancerPaiement()">
                <i class="ti ti-lock"></i> Payer <span id="btn-montant">— F CFA</span>
              </button>
            </div>
          </div>

        </div><div class="form-actions">
          <button type="button" class="btn-ghost" onclick="goTo(1)">
            <i class="ti ti-arrow-left"></i> Retour
          </button>
        </div>
      </div><div class="panel" id="p3">
        <div class="confirm-center">
          <div class="confirm-icon"><i class="ti ti-circle-check"></i></div>
          <h2>Inscription confirmée !</h2>
          <p id="confirm-msg">Bienvenue dans MonAsso.</p>
          <div class="login-box"><span id="confirm-login">—</span></div>
          <p class="login-label">Votre identifiant MonAsso</p>
          <div class="notif-row">
            <span class="notif-badge"><i class="ti ti-message"></i> SMS envoyé</span>
            <span class="notif-badge"><i class="ti ti-mail"></i> Email envoyé</span>
          </div>
          <p class="confirm-note">
            Vos identifiants et mot de passe temporaire ont été envoyés par SMS et Email.
            Connectez-vous à votre espace MonAsso pour gérer votre adhésion.
          </p>
          <a href="connexion.php" class="btn-main">
            <i class="ti ti-login"></i> Accéder à mon espace
          </a>
        </div>
      </div></div></div>
</section>

<footer class="footer">
  <div class="container footer-inner">
    <img src="assets/img/logo-white.svg" alt="MonAsso" height="32" class="logo-img"/>
    <div class="footer-links">
      <a href="#">Mentions légales</a>
      <a href="#">Confidentialité</a>
      <a href="#">Contact</a>
    </div>
    <p>© <?= date('Y') ?> MonAsso. Tous droits réservés.</p>
  </div>
</footer>

<script>
  window.FRAIS_INSCRIPTION = <?= json_encode(FRAIS_INSCRIPTION, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
</script>

<div class="modal-overlay" id="don-overlay">
  <div class="modal-box" id="don-box">
    <button type="button" class="modal-close" onclick="fermerModalDon()" aria-label="Fermer">
      <i class="ti ti-x"></i>
    </button>

    <div id="don-form-wrap">
      <h3><i class="ti ti-heart" style="color:var(--green)"></i> Faire un don</h3>
      <p class="section-sub" style="margin-bottom:20px;">Votre générosité soutient les actions solidaires des organisations MonAsso.</p>

      <div class="fg" style="margin-bottom:14px;">
        <label for="don_montant">Montant (FCFA) *</label>
        <input type="number" id="don_montant" min="100" placeholder="5000"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_nom">Nom *</label>
        <input type="text" id="don_nom" placeholder="KOUASSI Jean"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_tel">Téléphone *</label>
        <input type="tel" id="don_tel" placeholder="+225 07 00 00 00"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_email">Email</label>
        <input type="email" id="don_email" placeholder="jean@email.com"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_moyen">Moyen de paiement *</label>
        <select id="don_moyen">
          <option value="">-- Choisir --</option>
          <?php foreach ($moyensPaiement as $mp): ?>
          <option value="<?= $mp['id'] ?>"><?= htmlspecialchars($mp['libelle']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg" style="margin-bottom:18px;">
        <label><input type="checkbox" id="don_anonyme"/> Faire ce don anonymement</label>
      </div>

      <button type="button" class="btn-main btn-block" id="btn-don-valider" onclick="envoyerDon()">
        <i class="ti ti-heart"></i> Confirmer le don
      </button>
    </div>

    <div id="don-confirm" hidden style="text-align:center;">
      <div class="confirm-icon"><i class="ti ti-circle-check"></i></div>
      <h3>Merci pour votre don !</h3>
      <p>Votre générosité fait la différence. Un reçu vous sera envoyé si vous avez renseigné votre email.</p>
      <button type="button" class="btn-main" onclick="fermerModalDon()">Fermer</button>
    </div>
  </div>
</div>

<script src="app.js"></script>
</body>
</html>
