// ============================================================
//  MONASSO — app.js
//  Navigation étapes, validation, récapitulatif paiement
// ============================================================

/* ---- État global ---- */
const state = {
  type: 'physique',   // 'physique' | 'morale'
  step: 1,
  data: {}
};

/* ============================================================
   NAVIGATION STEPPER
============================================================ */
function goTo(n) {
  // Cacher tous les panels
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('p' + n).classList.add('active');
  state.step = n;

  // Mettre à jour le stepper
  [1, 2, 3].forEach(i => {
    const s  = document.getElementById('s'  + i);
    const sn = document.getElementById('sn' + i);
    s.className = 'step';
    if (i < n)  { s.classList.add('done');   sn.innerHTML = '<i class="ti ti-check"></i>'; }
    if (i === n){ s.classList.add('active'); sn.textContent = i; }
    if (i > n)  { sn.textContent = i; }
  });
  [1, 2].forEach(i => {
    const sep = document.getElementById('sep' + i);
    if (sep) sep.className = 'sep' + (i < n ? ' done' : '');
  });

  // Scroll vers le formulaire
  document.getElementById('adherer').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================================
   SWITCH PERSONNE PHYSIQUE / MORALE
============================================================ */
function switchType(type) {
  state.type = type;
  document.getElementById('btn-phys') .classList.toggle('active', type === 'physique');
  document.getElementById('btn-moral').classList.toggle('active', type === 'morale');
  document.getElementById('form-physique').style.display = type === 'physique' ? 'block' : 'none';
  document.getElementById('form-morale') .style.display = type === 'morale'   ? 'block' : 'none';

  const orgSection = document.getElementById('section-org-join');
  if (orgSection) orgSection.style.display = type === 'physique' ? 'block' : 'none';
}

/* ============================================================
   VALIDATION ÉTAPE 1
============================================================ */
function validerEtape1() {
  let ok = true;

  // Réinitialiser les erreurs
  document.querySelectorAll('.fg input, .fg select').forEach(el => el.classList.remove('error'));

  function requis(id) {
    const el = document.getElementById(id);
    if (!el) return true;
    if (!el.value.trim()) { el.classList.add('error'); ok = false; return false; }
    return true;
  }

  if (state.type === 'physique') {
    requis('pp_nom'); requis('pp_prenom');
    requis('pp_sexe'); requis('pp_situation');
    requis('pp_naissance'); requis('pp_pays');
    requis('pp_tel');

    if (ok) {
      state.data.nom    = document.getElementById('pp_nom').value.trim().toUpperCase();
      state.data.prenom = document.getElementById('pp_prenom').value.trim();
      state.data.tel    = document.getElementById('pp_tel').value.trim();
      state.data.email  = document.getElementById('pp_email').value.trim();
      state.data.avatar = state.data.prenom[0] + state.data.nom[0];
    }
  } else {
    requis('pm_raison'); requis('pm_type_struct');
    requis('pm_immat'); requis('pm_pays');
    requis('pm_rep_nom'); requis('pm_rep_prenom');
    requis('pm_fonction'); requis('pm_tel'); requis('pm_email');

    const reglementInput = document.getElementById('pm_reglement');
    const pdfZone = document.getElementById('pdf-upload-zone');
    if (!reglementInput || !reglementInput.files || !reglementInput.files.length) {
      if (pdfZone) pdfZone.classList.add('error');
      ok = false;
    } else if (pdfZone) {
      pdfZone.classList.remove('error');
    }

    if (ok) {
      state.data.nom    = document.getElementById('pm_raison').value.trim();
      state.data.prenom = document.getElementById('pm_rep_prenom').value.trim();
      state.data.tel    = document.getElementById('pm_tel').value.trim();
      state.data.email  = document.getElementById('pm_email').value.trim();
      state.data.avatar = 'PM';
      state.data.pm_raison         = document.getElementById('pm_raison').value.trim();
      state.data.pm_type_struct    = document.getElementById('pm_type_struct').value.trim();
      state.data.pm_immat          = document.getElementById('pm_immat').value.trim();
      state.data.pm_date_creation  = document.getElementById('pm_date_creation').value;
      state.data.pm_pays           = document.getElementById('pm_pays').value;
      state.data.pm_rep_nom        = document.getElementById('pm_rep_nom').value.trim();
      state.data.pm_rep_prenom     = document.getElementById('pm_rep_prenom').value.trim();
      state.data.pm_fonction       = document.getElementById('pm_fonction').value.trim();
      state.data.org_nom           = state.data.pm_raison;
      state.data.org_type          = state.data.pm_type_struct;
    }
  }

  if (state.type === 'physique') {
    requis('organisation_id');
    if (ok) {
      const sel = document.getElementById('organisation_id');
      state.data.org_id   = sel.value;
      state.data.org_nom  = sel.options[sel.selectedIndex].text;
      state.data.org_type = sel.options[sel.selectedIndex].dataset.type || '';
    }
  }

  if (!ok) {
    const firstError = document.querySelector('.fg input.error, .fg select.error');
    if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  // Remplir le récapitulatif
  remplirRecap();
  goTo(2);
}

/* ============================================================
   RÉCAPITULATIF PAIEMENT
============================================================ */
function remplirRecap() {
  document.getElementById('recap-avatar').textContent = state.data.avatar || '?';
  document.getElementById('recap-nom').textContent    = state.data.nom    || '—';
  document.getElementById('recap-org').textContent    = state.data.org_nom|| '—';

  // Cotisation fictive — frais d'inscription fournis côté serveur
  const cotisation = 3000;
  const frais      = Number(window.FRAIS_INSCRIPTION || 0);
  const total      = frais + cotisation;

  document.getElementById('r-cotisation').textContent = cotisation.toLocaleString('fr') + ' F';
  document.getElementById('r-total').textContent      = total.toLocaleString('fr') + ' F CFA';
  document.getElementById('btn-montant').textContent  = total.toLocaleString('fr') + ' F CFA';

  state.data.montant    = total;
  state.data.cotisation = cotisation;
}

/* ============================================================
   SÉLECTION DU MOYEN DE PAIEMENT
============================================================ */
function selMethod(el, type) {
  document.querySelectorAll('.method').forEach(m => m.classList.remove('active'));
  el.classList.add('active');
  state.data.moyen = type;

  document.getElementById('fields-mobile').style.display = type === 'card' ? 'none' : 'block';
  document.getElementById('fields-card') .style.display = type === 'card' ? 'block' : 'none';
}

/* ============================================================
   LANCER LE PAIEMENT (CinetPay)
============================================================ */
function lancerPaiement() {
  const btn = document.getElementById('btn-payer');
  btn.disabled = true;
  btn.innerHTML = '<i class="ti ti-loader ti-spin"></i> Traitement…';

  const onError = (message) => {
    alert(message || 'Une erreur est survenue.');
    btn.disabled = false;
    btn.innerHTML = '<i class="ti ti-lock"></i> Payer <span id="btn-montant">' + state.data.montant.toLocaleString('fr') + ' F CFA</span>';
  };

  if (state.type === 'morale') {
    const formData = new FormData();
    formData.append('type', state.type);
    formData.append('nom', state.data.nom);
    formData.append('prenom', state.data.prenom);
    formData.append('tel', state.data.tel);
    formData.append('email', state.data.email);
    formData.append('montant', state.data.montant);
    formData.append('moyen', state.data.moyen || 'mobile');
    formData.append('pm_raison', state.data.pm_raison);
    formData.append('pm_type_struct', state.data.pm_type_struct);
    formData.append('pm_immat', state.data.pm_immat);
    formData.append('pm_date_creation', state.data.pm_date_creation || '');
    formData.append('pm_pays', state.data.pm_pays);
    formData.append('pm_rep_nom', state.data.pm_rep_nom);
    formData.append('pm_rep_prenom', state.data.pm_rep_prenom);
    formData.append('pm_fonction', state.data.pm_fonction);

    const reglementInput = document.getElementById('pm_reglement');
    if (reglementInput && reglementInput.files.length) {
      formData.append('reglement_pdf', reglementInput.files[0]);
    }

    fetch('inscrire.php', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(res => traiterReponseInscription(res, btn, onError))
      .catch(() => onError('Erreur de connexion. Veuillez réessayer.'));
    return;
  }

  const payload = {
    type:          state.type,
    nom:           state.data.nom,
    prenom:        state.data.prenom,
    tel:           state.data.tel,
    email:         state.data.email,
    organisation:  state.data.org_id,
    montant:       state.data.montant,
    moyen:         state.data.moyen || 'mobile',
  };

  fetch('inscrire.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(res => traiterReponseInscription(res, btn, onError))
  .catch(() => onError('Erreur de connexion. Veuillez réessayer.'));
}

function traiterReponseInscription(res, btn, onError) {
  if (res.success) {
    if (res.payment_url) {
      window.location.href = res.payment_url;
    } else {
      afficherConfirmation(res.login, res.org_nom);
    }
  } else {
    onError('Erreur : ' + (res.message || 'Une erreur est survenue.'));
  }
}

/* ============================================================
   AFFICHER LA CONFIRMATION (étape 3)
============================================================ */
function afficherConfirmation(login, orgNom) {
  document.getElementById('confirm-login').textContent = login || 'CivMUT001';
  document.getElementById('confirm-msg').textContent   =
    'Bienvenue dans ' + (orgNom || state.data.org_nom) + '.';
  goTo(3);
}

/* ============================================================
   NAVBAR — menu burger mobile
============================================================ */
document.getElementById('burger').addEventListener('click', () => {
  const links = document.getElementById('nav-links');
  links.classList.toggle('open');
});

// Fermer le menu au clic sur un lien
document.querySelectorAll('#nav-links a').forEach(a => {
  a.addEventListener('click', () => {
    document.getElementById('nav-links').classList.remove('open');
  });
});

// Navbar ombre au scroll
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 20);
});

// Formatage carte bancaire
const cardNum = document.getElementById('card_num');
if (cardNum) {
  cardNum.addEventListener('input', e => {
    let v = e.target.value.replace(/\D/g,'').substring(0,16);
    e.target.value = v.replace(/(.{4})/g,'$1 ').trim();
  });
}

/* ============================================================
   UPLOAD PDF — Personne morale
============================================================ */
(function initPdfUpload() {
  const zone       = document.getElementById('pdf-upload-zone');
  const input      = document.getElementById('pm_reglement');
  const inner      = document.getElementById('pdf-upload-inner');
  const preview    = document.getElementById('pdf-file-preview');
  const fileNameEl = document.getElementById('pdf-file-name');
  const removeBtn  = document.getElementById('pdf-remove-btn');

  if (!zone || !input) return;

  zone.addEventListener('click', (e) => {
    if (e.target.closest('.pdf-remove')) return;
    input.click();
  });

  input.addEventListener('change', () => {
    if (!input.files || !input.files.length) return;
    const file = input.files[0];
    if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
      alert('Veuillez sélectionner un fichier PDF.');
      input.value = '';
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert('Le fichier ne doit pas dépasser 5 Mo.');
      input.value = '';
      return;
    }
    zone.classList.remove('error');
    fileNameEl.textContent = file.name;
    inner.hidden = true;
    preview.hidden = false;
  });

  if (removeBtn) {
    removeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      input.value = '';
      inner.hidden = false;
      preview.hidden = true;
      zone.classList.remove('error');
    });
  }

  ['dragenter', 'dragover'].forEach(evt => {
    zone.addEventListener(evt, (e) => {
      e.preventDefault();
      zone.classList.add('dragover');
    });
  });
  ['dragleave', 'drop'].forEach(evt => {
    zone.addEventListener(evt, (e) => {
      e.preventDefault();
      zone.classList.remove('dragover');
    });
  });
  zone.addEventListener('drop', (e) => {
    const files = e.dataTransfer.files;
    if (files && files.length) {
      input.files = files;
      input.dispatchEvent(new Event('change'));
    }
  });
})();
