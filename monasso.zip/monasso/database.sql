-- ============================================================
--  MONASSO — Schéma MySQL complet
--  Compatible WAMP (MySQL 8+)
--  Importer via phpMyAdmin ou : mysql -u root monasso < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS monasso
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE monasso;

-- ============================================================
--  1. TABLES DE RÉFÉRENCE
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_PAYS (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    code_iso    VARCHAR(3)  NOT NULL UNIQUE,
    libelle     VARCHAR(100) NOT NULL,
    code_login  VARCHAR(5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_TYPE_ORGANISATION (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    libelle     VARCHAR(100) NOT NULL UNIQUE,
    code_login  VARCHAR(5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_SEXE (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_SITUATION_MATRIMONIALE (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_LIEN (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_MOYEN_PAIEMENT (
    id      INT AUTO_INCREMENT PRIMARY KEY,
    libelle VARCHAR(100) NOT NULL UNIQUE,
    actif   TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  2. ORGANISATIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_ORGANISATION (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    type_organisation_id INT NOT NULL,
    pays_siege_id        INT NOT NULL,
    nom                  VARCHAR(200) NOT NULL,
    email                VARCHAR(150) UNIQUE,
    telephone            VARCHAR(30),
    adresse              TEXT,
    logo_url             TEXT,
    reglement_interieur_pdf VARCHAR(500),
    numero_immatriculation  VARCHAR(100),
    date_creation        DATE,
    compteur_membres     INT NOT NULL DEFAULT 0,
    acces_actif          TINYINT(1) NOT NULL DEFAULT 0,
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (type_organisation_id) REFERENCES GPOTB_TYPE_ORGANISATION(id),
    FOREIGN KEY (pays_siege_id)        REFERENCES GPOTB_PAYS(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_PAYS_REPRESENTATION (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    pays_id         INT NOT NULL,
    responsable     VARCHAR(200),
    UNIQUE KEY uq_org_pays (organisation_id, pays_id),
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE,
    FOREIGN KEY (pays_id)         REFERENCES GPOTB_PAYS(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  3. ABONNEMENTS SaaS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_PLAN_ABONNEMENT (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    libelle       VARCHAR(100) NOT NULL,
    prix_mensuel  DECIMAL(12,2) NOT NULL DEFAULT 0,
    prix_annuel   DECIMAL(12,2) NOT NULL DEFAULT 0,
    description   TEXT,
    actif         TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_ABONNEMENT_ORGANISATION (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    plan_id         INT NOT NULL,
    periodicite     ENUM('MENSUEL','ANNUEL') NOT NULL,
    date_debut      DATE NOT NULL,
    date_fin        DATE NOT NULL,
    statut          ENUM('ACTIF','EXPIRE','SUSPENDU','EN_ATTENTE') NOT NULL DEFAULT 'EN_ATTENTE',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE,
    FOREIGN KEY (plan_id)         REFERENCES GPOTB_PLAN_ABONNEMENT(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  4. MEMBRES
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_MEMBRE (
    id                        INT AUTO_INCREMENT PRIMARY KEY,
    sexe_id                   INT,
    situation_matrimoniale_id INT,
    pays_id                   INT,
    nom                       VARCHAR(100) NOT NULL,
    prenom                    VARCHAR(100) NOT NULL,
    telephone                 VARCHAR(30) NOT NULL UNIQUE,
    email                     VARCHAR(150) UNIQUE,
    date_naissance            DATE,
    date_inscription          DATE NOT NULL DEFAULT (CURRENT_DATE),
    acces_actif               TINYINT(1) NOT NULL DEFAULT 0,
    created_at                TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sexe_id)                   REFERENCES GPOTB_SEXE(id),
    FOREIGN KEY (situation_matrimoniale_id) REFERENCES GPOTB_SITUATION_MATRIMONIALE(id),
    FOREIGN KEY (pays_id)                   REFERENCES GPOTB_PAYS(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_PAIEMENT_INSCRIPTION (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    membre_id           INT NOT NULL,
    montant             DECIMAL(12,2) NOT NULL,
    moyen_paiement_id   INT,
    reference_operateur VARCHAR(200),
    statut              ENUM('EN_ATTENTE','REUSSI','ECHOUE') NOT NULL DEFAULT 'EN_ATTENTE',
    date_paiement       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (membre_id)         REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (moyen_paiement_id) REFERENCES GPOTB_MOYEN_PAIEMENT(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  5. UTILISATEURS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_UTILISATEUR (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    membre_id          INT UNIQUE,
    login              VARCHAR(100) NOT NULL UNIQUE,
    mot_de_passe_hash  VARCHAR(255) NOT NULL,
    actif              TINYINT(1) NOT NULL DEFAULT 1,
    derniere_connexion TIMESTAMP NULL,
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (membre_id) REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  6. ADHÉSIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_ADHESION (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    membre_id       INT NOT NULL,
    organisation_id INT NOT NULL,
    numero_membre   VARCHAR(50),
    date_debut      DATE NOT NULL DEFAULT (CURRENT_DATE),
    date_fin        DATE,
    statut          ENUM('ACTIF','SUSPENDU','RADIE','EN_ATTENTE') NOT NULL DEFAULT 'EN_ATTENTE',
    UNIQUE KEY uq_membre_org (membre_id, organisation_id),
    FOREIGN KEY (membre_id)       REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  7. POSTES & RÔLES
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_POSTE (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    libelle         VARCHAR(100) NOT NULL,
    permissions     JSON,
    UNIQUE KEY uq_org_poste (organisation_id, libelle),
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_MEMBRE_POSTE (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    membre_id       INT NOT NULL,
    poste_id        INT NOT NULL,
    organisation_id INT NOT NULL,
    date_debut      DATE NOT NULL DEFAULT (CURRENT_DATE),
    date_fin        DATE,
    actif           TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (membre_id)       REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (poste_id)        REFERENCES GPOTB_POSTE(id)  ON DELETE CASCADE,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  8. LIENS & AYANTS DROIT
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_LIEN_MEMBRE (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    membre_id      INT NOT NULL,
    membre_lie_id  INT NOT NULL,
    lien_id        INT NOT NULL,
    UNIQUE KEY uq_lien (membre_id, membre_lie_id, lien_id),
    FOREIGN KEY (membre_id)     REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (membre_lie_id) REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (lien_id)       REFERENCES GPOTB_LIEN(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_AYANT_DROIT (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    membre_id   INT NOT NULL,
    lien_id     INT NOT NULL,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100) NOT NULL,
    telephone   VARCHAR(30),
    pourcentage DECIMAL(5,2) NOT NULL DEFAULT 0
                CHECK (pourcentage >= 0 AND pourcentage <= 100),
    FOREIGN KEY (membre_id) REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE,
    FOREIGN KEY (lien_id)   REFERENCES GPOTB_LIEN(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  9. ÉVÉNEMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_EVENEMENT (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    titre           VARCHAR(200) NOT NULL,
    type_evenement  ENUM('NAISSANCE','MARIAGE','DECES','SINISTRE','AUTRE') NOT NULL DEFAULT 'AUTRE',
    description     TEXT,
    date_debut      DATE,
    date_fin        DATE,
    lieu            VARCHAR(200),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  10. TONTINES
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_TONTINE (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    titre           VARCHAR(200) NOT NULL,
    montant_mise    DECIMAL(12,2) NOT NULL,
    frequence       ENUM('HEBDOMADAIRE','MENSUEL','TRIMESTRIEL') NOT NULL DEFAULT 'MENSUEL',
    statut          ENUM('EN_ATTENTE','EN_COURS','TERMINE') NOT NULL DEFAULT 'EN_ATTENTE',
    date_debut      DATE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS GPOTB_TONTINE_MEMBRE (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    tontine_id    INT NOT NULL,
    membre_id     INT NOT NULL,
    ordre_gain    INT,
    date_adhesion DATE NOT NULL DEFAULT (CURRENT_DATE),
    UNIQUE KEY uq_tontine_membre (tontine_id, membre_id),
    FOREIGN KEY (tontine_id) REFERENCES GPOTB_TONTINE(id) ON DELETE CASCADE,
    FOREIGN KEY (membre_id)  REFERENCES GPOTB_MEMBRE(id)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  11. CAMPAGNES ÉVÉNEMENTIELLES
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_CAMPAGNE_EVENEMENT (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id    INT NOT NULL,
    membre_concerne_id INT,
    titre              VARCHAR(200) NOT NULL,
    type_evenement     ENUM('NAISSANCE','MARIAGE','DECES','SINISTRE','AUTRE') NOT NULL,
    description        TEXT,
    montant_objectif   DECIMAL(12,2),
    statut             ENUM('OUVERTE','FERMEE','ANNULEE') NOT NULL DEFAULT 'OUVERTE',
    created_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id)    REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE,
    FOREIGN KEY (membre_concerne_id) REFERENCES GPOTB_MEMBRE(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  12. OPPORTUNITÉS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_OPPORTUNITE (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id INT NOT NULL,
    titre           VARCHAR(200) NOT NULL,
    type            ENUM('FINANCEMENT','SUBVENTION','PARTENARIAT') NOT NULL,
    description     TEXT,
    statut          ENUM('PUBLIEE','FERMEE','ANNULEE') NOT NULL DEFAULT 'PUBLIEE',
    date_expiration DATE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id) REFERENCES GPOTB_ORGANISATION(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  13. NOTIFICATIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_NOTIFICATION (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    membre_id    INT NOT NULL,
    canal        ENUM('SMS','EMAIL','WHATSAPP') NOT NULL,
    destinataire VARCHAR(200) NOT NULL,
    objet        VARCHAR(200),
    message      TEXT NOT NULL,
    statut       ENUM('EN_ATTENTE','ENVOYE','ECHEC') NOT NULL DEFAULT 'EN_ATTENTE',
    date_envoi   TIMESTAMP NULL,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (membre_id) REFERENCES GPOTB_MEMBRE(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  14. TRANSACTIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS GPOTB_TRANSACTION (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    organisation_id     INT,
    membre_id           INT,
    moyen_paiement_id   INT,
    tontine_id          INT,
    campagne_id         INT,
    abonnement_id       INT,
    montant             DECIMAL(12,2) NOT NULL,
    type_flux           ENUM('COTISATION_EVENEMENT','MISE_TONTINE','GAIN_TONTINE',
                             'ALLOCATION_SECOURS','ABONNEMENT_ORGANISATION',
                             'INSCRIPTION_MEMBRE','DON') NOT NULL,
    reference_operateur VARCHAR(200),
    statut_paiement     ENUM('EN_ATTENTE','REUSSI','ECHOUE') NOT NULL DEFAULT 'EN_ATTENTE',
    date_transaction    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (organisation_id)   REFERENCES GPOTB_ORGANISATION(id),
    FOREIGN KEY (membre_id)         REFERENCES GPOTB_MEMBRE(id),
    FOREIGN KEY (moyen_paiement_id) REFERENCES GPOTB_MOYEN_PAIEMENT(id),
    FOREIGN KEY (tontine_id)        REFERENCES GPOTB_TONTINE(id),
    FOREIGN KEY (campagne_id)       REFERENCES GPOTB_CAMPAGNE_EVENEMENT(id),
    FOREIGN KEY (abonnement_id)     REFERENCES GPOTB_ABONNEMENT_ORGANISATION(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
--  15. INDEX DE PERFORMANCE
-- ============================================================

CREATE INDEX idx_adhesion_membre        ON GPOTB_ADHESION(membre_id);
CREATE INDEX idx_adhesion_organisation  ON GPOTB_ADHESION(organisation_id);
CREATE INDEX idx_membre_poste_membre    ON GPOTB_MEMBRE_POSTE(membre_id);
CREATE INDEX idx_transaction_membre     ON GPOTB_TRANSACTION(membre_id);
CREATE INDEX idx_transaction_org        ON GPOTB_TRANSACTION(organisation_id);
CREATE INDEX idx_notification_statut    ON GPOTB_NOTIFICATION(statut);

-- ============================================================
--  16. DONNÉES DE BASE
-- ============================================================

INSERT IGNORE INTO GPOTB_SEXE (libelle) VALUES ('Masculin'), ('Féminin'), ('Autre');

INSERT IGNORE INTO GPOTB_SITUATION_MATRIMONIALE (libelle) VALUES
    ('Célibataire'), ('Marié(e)'), ('Divorcé(e)'), ('Veuf/Veuve'), ('Union libre');

INSERT IGNORE INTO GPOTB_LIEN (libelle) VALUES
    ('Conjoint(e)'), ('Père'), ('Mère'), ('Fils'), ('Fille'),
    ('Frère'), ('Sœur'), ('Grand-père'), ('Grand-mère'), ('Autre');

INSERT IGNORE INTO GPOTB_MOYEN_PAIEMENT (libelle) VALUES
    ('Mobile Money'), ('Orange Money'), ('Wave'), ('MTN Money'),
    ('Moov Money'), ('Carte bancaire'), ('Espèces'), ('Virement');

INSERT IGNORE INTO GPOTB_TYPE_ORGANISATION (libelle, code_login) VALUES
    ('Mutuelle',    'MUT'),
    ('Association', 'ASS'),
    ('ONG',         'ONG');

INSERT IGNORE INTO GPOTB_PAYS (code_iso, libelle, code_login) VALUES
    ('CIV', "Côte d'Ivoire", 'Civ'),
    ('MLI', 'Mali',          'Mal'),
    ('BFA', 'Burkina Faso',  'Bfa'),
    ('BEN', 'Bénin',         'Ben'),
    ('MDG', 'Madagascar',    'Mdg'),
    ('NGA', 'Nigeria',       'Nga');

INSERT IGNORE INTO GPOTB_PLAN_ABONNEMENT (libelle, prix_mensuel, prix_annuel, description) VALUES
    ('Starter', 5000,   50000,  "Jusqu'à 50 membres"),
    ('Pro',     15000,  150000, "Jusqu'à 500 membres"),
    ('Premium', 30000,  300000, 'Membres illimités');

-- Organisations de test
INSERT IGNORE INTO GPOTB_ORGANISATION (id, type_organisation_id, pays_siege_id, nom, email, acces_actif, compteur_membres) VALUES
    (1, 1, 1, 'Mutuelle Solidarité Abidjan',   'contact@msa.ci',   1, 0),
    (2, 2, 1, 'Association des Femmes Leaders', 'contact@afl.ci',   1, 0),
    (3, 3, 1, 'ONG Jeunesse Active Sénégal',   'contact@ojas.sn',  1, 0);

