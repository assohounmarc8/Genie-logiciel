<?php
// ============================================================
//  MONASSO — app/login.php
//  Page de connexion de l'application web privée
// ============================================================
require_once '../config.php';
session_start();

// Déjà connecté → rediriger vers le bon dashboard
if (!empty($_SESSION['membre_id'])) {
    header('Location: dashboard.php');
    exit;
}

$erreur = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $mdp   = trim($_POST['password'] ?? '');

    if (!$login || !$mdp) {
        $erreur = 'Veuillez renseigner votre identifiant et votre mot de passe.';
    } else {
        try {
            $db = getDB();

            // Récupérer l'GPOTB_UTILISATEUR + infos GPOTB_MEMBRE + GPOTB_POSTE actif
            $stmt = $db->prepare("
                SELECT
                    u.id             AS user_id,
                    u.mot_de_passe_hash,
                    u.actif,
                    m.id             AS membre_id,
                    m.nom,
                    m.prenom,
                    m.acces_actif
                FROM GPOTB_UTILISATEUR u
                JOIN GPOTB_MEMBRE m ON m.id = u.membre_id
                WHERE u.login = ?
                LIMIT 1
            ");
            $stmt->execute([$login]);
            $user = $stmt->fetch();

            if (!$user) {
                $erreur = 'Identifiant ou mot de passe incorrect.';
            } elseif (!$user['actif'] || !$user['acces_actif']) {
                $erreur = 'Votre compte est inactif. Contactez votre organisation.';
            } elseif (!password_verify($mdp, $user['mot_de_passe_hash'])) {
                $erreur = 'Identifiant ou mot de passe incorrect.';
            } else {
                // Récupérer le GPOTB_POSTE actif du GPOTB_MEMBRE (pour choisir le dashboard)
                $stmt2 = $db->prepare("
                    SELECT
                        p.libelle        AS GPOTB_POSTE,
                        mp.organisation_id,
                        o.nom            AS org_nom,
                        t.libelle        AS org_type,
                        t.code_login     AS org_code
                    FROM GPOTB_MEMBRE_POSTE mp
                    JOIN GPOTB_POSTE p              ON p.id  = mp.poste_id
                    JOIN GPOTB_ORGANISATION o       ON o.id  = mp.organisation_id
                    JOIN GPOTB_TYPE_ORGANISATION t  ON t.id  = o.type_organisation_id
                    WHERE mp.membre_id = ?
                      AND mp.actif = 1
                      AND (mp.date_fin IS NULL OR mp.date_fin >= CURDATE())
                    ORDER BY mp.date_debut DESC
                    LIMIT 1
                ");
                $stmt2->execute([$user['membre_id']]);
                $GPOTB_POSTE = $stmt2->fetch();

                // Mettre à jour la dernière connexion
                $db->prepare("
                    UPDATE GPOTB_UTILISATEUR SET derniere_connexion = NOW() WHERE id = ?
                ")->execute([$user['user_id']]);

                // Stocker la session
                session_regenerate_id(true);
                $_SESSION['membre_id']   = $user['membre_id'];
                $_SESSION['user_id']     = $user['user_id'];
                $_SESSION['nom']         = $user['nom'];
                $_SESSION['prenom']      = $user['prenom'];
                $_SESSION['login']       = $login;
                $_SESSION['GPOTB_POSTE']       = $GPOTB_POSTE['GPOTB_POSTE']        ?? null;
                $_SESSION['org_id']      = $GPOTB_POSTE['organisation_id'] ?? null;
                $_SESSION['org_nom']     = $GPOTB_POSTE['org_nom']      ?? null;
                $_SESSION['org_type']    = $GPOTB_POSTE['org_type']     ?? null;
                $_SESSION['premiere_connexion'] = str_contains(
                    $user['mot_de_passe_hash'], '$2y$'
                ) && strlen($mdp) === 8; // mot de passe temporaire probable

                header('Location: dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            $erreur = 'Erreur serveur. Veuillez réessayer.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Connexion — MonAsso</title>
  <link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="login.css"/>
</head>
<body>

<div class="login-page">

  <!-- ===== PANNEAU GAUCHE ===== -->
  <div class="panel-left">
    <div class="panel-top">
      <div class="logo-wrap">
        <img src="../assets/img/logo-white.svg" alt="MonAsso" height="36" class="logo-img"/>
      </div>
      <p class="panel-sub">Votre espace de gestion associative,<br>sécurisé et disponible partout.</p>
    </div>
    <ul class="feat-list">
      <li><i class="ti ti-users"></i> Gérez vos membres et cotisations</li>
      <li><i class="ti ti-refresh"></i> Suivez vos tontines en temps réel</li>
      <li><i class="ti ti-calendar-event"></i> Organisez événements et campagnes</li>
      <li><i class="ti ti-trophy"></i> Publiez vos opportunités</li>
      <li><i class="ti ti-shield-check"></i> Accès sécurisé selon votre rôle</li>
    </ul>
    <p class="panel-copy">© <?= date('Y') ?> MonAsso. Tous droits réservés.</p>
  </div>

  <!-- ===== PANNEAU DROIT ===== -->
  <div class="panel-right">
    <div class="form-box">

      <div class="form-header">
        <h1>Connexion à votre espace</h1>
        <p>Utilisez les identifiants reçus par SMS et Email lors de votre inscription.</p>
      </div>

      <?php if ($erreur): ?>
      <div class="alert alert-error">
        <i class="ti ti-alert-circle"></i>
        <?= htmlspecialchars($erreur) ?>
      </div>
      <?php endif; ?>

      <form method="POST" action="login.php" novalidate>

        <div class="fg">
          <label for="login">Identifiant</label>
          <div class="input-wrap">
            <i class="ti ti-id-badge"></i>
            <input
              type="text"
              id="login"
              name="login"
              placeholder="Ex : CivMUT001"
              value="<?= htmlspecialchars($_POST['login'] ?? '') ?>"
              autocomplete="username"
              autocapitalize="none"
              autocorrect="off"
              spellcheck="false"
              class="mono-input"
              required
            />
          </div>
        </div>

        <div class="fg">
          <label for="password">Mot de passe</label>
          <div class="input-wrap">
            <i class="ti ti-lock"></i>
            <input
              type="password"
              id="password"
              name="password"
              placeholder="Votre mot de passe"
              autocomplete="current-password"
              required
            />
            <button type="button" class="toggle-pwd" id="toggle-pwd" aria-label="Afficher le mot de passe">
              <i class="ti ti-eye" id="eye-icon"></i>
            </button>
          </div>
        </div>

        <div class="forgot-row">
          <a href="mot-de-passe-oublie.php" class="forgot-link">Mot de passe oublié ?</a>
        </div>

        <button type="submit" class="btn-login">
          <i class="ti ti-login"></i> Se connecter
        </button>

      </form>

      <div class="divider"><span>ou</span></div>

      <p class="register-link">
        Pas encore membre ?
        <a href="<?= SITE_URL ?>/#adherer">Adhérer maintenant →</a>
      </p>

    </div>
  </div>

</div>

<script>
// Afficher / masquer le mot de passe
document.getElementById('toggle-pwd').addEventListener('click', function () {
  const input = document.getElementById('password');
  const icon  = document.getElementById('eye-icon');
  if (input.type === 'password') {
    input.type = 'text';
    icon.className = 'ti ti-eye-off';
    this.setAttribute('aria-label', 'Masquer le mot de passe');
  } else {
    input.type = 'password';
    icon.className = 'ti ti-eye';
    this.setAttribute('aria-label', 'Afficher le mot de passe');
  }
});

// Mettre le login en majuscules automatiquement
document.getElementById('login').addEventListener('input', function () {
  const pos = this.selectionStart;
  this.value = this.value.toUpperCase();
  this.setSelectionRange(pos, pos);
});
</script>

</body>
</html>

