<?php
// ============================================================
//  MONASSO — app/changer-mot-de-passe.php
// ============================================================
require_once 'auth.php';

$premiere = !empty($_GET['premiere']);
$erreur   = '';
$succes   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ancien   = $_POST['ancien']   ?? '';
    $nouveau  = $_POST['nouveau']  ?? '';
    $confirme = $_POST['confirme'] ?? '';

    if (!$ancien || !$nouveau || !$confirme) {
        $erreur = 'Tous les champs sont obligatoires.';
    } elseif (strlen($nouveau) < 8) {
        $erreur = 'Le mot de passe doit contenir au moins 8 caractères.';
    } elseif ($nouveau !== $confirme) {
        $erreur = 'Les deux mots de passe ne correspondent pas.';
    } else {
        try {
            $db   = getDB();
            $stmt = $db->prepare("SELECT mot_de_passe_hash FROM GPOTB_UTILISATEUR WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $hash = $stmt->fetchColumn();

            if (!password_verify($ancien, $hash)) {
                $erreur = 'L\'ancien mot de passe est incorrect.';
            } else {
                $nouveau_hash = password_hash($nouveau, PASSWORD_BCRYPT);
                $db->prepare("UPDATE GPOTB_UTILISATEUR SET mot_de_passe_hash = ? WHERE id = ?")
                   ->execute([$nouveau_hash, $_SESSION['user_id']]);

                unset($_SESSION['premiere_connexion']);
                $succes = true;

                // Rediriger après 2 secondes
                header('refresh:2;url=' . getDashboardUrl());
            }
        } catch (Exception $e) {
            $erreur = 'Erreur serveur. Veuillez réessayer.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Changer mon mot de passe — MonAsso</title>
  <link rel="icon" type="image/svg+xml" href="../assets/img/favicon.svg"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="login.css"/>
  <style>
    .mdp-box { width: 100%; max-width: 420px; }
    .mdp-icon { width: 56px; height: 56px; border-radius: 50%; background: #E1F5EE; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; }
    .mdp-icon i { font-size: 28px; color: #1D9E75; }
    .mdp-box h1 { text-align: center; font-size: 20px; font-weight: 700; margin-bottom: 6px; }
    .mdp-box > p { text-align: center; font-size: 13px; color: #6b7280; margin-bottom: 28px; line-height: 1.6; }
    .alert-success { background: #E1F5EE; color: #085041; }
    .strength-bar { height: 4px; border-radius: 2px; background: #e5e7eb; margin-top: 6px; overflow: hidden; }
    .strength-fill { height: 100%; width: 0; border-radius: 2px; transition: width .3s, background .3s; }
  </style>
</head>
<body>
<div class="login-page">

  <div class="panel-left">
    <div class="panel-top">
      <img src="../assets/img/logo-white.svg" alt="MonAsso" height="36"/>
    </div>
    <ul class="feat-list">
      <li><i class="ti ti-lock"></i> Sécurisez votre compte</li>
      <li><i class="ti ti-shield-check"></i> Choisissez un mot de passe fort</li>
      <li><i class="ti ti-eye-off"></i> Ne le partagez jamais</li>
    </ul>
    <p class="panel-copy">© <?= date('Y') ?> MonAsso.</p>
  </div>

  <div class="panel-right">
    <div class="mdp-box">
      <div class="mdp-icon"><i class="ti ti-lock"></i></div>
      <h1><?= $premiere ? 'Créez votre mot de passe' : 'Changer mon mot de passe' ?></h1>
      <p><?= $premiere
        ? 'Bienvenue ! Pour sécuriser votre compte, veuillez choisir un nouveau mot de passe personnel.'
        : 'Renseignez votre ancien mot de passe puis choisissez-en un nouveau.' ?>
      </p>

      <?php if ($erreur): ?>
      <div class="alert alert-error"><i class="ti ti-alert-circle"></i> <?= htmlspecialchars($erreur) ?></div>
      <?php endif; ?>

      <?php if ($succes): ?>
      <div class="alert alert-success"><i class="ti ti-circle-check"></i> Mot de passe modifié avec succès ! Redirection en cours…</div>
      <?php else: ?>

      <form method="POST">
        <div class="fg">
          <label>Mot de passe <?= $premiere ? 'temporaire' : 'actuel' ?></label>
          <div class="input-wrap">
            <i class="ti ti-lock"></i>
            <input type="password" name="ancien" placeholder="Votre mot de passe actuel" required/>
          </div>
        </div>
        <div class="fg">
          <label>Nouveau mot de passe</label>
          <div class="input-wrap">
            <i class="ti ti-lock-open"></i>
            <input type="password" name="nouveau" id="nouveau" placeholder="8 caractères minimum" required minlength="8" oninput="majForce(this.value)"/>
          </div>
          <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
        </div>
        <div class="fg">
          <label>Confirmer le nouveau mot de passe</label>
          <div class="input-wrap">
            <i class="ti ti-lock-open"></i>
            <input type="password" name="confirme" placeholder="Répétez le mot de passe" required/>
          </div>
        </div>
        <button type="submit" class="btn-login">
          <i class="ti ti-check"></i> Valider mon mot de passe
        </button>
      </form>

      <?php if (!$premiere): ?>
      <div class="divider"><span>ou</span></div>
      <p style="text-align:center; font-size:13px;">
        <a href="<?= getDashboardUrl() ?>" style="color:#1D9E75;">← Retour au tableau de bord</a>
      </p>
      <?php endif; ?>

      <?php endif; ?>
    </div>
  </div>

</div>
<script>
function majForce(val) {
  let score = 0;
  if (val.length >= 8)  score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;
  const fill   = document.getElementById('strength-fill');
  const colors = ['#ef4444','#f97316','#eab308','#1D9E75'];
  fill.style.width      = (score * 25) + '%';
  fill.style.background = colors[score - 1] || '#e5e7eb';
}
</script>
</body>
</html>

