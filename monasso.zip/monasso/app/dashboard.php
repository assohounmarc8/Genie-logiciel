<?php
// ============================================================
//  MONASSO — app/dashboard.php
//  Routeur central — redirige vers le bon dashboard selon le GPOTB_POSTE
// ============================================================
require_once 'auth.php';

// Si c'est la première connexion (mot de passe temporaire) → forcer changement
if (!empty($_SESSION['premiere_connexion'])) {
    header('Location: changer-mot-de-passe.php?premiere=1');
    exit;
}

// Redirection vers le dashboard approprié
header('Location: ' . getDashboardUrl());
exit;

