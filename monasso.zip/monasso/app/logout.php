<?php
// ============================================================
//  MONASSO — app/logout.php
// ============================================================
session_start();
session_destroy();
header('Location: login.php?deconnecte=1');
exit;
