<?php
// ============================================================
//  MONASSO — app/auth.php
//  Garde de session — inclure en haut de chaque page privée
// ============================================================
require_once '../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Non connecté → rediriger vers login
if (empty($_SESSION['membre_id'])) {
    header('Location: login.php');
    exit;
}

// Fonctions utilitaires de session
function getMembreId(): int {
    return (int) $_SESSION['membre_id'];
}

function getMembreNom(): string {
    return $_SESSION['prenom'] . ' ' . $_SESSION['nom'];
}

function getLogin(): string {
    return $_SESSION['login'] ?? '';
}

function getPoste(): ?string {
    return $_SESSION['GPOTB_POSTE'] ?? null;
}

function getOrgId(): ?int {
    return isset($_SESSION['org_id']) ? (int) $_SESSION['org_id'] : null;
}

function getOrgNom(): string {
    return $_SESSION['org_nom'] ?? 'MonAsso';
}

function estSuperAdmin(): bool {
    return ($_SESSION['GPOTB_POSTE'] ?? '') === 'Super-admin';
}

function estPresident(): bool {
    return in_array($_SESSION['GPOTB_POSTE'] ?? '', ['Président', 'Directeur', 'Président / Directeur']);
}

function estTresorier(): bool {
    return in_array($_SESSION['GPOTB_POSTE'] ?? '', ['Trésorier', 'Comptable', 'Trésorier / Comptable']);
}

function estSecretaire(): bool {
    return in_array($_SESSION['GPOTB_POSTE'] ?? '', ['Secrétaire', 'Secrétaire général']);
}

function estControleur(): bool {
    return in_array($_SESSION['GPOTB_POSTE'] ?? '', ['Contrôleur', 'Auditeur', 'Contrôleur / Auditeur']);
}

function estAdherentSimple(): bool {
    return empty($_SESSION['GPOTB_POSTE']);
}

// Rediriger vers le bon dashboard selon le GPOTB_POSTE
function getDashboardUrl(): string {
    $GPOTB_POSTE = $_SESSION['GPOTB_POSTE'] ?? null;
    return match(true) {
        estSuperAdmin()   => 'dashboard-superadmin.php',
        estPresident()    => 'dashboard-president.php',
        estTresorier()    => 'dashboard-tresorier.php',
        estSecretaire()   => 'dashboard-secretaire.php',
        estControleur()   => 'dashboard-controleur.php',
        default           => 'dashboard-adherent.php',
    };
}

