<?php

function enregistrerReglementPdf(array $file): array
{
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['ok' => false, 'message' => 'Fichier invalide.'];
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        return ['ok' => false, 'message' => 'Le règlement intérieur (PDF) est obligatoire.'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['ok' => false, 'message' => 'Erreur lors du transfert du fichier PDF.'];
    }

    if ($file['size'] > UPLOAD_REGLEMENT_MAX_BYTES) {
        return ['ok' => false, 'message' => 'Le PDF ne doit pas dépasser 5 Mo.'];
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime  = $finfo->file($file['tmp_name']);

    if ($mime !== 'application/pdf') {
        return ['ok' => false, 'message' => 'Seuls les fichiers PDF sont acceptés.'];
    }

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($ext !== 'pdf') {
        return ['ok' => false, 'message' => 'Seuls les fichiers PDF sont acceptés.'];
    }

    if (!is_dir(UPLOAD_REGLEMENT_DIR)) {
        if (!mkdir(UPLOAD_REGLEMENT_DIR, 0755, true) && !is_dir(UPLOAD_REGLEMENT_DIR)) {
            return ['ok' => false, 'message' => 'Impossible de créer le dossier d\'upload.'];
        }
    }

    $filename = 'reglement_' . date('Ymd_His') . '_' . bin2hex(random_bytes(8)) . '.pdf';
    $destPath = UPLOAD_REGLEMENT_DIR . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $destPath)) {
        return ['ok' => false, 'message' => 'Impossible de sauvegarder le PDF.'];
    }

    return [
        'ok'       => true,
        'path'     => 'uploads/reglements/' . $filename,
        'filename' => $filename,
    ];
}

function mapperTypeOrganisation(string $libelle): string
{
    $map = [
        'Entreprise / Société'          => 'Association',
        'ONG / Association existante'   => 'ONG',
        'Collectivité / Institution'    => 'Association',
    ];

    return $map[$libelle] ?? 'Association';
}
