<?php
// ============================================================
//  MONASSO — libs/mailer.php
//  Service d'envoi d'emails via PHPMailer + Gmail SMTP
// ============================================================
require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Envoie un email HTML via Gmail SMTP
 *
 * @param string $to_email     Adresse email du destinataire
 * @param string $to_name      Nom du destinataire
 * @param string $sujet        Sujet de l'email
 * @param string $corps_html   Corps HTML de l'email
 * @return bool                true si envoi réussi, false sinon
 */
function envoyerEmail(string $to_email, string $to_name, string $sujet, string $corps_html): bool {
    $mail = new PHPMailer(true);
    try {
        // Serveur SMTP
        $mail->isSMTP();
        $mail->Host        = MAIL_HOST;
        $mail->SMTPAuth    = true;
        $mail->Username    = MAIL_USERNAME;
        $mail->Password    = MAIL_PASSWORD;
        $mail->SMTPSecure  = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port        = MAIL_PORT;
        $mail->CharSet     = 'UTF-8';

        // Expéditeur & destinataire
        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($to_email, $to_name);
        $mail->addReplyTo(MAIL_FROM, MAIL_FROM_NAME);

        // Contenu
        $mail->isHTML(true);
        $mail->Subject = $sujet;
        $mail->Body    = $corps_html;
        $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '</p>'], "\n", $corps_html));

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('[MonAsso] Erreur email : ' . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Génère le template HTML de l'email de bienvenue
 * Envoyé après inscription réussie (personne physique ou morale)
 */
function templateBienvenue(
    string $prenom,
    string $nom,
    string $login,
    string $mdp_temp,
    string $org_nom,
    string $type_compte  // 'physique' ou 'morale'
): string {
    $app_url    = APP_URL . '/login.php';
    $annee      = date('Y');
    $salutation = $type_compte === 'morale'
        ? "Représentant(e) de <strong>" . htmlspecialchars($nom) . "</strong>"
        : htmlspecialchars($prenom) . " " . htmlspecialchars($nom);

    return <<<HTML
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Bienvenue sur MonAsso</title>
</head>
<body style="margin:0;padding:0;background:#f9fafb;font-family:'Segoe UI',Arial,sans-serif;">

  <!-- Wrapper -->
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e5e7eb;">

          <!-- HEADER -->
          <tr>
            <td style="background:#085041;padding:32px 40px;text-align:center;">
              <table cellpadding="0" cellspacing="0" style="margin:0 auto;">
                <tr>
                  <td style="background:rgba(255,255,255,.15);border-radius:10px;padding:10px 14px;">
                    <span style="font-size:22px;font-weight:700;color:#ffffff;letter-spacing:.5px;">
                      Mon<span style="color:#9FE1CB;">Asso</span>
                    </span>
                  </td>
                </tr>
              </table>
              <p style="margin:14px 0 0;font-size:13px;color:rgba(255,255,255,.6);">
                Associations · Mutuelles · ONG
              </p>
            </td>
          </tr>

          <!-- CORPS -->
          <tr>
            <td style="padding:40px 40px 32px;">

              <!-- Icône succès -->
              <div style="text-align:center;margin-bottom:24px;">
                <div style="width:60px;height:60px;border-radius:50%;background:#E1F5EE;margin:0 auto;display:flex;align-items:center;justify-content:center;font-size:28px;line-height:60px;">
                  ✅
                </div>
              </div>

              <h1 style="font-size:20px;font-weight:700;color:#085041;text-align:center;margin:0 0 8px;">
                Inscription confirmée !
              </h1>
              <p style="font-size:14px;color:#6b7280;text-align:center;margin:0 0 28px;">
                Bienvenue dans <strong style="color:#085041;"><?= htmlspecialchars($org_nom) ?></strong>
              </p>

              <p style="font-size:15px;color:#1a1a1a;margin:0 0 24px;">
                Bonjour <strong><?= $salutation ?></strong>,<br><br>
                Votre adhésion à <strong><?= htmlspecialchars($org_nom) ?></strong> a été validée avec succès.
                Vous trouverez ci-dessous vos identifiants de connexion à votre espace MonAsso.
              </p>

              <!-- Carte identifiants -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0faf6;border:1.5px solid #9FE1CB;border-radius:10px;margin-bottom:28px;">
                <tr>
                  <td style="padding:24px 28px;">
                    <p style="font-size:12px;font-weight:700;color:#0F6E56;text-transform:uppercase;letter-spacing:.07em;margin:0 0 16px;">
                      Vos identifiants de connexion
                    </p>
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="font-size:13px;color:#6b7280;padding:6px 0;width:40%;">Identifiant</td>
                        <td style="font-size:16px;font-weight:700;color:#085041;font-family:monospace;letter-spacing:.1em;padding:6px 0;">
                          <?= htmlspecialchars($login) ?>
                        </td>
                      </tr>
                      <tr>
                        <td colspan="2" style="border-top:1px solid #9FE1CB;padding:0;"></td>
                      </tr>
                      <tr>
                        <td style="font-size:13px;color:#6b7280;padding:6px 0;">Mot de passe</td>
                        <td style="font-size:16px;font-weight:700;color:#085041;font-family:monospace;letter-spacing:.1em;padding:6px 0;">
                          <?= htmlspecialchars($mdp_temp) ?>
                        </td>
                      </tr>
                    </table>
                    <p style="font-size:12px;color:#0F6E56;margin:16px 0 0;line-height:1.6;">
                      ⚠️ Ce mot de passe est <strong>temporaire</strong>. Il vous sera demandé de le modifier lors de votre première connexion.
                    </p>
                  </td>
                </tr>
              </table>

              <!-- Bouton accès app -->
              <div style="text-align:center;margin-bottom:28px;">
                <a href="{$app_url}"
                   style="display:inline-block;background:#1D9E75;color:#ffffff;font-size:15px;font-weight:700;
                          padding:14px 36px;border-radius:10px;text-decoration:none;letter-spacing:.3px;">
                  🔐 Accéder à mon espace MonAsso
                </a>
                <p style="font-size:12px;color:#9ca3af;margin:12px 0 0;">
                  Ou copiez ce lien dans votre navigateur :<br>
                  <a href="{$app_url}" style="color:#1D9E75;word-break:break-all;">{$app_url}</a>
                </p>
              </div>

              <!-- Étapes -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#f9fafb;border-radius:10px;margin-bottom:24px;">
                <tr>
                  <td style="padding:20px 24px;">
                    <p style="font-size:12px;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.07em;margin:0 0 14px;">
                      Comment se connecter ?
                    </p>
                    <table cellpadding="0" cellspacing="0" width="100%">
                      <tr>
                        <td style="vertical-align:top;padding:4px 0;">
                          <span style="background:#1D9E75;color:#fff;border-radius:50%;width:20px;height:20px;display:inline-block;text-align:center;font-size:11px;font-weight:700;line-height:20px;">1</span>
                        </td>
                        <td style="font-size:13px;color:#374151;padding:4px 0 4px 10px;">Cliquez sur le bouton ci-dessus ou accédez à <strong>monasso.ci/app</strong></td>
                      </tr>
                      <tr>
                        <td style="vertical-align:top;padding:4px 0;">
                          <span style="background:#1D9E75;color:#fff;border-radius:50%;width:20px;height:20px;display:inline-block;text-align:center;font-size:11px;font-weight:700;line-height:20px;">2</span>
                        </td>
                        <td style="font-size:13px;color:#374151;padding:4px 0 4px 10px;">Entrez votre identifiant <strong style="font-family:monospace;"><?= htmlspecialchars($login) ?></strong></td>
                      </tr>
                      <tr>
                        <td style="vertical-align:top;padding:4px 0;">
                          <span style="background:#1D9E75;color:#fff;border-radius:50%;width:20px;height:20px;display:inline-block;text-align:center;font-size:11px;font-weight:700;line-height:20px;">3</span>
                        </td>
                        <td style="font-size:13px;color:#374151;padding:4px 0 4px 10px;">Entrez votre mot de passe temporaire et choisissez-en un nouveau</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>

              <p style="font-size:13px;color:#6b7280;line-height:1.7;margin:0;">
                Pour toute question, contactez votre organisation ou écrivez-nous à
                <a href="mailto:<?= MAIL_FROM ?>" style="color:#1D9E75;"><?= MAIL_FROM ?></a>.
              </p>

            </td>
          </tr>

          <!-- FOOTER -->
          <tr>
            <td style="background:#f9fafb;border-top:1px solid #e5e7eb;padding:20px 40px;text-align:center;">
              <p style="font-size:12px;color:#9ca3af;margin:0;">
                © {$annee} MonAsso — Associations · Mutuelles · ONG<br>
                Vous recevez cet email car vous venez de vous inscrire sur MonAsso.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>
HTML;
}
