<?php
// ============================================================
//  MONASSO — don.php (enregistrement des dons)
// ============================================================
require_once 'config.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true) ?? [];

$requis = ['nom', 'tel', 'montant', 'moyen'];
foreach ($requis as $champ) {
    if (empty($input[$champ])) {
        echo json_encode(['success' => false, 'message' => "Champ manquant : $champ"]);
        exit;
    }
}

$montant = (float) $input['montant'];
if ($montant < 100) {
    echo json_encode(['success' => false, 'message' => 'Le montant minimum est de 100 FCFA.']);
    exit;
}

try {
    $db = getDB();

    $stmtMoyen = $db->prepare('SELECT id FROM GPOTB_MOYEN_PAIEMENT WHERE id = ? AND actif = 1');
    $stmtMoyen->execute([(int) $input['moyen']]);
    if (!$stmtMoyen->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Moyen de paiement invalide.']);
        exit;
    }

    $anonyme = !empty($input['anonyme']) ? 1 : 0;

    $db->prepare("
        INSERT INTO GPOTB_DON (nom, telephone, email, montant, moyen_paiement_id, anonyme, statut)
        VALUES (?, ?, ?, ?, ?, ?, 'EN_ATTENTE')
    ")->execute([
        trim($input['nom']),
        trim($input['tel']),
        trim($input['email'] ?? '') ?: null,
        $montant,
        (int) $input['moyen'],
        $anonyme,
    ]);

    echo json_encode(['success' => true, 'message' => 'Don enregistré. Merci pour votre générosité !']);

} catch (Exception $e) {
    error_log('[MonAsso] Erreur don : ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Veuillez réessayer.']);
}
