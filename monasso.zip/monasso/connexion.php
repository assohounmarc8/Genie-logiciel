<?php
// ============================================================
//  MONASSO — connexion.php (page de connexion publique)
// ============================================================
require_once 'config.php';
session_start();

// Déjà connecté → rediriger vers le dashboard
if (!empty($_SESSION['membre_id'])) {
    header('Location: ' . APP_URL . '/dashboard.php');
    exit;
}

$erreur = '';

$moyensPaiement = [];
try {
    $moyensPaiement = getDB()->query(
        "SELECT id, libelle FROM GPOTB_MOYEN_PAIEMENT WHERE actif = 1 ORDER BY id"
    )->fetchAll();
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $mdp   = trim($_POST['password'] ?? '');

    if (!$login || !$mdp) {
        $erreur = 'Veuillez renseigner votre identifiant et votre mot de passe.';
    } else {
        try {
            $db = getDB();

            $stmt = $db->prepare("
                SELECT
                    u.id             AS user_id,
                    u.mot_de_passe_hash,
                    u.actif,
                    m.id             AS membre_id,
                    m.nom,
                    m.prenom,
                    m.acces_actif
                FROM GPOTB_UTILISATEUR u
                JOIN GPOTB_MEMBRE m ON m.id = u.membre_id
                WHERE u.login = ?
                LIMIT 1
            ");
            $stmt->execute([$login]);
            $user = $stmt->fetch();

            if (!$user) {
                $erreur = 'Identifiant ou mot de passe incorrect.';
            } elseif (!$user['actif'] || !$user['acces_actif']) {
                $erreur = 'Votre compte est inactif. Contactez votre organisation.';
            } elseif (!password_verify($mdp, $user['mot_de_passe_hash'])) {
                $erreur = 'Identifiant ou mot de passe incorrect.';
            } else {
                $stmt2 = $db->prepare("
                    SELECT
                        p.libelle        AS GPOTB_POSTE,
                        mp.organisation_id,
                        o.nom            AS org_nom,
                        t.libelle        AS org_type,
                        t.code_login     AS org_code
                    FROM GPOTB_MEMBRE_POSTE mp
                    JOIN GPOTB_POSTE p              ON p.id  = mp.poste_id
                    JOIN GPOTB_ORGANISATION o       ON o.id  = mp.organisation_id
                    JOIN GPOTB_TYPE_ORGANISATION t  ON t.id  = o.type_organisation_id
                    WHERE mp.membre_id = ?
                      AND mp.actif = 1
                      AND (mp.date_fin IS NULL OR mp.date_fin >= CURDATE())
                    ORDER BY mp.date_debut DESC
                    LIMIT 1
                ");
                $stmt2->execute([$user['membre_id']]);
                $GPOTB_POSTE = $stmt2->fetch();

                $db->prepare("
                    UPDATE GPOTB_UTILISATEUR SET derniere_connexion = NOW() WHERE id = ?
                ")->execute([$user['user_id']]);

                session_regenerate_id(true);
                $_SESSION['membre_id']   = $user['membre_id'];
                $_SESSION['user_id']     = $user['user_id'];
                $_SESSION['nom']         = $user['nom'];
                $_SESSION['prenom']      = $user['prenom'];
                $_SESSION['login']       = $login;
                $_SESSION['GPOTB_POSTE'] = $GPOTB_POSTE['GPOTB_POSTE']    ?? null;
                $_SESSION['org_id']      = $GPOTB_POSTE['organisation_id'] ?? null;
                $_SESSION['org_nom']     = $GPOTB_POSTE['org_nom']        ?? null;
                $_SESSION['org_type']    = $GPOTB_POSTE['org_type']       ?? null;
                $_SESSION['premiere_connexion'] = str_contains(
                    $user['mot_de_passe_hash'], '$2y$'
                ) && strlen($mdp) === 8;

                header('Location: ' . APP_URL . '/dashboard.php');
                exit;
            }
        } catch (Exception $e) {
            $erreur = 'Erreur serveur. Veuillez réessayer.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MonAsso — Connexion</title>
  <meta name="description" content="Connectez-vous à votre espace MonAsso."/>
  <link rel="icon" type="image/svg+xml" href="assets/img/favicon.svg"/>
  <link rel="apple-touch-icon" href="assets/img/logo-icon.svg"/>
  <meta name="theme-color" content="#1D9E75"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="style.css?v=<?= filemtime(__DIR__ . '/style.css') ?>"/>
</head>
<body>

<nav class="navbar" id="navbar">
  <div class="container nav-inner">
    <a href="index.php" class="nav-logo">
      <img src="assets/img/logo.svg" alt="MonAsso" height="40" class="logo-img"/>
    </a>
    <div class="nav-links" id="nav-links">
      <a href="index.php#pour-qui">Pour qui ?</a>
      <a href="index.php#comment">Comment ça marche ?</a>
      <a href="adhesion.php" class="btn-main nav-cta">
        <i class="ti ti-user-plus"></i> Adhérer maintenant
      </a>
      <a href="connexion.php" class="btn-main nav-cta">
        <i class="ti ti-login"></i> Se connecter
      </a>
      <a href="#" class="btn-main nav-cta" onclick="ouvrirModalDon(event)">
        <i class="ti ti-heart"></i> Faire un don
      </a>
    </div>
    <button class="burger" id="burger" aria-label="Ouvrir le menu">
      <i class="ti ti-menu-2"></i>
    </button>
  </div>
</nav>

<section class="section-alt" id="connexion">
  <div class="container">
    <h2>Connexion à votre espace</h2>
    <p class="section-sub">Utilisez les identifiants reçus par SMS et Email lors de votre inscription.</p>

    <?php if ($erreur): ?>
    <div class="alert alert-error">
      <i class="ti ti-alert-circle"></i>
      <?= htmlspecialchars($erreur) ?>
    </div>
    <?php endif; ?>

    <div class="form-wrap" style="max-width:440px;">
      <form method="POST" action="connexion.php" novalidate>
        <div class="fg" style="margin-bottom:16px;">
          <label for="login">Identifiant</label>
          <input
            type="text"
            id="login"
            name="login"
            placeholder="Ex : CivMUT001"
            value="<?= htmlspecialchars($_POST['login'] ?? '') ?>"
            autocomplete="username"
            autocapitalize="none"
            autocorrect="off"
            spellcheck="false"
            class="mono"
            required
          />
        </div>

        <div class="fg" style="margin-bottom:20px;">
          <label for="password">Mot de passe</label>
          <input
            type="password"
            id="password"
            name="password"
            placeholder="Votre mot de passe"
            autocomplete="current-password"
            required
          />
        </div>

        <button type="submit" class="btn-main btn-block">
          <i class="ti ti-login"></i> Se connecter
        </button>
      </form>

      <p class="form-note" style="text-align:center; margin-top:18px;">
        Pas encore membre ? <a href="adhesion.php" class="green">Adhérer maintenant</a>
      </p>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="container footer-inner">
    <img src="assets/img/logo-white.svg" alt="MonAsso" height="32" class="logo-img"/>
    <div class="footer-links">
      <a href="#">Mentions légales</a>
      <a href="#">Confidentialité</a>
      <a href="#">Contact</a>
    </div>
    <p>© <?= date('Y') ?> MonAsso. Tous droits réservés.</p>
  </div>
</footer>

<div class="modal-overlay" id="don-overlay">
  <div class="modal-box" id="don-box">
    <button type="button" class="modal-close" onclick="fermerModalDon()" aria-label="Fermer">
      <i class="ti ti-x"></i>
    </button>

    <div id="don-form-wrap">
      <h3><i class="ti ti-heart" style="color:var(--green)"></i> Faire un don</h3>
      <p class="section-sub" style="margin-bottom:20px;">Votre générosité soutient les actions solidaires des organisations MonAsso.</p>

      <div class="fg" style="margin-bottom:14px;">
        <label for="don_montant">Montant (FCFA) *</label>
        <input type="number" id="don_montant" min="100" placeholder="5000"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_nom">Nom *</label>
        <input type="text" id="don_nom" placeholder="KOUASSI Jean"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_tel">Téléphone *</label>
        <input type="tel" id="don_tel" placeholder="+225 07 00 00 00"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_email">Email</label>
        <input type="email" id="don_email" placeholder="jean@email.com"/>
      </div>
      <div class="fg" style="margin-bottom:14px;">
        <label for="don_moyen">Moyen de paiement *</label>
        <select id="don_moyen">
          <option value="">-- Choisir --</option>
          <?php foreach ($moyensPaiement as $mp): ?>
          <option value="<?= $mp['id'] ?>"><?= htmlspecialchars($mp['libelle']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg" style="margin-bottom:18px;">
        <label><input type="checkbox" id="don_anonyme"/> Faire ce don anonymement</label>
      </div>

      <button type="button" class="btn-main btn-block" id="btn-don-valider" onclick="envoyerDon()">
        <i class="ti ti-heart"></i> Confirmer le don
      </button>
    </div>

    <div id="don-confirm" hidden style="text-align:center;">
      <div class="confirm-icon"><i class="ti ti-circle-check"></i></div>
      <h3>Merci pour votre don !</h3>
      <p>Votre générosité fait la différence. Un reçu vous sera envoyé si vous avez renseigné votre email.</p>
      <button type="button" class="btn-main" onclick="fermerModalDon()">Fermer</button>
    </div>
  </div>
</div>

<script src="app.js"></script>
</body>
</html>
