<?php
// ============================================================
//  MONASSO — Site public (index.php)
//  Accueil + Adhésion sur une seule page
// ============================================================
require_once 'config.php';
session_start();

$db           = getDB();
$organisations = [];
$pays          = [];
$sexes         = [];
$situations    = [];

try {
    $organisations = $db->query("
        SELECT o.id, o.nom, t.libelle AS type
        FROM organisation o
        JOIN type_organisation t ON t.id = o.type_organisation_id
        WHERE o.acces_actif = TRUE
        ORDER BY t.libelle, o.nom
    ")->fetchAll();

    $pays = $db->query(
        "SELECT id, libelle, code_login FROM pays ORDER BY libelle"
    )->fetchAll();

    $sexes = $db->query(
        "SELECT id, libelle FROM sexe ORDER BY id"
    )->fetchAll();

    $situations = $db->query(
        "SELECT id, libelle FROM situation_matrimoniale ORDER BY id"
    )->fetchAll();
} catch (Exception $e) {}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MonAsso — Adhérez à votre organisation</title>
  <meta name="description" content="MonAsso : la plateforme de gestion pour associations, mutuelles et ONG d'Afrique de l'Ouest."/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/dist/tabler-icons.min.css"/>
  <link rel="stylesheet" href="style.css"/>
</head>
<body>

<!-- ============================================================
     NAVBAR
============================================================ -->
<nav class="navbar" id="navbar">
  <div class="container nav-inner">
    <a href="#" class="nav-logo">
      <div class="logo-box"><i class="ti ti-building-community"></i></div>
      Mon<span class="green">Asso</span>
    </a>
    <div class="nav-links" id="nav-links">
      <a href="#fonctionnalites">Fonctionnalités</a>
      <a href="#pour-qui">Pour qui ?</a>
      <a href="#comment">Comment ça marche ?</a>
      <a href="#adherer">Adhérer</a>
    </div>
    <a href="#adherer" class="btn-main nav-cta">
      <i class="ti ti-user-plus"></i> Adhérer maintenant
    </a>
    <button class="burger" id="burger" aria-label="Ouvrir le menu">
      <i class="ti ti-menu-2"></i>
    </button>
  </div>
</nav>

<!-- ============================================================
     HERO
============================================================ -->
<section class="hero">
  <div class="container hero-inner">
    <div class="hero-content">
      <div class="badge"><i class="ti ti-star"></i> Associations · Mutuelles · ONG</div>
      <h1>Adhérez à votre organisation,<br><span class="green">gérez tout depuis MonAsso</span></h1>
      <p>Inscrivez-vous en ligne en quelques minutes. Recevez vos identifiants par SMS et Email, puis accédez à l'espace membre pour gérer vos cotisations, tontines et événements.</p>
      <div class="hero-btns">
        <a href="#adherer" class="btn-main"><i class="ti ti-user-plus"></i> Adhérer maintenant</a>
        <a href="#comment" class="btn-outline">Comment ça marche ?</a>
      </div>
      <div class="hero-stats">
        <div class="stat"><span class="stat-num">500+</span><span class="stat-label">Organisations</span></div>
        <div class="stat"><span class="stat-num">12 000+</span><span class="stat-label">Membres actifs</span></div>
        <div class="stat"><span class="stat-num">8 pays</span><span class="stat-label">Afrique de l'Ouest</span></div>
      </div>
    </div>
    <div class="hero-visual">
      <div class="visual-header">
        <div class="avatar-md">JK</div>
        <div>
          <div class="v-name">Jean KOUASSI</div>
          <div class="v-sub">Mutuelle Solidarité Abidjan</div>
        </div>
        <span class="tag-green"><i class="ti ti-check"></i> Actif</span>
      </div>
      <div class="v-row"><span>Identifiant</span><span class="mono green">CivMUT001</span></div>
      <div class="v-row"><span>Cotisation du mois</span><span class="green">Payée ✓</span></div>
      <div class="v-row"><span>Tontine en cours</span><span>Tour 3 / 12</span></div>
      <div class="v-row"><span>Prochain événement</span><span>AG du 30 juin</span></div>
      <div class="v-row last"><span>Ayants droit</span><span>2 enregistrés</span></div>
    </div>
  </div>
</section>

<!-- ============================================================
     FONCTIONNALITÉS
============================================================ -->
<section class="section" id="fonctionnalites">
  <div class="container">
    <h2>Tout ce dont votre organisation a besoin</h2>
    <p class="section-sub">Des outils puissants disponibles dans votre espace MonAsso.</p>
    <div class="feat-grid">
      <?php
      $feats = [
        ['ti-users',          'Gestion des membres',      'Fiches membres, statuts, ayants droit et liens familiaux centralisés.'],
        ['ti-refresh',        'Tontines',                 'Cycles hebdomadaires ou mensuels, suivi des mises et gains automatisé.'],
        ['ti-cash',           'Cotisations & paiements',  'Mobile Money, Wave, Orange Money et carte bancaire intégrés.'],
        ['ti-calendar-event', 'Événements',               'Mariages, naissances, décès — campagnes de solidarité en temps réel.'],
        ['ti-trophy',         'Opportunités',             'Financements, subventions et partenariats publiés pour vos membres.'],
        ['ti-shield-check',   'Sécurité & rôles',         'Interfaces dédiées : Président, Trésorier, Secrétaire, Contrôleur.'],
      ];
      foreach ($feats as [$icon, $title, $desc]): ?>
      <div class="feat-card">
        <div class="feat-icon"><i class="ti <?= $icon ?>"></i></div>
        <div class="feat-title"><?= $title ?></div>
        <p><?= $desc ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ============================================================
     POUR QUI
============================================================ -->
<section class="section-alt" id="pour-qui">
  <div class="container">
    <h2>Pour qui est MonAsso ?</h2>
    <p class="section-sub">Une plateforme adaptée à trois types de structures.</p>
    <div class="org-grid">
      <div class="org-card">
        <div class="org-icon">🤝</div>
        <h3>Mutuelles</h3>
        <p>Gérez les cotisations, remboursements et sinistres de vos adhérents avec rigueur.</p>
      </div>
      <div class="org-card">
        <div class="org-icon">🌿</div>
        <h3>Associations</h3>
        <p>Animez votre communauté et gérez vos membres à travers plusieurs pays.</p>
      </div>
      <div class="org-card">
        <div class="org-icon">🌍</div>
        <h3>ONG</h3>
        <p>Suivez vos bénéficiaires, gérez vos dons et publiez vos opportunités de financement.</p>
      </div>
    </div>
  </div>
</section>

<!-- ============================================================
     COMMENT ÇA MARCHE
============================================================ -->
<section class="section" id="comment">
  <div class="container">
    <h2>Comment ça marche ?</h2>
    <p class="section-sub">Rejoignez MonAsso en 4 étapes simples.</p>
    <div class="how-grid">
      <?php
      $steps = [
        ['Renseignez vos infos',          'Formulaire en ligne en tant que personne physique ou morale.'],
        ['Choisissez votre organisation', 'Sélectionnez la mutuelle, association ou ONG à rejoindre.'],
        ['Payez en ligne',                'Réglez vos frais via Mobile Money, Wave ou carte bancaire.'],
        ['Accédez à votre espace',        'Recevez votre identifiant par SMS et Email, connectez-vous.'],
      ];
      foreach ($steps as $i => [$title, $desc]): ?>
      <div class="how-step">
        <div class="how-num"><?= $i + 1 ?></div>
        <h4><?= $title ?></h4>
        <p><?= $desc ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ============================================================
     FORMULAIRE D'ADHÉSION (page unique — 3 étapes JS)
============================================================ -->
<section class="section-alt" id="adherer">
  <div class="container">
    <h2>Adhérer à une organisation</h2>
    <p class="section-sub">Remplissez le formulaire ci-dessous pour créer votre compte MonAsso.</p>

    <?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?>">
      <i class="ti ti-<?= $flash['type'] === 'success' ? 'circle-check' : 'alert-circle' ?>"></i>
      <?= htmlspecialchars($flash['message']) ?>
    </div>
    <?php endif; ?>

    <!-- STEPPER -->
    <div class="stepper">
      <div class="step active" id="s1"><div class="snum" id="sn1">1</div><span>Informations</span></div>
      <div class="sep" id="sep1"></div>
      <div class="step" id="s2"><div class="snum" id="sn2">2</div><span>Paiement</span></div>
      <div class="sep" id="sep2"></div>
      <div class="step" id="s3"><div class="snum" id="sn3">3</div><span>Confirmation</span></div>
    </div>

    <div class="form-wrap">

      <!-- ===== ÉTAPE 1 : INFORMATIONS ===== -->
      <div class="panel active" id="p1">

        <!-- Switch physique / morale -->
        <div class="type-switch">
          <button type="button" class="type-btn active" id="btn-phys" onclick="switchType('physique')">
            <i class="ti ti-user"></i>
            <div><strong>Personne physique</strong><small>Particulier, individu</small></div>
          </button>
          <button type="button" class="type-btn" id="btn-moral" onclick="switchType('morale')">
            <i class="ti ti-building"></i>
            <div><strong>Personne morale</strong><small>Entreprise, ONG, institution</small></div>
          </button>
        </div>

        <!-- ---- Formulaire Personne Physique ---- -->
        <div id="form-physique">
          <p class="form-label-section">Informations personnelles</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pp_nom">Nom *</label>
              <input type="text" id="pp_nom" placeholder="KOUASSI" autocomplete="family-name"/>
            </div>
            <div class="fg">
              <label for="pp_prenom">Prénom *</label>
              <input type="text" id="pp_prenom" placeholder="Jean" autocomplete="given-name"/>
            </div>
            <div class="fg">
              <label for="pp_sexe">Sexe *</label>
              <select id="pp_sexe">
                <option value="">-- Choisir --</option>
                <?php foreach ($sexes as $s): ?>
                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="fg">
              <label for="pp_situation">Situation matrimoniale *</label>
              <select id="pp_situation">
                <option value="">-- Choisir --</option>
                <?php foreach ($situations as $sit): ?>
                <option value="<?= $sit['id'] ?>"><?= htmlspecialchars($sit['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="fg">
              <label for="pp_naissance">Date de naissance *</label>
              <input type="date" id="pp_naissance"/>
            </div>
            <div class="fg">
              <label for="pp_pays">Pays *</label>
              <select id="pp_pays">
                <option value="">-- Choisir --</option>
                <?php foreach ($pays as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <p class="form-label-section">Coordonnées</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pp_tel">Téléphone *</label>
              <input type="tel" id="pp_tel" placeholder="+225 07 00 00 00" autocomplete="tel"/>
            </div>
            <div class="fg">
              <label for="pp_email">Email</label>
              <input type="email" id="pp_email" placeholder="jean@email.com" autocomplete="email"/>
            </div>
            <div class="fg full">
              <label for="pp_adresse">Adresse</label>
              <input type="text" id="pp_adresse" placeholder="Cocody, Abidjan"/>
            </div>
          </div>
        </div>

        <!-- ---- Formulaire Personne Morale ---- -->
        <div id="form-morale" style="display:none;">
          <p class="form-label-section">Informations de la structure</p>
          <div class="form-grid">
            <div class="fg full">
              <label for="pm_raison">Raison sociale *</label>
              <input type="text" id="pm_raison" placeholder="SARL Kouassi & Associés"/>
            </div>
            <div class="fg">
              <label for="pm_type_struct">Type de structure *</label>
              <select id="pm_type_struct">
                <option value="">-- Choisir --</option>
                <option>Entreprise / Société</option>
                <option>ONG / Association existante</option>
                <option>Collectivité / Institution</option>
              </select>
            </div>
            <div class="fg">
              <label for="pm_immat">N° d'immatriculation *</label>
              <input type="text" id="pm_immat" placeholder="CI-ABJ-2020-B-00123"/>
            </div>
            <div class="fg">
              <label for="pm_date_creation">Date de création</label>
              <input type="date" id="pm_date_creation"/>
            </div>
            <div class="fg">
              <label for="pm_pays">Pays du siège *</label>
              <select id="pm_pays">
                <option value="">-- Choisir --</option>
                <?php foreach ($pays as $p): ?>
                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['libelle']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <p class="form-label-section">Représentant légal</p>
          <div class="form-grid">
            <div class="fg">
              <label for="pm_rep_nom">Nom *</label>
              <input type="text" id="pm_rep_nom" placeholder="KOUASSI"/>
            </div>
            <div class="fg">
              <label for="pm_rep_prenom">Prénom *</label>
              <input type="text" id="pm_rep_prenom" placeholder="Jean"/>
            </div>
            <div class="fg">
              <label for="pm_fonction">Fonction *</label>
              <input type="text" id="pm_fonction" placeholder="Directeur Général"/>
            </div>
            <div class="fg">
              <label for="pm_tel">Téléphone *</label>
              <input type="tel" id="pm_tel" placeholder="+225 07 00 00 00"/>
            </div>
            <div class="fg full">
              <label for="pm_email">Email *</label>
              <input type="email" id="pm_email" placeholder="contact@structure.com"/>
            </div>
          </div>
        </div>

        <!-- Organisation -->
        <p class="form-label-section">Organisation à rejoindre</p>
        <div class="form-grid">
          <div class="fg full">
            <label for="organisation_id">Organisation *</label>
            <select id="organisation_id">
              <option value="">-- Sélectionner une organisation --</option>
              <?php foreach ($organisations as $org): ?>
              <option value="<?= $org['id'] ?>"
                      data-type="<?= htmlspecialchars($org['type']) ?>">
                [<?= htmlspecialchars($org['type']) ?>] <?= htmlspecialchars($org['nom']) ?>
              </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="form-actions">
          <span class="form-note">* Champs obligatoires</span>
          <button type="button" class="btn-main" onclick="validerEtape1()">
            Continuer <i class="ti ti-arrow-right"></i>
          </button>
        </div>
      </div><!-- /p1 -->

      <!-- ===== ÉTAPE 2 : PAIEMENT ===== -->
      <div class="panel" id="p2">
        <div class="pay-layout">

          <!-- Gauche : choix paiement -->
          <div>
            <h3 class="pay-title">Moyen de paiement</h3>
            <div class="method-grid">
              <div class="method active" onclick="selMethod(this,'mobile')">
                <i class="ti ti-device-mobile"></i><span>Mobile Money</span>
              </div>
              <div class="method" onclick="selMethod(this,'wave')">
                <i class="ti ti-ripple"></i><span>Wave</span>
              </div>
              <div class="method" onclick="selMethod(this,'orange')">
                <i class="ti ti-phone"></i><span>Orange Money</span>
              </div>
              <div class="method" onclick="selMethod(this,'card')">
                <i class="ti ti-credit-card"></i><span>Carte bancaire</span>
              </div>
            </div>

            <!-- Champs Mobile Money -->
            <div id="fields-mobile">
              <div class="fg">
                <label>Numéro *</label>
                <div class="phone-row">
                  <select id="indicatif">
                    <option value="+225">🇨🇮 +225</option>
                    <option value="+221">🇸🇳 +221</option>
                    <option value="+223">🇲🇱 +223</option>
                    <option value="+226">🇧🇫 +226</option>
                    <option value="+228">🇹🇬 +228</option>
                    <option value="+229">🇧🇯 +229</option>
                    <option value="+233">🇬🇭 +233</option>
                  </select>
                  <input type="tel" id="numero_mobile" placeholder="07 00 00 00 00"/>
                </div>
              </div>
              <div class="info-box">
                <i class="ti ti-info-circle"></i>
                Vous recevrez une demande de confirmation sur votre téléphone. Validez avec votre code secret pour finaliser.
              </div>
            </div>

            <!-- Champs Carte -->
            <div id="fields-card" style="display:none;">
              <div class="fg" style="margin-bottom:12px;">
                <label>Numéro de carte *</label>
                <input type="text" id="card_num" placeholder="0000 0000 0000 0000" maxlength="19"/>
              </div>
              <div class="fg" style="margin-bottom:12px;">
                <label>Titulaire *</label>
                <input type="text" id="card_holder" placeholder="KOUASSI Jean"/>
              </div>
              <div class="form-grid">
                <div class="fg"><label>Expiration *</label><input type="text" id="card_exp" placeholder="MM / AA"/></div>
                <div class="fg"><label>CVV *</label><input type="text" id="card_cvv" placeholder="000" maxlength="3"/></div>
              </div>
            </div>
          </div>

          <!-- Droite : récapitulatif -->
          <div>
            <h3 class="pay-title">Récapitulatif</h3>
            <div class="recap-card">
              <div class="recap-header">
                <div class="avatar-sm" id="recap-avatar">?</div>
                <div>
                  <div class="r-name" id="recap-nom">—</div>
                  <div class="r-sub"  id="recap-org">—</div>
                </div>
              </div>
              <div class="recap-row"><span>Frais MonAsso</span><span><?= number_format(FRAIS_INSCRIPTION,0,',',' ') ?> F</span></div>
              <div class="recap-row"><span>Cotisation</span><span id="r-cotisation">— F</span></div>
              <div class="recap-row total"><span>Total</span><span id="r-total">— F CFA</span></div>
              <div class="secure-row">
                <span><i class="ti ti-lock"></i> Sécurisé</span>
                <span><i class="ti ti-shield-check"></i> CinetPay</span>
              </div>
              <button type="button" class="btn-main btn-block" id="btn-payer" onclick="lancerPaiement()">
                <i class="ti ti-lock"></i> Payer <span id="btn-montant">— F CFA</span>
              </button>
            </div>
          </div>

        </div><!-- /pay-layout -->
        <div class="form-actions">
          <button type="button" class="btn-ghost" onclick="goTo(1)">
            <i class="ti ti-arrow-left"></i> Retour
          </button>
        </div>
      </div><!-- /p2 -->

      <!-- ===== ÉTAPE 3 : CONFIRMATION ===== -->
      <div class="panel" id="p3">
        <div class="confirm-center">
          <div class="confirm-icon"><i class="ti ti-circle-check"></i></div>
          <h2>Inscription confirmée !</h2>
          <p id="confirm-msg">Bienvenue dans MonAsso.</p>
          <div class="login-box"><span id="confirm-login">—</span></div>
          <p class="login-label">Votre identifiant MonAsso</p>
          <div class="notif-row">
            <span class="notif-badge"><i class="ti ti-message"></i> SMS envoyé</span>
            <span class="notif-badge"><i class="ti ti-mail"></i> Email envoyé</span>
          </div>
          <p class="confirm-note">
            Vos identifiants et mot de passe temporaire ont été envoyés par SMS et Email.
            Connectez-vous à votre espace MonAsso pour gérer votre adhésion.
          </p>
          <a href="<?= APP_URL ?>/login.php" class="btn-main">
            <i class="ti ti-login"></i> Accéder à mon espace
          </a>
        </div>
      </div><!-- /p3 -->

    </div><!-- /form-wrap -->
  </div>
</section>

<!-- ============================================================
     CTA FINAL
============================================================ -->
<section class="cta">
  <div class="container">
    <h2>Prêt à rejoindre MonAsso ?</h2>
    <p>Adhérez à votre organisation en quelques minutes.<br>Vos identifiants vous seront envoyés par SMS et Email.</p>
    <a href="#adherer" class="btn-white"><i class="ti ti-user-plus"></i> Commencer l'adhésion</a>
  </div>
</section>

<!-- ============================================================
     FOOTER
============================================================ -->
<footer class="footer">
  <div class="container footer-inner">
    <div class="nav-logo">
      <div class="logo-box sm"><i class="ti ti-building-community"></i></div>
      Mon<span class="green">Asso</span>
    </div>
    <div class="footer-links">
      <a href="#">Mentions légales</a>
      <a href="#">Confidentialité</a>
      <a href="#">Contact</a>
    </div>
    <p>© <?= date('Y') ?> MonAsso. Tous droits réservés.</p>
  </div>
</footer>

<script src="app.js"></script>
</body>
</html>
