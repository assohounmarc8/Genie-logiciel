<?php
// ============================================================
//  MONASSO — inscrire.php (MySQL)
// ============================================================
require_once 'config.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Données invalides.']);
    exit;
}

$requis = ['type', 'nom', 'tel', 'organisation', 'montant'];
foreach ($requis as $champ) {
    if (empty($input[$champ])) {
        echo json_encode(['success' => false, 'message' => "Champ manquant : $champ"]);
        exit;
    }
}

try {
    $db = getDB();

    // Vérifier l'organisation
    $stmt = $db->prepare("
        SELECT o.id, o.nom, o.compteur_membres,
               p.code_login AS code_pays,
               t.code_login AS code_type
        FROM organisation o
        JOIN pays p              ON p.id = o.pays_siege_id
        JOIN type_organisation t ON t.id = o.type_organisation_id
        WHERE o.id = ? AND o.acces_actif = 1
    ");
    $stmt->execute([$input['organisation']]);
    $org = $stmt->fetch();

    if (!$org) {
        echo json_encode(['success' => false, 'message' => 'Organisation introuvable ou inactive.']);
        exit;
    }

    // Vérifier doublon téléphone
    $stmt = $db->prepare("SELECT id FROM membre WHERE telephone = ?");
    $stmt->execute([$input['tel']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ce numéro est déjà enregistré.']);
        exit;
    }

    $db->beginTransaction();

    // 1. Insérer le membre
    $db->prepare("
        INSERT INTO membre (nom, prenom, telephone, email, acces_actif)
        VALUES (?, ?, ?, ?, 0)
    ")->execute([
        strtoupper(trim($input['nom'])),
        ucfirst(strtolower(trim($input['prenom'] ?? ''))),
        trim($input['tel']),
        trim($input['email'] ?? '') ?: null,
    ]);
    $membre_id = $db->lastInsertId();

    // 2. Adhésion
    $db->prepare("
        INSERT INTO adhesion (membre_id, organisation_id, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $org['id']]);

    // 3. Paiement inscription
    $db->prepare("
        INSERT INTO paiement_inscription (membre_id, montant, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $input['montant']]);

    // 4. Générer le login
    $nouveau_compteur = $org['compteur_membres'] + 1;
    $login = $org['code_pays'] . $org['code_type'] . str_pad($nouveau_compteur, 3, '0', STR_PAD_LEFT);

    // 5. Incrémenter le compteur
    $db->prepare("
        UPDATE organisation SET compteur_membres = compteur_membres + 1 WHERE id = ?
    ")->execute([$org['id']]);

    // 6. Mot de passe temporaire
    $chars    = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $mdp_temp = '';
    for ($i = 0; $i < 8; $i++) {
        $mdp_temp .= $chars[random_int(0, strlen($chars) - 1)];
    }

    // 7. Compte utilisateur
    $hash = password_hash($mdp_temp, PASSWORD_BCRYPT);
    $db->prepare("
        INSERT INTO utilisateur (membre_id, login, mot_de_passe_hash, actif)
        VALUES (?, ?, ?, 1)
    ")->execute([$membre_id, $login, $hash]);

    // 8. Activer le membre
    $db->prepare("UPDATE membre SET acces_actif = 1 WHERE id = ?")->execute([$membre_id]);
    $db->prepare("
        UPDATE adhesion SET statut = 'ACTIF'
        WHERE membre_id = ? AND organisation_id = ?
    ")->execute([$membre_id, $org['id']]);

    // 9. Notifications
    $msg_sms = "MonAsso : Bienvenue ! Login : $login | MDP : $mdp_temp. Connectez-vous sur " . SITE_URL . "/app";
    $db->prepare("
        INSERT INTO notification (membre_id, canal, destinataire, message, statut)
        VALUES (?, 'SMS', ?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $input['tel'], $msg_sms]);

    if (!empty($input['email'])) {
        $msg_email = "Bonjour,\n\nVotre inscription à {$org['nom']} est confirmée.\n\nIdentifiant : $login\nMot de passe : $mdp_temp\n\nConnectez-vous : " . APP_URL . "/login.php\n\nMonAsso";
        $db->prepare("
            INSERT INTO notification (membre_id, canal, destinataire, objet, message, statut)
            VALUES (?, 'EMAIL', ?, 'Vos identifiants MonAsso', ?, 'EN_ATTENTE')
        ")->execute([$membre_id, $input['email'], $msg_email]);
    }

    // 10. Transaction
    $db->prepare("
        INSERT INTO transaction (organisation_id, membre_id, montant, type_flux, statut_paiement)
        VALUES (?, ?, ?, 'INSCRIPTION_MEMBRE', 'EN_ATTENTE')
    ")->execute([$org['id'], $membre_id, $input['montant']]);

    $db->commit();

    echo json_encode([
        'success' => true,
        'login'   => $login,
        'org_nom' => $org['nom'],
        'message' => 'Inscription réussie.',
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Veuillez réessayer.']);
}
