// ============================================================
//  MONASSO — app.js
//  Navigation étapes, validation, récapitulatif paiement
// ============================================================

/* ---- État global ---- */
const state = {
  type: 'physique',   // 'physique' | 'morale'
  step: 1,
  data: {}
};

/* ============================================================
   NAVIGATION STEPPER
============================================================ */
function goTo(n) {
  // Cacher tous les panels
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.getElementById('p' + n).classList.add('active');
  state.step = n;

  // Mettre à jour le stepper
  [1, 2, 3].forEach(i => {
    const s  = document.getElementById('s'  + i);
    const sn = document.getElementById('sn' + i);
    s.className = 'step';
    if (i < n)  { s.classList.add('done');   sn.innerHTML = '<i class="ti ti-check"></i>'; }
    if (i === n){ s.classList.add('active'); sn.textContent = i; }
    if (i > n)  { sn.textContent = i; }
  });
  [1, 2].forEach(i => {
    const sep = document.getElementById('sep' + i);
    if (sep) sep.className = 'sep' + (i < n ? ' done' : '');
  });

  // Scroll vers le formulaire
  document.getElementById('adherer').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================================
   SWITCH PERSONNE PHYSIQUE / MORALE
============================================================ */
function switchType(type) {
  state.type = type;
  document.getElementById('btn-phys') .classList.toggle('active', type === 'physique');
  document.getElementById('btn-moral').classList.toggle('active', type === 'morale');
  document.getElementById('form-physique').style.display = type === 'physique' ? 'block' : 'none';
  document.getElementById('form-morale') .style.display = type === 'morale'   ? 'block' : 'none';
}

/* ============================================================
   VALIDATION ÉTAPE 1
============================================================ */
function validerEtape1() {
  let ok = true;

  // Réinitialiser les erreurs
  document.querySelectorAll('.fg input, .fg select').forEach(el => el.classList.remove('error'));

  function requis(id) {
    const el = document.getElementById(id);
    if (!el) return true;
    if (!el.value.trim()) { el.classList.add('error'); ok = false; return false; }
    return true;
  }

  if (state.type === 'physique') {
    requis('pp_nom'); requis('pp_prenom');
    requis('pp_sexe'); requis('pp_situation');
    requis('pp_naissance'); requis('pp_pays');
    requis('pp_tel');

    if (ok) {
      state.data.nom    = document.getElementById('pp_nom').value.trim().toUpperCase();
      state.data.prenom = document.getElementById('pp_prenom').value.trim();
      state.data.tel    = document.getElementById('pp_tel').value.trim();
      state.data.email  = document.getElementById('pp_email').value.trim();
      state.data.avatar = state.data.prenom[0] + state.data.nom[0];
    }
  } else {
    requis('pm_raison'); requis('pm_type_struct');
    requis('pm_immat'); requis('pm_pays');
    requis('pm_rep_nom'); requis('pm_rep_prenom');
    requis('pm_fonction'); requis('pm_tel'); requis('pm_email');

    if (ok) {
      state.data.nom    = document.getElementById('pm_raison').value.trim();
      state.data.prenom = document.getElementById('pm_rep_prenom').value.trim();
      state.data.tel    = document.getElementById('pm_tel').value.trim();
      state.data.email  = document.getElementById('pm_email').value.trim();
      state.data.avatar = 'PM';
    }
  }

  requis('organisation_id');
  if (ok) {
    const sel = document.getElementById('organisation_id');
    state.data.org_id   = sel.value;
    state.data.org_nom  = sel.options[sel.selectedIndex].text;
    state.data.org_type = sel.options[sel.selectedIndex].dataset.type || '';
  }

  if (!ok) {
    const firstError = document.querySelector('.fg input.error, .fg select.error');
    if (firstError) firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
    return;
  }

  // Remplir le récapitulatif
  remplirRecap();
  goTo(2);
}

/* ============================================================
   RÉCAPITULATIF PAIEMENT
============================================================ */
function remplirRecap() {
  document.getElementById('recap-avatar').textContent = state.data.avatar || '?';
  document.getElementById('recap-nom').textContent    = state.data.nom    || '—';
  document.getElementById('recap-org').textContent    = state.data.org_nom|| '—';

  // Cotisation fictive — frais d'inscription fournis côté serveur
  const cotisation = 3000;
  const frais      = Number(window.FRAIS_INSCRIPTION || 0);
  const total      = frais + cotisation;

  document.getElementById('r-cotisation').textContent = cotisation.toLocaleString('fr') + ' F';
  document.getElementById('r-total').textContent      = total.toLocaleString('fr') + ' F CFA';
  document.getElementById('btn-montant').textContent  = total.toLocaleString('fr') + ' F CFA';

  state.data.montant    = total;
  state.data.cotisation = cotisation;
}

/* ============================================================
   SÉLECTION DU MOYEN DE PAIEMENT
============================================================ */
function selMethod(el, type) {
  document.querySelectorAll('.method').forEach(m => m.classList.remove('active'));
  el.classList.add('active');
  state.data.moyen = type;

  document.getElementById('fields-mobile').style.display = type === 'card' ? 'none' : 'block';
  document.getElementById('fields-card') .style.display = type === 'card' ? 'block' : 'none';
}

/* ============================================================
   LANCER LE PAIEMENT (CinetPay)
============================================================ */
function lancerPaiement() {
  // Collecter les données du formulaire en POST via fetch → inscriptions.php
  const payload = {
    type:          state.type,
    nom:           state.data.nom,
    prenom:        state.data.prenom,
    tel:           state.data.tel,
    email:         state.data.email,
    organisation:  state.data.org_id,
    montant:       state.data.montant,
    moyen:         state.data.moyen || 'mobile',
  };

  const btn = document.getElementById('btn-payer');
  btn.disabled = true;
  btn.innerHTML = '<i class="ti ti-loader ti-spin"></i> Traitement…';

  fetch('inscrire.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  .then(r => r.json())
  .then(res => {
    if (res.success) {
      // Redirection vers CinetPay
      if (res.payment_url) {
        window.location.href = res.payment_url;
      } else {
        // Mode test : afficher la confirmation directement
        afficherConfirmation(res.login, res.org_nom);
      }
    } else {
      alert('Erreur : ' + (res.message || 'Une erreur est survenue.'));
      btn.disabled = false;
      btn.innerHTML = '<i class="ti ti-lock"></i> Payer <span id="btn-montant">' + state.data.montant.toLocaleString('fr') + ' F CFA</span>';
    }
  })
  .catch(() => {
    alert('Erreur de connexion. Veuillez réessayer.');
    btn.disabled = false;
    btn.innerHTML = '<i class="ti ti-lock"></i> Payer';
  });
}

/* ============================================================
   AFFICHER LA CONFIRMATION (étape 3)
============================================================ */
function afficherConfirmation(login, orgNom) {
  document.getElementById('confirm-login').textContent = login || 'CivMUT001';
  document.getElementById('confirm-msg').textContent   =
    'Bienvenue dans ' + (orgNom || state.data.org_nom) + '.';
  goTo(3);
}

/* ============================================================
   NAVBAR — menu burger mobile
============================================================ */
document.getElementById('burger').addEventListener('click', () => {
  const links = document.getElementById('nav-links');
  links.classList.toggle('open');
});

// Fermer le menu au clic sur un lien
document.querySelectorAll('#nav-links a').forEach(a => {
  a.addEventListener('click', () => {
    document.getElementById('nav-links').classList.remove('open');
  });
});

// Navbar ombre au scroll
window.addEventListener('scroll', () => {
  document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 20);
});

// Formatage carte bancaire
const cardNum = document.getElementById('card_num');
if (cardNum) {
  cardNum.addEventListener('input', e => {
    let v = e.target.value.replace(/\D/g,'').substring(0,16);
    e.target.value = v.replace(/(.{4})/g,'$1 ').trim();
  });
}
