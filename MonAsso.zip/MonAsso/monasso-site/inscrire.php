<?php
// ============================================================
//  MONASSO — inscrire.php (MySQL + PHPMailer)
// ============================================================
require_once 'config.php';
require_once 'libs/mailer.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['success' => false, 'message' => 'Données invalides.']);
    exit;
}

$requis = ['type', 'nom', 'tel', 'organisation', 'montant'];
foreach ($requis as $champ) {
    if (empty($input[$champ])) {
        echo json_encode(['success' => false, 'message' => "Champ manquant : $champ"]);
        exit;
    }
}

try {
    $db = getDB();

    // Vérifier l'GPOTB_ORGANISATION
    $stmt = $db->prepare("
        SELECT o.id, o.nom, o.compteur_membres,
               p.code_login AS code_pays,
               t.code_login AS code_type
        FROM GPOTB_ORGANISATION o
        JOIN GPOTB_PAYS p              ON p.id = o.pays_siege_id
        JOIN GPOTB_TYPE_ORGANISATION t ON t.id = o.type_organisation_id
        WHERE o.id = ? AND o.acces_actif = 1
    ");
    $stmt->execute([$input['organisation']]);
    $org = $stmt->fetch();

    if (!$org) {
        echo json_encode(['success' => false, 'message' => 'Organisation introuvable ou inactive.']);
        exit;
    }

    // Vérifier doublon téléphone
    $stmt = $db->prepare("SELECT id FROM GPOTB_MEMBRE WHERE telephone = ?");
    $stmt->execute([$input['tel']]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ce numéro est déjà enregistré.']);
        exit;
    }

    $db->beginTransaction();

    // Données selon le type
    $nom    = strtoupper(trim($input['nom']));
    $prenom = ucfirst(strtolower(trim($input['prenom'] ?? '')));
    $email  = trim($input['email'] ?? '') ?: null;
    $tel    = trim($input['tel']);
    $type   = $input['type']; // 'physique' ou 'morale'

    // 1. Insérer le GPOTB_MEMBRE
    $db->prepare("
        INSERT INTO GPOTB_MEMBRE (nom, prenom, telephone, email, acces_actif)
        VALUES (?, ?, ?, ?, 0)
    ")->execute([$nom, $prenom, $tel, $email]);
    $membre_id = $db->lastInsertId();

    // 2. Adhésion
    $db->prepare("
        INSERT INTO GPOTB_ADHESION (membre_id, organisation_id, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $org['id']]);

    // 3. Paiement inscription
    $db->prepare("
        INSERT INTO GPOTB_PAIEMENT_INSCRIPTION (membre_id, montant, statut)
        VALUES (?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $input['montant']]);

    // 4. Générer le login : CodePays + CodeType + Numéro séquentiel (3 chiffres)
    $nouveau_compteur = $org['compteur_membres'] + 1;
    $login = $org['code_pays'] . $org['code_type'] . str_pad($nouveau_compteur, 3, '0', STR_PAD_LEFT);

    // 5. Incrémenter le compteur
    $db->prepare("UPDATE GPOTB_ORGANISATION SET compteur_membres = compteur_membres + 1 WHERE id = ?")
       ->execute([$org['id']]);

    // 6. Mot de passe temporaire (8 caractères)
    $chars    = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
    $mdp_temp = '';
    for ($i = 0; $i < 8; $i++) {
        $mdp_temp .= $chars[random_int(0, strlen($chars) - 1)];
    }

    // 7. Compte GPOTB_UTILISATEUR (bcrypt)
    $hash = password_hash($mdp_temp, PASSWORD_BCRYPT);
    $db->prepare("
        INSERT INTO GPOTB_UTILISATEUR (membre_id, login, mot_de_passe_hash, actif)
        VALUES (?, ?, ?, 1)
    ")->execute([$membre_id, $login, $hash]);

    // 8. Activer le GPOTB_MEMBRE
    $db->prepare("UPDATE GPOTB_MEMBRE SET acces_actif = 1 WHERE id = ?")->execute([$membre_id]);
    $db->prepare("
        UPDATE GPOTB_ADHESION SET statut = 'ACTIF'
        WHERE membre_id = ? AND organisation_id = ?
    ")->execute([$membre_id, $org['id']]);

    // 9. Enregistrer la GPOTB_NOTIFICATION SMS
    $msg_sms = "MonAsso : Bienvenue ! Login : $login | MDP : $mdp_temp. Connectez-vous : " . APP_URL . "/login.php";
    $db->prepare("
        INSERT INTO GPOTB_NOTIFICATION (membre_id, canal, destinataire, message, statut)
        VALUES (?, 'SMS', ?, ?, 'EN_ATTENTE')
    ")->execute([$membre_id, $tel, $msg_sms]);

    // 10. Envoyer l'email avec PHPMailer
    $email_envoye = false;
    if ($email) {
        $sujet      = "✅ Vos identifiants MonAsso — " . $org['nom'];
        $corps_html = templateBienvenue($prenom, $nom, $login, $mdp_temp, $org['nom'], $type);
        $email_envoye = envoyerEmail($email, "$prenom $nom", $sujet, $corps_html);

        // Enregistrer la GPOTB_NOTIFICATION email
        $statut_notif = $email_envoye ? 'ENVOYE' : 'ECHEC';
        $db->prepare("
            INSERT INTO GPOTB_NOTIFICATION (membre_id, canal, destinataire, objet, message, statut, date_envoi)
            VALUES (?, 'EMAIL', ?, ?, ?, ?, NOW())
        ")->execute([
            $membre_id,
            $email,
            $sujet,
            "Identifiant : $login | MDP : $mdp_temp | Lien : " . APP_URL . "/login.php",
            $statut_notif
        ]);
    }

    // 11. Transaction financière
    $db->prepare("
        INSERT INTO GPOTB_TRANSACTION (organisation_id, membre_id, montant, type_flux, statut_paiement)
        VALUES (?, ?, ?, 'INSCRIPTION_MEMBRE', 'EN_ATTENTE')
    ")->execute([$org['id'], $membre_id, $input['montant']]);

    $db->commit();

    echo json_encode([
        'success'       => true,
        'login'         => $login,
        'org_nom'       => $org['nom'],
        'email_envoye'  => $email_envoye,
        'message'       => 'Inscription réussie.',
    ]);

} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    error_log('[MonAsso] Erreur inscription : ' . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erreur serveur. Veuillez réessayer.']);
}

