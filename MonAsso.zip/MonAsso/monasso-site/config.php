<?php
// ============================================================
//  MONASSO — Configuration générale (MySQL + WAMP)
// ============================================================

define('DB_HOST', 'localhost');
define('DB_PORT', '3308');
define('DB_NAME', 'monasso');
define('DB_USER', 'root');
define('DB_PASS', '');          // WAMP : mot de passe vide par défaut

define('SITE_NAME', 'MonAsso');
define('SITE_URL',  'http://localhost/monasso-site');
define('APP_URL',   'http://localhost/monasso-site/app');

define('FRAIS_INSCRIPTION', 2000); // FCFA

// CinetPay
define('CINETPAY_APIKEY',    'VOTRE_API_KEY');
define('CINETPAY_SITE_ID',   'VOTRE_SITE_ID');
define('CINETPAY_NOTIFY_URL', SITE_URL . '/notify.php');
define('CINETPAY_RETURN_URL', SITE_URL . '/retour-paiement.php');

// Connexion PDO MySQL (singleton)
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=".DB_HOST.";port=".DB_PORT.";dbname=".DB_NAME.";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

// ---- SMTP Gmail (PHPMailer) ----
define('MAIL_HOST',      'smtp.gmail.com');
define('MAIL_PORT',      587);
define('MAIL_USERNAME',  'votre.email@gmail.com');   // Votre adresse Gmail
define('MAIL_PASSWORD',  'xxxx xxxx xxxx xxxx');     // Mot de passe d'application Google (16 car.)
define('MAIL_FROM',      'votre.email@gmail.com');   // Expéditeur
define('MAIL_FROM_NAME', 'MonAsso');                 // Nom affiché dans la boite mail
