/**
 * Affiche le nom du fichier choisi dans les champs [data-file-upload], et gère le glisser-déposer.
 */
(function () {
    document.querySelectorAll('[data-file-upload]').forEach(function (wrap) {
        var input = wrap.querySelector('.file-upload-input');
        var text = wrap.querySelector('[data-file-upload-text]');
        var trigger = wrap.querySelector('.file-upload-trigger');
        if (!input || !text || !trigger) {
            return;
        }
        var defaultText = text.textContent;

        function updateText() {
            text.textContent = input.files.length ? input.files[0].name : defaultText;
            wrap.classList.toggle('has-file', input.files.length > 0);
        }

        input.addEventListener('change', updateText);

        ['dragenter', 'dragover'].forEach(function (evt) {
            trigger.addEventListener(evt, function (e) {
                e.preventDefault();
                wrap.classList.add('is-dragover');
            });
        });
        ['dragleave', 'drop'].forEach(function (evt) {
            trigger.addEventListener(evt, function (e) {
                e.preventDefault();
                wrap.classList.remove('is-dragover');
            });
        });
        trigger.addEventListener('drop', function (e) {
            if (e.dataTransfer && e.dataTransfer.files.length) {
                input.files = e.dataTransfer.files;
                updateText();
            }
        });

        updateText();
    });
})();
