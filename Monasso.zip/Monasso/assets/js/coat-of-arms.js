/**
 * Met à jour les armoiries sous le logo quand le pays change (#pays_code).
 */
(function () {
    var paysSelect = document.getElementById('pays_code');
    var containers = document.querySelectorAll('[data-coat-of-arms-dynamic]');
    if (!paysSelect || !containers.length) {
        return;
    }

    var urls = {};
    try {
        urls = JSON.parse(paysSelect.getAttribute('data-coat-of-arms') || '{}');
    } catch (e) {
        urls = {};
    }

    function updateCoatOfArms() {
        var code = paysSelect.value;
        var url = urls[code] || '';

        containers.forEach(function (container) {
            var img = container.querySelector('.coat-of-arms-img');
            if (!img) {
                return;
            }
            if (url) {
                img.src = url;
                img.hidden = false;
                container.hidden = false;
            } else {
                img.removeAttribute('src');
                img.hidden = true;
                container.hidden = true;
            }
        });
    }

    paysSelect.addEventListener('change', updateCoatOfArms);
    updateCoatOfArms();
})();
