/**
 * Anime en fondu + léger décalage vertical tout élément .reveal qui entre dans le viewport.
 * Dégradation silencieuse (élément visible immédiatement) si IntersectionObserver est indisponible.
 */
(function () {
    var items = document.querySelectorAll('.reveal');
    if (!items.length) {
        return;
    }

    if (!('IntersectionObserver' in window)) {
        items.forEach(function (el) { el.classList.add('in-view'); });
        return;
    }

    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

    items.forEach(function (el, index) {
        el.style.transitionDelay = Math.min(index % 6, 5) * 60 + 'ms';
        observer.observe(el);
    });
})();
