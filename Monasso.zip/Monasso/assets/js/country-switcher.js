/**
 * Dépliant pays — ouverture/fermeture du menu.
 */
(function () {
    document.querySelectorAll('[data-country-switcher]').forEach(function (root) {
        var btn = root.querySelector('.country-switcher-btn');
        var menu = root.querySelector('.country-switcher-menu');
        if (!btn || !menu) {
            return;
        }

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var open = btn.getAttribute('aria-expanded') === 'true';
            btn.setAttribute('aria-expanded', open ? 'false' : 'true');
            menu.hidden = open;
            root.classList.toggle('is-open', !open);
        });

        menu.addEventListener('click', function (e) {
            e.stopPropagation();
        });

        document.addEventListener('click', function () {
            btn.setAttribute('aria-expanded', 'false');
            menu.hidden = true;
            root.classList.remove('is-open');
        });
    });
})();
