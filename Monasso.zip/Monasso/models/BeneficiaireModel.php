<?php

class BeneficiaireModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM beneficiaires WHERE beneficiaire_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT b.*, p.nom AS programme_nom
             FROM beneficiaires b
             LEFT JOIN programmes p ON p.programme_code = b.programme_code
             WHERE b.organisation_code = :o ORDER BY b.created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function countByOrganisation(string $organisationCode): int
    {
        $stmt = Database::connection()->prepare('SELECT COUNT(*) FROM beneficiaires WHERE organisation_code = :o');
        $stmt->execute(['o' => $organisationCode]);
        return (int) $stmt->fetchColumn();
    }

    /** Nombre de bénéficiaires par programme (clé = programme_code), pour les barres d'avancement du dashboard ONG. */
    public static function countByProgramme(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT programme_code, COUNT(*) AS nb FROM beneficiaires
             WHERE organisation_code = :o AND programme_code IS NOT NULL GROUP BY programme_code'
        );
        $stmt->execute(['o' => $organisationCode]);
        $counts = [];
        foreach ($stmt->fetchAll() as $row) {
            $counts[$row['programme_code']] = (int) $row['nb'];
        }
        return $counts;
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::beneficiaireCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO beneficiaires (beneficiaire_code, organisation_code, programme_code, nom, contact, notes, created_at)
             VALUES (:code, :org, :programme, :nom, :contact, :notes, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'programme' => $data['programme_code'] !== '' ? $data['programme_code'] : null,
            'nom' => $data['nom'],
            'contact' => $data['contact'] !== '' ? $data['contact'] : null,
            'notes' => $data['notes'] !== '' ? $data['notes'] : null,
        ]);
        return self::findByCode($code);
    }
}
