<?php

class RegionModel
{
    public static function byPays(string $paysCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM regions WHERE pays_code = :pays ORDER BY nom');
        $stmt->execute(['pays' => $paysCode]);
        return $stmt->fetchAll();
    }

    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM regions WHERE region_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function exists(string $code): bool
    {
        return self::findByCode($code) !== null;
    }
}
