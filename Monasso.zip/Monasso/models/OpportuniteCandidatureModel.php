<?php

class OpportuniteCandidatureModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM opportunite_candidatures WHERE candidature_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByOpportuniteAndOrganisation(string $opportuniteCode, string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM opportunite_candidatures WHERE opportunite_code = :o AND organisation_code = :org'
        );
        $stmt->execute(['o' => $opportuniteCode, 'org' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Candidatures reçues sur une opportunité — vue de gestion Super Admin. */
    public static function listByOpportunite(string $opportuniteCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT c.*, o.nom AS organisation_nom, o.pays_code, u.nom AS candidat_nom
             FROM opportunite_candidatures c
             JOIN organisations o ON o.organisation_code = c.organisation_code
             JOIN users u ON u.user_code = c.user_code
             WHERE c.opportunite_code = :o
             ORDER BY c.created_at DESC'
        );
        $stmt->execute(['o' => $opportuniteCode]);
        return $stmt->fetchAll();
    }

    /** Candidatures envoyées par une organisation, toutes opportunités confondues — "Mes candidatures". */
    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT c.*, op.titre AS opportunite_titre, op.type_opportunite, op.statut AS opportunite_statut
             FROM opportunite_candidatures c
             JOIN opportunites op ON op.opportunite_code = c.opportunite_code
             WHERE c.organisation_code = :org
             ORDER BY c.created_at DESC'
        );
        $stmt->execute(['org' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::candidatureCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO opportunite_candidatures
                (candidature_code, opportunite_code, organisation_code, user_code, message, statut, created_at)
             VALUES
                (:code, :opp, :org, :user, :message, 'EN_ATTENTE', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'opp' => $data['opportunite_code'],
            'org' => $data['organisation_code'],
            'user' => $data['user_code'],
            'message' => $data['message'],
        ]);
        return self::findByCode($code);
    }

    /** $montantAccorde n'est renseigné que pour une candidature sur une opportunité de type FINANCEMENT. */
    public static function accepter(string $code, ?float $montantAccorde): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE opportunite_candidatures SET statut = 'ACCEPTEE', montant_accorde = :m WHERE candidature_code = :code"
        );
        $stmt->execute(['m' => $montantAccorde, 'code' => $code]);
    }

    /** $motif = raison du refus donnée par l'entreprise, affichée à l'organisation candidate. */
    public static function refuser(string $code, ?string $motif = null): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE opportunite_candidatures SET statut = 'REFUSEE', motif_refus = :motif WHERE candidature_code = :code"
        );
        $stmt->execute(['motif' => $motif, 'code' => $code]);
    }

    /**
     * Génère et stocke le jeton "magic link" envoyé par e-mail à l'entreprise pour trancher la
     * candidature sans authentification. bin2hex(random_bytes(32)) = 64 caractères hexadécimaux,
     * imprévisible, aligné sur la colonne response_token VARCHAR(64).
     */
    public static function generateResponseToken(string $code): string
    {
        $token = bin2hex(random_bytes(32));
        $stmt = Database::connection()->prepare(
            'UPDATE opportunite_candidatures SET response_token = :token WHERE candidature_code = :code'
        );
        $stmt->execute(['token' => $token, 'code' => $code]);
        return $token;
    }

    public static function findByToken(string $token): ?array
    {
        if ($token === '') {
            return null;
        }
        $stmt = Database::connection()->prepare(
            'SELECT c.*, o.titre AS opportunite_titre, o.type_opportunite, org.nom AS organisation_nom
             FROM opportunite_candidatures c
             JOIN opportunites o ON o.opportunite_code = c.opportunite_code
             JOIN organisations org ON org.organisation_code = c.organisation_code
             WHERE c.response_token = :token'
        );
        $stmt->execute(['token' => $token]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Invalide le jeton après usage — empêche de rejouer le même lien e-mail une fois la décision prise. */
    public static function clearResponseToken(string $code): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE opportunite_candidatures SET response_token = NULL WHERE candidature_code = :code'
        );
        $stmt->execute(['code' => $code]);
    }

    public static function totalVerse(string $candidatureCode): float
    {
        $stmt = Database::connection()->prepare(
            'SELECT COALESCE(SUM(montant), 0) FROM opportunite_versements WHERE candidature_code = :c'
        );
        $stmt->execute(['c' => $candidatureCode]);
        return (float) $stmt->fetchColumn();
    }
}
