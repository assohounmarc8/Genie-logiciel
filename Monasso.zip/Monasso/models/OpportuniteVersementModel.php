<?php

class OpportuniteVersementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM opportunite_versements WHERE versement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByCandidature(string $candidatureCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM opportunite_versements WHERE candidature_code = :c ORDER BY date_versement DESC'
        );
        $stmt->execute(['c' => $candidatureCode]);
        return $stmt->fetchAll();
    }

    /**
     * Enregistre un versement — déclaratif comme le reste des flux financiers V1 (aucune passerelle de
     * paiement réelle) : le Super Admin constate ici qu'il a effectivement transféré les fonds à
     * l'association, le versement est donc considéré effectué dès sa création.
     */
    public static function create(array $data): array
    {
        $code = CodeGenerator::versementCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO opportunite_versements
                (versement_code, candidature_code, montant, mode_paiement, reference, date_versement, created_at)
             VALUES
                (:code, :candidature, :montant, :mode, :reference, NOW(), NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'candidature' => $data['candidature_code'],
            'montant' => $data['montant'],
            'mode' => $data['mode_paiement'],
            'reference' => $data['reference'] !== '' ? $data['reference'] : null,
        ]);
        return self::findByCode($code);
    }
}
