<?php

class ChatMessageModel
{
    public const CANAUX = ['GENERALE', 'FINANCES', 'BUREAU'];

    public static function create(string $organisationCode, string $canal, string $userCode, string $contenu): array
    {
        $code = CodeGenerator::chatMessageCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO chat_messages (message_code, organisation_code, canal, user_code, contenu, created_at)
             VALUES (:code, :org, :canal, :user, :contenu, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'org' => $organisationCode,
            'canal' => $canal,
            'user' => $userCode,
            'contenu' => $contenu,
        ]);
        return self::findByCode($code);
    }

    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM chat_messages WHERE message_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Fil de discussion d'un canal, du plus ancien au plus récent, avec le nom de l'auteur. */
    public static function listByChannel(string $organisationCode, string $canal, int $limit = 200): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT m.*, u.nom AS auteur_nom
             FROM chat_messages m
             JOIN users u ON u.user_code = m.user_code
             WHERE m.organisation_code = :org AND m.canal = :canal
             ORDER BY m.created_at ASC, m.message_code ASC
             LIMIT :limit'
        );
        $stmt->bindValue('org', $organisationCode);
        $stmt->bindValue('canal', $canal);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** Dernier message d'un canal — utilisé pour l'aperçu dans la liste des canaux. */
    public static function lastMessage(string $organisationCode, string $canal): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT m.*, u.nom AS auteur_nom
             FROM chat_messages m
             JOIN users u ON u.user_code = m.user_code
             WHERE m.organisation_code = :org AND m.canal = :canal
             ORDER BY m.created_at DESC, m.message_code DESC
             LIMIT 1'
        );
        $stmt->execute(['org' => $organisationCode, 'canal' => $canal]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
