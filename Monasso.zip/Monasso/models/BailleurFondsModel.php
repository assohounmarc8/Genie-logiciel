<?php

class BailleurFondsModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM bailleurs_fonds WHERE bailleur_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM bailleurs_fonds WHERE organisation_code = :o ORDER BY created_at DESC');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function countActifs(string $organisationCode): int
    {
        $stmt = Database::connection()->prepare("SELECT COUNT(*) FROM bailleurs_fonds WHERE organisation_code = :o AND statut = 'ACTIF'");
        $stmt->execute(['o' => $organisationCode]);
        return (int) $stmt->fetchColumn();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::bailleurCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO bailleurs_fonds (bailleur_code, organisation_code, nom, statut, montant_engage, created_at)
             VALUES (:code, :org, :nom, 'ACTIF', :montant, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'nom' => $data['nom'],
            'montant' => $data['montant_engage'] !== '' ? (float) $data['montant_engage'] : null,
        ]);
        return self::findByCode($code);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE bailleurs_fonds SET statut = :s WHERE bailleur_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
