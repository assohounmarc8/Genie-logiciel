<?php

class OpportuniteModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM opportunites WHERE opportunite_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /**
     * Fiche enrichie (nom du pays ciblé) pour l'affichage détail — le pays_code peut être NULL
     * (opportunité ouverte à tous les pays).
     */
    public static function findDetailByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT o.*, u.nom AS cree_par_nom
             FROM opportunites o
             JOIN users u ON u.user_code = o.cree_par_user_code
             WHERE o.opportunite_code = :code'
        );
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /**
     * Recherche filtrée — coeur de la fonctionnalité de recherche d'opportunités. Construit la
     * clause WHERE dynamiquement à partir de filtres optionnels, en gardant des requêtes préparées.
     *
     * Filtres acceptés : 'q' (texte libre sur titre/description), 'type' (type_opportunite_code),
     * 'pays' (pays_code ciblé — inclut toujours les opportunités ouvertes à tous les pays),
     * 'statut' : code précis pour filtrer exactement dessus ; null (par défaut, cf.
     * OpportunitesController::index) pour montrer ACTIF + FERME et masquer ARCHIVE ; '' pour ne
     * filtrer sur rien et tout montrer, y compris ARCHIVE (choix explicite "Tous les statuts" côté
     * Super Admin) ; clé absente pour ne montrer que ACTIF (comportement par défaut historique,
     * conservé pour d'éventuels autres appelants).
     */
    public static function search(array $filters): array
    {
        $where = [];
        $params = [];

        $statut = array_key_exists('statut', $filters) ? $filters['statut'] : 'ACTIF';
        if ($statut !== null && $statut !== '') {
            $where[] = 'o.statut = :statut';
            $params['statut'] = $statut;
        } elseif ($statut === null) {
            // Pas de filtre statut explicite (chargement initial de la vue Super Admin, cf.
            // OpportunitesController::index) : on masque quand même les opportunités archivées par
            // défaut, sinon elles reviendraient encombrer le menu qu'on cherche justement à
            // désencombrer. Un choix explicite de "Tous les statuts" (statut = '') les affiche.
            $where[] = "o.statut != 'ARCHIVE'";
        }

        $type = trim((string) ($filters['type'] ?? ''));
        if ($type !== '') {
            $where[] = 'o.type_opportunite = :type';
            $params['type'] = $type;
        }

        $pays = trim((string) ($filters['pays'] ?? ''));
        if ($pays !== '') {
            $where[] = '(o.pays_code = :pays OR o.pays_code IS NULL)';
            $params['pays'] = $pays;
        }

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            // Deux paramètres distincts (:q1/:q2) plutôt qu'un seul :q réutilisé deux fois : PDO en
            // requêtes préparées natives (ATTR_EMULATE_PREPARES = false, cf. core/Database.php) ne
            // supporte pas la réutilisation d'un même paramètre nommé plusieurs fois dans une requête
            // MySQL — ça levait un "SQLSTATE[HY093]: Invalid parameter number" qui cassait toute
            // recherche par mot-clé.
            $where[] = '(o.titre LIKE :q1 OR o.description LIKE :q2)';
            $params['q1'] = '%' . $q . '%';
            $params['q2'] = '%' . $q . '%';
        }

        $sql = 'SELECT o.*, u.nom AS cree_par_nom FROM opportunites o
                JOIN users u ON u.user_code = o.cree_par_user_code';
        if ($where) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY o.created_at DESC';

        $stmt = Database::connection()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::opportuniteCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO opportunites
                (opportunite_code, type_opportunite, titre, description, montant, pays_code, date_limite,
                 statut, cree_par_user_code, nom_contact, email_contact, created_at)
             VALUES
                (:code, :type, :titre, :description, :montant, :pays, :date_limite, \'ACTIF\', :user, :nom_contact, :email_contact, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'type' => $data['type_opportunite'],
            'titre' => $data['titre'],
            'description' => $data['description'],
            'montant' => $data['montant'] !== null ? $data['montant'] : null,
            'pays' => $data['pays_code'] !== '' ? $data['pays_code'] : null,
            'date_limite' => $data['date_limite'] !== '' ? $data['date_limite'] : null,
            'user' => $data['cree_par_user_code'],
            'nom_contact' => ($data['nom_contact'] ?? '') !== '' ? $data['nom_contact'] : null,
            'email_contact' => ($data['email_contact'] ?? '') !== '' ? $data['email_contact'] : null,
        ]);
        return self::findByCode($code);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE opportunites SET statut = :s WHERE opportunite_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
