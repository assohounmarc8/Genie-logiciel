<?php

class MinistereTutelleModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM ministeres_tutelle ORDER BY nom')->fetchAll();
    }

    public static function byPays(string $paysCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM ministeres_tutelle WHERE pays_code = :pays ORDER BY nom');
        $stmt->execute(['pays' => $paysCode]);
        return $stmt->fetchAll();
    }

    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM ministeres_tutelle WHERE ministere_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function exists(string $code): bool
    {
        return self::findByCode($code) !== null;
    }
}
