<?php

class TypeOpportuniteModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM types_opportunite ORDER BY type_opportunite_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM types_opportunite WHERE type_opportunite_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
