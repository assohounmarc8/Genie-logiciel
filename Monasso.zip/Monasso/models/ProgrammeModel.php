<?php

class ProgrammeModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM programmes WHERE programme_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM programmes WHERE organisation_code = :o ORDER BY created_at DESC');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function countActifs(string $organisationCode): int
    {
        $stmt = Database::connection()->prepare("SELECT COUNT(*) FROM programmes WHERE organisation_code = :o AND statut = 'EN_COURS'");
        $stmt->execute(['o' => $organisationCode]);
        return (int) $stmt->fetchColumn();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::programmeCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO programmes (programme_code, organisation_code, nom, description, statut, objectif_beneficiaires, created_at)
             VALUES (:code, :org, :nom, :description, 'EN_COURS', :objectif, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'nom' => $data['nom'],
            'description' => $data['description'] !== '' ? $data['description'] : null,
            'objectif' => $data['objectif_beneficiaires'] !== '' ? (int) $data['objectif_beneficiaires'] : null,
        ]);
        return self::findByCode($code);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE programmes SET statut = :s WHERE programme_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
