<?php

class PrestationModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM prestations WHERE prestation_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, u.nom AS membre_nom
             FROM prestations p
             JOIN users u ON u.user_code = p.user_code
             WHERE p.organisation_code = :o ORDER BY p.created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function listEnAttente(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT p.*, u.nom AS membre_nom
             FROM prestations p
             JOIN users u ON u.user_code = p.user_code
             WHERE p.organisation_code = :o AND p.statut = 'EN_ATTENTE' ORDER BY p.created_at ASC"
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    /** Total versé (statut PAYE) et total engagé (EN_ATTENTE + APPROUVE, pas encore payé) — pour le fonds de solidarité. */
    public static function stats(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT
                COALESCE(SUM(CASE WHEN statut = 'PAYE' THEN montant ELSE 0 END), 0) AS total_paye,
                COALESCE(SUM(CASE WHEN statut IN ('EN_ATTENTE', 'APPROUVE') THEN montant ELSE 0 END), 0) AS total_engage,
                SUM(CASE WHEN statut = 'EN_ATTENTE' THEN 1 ELSE 0 END) AS nb_en_attente
             FROM prestations WHERE organisation_code = :o"
        );
        $stmt->execute(['o' => $organisationCode]);
        $row = $stmt->fetch();
        return [
            'total_paye' => (float) $row['total_paye'],
            'total_engage' => (float) $row['total_engage'],
            'nb_en_attente' => (int) $row['nb_en_attente'],
        ];
    }

    public static function totalPayeForMonth(string $organisationCode, int $year, int $month): float
    {
        $stmt = Database::connection()->prepare(
            "SELECT COALESCE(SUM(montant), 0) FROM prestations
             WHERE organisation_code = :o AND statut = 'PAYE' AND YEAR(created_at) = :y AND MONTH(created_at) = :m"
        );
        $stmt->execute(['o' => $organisationCode, 'y' => $year, 'm' => $month]);
        return (float) $stmt->fetchColumn();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::prestationCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO prestations (prestation_code, organisation_code, user_code, motif, montant, statut, created_at)
             VALUES (:code, :org, :user, :motif, :montant, 'EN_ATTENTE', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'user' => $data['user_code'],
            'motif' => $data['motif'],
            'montant' => (float) $data['montant'],
        ]);
        return self::findByCode($code);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE prestations SET statut = :s WHERE prestation_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
