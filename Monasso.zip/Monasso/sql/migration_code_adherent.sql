-- Migration incrémentale — nouveau format de code adhérent : PAYS-TYPE(1c)-ORGA(4c)-PERSO(4c).
-- Non destructive : ALTER TABLE ADD COLUMN + UPDATE de la table de référence uniquement.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_code_adherent.sql

USE monasso;

-- users.code_perso : identifiant personnel de 4 caractères, généré une seule fois par utilisateur
-- (réutilisé tel quel pour chaque nouvelle organisation rejointe, cf. CodeGenerator::codePerso()).
ALTER TABLE users
    ADD COLUMN code_perso CHAR(4) NULL AFTER photo_chemin,
    ADD UNIQUE KEY uq_users_code_perso (code_perso);

-- types_organisation.code_court : lettre unique utilisée dans le code adhérent (cf.
-- CodeGenerator::numeroAdherent()).
ALTER TABLE types_organisation
    ADD COLUMN code_court CHAR(1) NOT NULL DEFAULT '';

UPDATE types_organisation SET code_court = 'A' WHERE type_organisation_code = 'ASSOCIATION';
UPDATE types_organisation SET code_court = 'O' WHERE type_organisation_code = 'ONG';
UPDATE types_organisation SET code_court = 'M' WHERE type_organisation_code = 'MUTUELLE';
