-- Migration incrémentale — ajoute la messagerie "Discussions" par organisation (3 canaux fixes :
-- GENERALE, FINANCES, BUREAU — permissions gérées côté application, cf. ChatController). Non
-- destructive : nouvelle table uniquement.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_chat.sql

USE monasso;

CREATE TABLE chat_messages (
    message_code         VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code     VARCHAR(40)  NOT NULL,
    canal                   VARCHAR(20)  NOT NULL,
    user_code                 VARCHAR(20)  NOT NULL,
    contenu                     TEXT NOT NULL,
    created_at                     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_chat_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_chat_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT chk_chat_canal CHECK (canal IN ('GENERALE', 'FINANCES', 'BUREAU')),
    INDEX idx_chat_org_canal (organisation_code, canal, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
