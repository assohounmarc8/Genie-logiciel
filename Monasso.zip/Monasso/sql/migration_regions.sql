-- Migration incrémentale — régions/villes principales des 6 pays couverts, pour la carte de
-- recherche d'organisation (adhérent) et pour situer une organisation. Positions x_percent/y_percent
-- schématiques (0-100), pas de vraies frontières administratives. Non destructive.
-- NOTE : les données (noms accentués) sont seedées séparément via un script PHP/PDO (pas le client
-- mysql en CLI, qui corrompt les caractères accentués sur cette machine — cf. mémoire
-- mysql_cli_utf8_gotcha). Exécuter d'abord ce fichier DDL, puis le script PHP de seed.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_regions.sql

USE monasso;

CREATE TABLE regions (
    region_code   VARCHAR(20)  NOT NULL PRIMARY KEY,
    pays_code     VARCHAR(3)   NOT NULL,
    nom           VARCHAR(100) NOT NULL,
    x_percent     TINYINT UNSIGNED NOT NULL,
    y_percent     TINYINT UNSIGNED NOT NULL,
    CONSTRAINT fk_region_pays FOREIGN KEY (pays_code) REFERENCES pays (pays_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE organisations
    ADD COLUMN region_code VARCHAR(20) NULL AFTER pays_code,
    ADD CONSTRAINT fk_org_region FOREIGN KEY (region_code) REFERENCES regions (region_code);
