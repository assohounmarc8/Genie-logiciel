-- Migration incrémentale — Magic Link entreprise + traçabilité des décisions de candidature.
-- Non destructive : uniquement des ALTER TABLE ADD COLUMN / INSERT. Aucun DROP, aucune donnée touchée.
-- À exécuter une fois sur la base "monasso" existante :
--   "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_magic_link.sql

USE monasso;

-- opportunites : coordonnées de l'entreprise/partenaire externe à contacter par mail pour trancher
-- les candidatures reçues sur cette opportunité (pas de compte MONASSO requis côté entreprise).
ALTER TABLE opportunites
    ADD COLUMN nom_contact   VARCHAR(150) NULL AFTER cree_par_user_code,
    ADD COLUMN email_contact VARCHAR(190) NULL AFTER nom_contact;

-- opportunite_candidatures : jeton à usage unique permettant à l'entreprise de trancher la
-- candidature depuis le lien reçu par e-mail, sans authentification. Effacé une fois utilisé.
ALTER TABLE opportunite_candidatures
    ADD COLUMN response_token VARCHAR(64) NULL AFTER statut,
    ADD UNIQUE KEY uq_cand_response_token (response_token);

-- Nouveau type d'e-mail automatique : demande de décision envoyée à l'entreprise à la candidature.
-- Réutilise la table types_notification déjà partagée par notifications.type_code et
-- mails_envoyes.type_code (cf. sql/monasso.sql).
INSERT INTO types_notification (type_notification_code, nom) VALUES
    ('CANDIDATURE_OPPORTUNITE_A_TRAITER', 'Décision entreprise demandée sur une candidature')
ON DUPLICATE KEY UPDATE nom = VALUES(nom);
