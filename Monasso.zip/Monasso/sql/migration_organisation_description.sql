-- Migration incrémentale — ajoute une description libre à l'organisation (formulaire de création
-- d'organisation, affichée aussi au verso de la carte de membre). Non destructive.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_organisation_description.sql

USE monasso;

ALTER TABLE organisations
    ADD COLUMN description TEXT NULL AFTER adresse;
