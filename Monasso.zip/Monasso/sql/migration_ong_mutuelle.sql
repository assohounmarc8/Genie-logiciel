-- Migration incrémentale — entités métier spécifiques aux organisations de type ONG (programmes,
-- bénéficiaires, bailleurs de fonds) et Mutuelle (prestations/remboursements). Non destructive :
-- nouvelles tables + nouveaux permission_code uniquement. Les libellés (colonne `nom` de
-- `permissions`) contiennent des accents — seedés séparément via script PHP/PDO, pas cette CLI
-- (cf. mémoire mysql_cli_utf8_gotcha).
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_ong_mutuelle.sql

USE monasso;

CREATE TABLE programmes (
    programme_code         VARCHAR(20)  NOT NULL PRIMARY KEY,
    organisation_code       VARCHAR(40)  NOT NULL,
    nom                       VARCHAR(190) NOT NULL,
    description                TEXT NULL,
    statut                        VARCHAR(15) NOT NULL DEFAULT 'EN_COURS',
    objectif_beneficiaires          INT UNSIGNED NULL,
    created_at                          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_programme_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    INDEX idx_programme_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE beneficiaires (
    beneficiaire_code       VARCHAR(20)  NOT NULL PRIMARY KEY,
    organisation_code        VARCHAR(40)  NOT NULL,
    programme_code             VARCHAR(20)  NULL,
    nom                           VARCHAR(190) NOT NULL,
    contact                          VARCHAR(190) NULL,
    notes                               TEXT NULL,
    created_at                             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_beneficiaire_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_beneficiaire_programme FOREIGN KEY (programme_code) REFERENCES programmes (programme_code),
    INDEX idx_beneficiaire_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE bailleurs_fonds (
    bailleur_code       VARCHAR(20)  NOT NULL PRIMARY KEY,
    organisation_code    VARCHAR(40)  NOT NULL,
    nom                     VARCHAR(190) NOT NULL,
    statut                     VARCHAR(15) NOT NULL DEFAULT 'ACTIF',
    montant_engage                DECIMAL(14,2) NULL,
    created_at                        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bailleur_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    INDEX idx_bailleur_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE prestations (
    prestation_code       VARCHAR(20)  NOT NULL PRIMARY KEY,
    organisation_code      VARCHAR(40)  NOT NULL,
    user_code                 VARCHAR(20)  NOT NULL,
    motif                       VARCHAR(190) NOT NULL,
    montant                        DECIMAL(14,2) NOT NULL,
    statut                            VARCHAR(15) NOT NULL DEFAULT 'EN_ATTENTE',
    created_at                           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_prestation_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_prestation_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    INDEX idx_prestation_org (organisation_code, statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Les 3 nouveaux permission_code (gerer_beneficiaires/gerer_bailleurs/gerer_prestations) sont
-- insérés séparément via script PHP/PDO pour préserver les accents (cf. en-tête de ce fichier).
