-- Migration incrémentale — ministère de tutelle des associations/ONG/mutuelles, un par pays (source :
-- textes régissant la vie associative de chaque pays, cf. recherche du 2026-07-16). Non destructive :
-- nouvelle table de référence + FK nullable sur organisations.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_ministeres_tutelle.sql

USE monasso;

CREATE TABLE ministeres_tutelle (
    ministere_code   VARCHAR(10)  NOT NULL PRIMARY KEY,
    pays_code        VARCHAR(3)   NOT NULL,
    nom              VARCHAR(190) NOT NULL,
    CONSTRAINT fk_ministere_pays FOREIGN KEY (pays_code) REFERENCES pays (pays_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO ministeres_tutelle (ministere_code, pays_code, nom) VALUES
('MIN-CIV', 'CIV', "Ministère de l'Intérieur et de la Sécurité"),
('MIN-MLI', 'MLI', "Ministère de l'Administration Territoriale et de la Décentralisation"),
('MIN-BEN', 'BEN', "Ministère de l'Intérieur et de la Sécurité Publique"),
('MIN-NER', 'NER', "Ministère de l'Intérieur, de la Sécurité Publique et de l'Administration du Territoire"),
('MIN-BFA', 'BFA', "Ministère de l'Administration Territoriale et de la Mobilité"),
('MIN-MDG', 'MDG', "Ministère de l'Intérieur et de la Décentralisation");

ALTER TABLE organisations
    ADD COLUMN ministere_tutelle_code VARCHAR(10) NULL AFTER type_organisation,
    ADD CONSTRAINT fk_org_ministere FOREIGN KEY (ministere_tutelle_code) REFERENCES ministeres_tutelle (ministere_code);
