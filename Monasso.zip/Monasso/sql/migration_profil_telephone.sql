-- Migration incrémentale — ajoute un numéro de téléphone au profil utilisateur (page "Mon profil"
-- et formulaire d'inscription). Non destructive : ALTER TABLE ADD COLUMN uniquement.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_profil_telephone.sql

USE monasso;

ALTER TABLE users
    ADD COLUMN telephone VARCHAR(30) NULL AFTER lieu_naissance;
