-- Migration incrémentale — statut ARCHIVE pour les opportunités (remplace la suppression définitive :
-- on garde une trace des opportunités closes avec accord conclu, on les masque juste des listes).
-- Non destructive : INSERT ... ON DUPLICATE KEY UPDATE uniquement. À exécuter une fois :
--   "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_archiver_opportunite.sql

USE monasso;

INSERT INTO statuts_opportunite (statut_opportunite_code, nom) VALUES
    ('ARCHIVE', 'Archivée')
ON DUPLICATE KEY UPDATE nom = VALUES(nom);
