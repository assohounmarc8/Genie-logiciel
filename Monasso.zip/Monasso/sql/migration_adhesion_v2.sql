-- Migration incrémentale — refonte du code adhérent (PAYS-TYPE3-NUMERO_ORGA-PERSO), niveau
-- d'études à l'inscription, délai de paiement de 7 jours, notification admin sur paiement reçu,
-- notification de bienvenue plateforme. Non destructive : ALTER TABLE ADD/MODIFY COLUMN, CREATE
-- TABLE, INSERT ... ON DUPLICATE KEY UPDATE uniquement.
-- À exécuter une fois : "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_adhesion_v2.sql

USE monasso;

-- 1) Code adhérent : type organisation passe de 1 à 3 caractères (A/O/M -> ASS/ONG/MUT)
ALTER TABLE types_organisation MODIFY COLUMN code_court CHAR(3) NOT NULL DEFAULT '';
UPDATE types_organisation SET code_court = 'ASS' WHERE type_organisation_code = 'ASSOCIATION';
UPDATE types_organisation SET code_court = 'ONG' WHERE type_organisation_code = 'ONG';
UPDATE types_organisation SET code_court = 'MUT' WHERE type_organisation_code = 'MUTUELLE';

-- 2) Numéro séquentiel de l'organisation en base (4 chiffres dans le code adhérent, ex. 0014)
ALTER TABLE organisations
    ADD COLUMN numero_organisation INT UNSIGNED NULL AFTER organisation_code,
    ADD UNIQUE KEY uq_org_numero (numero_organisation);

-- Backfill des organisations déjà existantes, numérotées par ordre de création
SET @n := 0;
UPDATE organisations
SET numero_organisation = (@n := @n + 1)
WHERE numero_organisation IS NULL
ORDER BY created_at ASC;

-- 3) niveaux_etude : référence pour users.niveau_etude (même pattern que metiers)
CREATE TABLE IF NOT EXISTS niveaux_etude (
    niveau_etude_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom               VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO niveaux_etude (niveau_etude_code, nom) VALUES
    ('AUCUN', 'Aucun'),
    ('PRIMAIRE', 'Primaire'),
    ('SECONDAIRE', 'Secondaire'),
    ('BAC', 'Baccalauréat'),
    ('BAC_PLUS_2', 'Bac+2'),
    ('LICENCE', 'Licence'),
    ('MASTER', 'Master'),
    ('DOCTORAT', 'Doctorat'),
    ('AUTRE', 'Autre')
ON DUPLICATE KEY UPDATE nom = VALUES(nom);

ALTER TABLE users
    ADD COLUMN niveau_etude VARCHAR(20) NULL AFTER metier,
    ADD CONSTRAINT fk_user_niveau_etude FOREIGN KEY (niveau_etude) REFERENCES niveaux_etude (niveau_etude_code);

-- 4) Délai de paiement de 7 jours sur le droit d'adhésion
ALTER TABLE adhesion_paiements
    ADD COLUMN date_limite DATETIME NULL AFTER token;

-- 5) Nouveaux types de notification/mail
INSERT INTO types_notification (type_notification_code, nom) VALUES
    ('BIENVENUE_PLATEFORME', 'Bienvenue sur la plateforme'),
    ('ADHESION_PAIEMENT_RECU_ADMIN', "Paiement d'adhésion reçu (notification admin)")
ON DUPLICATE KEY UPDATE nom = VALUES(nom);
