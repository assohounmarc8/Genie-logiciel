-- Migration incrémentale — motif de refus entreprise sur une candidature à une opportunité.
-- Non destructive : ALTER TABLE ADD COLUMN uniquement. À exécuter une fois sur la base existante :
--   "C:\xampp\mysql\bin\mysql.exe" -u root monasso < sql/migration_motif_refus.sql

USE monasso;

ALTER TABLE opportunite_candidatures
    ADD COLUMN motif_refus TEXT NULL AFTER montant_accorde;
