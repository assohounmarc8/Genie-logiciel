<?php

class BailleursController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_bailleurs');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('bailleurs/index', [
            'organisation' => $org,
            'bailleurs' => BailleurFondsModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_bailleurs');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $montant = trim($_POST['montant_engage'] ?? '');

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.name_required');
            }
            if ($montant !== '' && (!is_numeric($montant) || (float) $montant < 0)) {
                $errors[] = t('validation.montant_positive');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('bailleurs/creer', ['org' => $orgCode]);
            }

            $bailleur = BailleurFondsModel::create([
                'organisation_code' => $orgCode,
                'nom' => $nom,
                'montant_engage' => $montant,
            ]);

            Audit::log($user['user_code'], $orgCode, 'CREATE_BAILLEUR', $bailleur['bailleur_code'], ['nom' => $nom]);

            redirect_route('bailleurs/index', ['org' => $orgCode]);
        }

        View::render('bailleurs/creer', ['organisation' => $org, 'errors' => flash_get('errors', [])]);
    }

    public function marquerRapportDu(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_bailleurs');
        $code = $_POST['id'] ?? '';
        $bailleur = BailleurFondsModel::findByCode($code);

        if ($bailleur && $bailleur['organisation_code'] === $orgCode) {
            $nouveau = $bailleur['statut'] === 'RAPPORT_DU' ? 'ACTIF' : 'RAPPORT_DU';
            BailleurFondsModel::updateStatut($code, $nouveau);
            Audit::log($user['user_code'], $orgCode, 'UPDATE_BAILLEUR_STATUT', $code, ['statut' => $nouveau]);
        }

        redirect_route('bailleurs/index', ['org' => $orgCode]);
    }
}
