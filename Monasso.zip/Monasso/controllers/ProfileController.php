<?php

class ProfileController
{
    private const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png'];

    public function index(): void
    {
        $user = Middleware::requireLogin();
        View::render('profile/index', ['user' => UserModel::findByCode($user['user_code'])]);
    }

    public function update(): void
    {
        $user = Middleware::requireLogin();

        $nom = trim($_POST['nom'] ?? '');
        $telephone = trim($_POST['telephone'] ?? '');
        $dateNaissance = trim($_POST['date_naissance'] ?? '');
        $lieuNaissance = trim($_POST['lieu_naissance'] ?? '');
        $currentPassword = (string) ($_POST['current_password'] ?? '');
        $newPassword = (string) ($_POST['new_password'] ?? '');
        $confirmPassword = (string) ($_POST['confirm_password'] ?? '');

        $errors = [];
        if ($nom === '') {
            $errors[] = t('validation.name_required');
        }
        if ($dateNaissance !== '' && !DateTime::createFromFormat('Y-m-d', $dateNaissance)) {
            $errors[] = t('validation.date_naissance_invalid');
        }

        $wantsPasswordChange = $newPassword !== '' || $confirmPassword !== '';
        if ($wantsPasswordChange) {
            if (!UserModel::verifyPassword($user, $currentPassword)) {
                $errors[] = t('profile.error.current_password_invalid');
            }
            if (strlen($newPassword) < 8) {
                $errors[] = t('validation.password_min');
            }
            if ($newPassword !== $confirmPassword) {
                $errors[] = t('profile.error.password_mismatch');
            }
        }

        $photoFile = $_FILES['photo'] ?? null;
        if ($photoFile && $photoFile['error'] !== UPLOAD_ERR_NO_FILE) {
            $errors = array_merge($errors, validate_uploaded_file($photoFile, self::IMAGE_EXTENSIONS));
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('profile/index');
        }

        UserModel::updateProfile($user['user_code'], [
            'nom' => $nom,
            'telephone' => $telephone,
            'date_naissance' => $dateNaissance,
            'lieu_naissance' => $lieuNaissance,
        ]);

        if ($photoFile && $photoFile['error'] !== UPLOAD_ERR_NO_FILE) {
            $diskName = $user['user_code'] . '_' . safe_filename($photoFile['name']);
            $stored = store_uploaded_file($photoFile, APP_DIR . '/uploads/photos', $diskName);
            if ($stored) {
                UserModel::updatePhoto($user['user_code'], 'uploads/photos/' . $diskName);
            }
        }

        if ($wantsPasswordChange) {
            UserModel::updatePassword($user['user_code'], $newPassword);
        }

        Audit::log($user['user_code'], null, 'UPDATE_PROFIL', $user['user_code']);
        flash_set('success', t('profile.success'));
        redirect_route('profile/index');
    }
}
