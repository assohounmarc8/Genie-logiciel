<?php

class ChatController
{
    private const CANAL_DEFAULT = 'GENERALE';

    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        $user = Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $canal = $_GET['canal'] ?? self::CANAL_DEFAULT;
        if (!in_array($canal, ChatMessageModel::CANAUX, true) || !$this->canAccessCanal($user, $orgCode, $canal)) {
            $canal = self::CANAL_DEFAULT;
        }

        $canaux = [];
        foreach (ChatMessageModel::CANAUX as $code) {
            if ($this->canAccessCanal($user, $orgCode, $code)) {
                $canaux[] = [
                    'code' => $code,
                    'last' => ChatMessageModel::lastMessage($orgCode, $code),
                ];
            }
        }

        View::render('chat/index', [
            'organisation' => $org,
            'canal' => $canal,
            'canaux' => $canaux,
            'messages' => ChatMessageModel::listByChannel($orgCode, $canal),
            'currentUserCode' => $user['user_code'],
        ]);
    }

    public function envoyer(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $canal = $_POST['canal'] ?? self::CANAL_DEFAULT;
        $user = Middleware::requireMembership($orgCode);

        if (!in_array($canal, ChatMessageModel::CANAUX, true) || !$this->canAccessCanal($user, $orgCode, $canal)) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $contenu = trim($_POST['contenu'] ?? '');
        if ($contenu !== '') {
            ChatMessageModel::create($orgCode, $canal, $user['user_code'], $contenu);
        }

        redirect_route('chat/index', ['org' => $orgCode, 'canal' => $canal]);
    }

    /** GENERALE = tout membre actif de l'organisation ; FINANCES = permission voir_finances ; BUREAU = rôle autre que MEMBRE. */
    private function canAccessCanal(array $user, string $orgCode, string $canal): bool
    {
        if ($canal === 'GENERALE') {
            return true;
        }
        if ($canal === 'FINANCES') {
            return Middleware::can($orgCode, 'voir_finances');
        }

        // BUREAU
        if ($user['type_compte'] === 'SUPER_ADMIN') {
            return true;
        }
        $org = OrganisationModel::findByCode($orgCode);
        if ($org && $org['admin_user_code'] === $user['user_code']) {
            return true;
        }
        $membership = OrganisationUserModel::find($user['user_code'], $orgCode);
        if (!$membership || !$membership['role_code']) {
            return false;
        }
        $role = RoleModel::findByCode($membership['role_code']);
        return $role && $role['nom_role'] !== 'MEMBRE';
    }
}
