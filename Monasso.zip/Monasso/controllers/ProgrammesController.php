<?php

class ProgrammesController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_projets');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('programmes/index', [
            'organisation' => $org,
            'programmes' => ProgrammeModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_projets');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $objectif = trim($_POST['objectif_beneficiaires'] ?? '');

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.name_required');
            }
            if ($objectif !== '' && (!ctype_digit($objectif) || (int) $objectif <= 0)) {
                $errors[] = t('validation.montant_positive');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('programmes/creer', ['org' => $orgCode]);
            }

            $programme = ProgrammeModel::create([
                'organisation_code' => $orgCode,
                'nom' => $nom,
                'description' => $description,
                'objectif_beneficiaires' => $objectif,
            ]);

            Audit::log($user['user_code'], $orgCode, 'CREATE_PROGRAMME', $programme['programme_code'], ['nom' => $nom]);

            redirect_route('programmes/index', ['org' => $orgCode]);
        }

        View::render('programmes/creer', ['organisation' => $org, 'errors' => flash_get('errors', [])]);
    }

    public function cloturer(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_projets');
        $code = $_POST['id'] ?? '';
        $programme = ProgrammeModel::findByCode($code);

        if ($programme && $programme['organisation_code'] === $orgCode) {
            ProgrammeModel::updateStatut($code, 'TERMINE');
            Audit::log($user['user_code'], $orgCode, 'CLOTURER_PROGRAMME', $code);
        }

        redirect_route('programmes/index', ['org' => $orgCode]);
    }
}
