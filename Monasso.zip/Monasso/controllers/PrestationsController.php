<?php

class PrestationsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_prestations');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('prestations/index', [
            'organisation' => $org,
            'prestations' => PrestationModel::listByOrganisation($orgCode),
        ]);
    }

    /** Un membre actif de l'organisation dépose sa propre demande de prise en charge. */
    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $motif = trim($_POST['motif'] ?? '');
            $montant = trim($_POST['montant'] ?? '');

            $errors = [];
            if ($motif === '') {
                $errors[] = t('validation.libelle_required');
            }
            if ($montant === '' || !is_numeric($montant) || (float) $montant <= 0) {
                $errors[] = t('validation.montant_positive');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('prestations/creer', ['org' => $orgCode]);
            }

            $prestation = PrestationModel::create([
                'organisation_code' => $orgCode,
                'user_code' => $user['user_code'],
                'motif' => $motif,
                'montant' => $montant,
            ]);

            Audit::log($user['user_code'], $orgCode, 'CREATE_PRESTATION', $prestation['prestation_code'], ['motif' => $motif]);

            flash_set('success', t('prestations.creer.success'));
            redirect_route('prestations/creer', ['org' => $orgCode]);
        }

        View::render('prestations/creer', [
            'organisation' => $org,
            'errors' => flash_get('errors', []),
            'success' => flash_get('success'),
            'mesPrestations' => array_values(array_filter(
                PrestationModel::listByOrganisation($orgCode),
                fn ($p) => $p['user_code'] === $user['user_code']
            )),
        ]);
    }

    public function decider(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_prestations');
        $code = $_POST['id'] ?? '';
        $decision = $_POST['decision'] ?? '';

        $prestation = PrestationModel::findByCode($code);
        $validDecisions = ['APPROUVE' => true, 'REJETE' => true, 'PAYE' => true];

        if ($prestation && $prestation['organisation_code'] === $orgCode && isset($validDecisions[$decision])) {
            PrestationModel::updateStatut($code, $decision);
            Audit::log($user['user_code'], $orgCode, 'DECIDER_PRESTATION', $code, ['statut' => $decision]);

            NotificationModel::create(
                $prestation['user_code'],
                $orgCode,
                'PRESTATION_DECIDEE',
                t('notif.prestation_decidee.title'),
                t('notif.prestation_decidee.message', ['statut' => enum_label('prestation_statut', $decision)])
            );
        }

        redirect_route('prestations/index', ['org' => $orgCode]);
    }
}
