<?php

class LanguageController
{
    public function switch(): void
    {
        $lang = $_GET['lang'] ?? '';
        Lang::set($lang);

        $this->redirectBack();
    }

    public function country(): void
    {
        $pays = $_GET['pays'] ?? '';
        Lang::setCountry($pays);

        $this->redirectBack();
    }

    private function redirectBack(): void
    {
        $back = $_GET['back'] ?? '';
        $isSafeLocalPath = $back !== '' && $back[0] === '/' && (!isset($back[1]) || $back[1] !== '/');
        if ($isSafeLocalPath) {
            header('Location: ' . $back);
            exit;
        }

        redirect_route('home/index');
    }
}
