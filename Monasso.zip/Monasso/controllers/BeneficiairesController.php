<?php

class BeneficiairesController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_beneficiaires');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('beneficiaires/index', [
            'organisation' => $org,
            'beneficiaires' => BeneficiaireModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_beneficiaires');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $contact = trim($_POST['contact'] ?? '');
            $notes = trim($_POST['notes'] ?? '');
            $programmeCode = trim($_POST['programme_code'] ?? '');
            if ($programmeCode !== '') {
                $programme = ProgrammeModel::findByCode($programmeCode);
                if (!$programme || $programme['organisation_code'] !== $orgCode) {
                    $programmeCode = '';
                }
            }

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.name_required');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('beneficiaires/creer', ['org' => $orgCode]);
            }

            $beneficiaire = BeneficiaireModel::create([
                'organisation_code' => $orgCode,
                'programme_code' => $programmeCode,
                'nom' => $nom,
                'contact' => $contact,
                'notes' => $notes,
            ]);

            Audit::log($user['user_code'], $orgCode, 'CREATE_BENEFICIAIRE', $beneficiaire['beneficiaire_code'], ['nom' => $nom]);

            redirect_route('beneficiaires/index', ['org' => $orgCode]);
        }

        View::render('beneficiaires/creer', [
            'organisation' => $org,
            'programmes' => ProgrammeModel::listByOrganisation($orgCode),
            'errors' => flash_get('errors', []),
        ]);
    }
}
