<?php

class DashboardController
{
    public function index(): void
    {
        $user = Middleware::requireLogin();
        $data = ['user' => $user, 'kpis' => [], 'richFinance' => null, 'richPlatform' => null, 'richMembre' => null, 'richOng' => null, 'richMutuelle' => null];

        if ($user['type_compte'] === 'SUPER_ADMIN') {
            $orgs = OrganisationModel::all();
            $data['kpis'] = [
                ['label' => t('kpi.organisations'), 'value' => (string) count($orgs)],
                ['label' => t('kpi.pending_validation'), 'value' => (string) count(array_filter($orgs, fn ($o) => $o['statut_validation'] === 'ATT'))],
                ['label' => t('kpi.active_subscriptions'), 'value' => (string) count(array_filter($orgs, fn ($o) => $o['statut_abonnement'] === 'ACT')), 'accent' => true],
            ];
            $data['richPlatform'] = self::buildRichPlatform($orgs);
        } elseif ($user['type_compte'] === 'ADMIN_ORGA') {
            $org = OrganisationModel::findByAdmin($user['user_code']);
            $data['organisation'] = $org;
            if ($org && $org['statut_validation'] === 'VAL') {
                $members = OrganisationUserModel::listByOrganisation($org['organisation_code']);
                $stats = PaiementModel::statsForOrganisation($org['organisation_code']);
                $data['kpis'] = [
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                    ['label' => t('kpi.subscription_status'), 'value' => enum_label('org_statut_abonnement', $org['statut_abonnement']), 'accent' => true],
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                ];
                self::attachTypeSpecificDashboard($data, $org['type_organisation'], $org['organisation_code']);
            }
        } else {
            $membership = OrganisationUserModel::primaryActiveMembership($user['user_code']);
            $roleName = $membership['nom_role'] ?? null;
            $orgCode = $membership['organisation_code'] ?? null;
            $data['roleName'] = $roleName;
            $data['roleOrgName'] = $membership['organisation_nom'] ?? null;
            $data['showJoinPrompt'] = !$membership;

            if ($membership && $roleName === 'PRESIDENT') {
                $members = OrganisationUserModel::listByOrganisation($orgCode);
                $stats = PaiementModel::statsForOrganisation($orgCode);
                $org = OrganisationModel::findByCode($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                    ['label' => t('kpi.subscription_status'), 'value' => enum_label('org_statut_abonnement', $org['statut_abonnement'] ?? 'EXP'), 'accent' => true],
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                ];
                self::attachTypeSpecificDashboard($data, $org['type_organisation'] ?? 'ASSOCIATION', $orgCode);
            } elseif ($membership && $roleName === 'SECRETAIRE') {
                $members = OrganisationUserModel::listByOrganisation($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                ];
            } elseif ($membership && $roleName === 'TRESORIER') {
                $stats = PaiementModel::statsForOrganisation($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.amount_to_collect'), 'value' => format_money($stats['due_amount'])],
                    ['label' => t('kpi.payment_rate'), 'value' => $stats['paid_rate'] . '%'],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                ];
                $orgForType = OrganisationModel::findByCode($orgCode);
                self::attachTypeSpecificDashboard($data, $orgForType['type_organisation'] ?? 'ASSOCIATION', $orgCode);
            } else {
                $memberships = OrganisationUserModel::listByUser($user['user_code']);
                $paiements = PaiementModel::listByUser($user['user_code']);
                $duePaiements = array_values(array_filter($paiements, fn ($p) => $p['statut_paiement'] === 'DU'));
                $data['memberships'] = $memberships;
                $data['kpis'] = [
                    ['label' => t('kpi.joined_orgs'), 'value' => (string) count($memberships)],
                    ['label' => t('kpi.dues_due'), 'value' => (string) count($duePaiements)],
                    ['label' => t('kpi.dues_paid'), 'value' => (string) count(array_filter($paiements, fn ($p) => $p['statut_paiement'] === 'PAY'))],
                ];
                $data['richMembre'] = self::buildRichMembre($user['user_code'], $memberships, $duePaiements);
            }
        }

        View::render('dashboard/index', $data);
    }

    /** Assemble la vue d'ensemble d'un membre simple : ses organisations, cotisations dues, cartes, événements à venir. */
    private static function buildRichMembre(string $userCode, array $memberships, array $duePaiements): array
    {
        $montantDu = array_sum(array_map(fn ($p) => (float) $p['montant'], $duePaiements));
        $cartes = CarteModel::listForUser($userCode);

        return [
            'memberships' => $memberships,
            'montantDu' => $montantDu,
            'duePaiements' => array_slice($duePaiements, 0, 5),
            'cartesActives' => count(array_filter($cartes, fn ($c) => $c['statut'] === 'ACTIF')),
            'cartesTotal' => count($cartes),
            'evenements' => array_slice(EvenementModel::listUpcomingForUser($userCode), 0, 5),
        ];
    }

    /** Assemble la vue d'ensemble plateforme (cartes, graphiques, organisations en attente) pour le Super Admin. */
    private static function buildRichPlatform(array $orgs): array
    {
        $validationCounts = ['ATT' => 0, 'VAL' => 0, 'REF' => 0];
        $typeCounts = ['ASSOCIATION' => 0, 'ONG' => 0, 'MUTUELLE' => 0];
        $paysCounts = [];

        foreach ($orgs as $org) {
            $validationCounts[$org['statut_validation']] = ($validationCounts[$org['statut_validation']] ?? 0) + 1;
            $typeCounts[$org['type_organisation']] = ($typeCounts[$org['type_organisation']] ?? 0) + 1;
            $paysCounts[$org['pays_code']] = ($paysCounts[$org['pays_code']] ?? 0) + 1;
        }
        arsort($paysCounts);

        $trend = [];
        for ($i = 5; $i >= 0; $i--) {
            $timestamp = strtotime("first day of -$i month");
            $trend[] = [
                'label' => t('month.' . date('m', $timestamp)) . ' ' . date('Y', $timestamp),
                'count' => OrganisationModel::countCreatedInMonth((int) date('Y', $timestamp), (int) date('m', $timestamp)),
            ];
        }

        $pendingOrgs = array_values(array_filter($orgs, fn ($o) => $o['statut_validation'] === 'ATT'));

        return [
            'kpis' => [
                'total_users' => UserModel::countAll(),
                'total_active_members' => OrganisationUserModel::countActiveAll(),
            ],
            'validationCounts' => $validationCounts,
            'typeCounts' => $typeCounts,
            'paysCounts' => $paysCounts,
            'orgsTrend' => $trend,
            'pendingOrgs' => array_slice($pendingOrgs, 0, 5),
            'pendingCount' => count($pendingOrgs),
        ];
    }

    /** Aiguille vers le bloc de tableau de bord adapté au type d'organisation (Association/ONG/Mutuelle). */
    private static function attachTypeSpecificDashboard(array &$data, string $typeOrganisation, string $orgCode): void
    {
        if ($typeOrganisation === 'ONG') {
            $data['richOng'] = self::buildRichOng($orgCode);
        } elseif ($typeOrganisation === 'MUTUELLE') {
            $data['richMutuelle'] = self::buildRichMutuelle($orgCode);
        } else {
            $data['richFinance'] = self::buildRichFinance($orgCode);
        }
    }

    /** Assemble le tableau de bord "Programmes & bénéficiaires" pour une organisation de type ONG. */
    private static function buildRichOng(string $orgCode): array
    {
        $programmes = ProgrammeModel::listByOrganisation($orgCode);
        $beneficiairesByProgramme = BeneficiaireModel::countByProgramme($orgCode);
        $bailleurs = BailleurFondsModel::listByOrganisation($orgCode);

        $programmesAvancement = array_map(function ($p) use ($beneficiairesByProgramme) {
            $atteints = $beneficiairesByProgramme[$p['programme_code']] ?? 0;
            $objectif = (int) ($p['objectif_beneficiaires'] ?? 0);
            $p['beneficiaires_atteints'] = $atteints;
            $p['pourcentage'] = $objectif > 0 ? min(100, (int) round(($atteints / $objectif) * 100)) : 0;
            return $p;
        }, array_filter($programmes, fn ($p) => $p['statut'] === 'EN_COURS'));

        return [
            'kpis' => [
                'programmes_actifs' => ProgrammeModel::countActifs($orgCode),
                'beneficiaires_total' => BeneficiaireModel::countByOrganisation($orgCode),
                'bailleurs_actifs' => BailleurFondsModel::countActifs($orgCode),
                'rapports_dus' => count(array_filter($bailleurs, fn ($b) => $b['statut'] === 'RAPPORT_DU')),
            ],
            'programmes' => array_slice($programmesAvancement, 0, 5),
            'bailleurs' => array_slice($bailleurs, 0, 5),
            'orgCode' => $orgCode,
        ];
    }

    /** Assemble le tableau de bord "Prestations & fonds de solidarité" pour une organisation de type Mutuelle. */
    private static function buildRichMutuelle(string $orgCode): array
    {
        $today = date('Y-m-d');
        $year = (int) date('Y');
        $month = (int) date('m');

        $members = OrganisationUserModel::listByOrganisation($orgCode);
        $activeMembers = array_filter($members, fn ($m) => $m['statut'] === 'ACT');

        $prestationStats = PrestationModel::stats($orgCode);
        $fondsTotal = FinanceModel::treasuryBalanceAsOf($orgCode, $today);
        $fondsDisponible = max(0, $fondsTotal - $prestationStats['total_engage']);
        $fondsPourcentDisponible = $fondsTotal > 0 ? (int) round(($fondsDisponible / $fondsTotal) * 100) : 0;

        return [
            'kpis' => [
                'cotisants_actifs' => count($activeMembers),
                'demandes_attente' => $prestationStats['nb_en_attente'],
                'fonds_solidarite' => $fondsTotal,
                'rembourse_mois' => PrestationModel::totalPayeForMonth($orgCode, $year, $month),
            ],
            'demandesEnAttente' => array_slice(PrestationModel::listEnAttente($orgCode), 0, 5),
            'fondsDisponiblePourcent' => $fondsPourcentDisponible,
            'fondsDisponible' => $fondsDisponible,
            'fondsEngage' => $prestationStats['total_engage'],
            'orgCode' => $orgCode,
        ];
    }

    /** Assemble le tableau de bord financier riche (cartes, graphiques, tableaux, alertes) pour une organisation. */
    private static function buildRichFinance(string $orgCode): array
    {
        $today = date('Y-m-d');
        $year = (int) date('Y');
        $month = (int) date('m');
        $lastDayPrevMonth = date('Y-m-d', strtotime('last day of -1 month'));

        $members = OrganisationUserModel::listByOrganisation($orgCode);
        $activeMembers = array_filter($members, fn ($m) => $m['statut'] === 'ACT');
        $newThisMonth = array_filter($activeMembers, function ($m) use ($year, $month) {
            return $m['date_adhesion'] && (int) date('Y', strtotime($m['date_adhesion'])) === $year
                && (int) date('m', strtotime($m['date_adhesion'])) === $month;
        });

        $tresorerieActuelle = FinanceModel::treasuryBalanceAsOf($orgCode, $today);
        $tresoreriePrevMonth = FinanceModel::treasuryBalanceAsOf($orgCode, $lastDayPrevMonth);

        $statutCounts = PaiementModel::countByStatutForMonth($orgCode, $year, $month);
        $totalCotisMois = array_sum($statutCounts);
        $tauxPaye = $totalCotisMois > 0 ? round(($statutCounts['PAY'] / $totalCotisMois) * 100) : 0;

        $depensesMois = DepenseModel::totalForMonth($orgCode, $year, $month);

        return [
            'kpis' => [
                'total_membres' => count($activeMembers),
                'nouveaux_ce_mois' => count($newThisMonth),
                'tresorerie' => $tresorerieActuelle,
                'tresorerie_delta' => $tresorerieActuelle - $tresoreriePrevMonth,
                'taux_cotisations_mois' => $tauxPaye,
                'depenses_mois' => $depensesMois,
            ],
            'treasuryTrend' => FinanceModel::treasuryTrend($orgCode, 6),
            'cotisationStatus' => $statutCounts,
            'topDepenses' => DepenseModel::topForMonth($orgCode, $year, $month, 5),
            'lateMembers' => PaiementModel::listLateMembers($orgCode, 5),
            'recentActivity' => FinanceModel::recentActivity($orgCode, 5),
            'alertCount' => PaiementModel::countLateSinceMonths($orgCode, 3),
            'orgCode' => $orgCode,
        ];
    }
}
