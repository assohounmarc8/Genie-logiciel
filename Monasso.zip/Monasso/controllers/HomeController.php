<?php

class HomeController
{
    public function index(): void
    {
        $orgsValidees = OrganisationModel::allValidated();
        $countriesCovered = count(array_unique(array_column($orgsValidees, 'pays_code')));

        View::render('home/index', [
            'statOrgs' => count($orgsValidees),
            'statMembres' => OrganisationUserModel::countActiveAll(),
            'statCountries' => $countriesCovered,
        ]);
    }
}
