<?php

/**
 * Page de paiement du droit d'adhésion — atteinte depuis le bouton "Payer" d'une notification
 * in-app (pas d'email avec lien). Connexion requise, et seul le membre concerné peut payer sa
 * propre adhésion.
 */
class AdhesionController
{
    public function payer(): void
    {
        $user = Middleware::requireLogin();
        $token = $_GET['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }
        if ($paiement['user_code'] !== $user['user_code']) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $org = OrganisationModel::findByCode($paiement['organisation_code']);
        $membre = UserModel::findByCode($paiement['user_code']);
        $membership = OrganisationUserModel::find($paiement['user_code'], $paiement['organisation_code']);

        View::render('adhesion/payer', [
            'paiement' => $paiement,
            'organisation' => $org,
            'membre' => $membre,
            'numeroAdherent' => $membership['numero_adherent'] ?? '',
            'errors' => flash_get('errors', []),
        ]);
    }

    public function confirmerPaiement(): void
    {
        $user = Middleware::requireLogin();
        $token = $_POST['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }
        if ($paiement['user_code'] !== $user['user_code']) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        if ($paiement['statut'] === 'EN_ATTENTE') {
            $modePaiement = $_POST['mode_paiement'] ?? '';
            if (!in_array($modePaiement, modes_paiement(), true)) {
                flash_set('errors', [t('validation.mode_paiement_invalid')]);
                redirect_route('adhesion/payer', ['token' => $token]);
            }

            AdhesionPaiementModel::markPaid($paiement['adhesion_paiement_code'], $modePaiement);
            OrganisationUserModel::activate($paiement['user_code'], $paiement['organisation_code']);

            Audit::log($paiement['user_code'], $paiement['organisation_code'], 'PAY_ADHESION', $paiement['adhesion_paiement_code'], [
                'montant' => $paiement['montant'],
                'mode_paiement' => $modePaiement,
            ]);

            $org = OrganisationModel::findByCode($paiement['organisation_code']);
            $membre = UserModel::findByCode($paiement['user_code']);
            $membership = OrganisationUserModel::find($paiement['user_code'], $paiement['organisation_code']);

            // Mail 2/2 du parcours d'adhésion payante : message de bienvenue révélant le code
            // adhérent complet (PAYS-TYPE-ORGA-PERSO), maintenant que le paiement est confirmé.
            Mailer::send(
                $membre['email'],
                $membre['nom'],
                t('mail.adhesion_payee.subject', ['org' => $org['nom']]),
                mail_template(
                    t('mail.adhesion_payee.subject', ['org' => $org['nom']]),
                    '<p>' . t('mail.adhesion_payee.body', ['org' => $org['nom'], 'numero' => $membership['numero_adherent'] ?? '']) . '</p>'
                ),
                'ADHESION_PAYEE',
                $paiement['user_code'],
                $paiement['organisation_code']
            );

            NotificationModel::create(
                $paiement['user_code'],
                $paiement['organisation_code'],
                'MEMBER_ACCEPTED',
                t('notif.member_accepted.title'),
                t('notif.member_accepted.message', ['org' => $org['nom'] ?? $paiement['organisation_code']])
            );
        }

        redirect_route('adhesion/merci', ['token' => $token]);
    }

    public function merci(): void
    {
        $user = Middleware::requireLogin();
        $token = $_GET['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement || $paiement['user_code'] !== $user['user_code']) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $org = OrganisationModel::findByCode($paiement['organisation_code']);
        View::render('adhesion/merci', ['paiement' => $paiement, 'organisation' => $org]);
    }
}
