<?php

/**
 * Opportunités (financement/subvention, bénévolat, partenariat) publiées par le Super Admin et
 * consultables/candidatables par les organisations connectées. Le versement des financements
 * accordés se fait ici (OpportuniteVersementModel) plutôt que via BesoinModel/DonModel, car le sens
 * du flux financier est inversé : l'argent va de l'émetteur de l'opportunité vers l'association.
 */
class OpportunitesController
{
    /** Recherche/liste des opportunités — accessible à tout utilisateur connecté. */
    public function index(): void
    {
        $user = Middleware::requireLogin();

        $filters = [
            'q' => trim($_GET['q'] ?? ''),
            'type' => $_GET['type'] ?? '',
            'pays' => $_GET['pays'] ?? '',
            // Pas de filtre statut explicite => OpportuniteModel::search() montre ACTIF + FERME
            // (tout le monde doit voir qu'une opportunité fermée n'est plus disponible) mais masque
            // ARCHIVE (c'est justement le but de l'archivage : désencombrer le menu une fois qu'une
            // opportunité est classée). Seul le Super Admin a un sélecteur de statut dans l'UI pour
            // consulter explicitement les opportunités archivées ("Opportunités passées").
            'statut' => $_GET['statut'] ?? null,
        ];

        $opportunites = OpportuniteModel::search($filters);

        $orgContext = $this->organisationContext($user);
        $candidaturesByOpportunite = [];
        if ($orgContext) {
            foreach ($opportunites as $opp) {
                $candidature = OpportuniteCandidatureModel::findByOpportuniteAndOrganisation($opp['opportunite_code'], $orgContext['organisation_code']);
                if ($candidature) {
                    $candidaturesByOpportunite[$opp['opportunite_code']] = $candidature;
                }
            }
        }

        View::render('opportunites/index', [
            'opportunites' => $opportunites,
            'filters' => $filters,
            'orgContext' => $orgContext,
            'candidaturesByOpportunite' => $candidaturesByOpportunite,
            'isSuperAdmin' => $user['type_compte'] === 'SUPER_ADMIN',
        ]);
    }

    public function creer(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $type = $_POST['type_opportunite'] ?? '';
            $titre = trim($_POST['titre'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $montantRaw = trim($_POST['montant'] ?? '');
            $paysCode = $_POST['pays_code'] ?? '';
            $dateLimite = trim($_POST['date_limite'] ?? '');
            $nomContact = trim($_POST['nom_contact'] ?? '');
            $emailContact = trim($_POST['email_contact'] ?? '');

            $errors = [];
            if (!TypeOpportuniteModel::exists($type)) {
                $errors[] = t('validation.opportunite_type_invalid');
            }
            if ($titre === '') {
                $errors[] = t('validation.name_required');
            }
            if ($description === '') {
                $errors[] = t('validation.libelle_required');
            }
            if ($montantRaw !== '' && (!is_numeric($montantRaw) || (float) $montantRaw <= 0)) {
                $errors[] = t('validation.montant_positive');
            }
            if ($paysCode !== '' && !PaysModel::exists($paysCode)) {
                $errors[] = t('validation.country_invalid');
            }
            if ($emailContact !== '' && !filter_var($emailContact, FILTER_VALIDATE_EMAIL)) {
                $errors[] = t('validation.email_contact_invalid');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('opportunites/creer');
            }

            $opportunite = OpportuniteModel::create([
                'type_opportunite' => $type,
                'titre' => $titre,
                'description' => $description,
                'montant' => $montantRaw !== '' ? (float) $montantRaw : null,
                'pays_code' => $paysCode,
                'date_limite' => $dateLimite,
                'cree_par_user_code' => $user['user_code'],
                'nom_contact' => $nomContact,
                'email_contact' => $emailContact,
            ]);

            Audit::log($user['user_code'], null, 'CREATE_OPPORTUNITE', $opportunite['opportunite_code'], [
                'titre' => $titre,
                'type' => $type,
            ]);

            redirect_route('opportunites/detail', ['id' => $opportunite['opportunite_code']]);
        }

        View::render('opportunites/creer', []);
    }

    public function detail(): void
    {
        $user = Middleware::requireLogin();
        $code = $_GET['id'] ?? '';
        $opportunite = OpportuniteModel::findDetailByCode($code);
        if (!$opportunite) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgContext = $this->organisationContext($user);
        $candidature = null;
        $versements = [];
        $totalVerse = 0.0;
        $peutPostuler = false;

        if ($orgContext) {
            $candidature = OpportuniteCandidatureModel::findByOpportuniteAndOrganisation($code, $orgContext['organisation_code']);
            if ($candidature) {
                $versements = OpportuniteVersementModel::listByCandidature($candidature['candidature_code']);
                $totalVerse = OpportuniteCandidatureModel::totalVerse($candidature['candidature_code']);
            } else {
                $peutPostuler = $opportunite['statut'] === 'ACTIF'
                    && Middleware::can($orgContext['organisation_code'], 'postuler_opportunites');
            }
        }

        View::render('opportunites/detail', [
            'opportunite' => $opportunite,
            'orgContext' => $orgContext,
            'candidature' => $candidature,
            'versements' => $versements,
            'totalVerse' => $totalVerse,
            'peutPostuler' => $peutPostuler,
            'isSuperAdmin' => $user['type_compte'] === 'SUPER_ADMIN',
            'peutArchiver' => $opportunite['statut'] === 'FERME',
            'errors' => flash_get('errors', []),
        ]);
    }

    public function postuler(): void
    {
        $user = Middleware::requireLogin();
        $code = $_POST['id'] ?? '';
        $opportunite = OpportuniteModel::findByCode($code);
        if (!$opportunite) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgContext = $this->organisationContext($user);
        if (!$orgContext) {
            flash_set('errors', [t('opportunites.postuler.no_org')]);
            redirect_route('opportunites/detail', ['id' => $code]);
        }
        Middleware::requirePermission($orgContext['organisation_code'], 'postuler_opportunites');

        if ($opportunite['statut'] !== 'ACTIF') {
            flash_set('errors', [t('opportunites.postuler.closed')]);
            redirect_route('opportunites/detail', ['id' => $code]);
        }
        if (OpportuniteCandidatureModel::findByOpportuniteAndOrganisation($code, $orgContext['organisation_code'])) {
            flash_set('errors', [t('opportunites.postuler.already')]);
            redirect_route('opportunites/detail', ['id' => $code]);
        }

        $message = trim($_POST['message'] ?? '');
        if ($message === '') {
            flash_set('errors', [t('validation.message_required')]);
            redirect_route('opportunites/detail', ['id' => $code]);
        }

        $candidature = OpportuniteCandidatureModel::create([
            'opportunite_code' => $code,
            'organisation_code' => $orgContext['organisation_code'],
            'user_code' => $user['user_code'],
            'message' => $message,
        ]);

        Audit::log($user['user_code'], $orgContext['organisation_code'], 'POSTULER_OPPORTUNITE', $candidature['candidature_code'], [
            'opportunite' => $code,
        ]);

        if (!empty($opportunite['email_contact'])) {
            $this->envoyerMagicLinkEntreprise($opportunite, $candidature, $orgContext);
        }

        redirect_route('opportunites/detail', ['id' => $code]);
    }

    /**
     * Envoie à l'entreprise/partenaire (email_contact de l'opportunité, pas de compte MONASSO requis)
     * un e-mail avec deux liens "magic link" (jeton à usage unique) pour accepter ou refuser la
     * candidature reçue, sans authentification. Le clic ouvre une page de confirmation publique
     * (opportunites/decider) plutôt que de trancher directement sur le simple GET, pour éviter
     * qu'un scanner anti-spam qui pré-charge les liens du mail ne déclenche la décision à la place
     * du destinataire.
     */
    private function envoyerMagicLinkEntreprise(array $opportunite, array $candidature, array $organisation): void
    {
        $token = OpportuniteCandidatureModel::generateResponseToken($candidature['candidature_code']);

        $lienAccepter = route_url('opportunites/decider', ['token' => $token, 'decision' => 'accept']);
        $lienRefuser = route_url('opportunites/decider', ['token' => $token, 'decision' => 'reject']);

        $body = '<p>' . h(t('mail.candidature_a_traiter.intro', [
            'organisation' => $organisation['nom'],
            'titre' => $opportunite['titre'],
        ])) . '</p>'
            . '<p>' . nl2br(h($candidature['message'])) . '</p>'
            . '<div style="margin:24px 0;text-align:center;">'
            . '<a href="' . h($lienAccepter) . '" style="background:#2f6b4a;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;margin-right:12px;">'
            . h(t('mail.candidature_a_traiter.accept_btn')) . '</a>'
            . '<a href="' . h($lienRefuser) . '" style="background:#b91c1c;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:bold;">'
            . h(t('mail.candidature_a_traiter.refuse_btn')) . '</a>'
            . '</div>';

        Mailer::send(
            $opportunite['email_contact'],
            $opportunite['nom_contact'] ?: $opportunite['email_contact'],
            t('mail.candidature_a_traiter.subject', ['titre' => $opportunite['titre']]),
            mail_template(t('mail.candidature_a_traiter.title'), $body),
            'CANDIDATURE_OPPORTUNITE_A_TRAITER',
            null,
            $organisation['organisation_code']
        );
    }

    /**
     * Suivi Super Admin des candidatures reçues sur une opportunité — lecture seule : la décision
     * (accepter/refuser) appartient désormais exclusivement à l'entreprise via le magic link reçu
     * par e-mail (cf. decider()), pas au Super Admin. Présenté en Kanban : "En attente" vs
     * "Abouties" (candidatures tranchées, acceptées ou refusées par l'entreprise).
     */
    public function candidatures(): void
    {
        Middleware::requireType(['SUPER_ADMIN']);
        $code = $_GET['id'] ?? '';
        $opportunite = OpportuniteModel::findByCode($code);
        if (!$opportunite) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $candidatures = OpportuniteCandidatureModel::listByOpportunite($code);
        $enAttente = array_values(array_filter($candidatures, fn ($c) => $c['statut'] === 'EN_ATTENTE'));
        $abouties = array_values(array_filter($candidatures, fn ($c) => $c['statut'] !== 'EN_ATTENTE'));

        $versementsByCandidature = [];
        $totalVerseByCandidature = [];
        foreach ($candidatures as $candidature) {
            $versementsByCandidature[$candidature['candidature_code']] = OpportuniteVersementModel::listByCandidature($candidature['candidature_code']);
            $totalVerseByCandidature[$candidature['candidature_code']] = OpportuniteCandidatureModel::totalVerse($candidature['candidature_code']);
        }

        View::render('opportunites/candidatures', [
            'opportunite' => $opportunite,
            'enAttente' => $enAttente,
            'abouties' => $abouties,
            'versementsByCandidature' => $versementsByCandidature,
            'totalVerseByCandidature' => $totalVerseByCandidature,
            'errors' => flash_get('errors', []),
        ]);
    }

    /**
     * Point 4 de la demande "notification interne pour l'association" : dépose une notification
     * in-app pour l'admin de l'organisation candidate (déjà exploitée par la cloche + badge du
     * dashboard, cf. views/layout/start.php et NotificationModel::countUnread). Déclenchée
     * uniquement au moment où l'entreprise tranche via le magic link (decider()) — jamais avant.
     * En cas d'acceptation, le message inclut l'e-mail de contact de l'entreprise pour que
     * l'association puisse poursuivre les échanges. En cas de refus, il inclut le motif donné.
     */
    private function notifierDecisionCandidature(array $candidature, ?array $opportunite, string $statut, ?string $motif = null): void
    {
        if (!$opportunite) {
            return;
        }
        $organisation = OrganisationModel::findByCode($candidature['organisation_code']);
        if (!$organisation) {
            return;
        }

        if ($statut === 'ACCEPTEE') {
            $typeCode = 'CANDIDATURE_OPPORTUNITE_ACCEPTEE';
            $titre = t('notif.candidature_acceptee.title');
            $message = !empty($opportunite['email_contact'])
                ? t('notif.candidature_acceptee.message_avec_contact', [
                    'titre' => $opportunite['titre'],
                    'contact' => $opportunite['nom_contact'] ?: $opportunite['email_contact'],
                    'email' => $opportunite['email_contact'],
                ])
                : t('notif.candidature_acceptee.message', ['titre' => $opportunite['titre']]);
        } else {
            $typeCode = 'CANDIDATURE_OPPORTUNITE_REFUSEE';
            $titre = t('notif.candidature_refusee.title');
            $message = $motif !== null && $motif !== ''
                ? t('notif.candidature_refusee.message_avec_motif', ['titre' => $opportunite['titre'], 'motif' => $motif])
                : t('notif.candidature_refusee.message', ['titre' => $opportunite['titre']]);
        }

        NotificationModel::create(
            $organisation['admin_user_code'],
            $candidature['organisation_code'],
            $typeCode,
            $titre,
            $message,
            route_url('opportunites/detail', ['id' => $candidature['opportunite_code']])
        );
    }

    /**
     * Magic link entreprise — accessible publiquement via le jeton reçu par e-mail (aucune
     * authentification). GET : affiche un écran de confirmation (montant à saisir si l'opportunité
     * est de type FINANCEMENT et que la décision est "accept"). POST : exécute réellement la
     * décision. Séparer les deux évite qu'un simple clic — ou un pré-chargement automatique du lien
     * par un client mail/antispam — ne déclenche la décision sans confirmation explicite.
     */
    public function decider(): void
    {
        $token = $_GET['token'] ?? $_POST['token'] ?? '';
        $decision = $_GET['decision'] ?? $_POST['decision'] ?? '';
        if (!in_array($decision, ['accept', 'reject'], true)) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $candidature = OpportuniteCandidatureModel::findByToken($token);
        if (!$candidature) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if ($candidature['statut'] !== 'EN_ATTENTE') {
                View::render('opportunites/decider', ['etat' => 'deja_traitee', 'candidature' => $candidature]);
                return;
            }

            $opportunite = OpportuniteModel::findByCode($candidature['opportunite_code']);
            $montantAccorde = null;
            $motif = null;
            if ($decision === 'accept') {
                if ($opportunite['type_opportunite'] === 'FINANCEMENT') {
                    $montantRaw = trim($_POST['montant_accorde'] ?? '');
                    if ($montantRaw === '' || !is_numeric($montantRaw) || (float) $montantRaw <= 0) {
                        View::render('opportunites/decider', [
                            'etat' => 'confirmation',
                            'candidature' => $candidature,
                            'opportunite' => $opportunite,
                            'decision' => $decision,
                            'errors' => [t('validation.montant_positive')],
                        ]);
                        return;
                    }
                    $montantAccorde = (float) $montantRaw;
                }
                OpportuniteCandidatureModel::accepter($candidature['candidature_code'], $montantAccorde);
            } else {
                $motif = trim($_POST['motif_refus'] ?? '');
                if ($motif === '') {
                    View::render('opportunites/decider', [
                        'etat' => 'confirmation',
                        'candidature' => $candidature,
                        'opportunite' => $opportunite,
                        'decision' => $decision,
                        'errors' => [t('validation.motif_refus_required')],
                    ]);
                    return;
                }
                OpportuniteCandidatureModel::refuser($candidature['candidature_code'], $motif);
            }

            OpportuniteCandidatureModel::clearResponseToken($candidature['candidature_code']);
            Audit::log(null, $candidature['organisation_code'], $decision === 'accept' ? 'ACCEPTER_CANDIDATURE_OPPORTUNITE' : 'REFUSER_CANDIDATURE_OPPORTUNITE', $candidature['candidature_code'], [
                'via' => 'magic_link',
                'montant_accorde' => $montantAccorde,
                'motif_refus' => $motif,
            ]);
            $this->notifierDecisionCandidature($candidature, $opportunite, $decision === 'accept' ? 'ACCEPTEE' : 'REFUSEE', $motif);

            View::render('opportunites/decider', [
                'etat' => 'merci',
                'candidature' => $candidature,
                'opportunite' => $opportunite,
                'decision' => $decision,
            ]);
            return;
        }

        // GET : écran de confirmation avant exécution.
        if ($candidature['statut'] !== 'EN_ATTENTE') {
            View::render('opportunites/decider', ['etat' => 'deja_traitee', 'candidature' => $candidature]);
            return;
        }

        $opportunite = OpportuniteModel::findByCode($candidature['opportunite_code']);
        View::render('opportunites/decider', [
            'etat' => 'confirmation',
            'candidature' => $candidature,
            'opportunite' => $opportunite,
            'decision' => $decision,
            'errors' => [],
        ]);
    }

    /** Enregistre un versement de financement accordé — Super Admin uniquement, déclaratif (V1). */
    public function verser(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $candidatureCode = $_POST['id'] ?? '';
        $candidature = OpportuniteCandidatureModel::findByCode($candidatureCode);
        if (!$candidature || $candidature['statut'] !== 'ACCEPTEE') {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $montant = (float) ($_POST['montant'] ?? 0);
        $modePaiement = $_POST['mode_paiement'] ?? 'ESPECES';
        if (!MoyenPaiementModel::exists($modePaiement)) {
            $modePaiement = 'ESPECES';
        }
        $reference = trim($_POST['reference'] ?? '');

        $errors = [];
        if ($montant <= 0) {
            $errors[] = t('validation.montant_positive');
        }
        $dejaVerse = OpportuniteCandidatureModel::totalVerse($candidatureCode);
        if ($candidature['montant_accorde'] !== null && $montant > ((float) $candidature['montant_accorde'] - $dejaVerse) + 0.001) {
            $errors[] = t('validation.montant_depasse_accorde');
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('opportunites/candidatures', ['id' => $candidature['opportunite_code']]);
        }

        $versement = OpportuniteVersementModel::create([
            'candidature_code' => $candidatureCode,
            'montant' => $montant,
            'mode_paiement' => $modePaiement,
            'reference' => $reference,
        ]);

        Audit::log($user['user_code'], $candidature['organisation_code'], 'VERSER_OPPORTUNITE', $versement['versement_code'], [
            'montant' => $montant,
            'candidature' => $candidatureCode,
        ]);

        $organisation = OrganisationModel::findByCode($candidature['organisation_code']);
        $opportunite = OpportuniteModel::findByCode($candidature['opportunite_code']);
        if ($organisation && $opportunite) {
            NotificationModel::create(
                $organisation['admin_user_code'],
                $candidature['organisation_code'],
                'VERSEMENT_OPPORTUNITE',
                t('notif.versement_opportunite.title'),
                t('notif.versement_opportunite.message', ['titre' => $opportunite['titre'], 'montant' => format_money($montant)]),
                route_url('opportunites/detail', ['id' => $candidature['opportunite_code']])
            );
        }

        redirect_route('opportunites/candidatures', ['id' => $candidature['opportunite_code']]);
    }

    /**
     * Archive une opportunité — étape 2 d'un cycle en deux temps désormais imposé au Super Admin :
     * fermer() d'abord (tout le monde voit qu'elle n'est plus disponible, cf. index() qui montre
     * ACTIF + FERME par défaut), puis archiver() une fois que la fiche ne sert plus à rien (elle
     * disparaît alors du menu pour tout le monde, cf. OpportuniteModel::search() qui masque ARCHIVE
     * par défaut). L'historique — candidatures, versements, notifications — reste intact en base.
     */
    public function archiver(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        $opportunite = OpportuniteModel::findByCode($code);
        if (!$opportunite) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }
        if ($opportunite['statut'] !== 'FERME') {
            flash_set('errors', [t('opportunites.archiver.pas_fermee')]);
            redirect_route('opportunites/detail', ['id' => $code]);
        }

        OpportuniteModel::updateStatut($code, 'ARCHIVE');
        Audit::log($user['user_code'], null, 'ARCHIVER_OPPORTUNITE', $code, ['titre' => $opportunite['titre']]);

        redirect_route('opportunites/index');
    }

    /** Retire une opportunité de l'archive — la refait apparaître dans le menu avec son ancien statut FERME. */
    public function desarchiver(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        $opportunite = OpportuniteModel::findByCode($code);
        if (!$opportunite) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        OpportuniteModel::updateStatut($code, 'FERME');
        Audit::log($user['user_code'], null, 'DESARCHIVER_OPPORTUNITE', $code, ['titre' => $opportunite['titre']]);

        redirect_route('opportunites/detail', ['id' => $code]);
    }

    public function fermer(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        if (OpportuniteModel::findByCode($code)) {
            OpportuniteModel::updateStatut($code, 'FERME');
            Audit::log($user['user_code'], null, 'FERMER_OPPORTUNITE', $code);
        }
        redirect_route('opportunites/detail', ['id' => $code]);
    }

    public function reouvrir(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        if (OpportuniteModel::findByCode($code)) {
            OpportuniteModel::updateStatut($code, 'ACTIF');
            Audit::log($user['user_code'], null, 'ROUVRIR_OPPORTUNITE', $code);
        }
        redirect_route('opportunites/detail', ['id' => $code]);
    }

    /** Candidatures envoyées par l'organisation de l'utilisateur connecté (ADMIN_ORGA ou MEMBRE). */
    public function mesCandidatures(): void
    {
        $user = Middleware::requireLogin();
        $orgContext = $this->organisationContext($user);
        if (!$orgContext) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $candidatures = OpportuniteCandidatureModel::listByOrganisation($orgContext['organisation_code']);
        $totalVerseByCandidature = [];
        foreach ($candidatures as $candidature) {
            $totalVerseByCandidature[$candidature['candidature_code']] = OpportuniteCandidatureModel::totalVerse($candidature['candidature_code']);
        }

        View::render('opportunites/mes-candidatures', [
            'organisation' => $orgContext,
            'candidatures' => $candidatures,
            'totalVerseByCandidature' => $totalVerseByCandidature,
        ]);
    }

    /**
     * Résout l'organisation "active" de l'utilisateur connecté pour porter une candidature :
     * l'organisation administrée (ADMIN_ORGA) ou l'adhésion active principale (MEMBRE). Retourne
     * null pour un Super Admin ou un utilisateur sans organisation active — il ne peut pas postuler.
     */
    private function organisationContext(array $user): ?array
    {
        if ($user['type_compte'] === 'ADMIN_ORGA') {
            $org = OrganisationModel::findByAdmin($user['user_code']);
            return ($org && $org['statut_validation'] === 'VAL') ? $org : null;
        }

        if ($user['type_compte'] === 'MEMBRE') {
            $membership = OrganisationUserModel::primaryActiveMembership($user['user_code']);
            if (!$membership) {
                return null;
            }
            return OrganisationModel::findByCode($membership['organisation_code']);
        }

        return null;
    }
}
