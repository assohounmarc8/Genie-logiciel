<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
            <h1 class="page-title"><?= h(t('beneficiaires.index.title')) ?></h1>
        </div>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('beneficiaires/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('beneficiaires.index.new')) ?></a>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('beneficiaires.field.nom')) ?></th>
            <th><?= h(t('programmes.field.nom')) ?></th>
            <th><?= h(t('beneficiaires.field.contact')) ?></th>
            <th><?= h(t('common.date')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$beneficiaires): ?><tr><td colspan="4" class="table-empty"><?= h(t('beneficiaires.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($beneficiaires as $b): ?>
            <tr>
                <td style="font-weight:600;"><?= h($b['nom']) ?></td>
                <td><?= h($b['programme_nom'] ?? '—') ?></td>
                <td><?= h($b['contact'] ?? '—') ?></td>
                <td><?= h(format_date($b['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
