<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('beneficiaires.index.new')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('beneficiaires/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom"><?= h(t('beneficiaires.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="contact"><?= h(t('beneficiaires.field.contact')) ?></label>
                <input type="text" id="contact" name="contact" value="<?= h(old_input('contact')) ?>">
            </div>
            <?php if ($programmes): ?>
            <div class="field">
                <label for="programme_code"><?= h(t('programmes.field.nom')) ?></label>
                <select id="programme_code" name="programme_code">
                    <option value=""><?= h(t('common.none')) ?></option>
                    <?php foreach ($programmes as $p): ?>
                        <option value="<?= h($p['programme_code']) ?>" <?= old_input('programme_code') === $p['programme_code'] ? 'selected' : '' ?>><?= h($p['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="field">
                <label for="notes"><?= h(t('common.notes')) ?></label>
                <textarea id="notes" name="notes" rows="3"><?= h(old_input('notes')) ?></textarea>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('common.save')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
