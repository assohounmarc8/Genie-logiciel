<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('prestations.index.title')) ?></h1>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('prestations.field.membre')) ?></th>
            <th><?= h(t('prestations.field.motif')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th></th>
        </tr></thead>
        <tbody>
            <?php if (!$prestations): ?><tr><td colspan="5" class="table-empty"><?= h(t('prestations.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($prestations as $p): ?>
            <tr>
                <td style="font-weight:600;"><?= h($p['membre_nom']) ?></td>
                <td><?= h($p['motif']) ?></td>
                <td><?= h(format_money((float) $p['montant'])) ?></td>
                <td><?= enum_badge_html('prestation_statut', $p['statut']) ?></td>
                <td>
                    <?php if ($p['statut'] === 'EN_ATTENTE'): ?>
                    <div class="table-actions">
                        <form method="post" action="<?= h(route_url('prestations/decider')) ?>">
                            <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                            <input type="hidden" name="id" value="<?= h($p['prestation_code']) ?>">
                            <input type="hidden" name="decision" value="APPROUVE">
                            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('prestations.approve_btn')) ?></button>
                        </form>
                        <form method="post" action="<?= h(route_url('prestations/decider')) ?>">
                            <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                            <input type="hidden" name="id" value="<?= h($p['prestation_code']) ?>">
                            <input type="hidden" name="decision" value="REJETE">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('prestations.reject_btn')) ?></button>
                        </form>
                    </div>
                    <?php elseif ($p['statut'] === 'APPROUVE'): ?>
                    <form method="post" action="<?= h(route_url('prestations/decider')) ?>">
                        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                        <input type="hidden" name="id" value="<?= h($p['prestation_code']) ?>">
                        <input type="hidden" name="decision" value="PAYE">
                        <button type="submit" class="btn btn-accent btn-sm"><?= h(t('prestations.pay_btn')) ?></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
