<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('prestations.creer.title')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>
    <?php if ($success): ?>
        <div class="card" style="border-color:var(--green-line); background:var(--green-light);"><div class="card-body">
            <p><?= h($success) ?></p>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('prestations/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="motif"><?= h(t('prestations.field.motif')) ?></label>
                <input type="text" id="motif" name="motif" required value="<?= h(old_input('motif')) ?>" placeholder="<?= h(t('prestations.field.motif_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="montant"><?= h(t('common.amount')) ?></label>
                <input type="number" min="1" step="1" id="montant" name="montant" required value="<?= h(old_input('montant')) ?>">
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('prestations.submit_btn')) ?></button>
        </div>
    </form>

    <div>
        <p class="page-eyebrow mt-2"><?= h(t('prestations.creer.mine_title')) ?></p>
    </div>
    <div class="table-wrap"><table class="data-table">
        <thead><tr><th><?= h(t('prestations.field.motif')) ?></th><th><?= h(t('common.amount')) ?></th><th><?= h(t('common.status')) ?></th></tr></thead>
        <tbody>
            <?php if (!$mesPrestations): ?><tr><td colspan="3" class="table-empty"><?= h(t('prestations.creer.mine_empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($mesPrestations as $p): ?>
            <tr>
                <td><?= h($p['motif']) ?></td>
                <td><?= h(format_money((float) $p['montant'])) ?></td>
                <td><?= enum_badge_html('prestation_statut', $p['statut']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
