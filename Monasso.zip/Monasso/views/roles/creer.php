<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('roles.creer.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('roles/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom_role"><?= h(t('roles.field.nom')) ?></label>
                <input type="text" id="nom_role" name="nom_role" required list="role-suggestions" value="<?= h(old_input('nom_role')) ?>">
                <datalist id="role-suggestions">
                    <option value="PRESIDENT"></option>
                    <option value="TRESORIER"></option>
                    <option value="SECRETAIRE"></option>
                    <option value="MEMBRE"></option>
                </datalist>
            </div>
            <div class="field">
                <label for="parent_role_code"><?= h(t('roles.field.parent')) ?></label>
                <select id="parent_role_code" name="parent_role_code">
                    <option value=""><?= h(t('common.none')) ?></option>
                    <?php foreach ($existingRoles as $r): ?>
                        <option value="<?= h($r['role_code']) ?>"><?= h($r['nom_role']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label><?= h(t('common.permissions')) ?></label>
                <?php foreach ($allPermissions as $perm): ?>
                    <label class="field-check">
                        <input type="checkbox" name="permissions[]" value="<?= h($perm['permission_code']) ?>">
                        <?= h(t('perm.' . $perm['permission_code'])) ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('roles.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
