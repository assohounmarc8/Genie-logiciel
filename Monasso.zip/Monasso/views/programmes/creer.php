<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('programmes.index.new')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('programmes/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom"><?= h(t('programmes.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="description"><?= h(t('org.field.description')) ?></label>
                <textarea id="description" name="description" rows="3"><?= h(old_input('description')) ?></textarea>
            </div>
            <div class="field">
                <label for="objectif_beneficiaires"><?= h(t('programmes.field.objectif')) ?></label>
                <input type="number" min="1" step="1" id="objectif_beneficiaires" name="objectif_beneficiaires" value="<?= h(old_input('objectif_beneficiaires')) ?>">
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('common.save')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
