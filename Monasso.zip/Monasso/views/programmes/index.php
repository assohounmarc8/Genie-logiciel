<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
            <h1 class="page-title"><?= h(t('programmes.index.title')) ?></h1>
        </div>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('programmes/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('programmes.index.new')) ?></a>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('programmes.field.nom')) ?></th>
            <th><?= h(t('programmes.field.objectif')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th></th>
        </tr></thead>
        <tbody>
            <?php if (!$programmes): ?><tr><td colspan="4" class="table-empty"><?= h(t('programmes.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($programmes as $p): ?>
            <tr>
                <td>
                    <span style="font-weight:600;"><?= h($p['nom']) ?></span>
                    <?php if (!empty($p['description'])): ?><p class="text-faint mt-2" style="max-width:360px;"><?= h($p['description']) ?></p><?php endif; ?>
                </td>
                <td><?= $p['objectif_beneficiaires'] ? h((string) $p['objectif_beneficiaires']) . ' ' . h(t('programmes.field.beneficiaires_unit')) : '—' ?></td>
                <td><?= enum_badge_html('programme_statut', $p['statut']) ?></td>
                <td>
                    <?php if ($p['statut'] === 'EN_COURS'): ?>
                    <form method="post" action="<?= h(route_url('programmes/cloturer')) ?>">
                        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                        <input type="hidden" name="id" value="<?= h($p['programme_code']) ?>">
                        <button type="submit" class="btn btn-outline btn-sm"><?= h(t('programmes.close_btn')) ?></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
