<?php
/** @var array $organisation */
/** @var string $canal */
/** @var array $canaux */
/** @var array $messages */
/** @var string $currentUserCode */
$autoRefreshSeconds = 8;
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('nav.discussions')) ?></h1>
    </div>

    <div class="chat-shell">
        <div class="chat-channels">
            <p class="chat-channels-label"><?= h($organisation['nom']) ?></p>
            <?php foreach ($canaux as $c): ?>
                <a class="chat-channel<?= $c['code'] === $canal ? ' active' : '' ?>" href="<?= h(route_url('chat/index', ['org' => $organisation['organisation_code'], 'canal' => $c['code']])) ?>">
                    <div class="chat-channel-icon"><?= h(substr(t('chat.canal.' . $c['code']), 0, 1)) ?></div>
                    <div style="min-width:0;">
                        <p class="chat-channel-name"><?= h(t('chat.canal.' . $c['code'])) ?></p>
                        <p class="chat-channel-hint">
                            <?= $c['last'] ? h($c['last']['auteur_nom'] . ' : ' . mb_substr($c['last']['contenu'], 0, 28)) : h(t('chat.canal.' . $c['code'] . '.hint')) ?>
                        </p>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="chat-main">
            <div class="chat-header">
                <p class="card-title" style="margin:0;"><?= h(t('chat.canal.' . $canal)) ?></p>
                <p class="page-subtitle"><?= h($organisation['nom']) ?></p>
            </div>

            <div class="chat-thread" id="chat-thread">
                <?php if (!$messages): ?>
                    <p class="table-empty"><?= h(t('chat.empty')) ?></p>
                <?php endif; ?>
                <?php foreach ($messages as $msg): ?>
                    <div class="chat-msg<?= $msg['user_code'] === $currentUserCode ? ' mine' : '' ?>">
                        <span class="chat-msg-meta"><?= h($msg['auteur_nom']) ?> · <?= h(format_datetime($msg['created_at'])) ?></span>
                        <div class="chat-bubble"><?= nl2br(h($msg['contenu'])) ?></div>
                    </div>
                <?php endforeach; ?>
            </div>

            <form class="chat-composer" method="post" action="<?= h(route_url('chat/envoyer')) ?>">
                <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                <input type="hidden" name="canal" value="<?= h($canal) ?>">
                <input type="text" name="contenu" placeholder="<?= h(t('chat.placeholder')) ?>" autocomplete="off" required>
                <button type="submit" class="btn btn-primary"><?= h(t('chat.send')) ?></button>
            </form>
        </div>
    </div>
</div>
<script>
    (function () {
        var thread = document.getElementById('chat-thread');
        if (thread) { thread.scrollTop = thread.scrollHeight; }
    })();
</script>
<?php require APP_DIR . '/views/layout/end.php'; ?>
