<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('cotisations.creer.title', ['org' => $organisation['nom']])) ?></h1>
        <p class="page-subtitle"><?= h(t('cotisations.creer.subtitle')) ?></p>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('cotisations/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="libelle"><?= h(t('cotisations.col_libelle')) ?></label>
                <input type="text" id="libelle" name="libelle" required value="<?= h(old_input('libelle')) ?>" placeholder="<?= h(t('cotisations.field.libelle_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="montant"><?= h(t('common.amount')) ?></label>
                <input type="number" id="montant" name="montant" min="1" step="1" required value="<?= h(old_input('montant')) ?>">
            </div>
            <div class="field">
                <label for="devise"><?= h(t('cotisations.field.devise')) ?></label>
                <select id="devise" name="devise">
                    <?php foreach (DeviseModel::all() as $devise): ?>
                        <option value="<?= h($devise['devise_code']) ?>" <?= (old_input('devise') ?: 'XOF') === $devise['devise_code'] ? 'selected' : '' ?>><?= h($devise['devise_code'] . ' — ' . $devise['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('cotisations.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
