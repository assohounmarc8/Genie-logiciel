<?php
$errors = flash_get('errors', []);

/**
 * Centre approximatif (centroïde de la boîte englobante) des 6 pays couverts, dans le même repère
 * que les tracés réels de views/partials/africa-map-paths.php (viewBox "373 183 179 196"), pour
 * positionner les pastilles de comptage.
 */
$mapPins = [
    'CIV' => ['x' => 407, 'y' => 266],
    'MLI' => ['x' => 411, 'y' => 240],
    'BEN' => ['x' => 427, 'y' => 262],
    'BFA' => ['x' => 417, 'y' => 254],
    'MDG' => ['x' => 538, 'y' => 333],
    'NGA' => ['x' => 443, 'y' => 262],
];

/** Organisations groupées par région, pour dessiner les points de couleur sur la carte régionale. */
$orgsByRegion = [];
foreach ($allOrgsInCountry as $o) {
    if (!empty($o['region_code'])) {
        $orgsByRegion[$o['region_code']][] = $o;
    }
}

require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('nav.available_orgs')) ?></h1>
        <p class="page-subtitle"><?= h(t('membres.available.map_subtitle')) ?></p>
    </div>

    <?php render_form_errors($errors); ?>

    <div class="africa-map-wrap">
        <div class="africa-map-box">
            <p class="card-title" style="margin-bottom:10px;"><?= h(t('membres.available.choose_country')) ?></p>
            <svg viewBox="373 183 179 196" xmlns="http://www.w3.org/2000/svg">
                <?php if ($selectedPays): ?>
                <style>[data-pays="<?= h($selectedPays) ?>"] { fill: var(--green-light); stroke: var(--green); stroke-width: 1.2; }</style>
                <?php endif; ?>
                <?php require APP_DIR . '/views/partials/africa-map-paths.php'; ?>
                <?php foreach ($pays as $info): ?>
                    <?php $pin = $mapPins[$info['pays_code']] ?? null; ?>
                    <?php if (!$pin) continue; ?>
                    <a href="<?= h(route_url('membres/organisationsDisponibles', ['pays' => $info['pays_code']])) ?>">
                        <g class="africa-pin<?= $selectedPays === $info['pays_code'] ? ' active' : '' ?>">
                            <circle cx="<?= $pin['x'] ?>" cy="<?= $pin['y'] ?>" r="6.5"></circle>
                            <text x="<?= $pin['x'] ?>" y="<?= $pin['y'] + 2.6 ?>" text-anchor="middle"><?= h((string) ($countsByPays[$info['pays_code']] ?? 0)) ?></text>
                        </g>
                    </a>
                <?php endforeach; ?>
            </svg>
        </div>

        <div class="region-map-box">
            <p class="card-title" style="margin-bottom:10px;"><?= h(t('membres.available.choose_region', ['pays' => pays_label($selectedPays)])) ?></p>
            <?php if (!$regions): ?>
                <p class="region-map-empty"><?= h(t('membres.available.no_regions')) ?></p>
            <?php else: ?>
                <?php foreach ($regions as $reg): ?>
                    <?php $regOrgs = $orgsByRegion[$reg['region_code']] ?? []; ?>
                    <a class="region-pin<?= $selectedRegion === $reg['region_code'] ? ' active' : '' ?>"
                       style="left:<?= (int) $reg['x_percent'] ?>%; top:<?= (int) $reg['y_percent'] ?>%;"
                       href="<?= h(route_url('membres/organisationsDisponibles', ['pays' => $selectedPays, 'region' => $selectedRegion === $reg['region_code'] ? '' : $reg['region_code']])) ?>"
                       title="<?= h($reg['nom']) ?> — <?= count($regOrgs) ?>">
                        <span class="region-pin-dots">
                            <?php if ($regOrgs): ?>
                                <?php foreach ($regOrgs as $o): ?>
                                    <span class="org-dot org-dot-<?= (int) ($colorByOrg[$o['organisation_code']] ?? 0) ?>"></span>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <span class="org-dot" style="background:var(--border-strong);"></span>
                            <?php endif; ?>
                        </span>
                        <span class="region-pin-label"><?= h($reg['nom']) ?></span>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($selectedRegion): ?>
        <p class="page-subtitle">
            <?= h(t('membres.available.filtered_by_region', ['region' => RegionModel::findByCode($selectedRegion)['nom'] ?? ''])) ?>
            — <a class="link-strong" href="<?= h(route_url('membres/organisationsDisponibles', ['pays' => $selectedPays])) ?>"><?= h(t('membres.available.clear_filter')) ?></a>
        </p>
    <?php endif; ?>

    <div class="table-wrap"><table class="data-table">
        <thead><tr><th></th><th><?= h(t('org.index.col_org')) ?></th><th><?= h(t('org.field.region')) ?></th><th><?= h(t('org.field.type_organisation')) ?></th><th><?= h(t('common.status')) ?></th><th><?= h(t('common.actions')) ?></th></tr></thead>
        <tbody>
            <?php if (!$organisations): ?><tr><td colspan="6" class="table-empty"><?= h(t('membres.available.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($organisations as $org): ?>
            <?php $membership = $membershipsByOrg[$org['organisation_code']] ?? null; ?>
            <?php $hasReglement = !empty($org['reglement_interieur_chemin']); ?>
            <?php $canJoin = $org['pays_code'] === $userPays; ?>
            <tr>
                <td><span class="org-dot org-dot-<?= (int) ($colorByOrg[$org['organisation_code']] ?? 0) ?>"></span></td>
                <td><?= h($org['nom']) ?></td>
                <td class="text-faint"><?= h($org['region'] ?? '—') ?></td>
                <td><?= enum_badge_html('type_organisation', $org['type_organisation']) ?></td>
                <td><?= $membership ? enum_badge_html('membre_statut', $membership['statut']) : badge_html(t('membres.available_badge'), 'success') ?></td>
                <td>
                    <?php if (!$membership && $canJoin): ?>
                    <form method="post" action="<?= h(route_url('membres/rejoindre')) ?>">
                        <input type="hidden" name="org" value="<?= h($org['organisation_code']) ?>">
                        <?php if ($hasReglement): ?>
                        <div style="background:var(--cream); border:1px solid var(--border); border-radius:var(--radius-sm); padding:10px 12px; margin-bottom:8px; max-width:280px;">
                            <a href="<?= h(asset_url('/' . $org['reglement_interieur_chemin'])) ?>" target="_blank" rel="noopener" style="font-weight:600; font-size:12.5px;">📄 <?= h(t('membres.view_reglement')) ?></a>
                            <label class="row mt-2" style="align-items:flex-start;">
                                <input type="checkbox" name="accepte_reglement" value="1" required style="margin-top:2px;">
                                <span style="font-size:12.5px;"><?= h(t('membres.accept_reglement')) ?></span>
                            </label>
                        </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary btn-sm"><?= h(t('membres.join_btn')) ?></button>
                    </form>
                    <?php elseif (!$membership && !$canJoin): ?>
                        <span class="text-faint" style="font-size:12px;" title="<?= h(t('membres.available.other_country_hint')) ?>"><?= h(t('membres.available.other_country_short')) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
