<?php
/** @var int $statOrgs */
/** @var int $statMembres */
/** @var int $statCountries */
$pays = PaysModel::all();
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('home.footer')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="landing-nav landing-nav-ghost">
    <div class="landing-nav-inner">
        <div class="landing-brand">
            <div class="sidebar-logo">M</div>
            <p class="landing-brand-name">MON<span class="accent">ASSO</span></p>
        </div>
        <div class="row">
            <a class="btn btn-ghost" href="#how-it-works"><?= h(t('home.section.how_it_works')) ?></a>
            <a class="btn btn-ghost" href="#countries"><?= h(t('home.section.countries')) ?></a>
            <?php render_country_switcher('light'); ?>
            <a class="btn btn-ghost" href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.give_btn')) ?></a>
            <a class="btn btn-ghost" href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a>
            <a class="btn btn-accent" href="<?= h(route_url('auth/register')) ?>"><?= h(t('common.register')) ?></a>
        </div>
    </div>
</div>

<div class="hero">
    <div class="hero-content">
        <div class="hero-inner">
            <p class="hero-eyebrow"><?= h(t('home.eyebrow')) ?></p>
            <h1 class="hero-title">MONASSO</h1>
            <p class="hero-tagline"><?= h(t('home.tagline')) ?></p>
            <div class="hero-actions">
                <a class="btn btn-primary btn-lg" href="<?= h(route_url('auth/register')) ?>"><?= h(t('nav.create_org')) ?></a>
                <a class="btn btn-outline btn-lg" href="<?= h(route_url('auth/login')) ?>"><?= h(t('home.have_account')) ?></a>
                <a class="btn btn-outline btn-lg" href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.give_btn')) ?></a>
            </div>
        </div>
        <div class="hero-phone reveal">
            <div class="iphone-16">
                <div class="iphone-16-frame">
                    <div class="iphone-16-screen">
                        <div class="iphone-16-island"></div>
                        <div class="iphone-16-app">
                            <div class="iphone-16-logo">M</div>
                            <p class="iphone-16-brand">MON<span class="accent">ASSO</span></p>
                            <p class="iphone-16-tagline"><?= h(t('home.tagline')) ?></p>
                        </div>
                    </div>
                    <div class="iphone-16-btn iphone-16-btn-action" aria-hidden="true"></div>
                    <div class="iphone-16-btn iphone-16-btn-vol-up" aria-hidden="true"></div>
                    <div class="iphone-16-btn iphone-16-btn-vol-down" aria-hidden="true"></div>
                </div>
                <div class="iphone-16-glow" aria-hidden="true"></div>
            </div>
        </div>
    </div>
    <div class="hero-stats reveal">
        <div>
            <p class="hero-stat-value"><?= h((string) $statOrgs) ?></p>
            <p class="hero-stat-label"><?= h(t('home.hero.stat.orgs')) ?></p>
        </div>
        <div>
            <p class="hero-stat-value"><?= h((string) $statMembres) ?></p>
            <p class="hero-stat-label"><?= h(t('home.hero.stat.members')) ?></p>
        </div>
        <div>
            <p class="hero-stat-value"><?= h((string) $statCountries) ?></p>
            <p class="hero-stat-label"><?= h(t('home.hero.stat.countries')) ?></p>
        </div>
    </div>
</div>

<div class="landing-body">
    <div class="landing-section" id="how-it-works">
        <p class="section-eyebrow"><?= h(t('home.section.how_it_works')) ?></p>
        <div class="step-grid">
            <div class="reveal">
                <div class="step-number">1</div>
                <p class="card-title"><?= h(t('home.step1.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.step1.desc')) ?></p>
            </div>
            <div class="reveal">
                <div class="step-number">2</div>
                <p class="card-title"><?= h(t('home.step2.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.step2.desc')) ?></p>
            </div>
            <div class="reveal">
                <div class="step-number">3</div>
                <p class="card-title"><?= h(t('home.step3.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.step3.desc')) ?></p>
            </div>
        </div>
    </div>

    <div class="landing-section">
        <h2 class="section-title"><?= h(t('home.section.workflow')) ?></h2>
        <div class="feature-grid">
            <div class="role-card role-card-dark reveal">
                <p class="role-card-title"><?= h(t('enum.type_compte.SUPER_ADMIN')) ?></p>
                <p class="role-card-headline"><?= h(t('home.feature.super_admin')) ?></p>
            </div>
            <div class="role-card card reveal">
                <p class="role-card-title"><?= h(t('enum.type_compte.ADMIN_ORGA')) ?></p>
                <p class="role-card-headline"><?= h(t('home.feature.admin_orga')) ?></p>
            </div>
            <div class="role-card card reveal">
                <p class="role-card-title"><?= h(t('enum.type_compte.MEMBRE')) ?></p>
                <p class="role-card-headline"><?= h(t('home.feature.membre')) ?></p>
            </div>
        </div>
    </div>

    <div class="landing-section">
        <p class="section-eyebrow"><?= h(t('home.section.showcase')) ?></p>
        <div class="feature-grid">
            <div class="card reveal"><div class="card-body">
                <p class="card-title"><?= h(t('home.showcase.association.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.showcase.association.desc')) ?></p>
            </div></div>
            <div class="card reveal"><div class="card-body">
                <p class="card-title"><?= h(t('home.showcase.ong.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.showcase.ong.desc')) ?></p>
            </div></div>
            <div class="card reveal"><div class="card-body">
                <p class="card-title"><?= h(t('home.showcase.mutuelle.title')) ?></p>
                <p class="page-subtitle"><?= h(t('home.showcase.mutuelle.desc')) ?></p>
            </div></div>
        </div>
    </div>

    <div class="landing-section" id="countries" style="margin-bottom:0;">
        <h2 class="section-title"><?= h(t('home.section.countries')) ?></h2>
        <div class="row">
            <?php foreach ($pays as $info): ?>
                <span class="badge badge-neutral"><?= flag_img_html($info['pays_code']) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<footer class="landing-footer-full">
    <div class="landing-footer-grid">
        <div class="landing-footer-brand">
            <div class="landing-brand" style="margin-bottom:0;">
                <div class="sidebar-logo">M</div>
                <p class="landing-brand-name">MON<span class="accent">ASSO</span></p>
            </div>
            <p class="landing-footer-tagline"><?= h(t('footer.tagline')) ?></p>
        </div>
        <div class="landing-footer-col">
            <p class="landing-footer-col-title"><?= h(t('footer.nav_title')) ?></p>
            <a href="#how-it-works"><?= h(t('home.section.how_it_works')) ?></a>
            <a href="#countries"><?= h(t('home.section.countries')) ?></a>
            <a href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.give_btn')) ?></a>
        </div>
        <div class="landing-footer-col">
            <p class="landing-footer-col-title"><?= h(t('footer.account_title')) ?></p>
            <a href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a>
            <a href="<?= h(route_url('auth/register')) ?>"><?= h(t('nav.create_org')) ?></a>
        </div>
        <div class="landing-footer-col">
            <p class="landing-footer-col-title"><?= h(t('footer.countries_title')) ?></p>
            <div class="landing-footer-flags">
                <?php foreach ($pays as $info): ?>
                    <?= flag_img_html($info['pays_code'], false) ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <div class="landing-footer-bottom">
        <p><?= h(t('home.footer')) ?></p>
        <p>&copy; <?= h(date('Y')) ?> MonAsso — <?= h(t('footer.rights')) ?></p>
    </div>
</footer>
<script src="<?= h(asset_url('/assets/js/reveal.js')) ?>"></script>
<script>
(function () {
    var nav = document.querySelector('.landing-nav-ghost');
    if (!nav) return;
    function onScroll() {
        nav.classList.toggle('is-scrolled', window.scrollY > 24);
    }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
})();
</script>
</body>
</html>
