<?php
$errors = flash_get('errors', []);
$pays = PaysModel::all();
$typesOrganisation = TypeOrganisationModel::all();
$ministeres = MinistereTutelleModel::all();
$regionsAll = [];
foreach ($pays as $p) {
    $regionsAll = array_merge($regionsAll, RegionModel::byPays($p['pays_code']));
}
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('nav.create_org')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('organisations/creer')) ?>" enctype="multipart/form-data">
        <div class="card"><div class="card-body">
            <div class="field">
                <label><?= h(t('org.field.logo')) ?></label>
                <?php render_file_field('logo', 'logo', 'image/png,image/jpeg', t('org.field.logo_choose')) ?>
            </div>
            <div class="field">
                <label for="nom"><?= h(t('org.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="form-grid">
                <div class="field">
                    <label for="pays_code"><?= h(t('common.country')) ?></label>
                    <select id="pays_code" name="pays_code" required>
                        <option value=""><?= h(t('common.choose')) ?></option>
                        <?php foreach ($pays as $info): ?>
                            <option value="<?= h($info['pays_code']) ?>" <?= old_input('pays_code') === $info['pays_code'] ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label for="type_organisation"><?= h(t('org.field.type_organisation')) ?></label>
                    <select id="type_organisation" name="type_organisation" required>
                        <option value=""><?= h(t('common.choose')) ?></option>
                        <?php foreach ($typesOrganisation as $type): ?>
                            <option value="<?= h($type['type_organisation_code']) ?>" <?= old_input('type_organisation') === $type['type_organisation_code'] ? 'selected' : '' ?>><?= h(t('enum.type_organisation.' . $type['type_organisation_code'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <div class="field">
                <label for="ministere_tutelle_code"><?= h(t('org.field.ministere_tutelle')) ?></label>
                <select id="ministere_tutelle_code" name="ministere_tutelle_code">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($ministeres as $min): ?>
                        <option value="<?= h($min['ministere_code']) ?>" data-pays="<?= h($min['pays_code']) ?>" <?= old_input('ministere_tutelle_code') === $min['ministere_code'] ? 'selected' : '' ?>><?= h($min['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
                <p class="text-faint mt-2"><?= h(t('org.field.ministere_tutelle_hint')) ?></p>
            </div>
            <div class="field">
                <label for="region_code"><?= h(t('org.field.region')) ?></label>
                <select id="region_code" name="region_code">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($regionsAll as $reg): ?>
                        <option value="<?= h($reg['region_code']) ?>" data-pays="<?= h($reg['pays_code']) ?>" <?= old_input('region_code') === $reg['region_code'] ? 'selected' : '' ?>><?= h($reg['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="description"><?= h(t('org.field.description')) ?></label>
                <textarea id="description" name="description" rows="3" placeholder="<?= h(t('org.field.description_placeholder')) ?>"><?= h(old_input('description')) ?></textarea>
            </div>
            <div class="field">
                <label for="reglement_interieur"><?= h(t('org.field.reglement_interieur')) ?></label>
                <?php render_file_field('reglement_interieur', 'reglement_interieur', 'application/pdf,.pdf', t('org.field.reglement_interieur_choose')) ?>
                <p class="text-faint mt-2"><?= h(t('org.field.reglement_interieur_hint')) ?></p>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('org.creer.submit')) ?></button>
        </div>
    </form>
</div>
<script>
    (function () {
        var paysSelect = document.getElementById('pays_code');
        var ministereSelect = document.getElementById('ministere_tutelle_code');
        var ministereOptions = Array.prototype.slice.call(ministereSelect.options);
        var regionSelect = document.getElementById('region_code');
        var regionOptions = Array.prototype.slice.call(regionSelect.options);

        function updateMinisteres() {
            var pays = paysSelect.value;
            ministereOptions.forEach(function (opt) {
                if (!opt.value) { return; }
                var visible = opt.dataset.pays === pays;
                opt.hidden = !visible;
                if (visible) { opt.selected = true; }
            });
            if (!pays) { ministereSelect.value = ''; }
        }

        function updateRegions() {
            var pays = paysSelect.value;
            var currentValid = false;
            regionOptions.forEach(function (opt) {
                if (!opt.value) { return; }
                var visible = opt.dataset.pays === pays;
                opt.hidden = !visible;
                if (visible && opt.selected) { currentValid = true; }
            });
            if (!currentValid) { regionSelect.value = ''; }
        }

        paysSelect.addEventListener('change', function () {
            updateMinisteres();
            updateRegions();
        });
        updateMinisteres();
        updateRegions();
    })();
</script>
<?php require APP_DIR . '/views/layout/end.php'; ?>
