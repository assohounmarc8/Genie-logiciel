<?php
$errors = flash_get('errors', []);
$orgCode = $organisation['organisation_code'];
$canGererOrganisation = Middleware::can($orgCode, 'gerer_organisation');
$canMembres = Middleware::can($orgCode, 'gerer_membres') || Middleware::can($orgCode, 'valider_adherent') || Middleware::can($orgCode, 'voir_membres');
$canCotisations = Middleware::can($orgCode, 'creer_cotisation') || Middleware::can($orgCode, 'voir_finances');
$canDocuments = Middleware::can($orgCode, 'voir_documents') || Middleware::can($orgCode, 'gerer_documents');
$autoRefreshSeconds = 20;
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
            <p class="page-subtitle text-mono"><?= h($organisation['organisation_code']) ?></p>
        </div>
        <div class="row">
            <?= enum_badge_html('type_organisation', $organisation['type_organisation']) ?>
            <?= enum_badge_html('org_statut_validation', $organisation['statut_validation']) ?>
            <?= enum_badge_html('org_statut_abonnement', $organisation['statut_abonnement']) ?>
            <?php if ($canGererOrganisation): ?>
                <a class="btn btn-outline btn-sm" href="<?= h(route_url('organisations/parametres', ['org' => $orgCode])) ?>"><?= h(t('nav.parametres')) ?></a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isOwner && !$isSuperAdmin && $organisation['statut_validation'] !== 'VAL'): ?>
    <div class="card"><div class="card-body">
        <?php if ($organisation['statut_validation'] === 'ATT'): ?>
            <p class="card-title"><?= h(t('org.pending.title')) ?></p>
            <p class="text-faint mt-2"><?= h(t('org.pending.text', ['org' => $organisation['nom']])) ?></p>
        <?php else: ?>
            <p class="card-title"><?= h(t('org.refused.title')) ?></p>
            <p class="text-faint mt-2"><?= h(t('org.refused.text', ['org' => $organisation['nom']])) ?></p>
        <?php endif; ?>
    </div></div>
    <?php endif; ?>

    <?php if ($canGererOrganisation && empty($organisation['reglement_interieur_chemin'])): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('org.detail.reglement_missing_title')) ?></p>
        <p class="text-faint mt-2"><?= h(t('org.detail.reglement_missing_body')) ?></p>
        <div class="row mt-2">
            <a class="btn btn-accent btn-sm" href="<?= h(route_url('organisations/parametres', ['org' => $orgCode])) ?>#reglement_interieur"><?= h(t('org.detail.reglement_missing_btn')) ?></a>
        </div>
    </div></div>
    <?php endif; ?>

    <?php if ($isSuperAdmin && $organisation['statut_validation'] === 'VAL' && $organisation['statut_abonnement'] !== 'ACT'): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('org.detail.collect_sub')) ?></p>
        <?php if ($errors): ?>
        <div class="auth-error mt-2">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div>
        <?php endif; ?>
        <form method="post" action="<?= h(route_url('abonnements/payer')) ?>" class="row mt-2">
            <input type="hidden" name="org" value="<?= h($orgCode) ?>">
            <select name="plan_code" id="plan_code" required style="max-width:180px;">
                <option value=""><?= h(t('common.choose')) ?></option>
                <?php foreach ($plans as $plan): ?>
                    <option value="<?= h($plan['plan_abonnement_code']) ?>" data-montant="<?= h((string) (int) $plan['montant_suggere']) ?>"><?= h(t('enum.plan_abonnement.' . $plan['plan_abonnement_code'])) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" name="montant" id="montant_abonnement" min="1" step="1" placeholder="<?= h(t('common.amount')) ?>" required style="max-width:160px;">
            <button type="submit" class="btn btn-accent"><?= h(t('org.detail.collect_btn')) ?></button>
        </form>
    </div></div>
    <script>
        (function () {
            var planSelect = document.getElementById('plan_code');
            var montantInput = document.getElementById('montant_abonnement');
            if (!planSelect) { return; }
            planSelect.addEventListener('change', function () {
                var selected = planSelect.options[planSelect.selectedIndex];
                var suggested = selected ? selected.getAttribute('data-montant') : '';
                if (suggested) {
                    montantInput.value = suggested;
                }
            });
        })();
    </script>
    <?php endif; ?>

    <div class="card"><div class="card-body form-grid">
        <div><p class="kpi-label"><?= h(t('common.country')) ?></p><p class="mt-2"><?= flag_img_html($organisation['pays_code']) ?></p></div>
        <div><p class="kpi-label"><?= h(t('org.detail.admin_label')) ?></p><p class="mt-2 text-mono"><?= h($organisation['admin_user_code']) ?></p></div>
        <div><p class="kpi-label"><?= h(t('org.detail.created_label')) ?></p><p class="mt-2"><?= h(format_date($organisation['created_at'])) ?></p></div>
        <?php if (!empty($organisation['email'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.email')) ?></p><p class="mt-2"><?= h($organisation['email']) ?></p></div>
        <?php endif; ?>
        <?php if (!empty($organisation['telephone'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.telephone')) ?></p><p class="mt-2"><?= h($organisation['telephone']) ?></p></div>
        <?php endif; ?>
        <?php if (!empty($organisation['adresse'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.adresse')) ?></p><p class="mt-2"><?= h($organisation['adresse']) ?></p></div>
        <?php endif; ?>
        <?php if (!empty($organisation['ministere_tutelle_code'])): ?>
        <?php $ministere = MinistereTutelleModel::findByCode($organisation['ministere_tutelle_code']); ?>
        <?php if ($ministere): ?>
        <div><p class="kpi-label"><?= h(t('org.field.ministere_tutelle')) ?></p><p class="mt-2"><?= h($ministere['nom']) ?></p></div>
        <?php endif; ?>
        <?php endif; ?>
        <?php if (!empty($organisation['description'])): ?>
        <div class="col-2"><p class="kpi-label"><?= h(t('org.field.description')) ?></p><p class="mt-2"><?= h($organisation['description']) ?></p></div>
        <?php endif; ?>
    </div></div>

    <div class="row">
        <?php if ($canMembres): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('membres/index', ['org' => $orgCode])) ?>"><?= h(t('nav.membres')) ?></a><?php endif; ?>
        <?php if ($isSuperAdmin || $organisation['statut_validation'] === 'VAL'): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('roles/index', ['org' => $orgCode])) ?>"><?= h(t('nav.roles')) ?></a><?php endif; ?>
        <?php if ($canCotisations): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('cotisations/index', ['org' => $orgCode])) ?>"><?= h(t('nav.cotisations')) ?></a><?php endif; ?>
        <?php if ($canDocuments): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('documents/index', ['org' => $orgCode])) ?>"><?= h(t('nav.documents')) ?></a><?php endif; ?>
    </div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('org.detail.sub_history')) ?></p>
        <div class="table-wrap"><table class="data-table">
            <thead><tr>
                <th><?= h(t('common.code')) ?></th>
                <th><?= h(t('common.status')) ?></th>
                <th><?= h(t('common.amount')) ?></th>
                <th><?= h(t('common.start_date')) ?></th>
                <th><?= h(t('common.end_date')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$abonnements): ?><tr><td colspan="5" class="table-empty"><?= h(t('org.detail.no_subscriptions')) ?></td></tr><?php endif; ?>
                <?php foreach ($abonnements as $abo): ?>
                <tr>
                    <td class="text-mono"><?= h($abo['abonnement_code']) ?></td>
                    <td><?= enum_badge_html('abonnement_statut', $abo['statut']) ?></td>
                    <td><?= h(format_money((float) $abo['montant'])) ?></td>
                    <td><?= h(format_date($abo['date_debut'])) ?></td>
                    <td><?= h(format_date($abo['date_fin'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
