<?php $autoRefreshSeconds = 20; require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.platform')) ?></p>
        <h1 class="page-title"><?= h(t('nav.organisations')) ?></h1>
        <p class="page-subtitle"><?= h(t('org.index.subtitle', ['count' => count($organisations)])) ?></p>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead><tr>
                <th><?= h(t('org.index.col_org')) ?></th>
                <th><?= h(t('common.country')) ?></th>
                <th><?= h(t('org.field.type_organisation')) ?></th>
                <th><?= h(t('org.index.col_admin')) ?></th>
                <th><?= h(t('org.index.col_validation')) ?></th>
                <th><?= h(t('org.index.col_subscription')) ?></th>
                <th><?= h(t('common.actions')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$organisations): ?><tr><td colspan="7" class="table-empty"><?= h(t('org.index.empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($organisations as $org): ?>
                <tr>
                    <td>
                        <a class="link-strong" href="<?= h(route_url('organisations/detail', ['id' => $org['organisation_code']])) ?>"><?= h($org['nom']) ?></a>
                        <br><span class="text-mono text-faint"><?= h($org['organisation_code']) ?></span>
                    </td>
                    <td><?= flag_img_html($org['pays_code']) ?></td>
                    <td><?= enum_badge_html('type_organisation', $org['type_organisation']) ?></td>
                    <td class="text-mono"><?= h($org['admin_user_code']) ?></td>
                    <td><?= enum_badge_html('org_statut_validation', $org['statut_validation']) ?></td>
                    <td><?= enum_badge_html('org_statut_abonnement', $org['statut_abonnement']) ?></td>
                    <td>
                        <div class="table-actions">
                            <?php if (!empty($org['reglement_interieur_chemin'])): ?>
                            <a class="btn btn-outline btn-sm" href="<?= h(asset_url('/' . $org['reglement_interieur_chemin'])) ?>" target="_blank" rel="noopener">📄 <?= h(t('org.index.voir_reglement')) ?></a>
                            <?php endif; ?>
                            <?php if ($org['statut_validation'] === 'ATT'): ?>
                            <form method="post" action="<?= h(route_url('organisations/valider')) ?>">
                                <input type="hidden" name="id" value="<?= h($org['organisation_code']) ?>">
                                <button type="submit" class="btn btn-primary btn-sm"><?= h(t('common.approve')) ?></button>
                            </form>
                            <form method="post" action="<?= h(route_url('organisations/refuser')) ?>" onsubmit="return confirm('<?= h(t('org.index.confirm_reject')) ?>');">
                                <input type="hidden" name="id" value="<?= h($org['organisation_code']) ?>">
                                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('common.reject')) ?></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
