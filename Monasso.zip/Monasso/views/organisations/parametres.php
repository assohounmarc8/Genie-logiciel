<?php
$errors = flash_get('errors', []);
$ministeres = MinistereTutelleModel::byPays($organisation['pays_code']);
$regions = RegionModel::byPays($organisation['pays_code']);
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('org.parametres.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('organisations/parametres')) ?>" enctype="multipart/form-data">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label><?= h(t('org.field.logo')) ?></label>
                <?php if (!empty($organisation['logo_chemin'])): ?>
                    <img src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:8px;display:block;margin-bottom:8px;">
                <?php endif; ?>
                <?php render_file_field('logo', 'logo', 'image/png,image/jpeg', t('org.field.logo_choose')) ?>
            </div>
            <div class="field">
                <label for="nom"><?= h(t('org.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom') ?: $organisation['nom']) ?>">
            </div>
            <div class="form-grid">
                <div class="field">
                    <label for="email"><?= h(t('org.field.email')) ?></label>
                    <input type="text" id="email" name="email" value="<?= h(old_input('email') ?: ($organisation['email'] ?? '')) ?>">
                </div>
                <div class="field">
                    <label for="telephone"><?= h(t('org.field.telephone')) ?></label>
                    <input type="text" id="telephone" name="telephone" value="<?= h(old_input('telephone') ?: ($organisation['telephone'] ?? '')) ?>">
                </div>
            </div>
            <div class="field">
                <label for="adresse"><?= h(t('org.field.adresse')) ?></label>
                <textarea id="adresse" name="adresse"><?= h(old_input('adresse') ?: ($organisation['adresse'] ?? '')) ?></textarea>
            </div>
            <div class="field">
                <label for="description"><?= h(t('org.field.description')) ?></label>
                <textarea id="description" name="description" placeholder="<?= h(t('org.field.description_placeholder')) ?>"><?= h(old_input('description') ?: ($organisation['description'] ?? '')) ?></textarea>
            </div>
            <div class="field">
                <label for="ministere_tutelle_code"><?= h(t('org.field.ministere_tutelle')) ?></label>
                <select id="ministere_tutelle_code" name="ministere_tutelle_code">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($ministeres as $min): ?>
                        <option value="<?= h($min['ministere_code']) ?>" <?= (old_input('ministere_tutelle_code') ?: ($organisation['ministere_tutelle_code'] ?? '')) === $min['ministere_code'] ? 'selected' : '' ?>><?= h($min['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="region_code"><?= h(t('org.field.region')) ?></label>
                <select id="region_code" name="region_code">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($regions as $reg): ?>
                        <option value="<?= h($reg['region_code']) ?>" <?= (old_input('region_code') ?: ($organisation['region_code'] ?? '')) === $reg['region_code'] ? 'selected' : '' ?>><?= h($reg['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="montant_adhesion"><?= h(t('org.field.montant_adhesion')) ?></label>
                <input type="number" min="0" step="1" id="montant_adhesion" name="montant_adhesion" value="<?= h(old_input('montant_adhesion') ?: ($organisation['montant_adhesion'] ?? '')) ?>">
                <p class="text-faint mt-2"><?= h(t('org.field.montant_adhesion_hint')) ?></p>
            </div>
            <div class="field">
                <label for="reglement_interieur"><?= h(t('org.field.reglement_interieur')) ?></label>
                <?php if (!empty($organisation['reglement_interieur_chemin'])): ?>
                    <p class="mt-2">
                        <a href="<?= h(asset_url('/' . $organisation['reglement_interieur_chemin'])) ?>" target="_blank" rel="noopener">📄 <?= h($organisation['reglement_interieur_nom'] ?: t('org.field.reglement_interieur')) ?></a>
                    </p>
                    <label class="row mt-2">
                        <input type="checkbox" name="supprimer_reglement" value="1">
                        <span><?= h(t('org.field.reglement_supprimer')) ?></span>
                    </label>
                <?php endif; ?>
                <?php render_file_field('reglement_interieur', 'reglement_interieur', 'application/pdf,.pdf', t('org.field.reglement_interieur_choose')) ?>
                <p class="text-faint mt-2"><?= h(t('org.field.reglement_interieur_hint')) ?></p>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('organisations/detail', ['id' => $organisation['organisation_code']])) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('org.parametres.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
