<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('evenements.creer.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('evenements/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="titre"><?= h(t('evenements.field.titre')) ?></label>
                <input type="text" id="titre" name="titre" required value="<?= h(old_input('titre')) ?>" placeholder="<?= h(t('evenements.field.titre_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="description"><?= h(t('evenements.field.description')) ?></label>
                <textarea id="description" name="description"><?= h(old_input('description')) ?></textarea>
            </div>
            <div class="form-grid">
                <div class="field">
                    <label for="lieu"><?= h(t('evenements.field.lieu')) ?></label>
                    <input type="text" id="lieu" name="lieu" value="<?= h(old_input('lieu')) ?>">
                </div>
                <div class="field">
                    <label for="date_heure"><?= h(t('evenements.field.date_heure')) ?></label>
                    <input type="datetime-local" id="date_heure" name="date_heure" required value="<?= h(old_input('date_heure')) ?>">
                </div>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('evenements/index', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('evenements.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
