<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('adhesion.payer.eyebrow')) ?></p>
        <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
    </div>

    <div class="card"><div class="card-body">
        <?php if (!empty($organisation['logo_chemin'])): ?>
            <img src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="" style="width:64px;height:64px;border-radius:10px;object-fit:cover;margin-bottom:12px;">
        <?php endif; ?>

        <div class="form-grid">
            <div>
                <p class="kpi-label"><?= h(t('cartes.field.numero')) ?></p>
                <p class="mt-2 text-mono"><?= h($numeroAdherent ?: '—') ?></p>
            </div>
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.motif')) ?></p>
                <p class="mt-2"><?= h(t('adhesion.field.motif_droit_adhesion')) ?></p>
            </div>
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.montant')) ?></p>
                <p class="mt-2"><?= h(format_money((float) $paiement['montant'])) ?></p>
            </div>
        </div>

        <?php if ($paiement['statut'] === 'PAYE'): ?>
            <p class="mt-2"><?= h(t('adhesion.payer.already_paid')) ?></p>
        <?php else: ?>
            <?php render_form_errors($errors); ?>
            <form method="post" action="<?= h(route_url('adhesion/confirmerPaiement')) ?>" class="mt-2">
                <input type="hidden" name="token" value="<?= h($paiement['token']) ?>">
                <?php render_mode_paiement_picker('mode_paiement_adhesion'); ?>
                <button type="submit" class="btn btn-accent mt-2"><?= h(t('adhesion.payer.pay_btn')) ?></button>
            </form>
        <?php endif; ?>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
