<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
            <h1 class="page-title"><?= h(t('bailleurs.index.title')) ?></h1>
        </div>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('bailleurs/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('bailleurs.index.new')) ?></a>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('bailleurs.field.nom')) ?></th>
            <th><?= h(t('bailleurs.field.montant')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th></th>
        </tr></thead>
        <tbody>
            <?php if (!$bailleurs): ?><tr><td colspan="4" class="table-empty"><?= h(t('bailleurs.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($bailleurs as $b): ?>
            <tr>
                <td style="font-weight:600;"><?= h($b['nom']) ?></td>
                <td><?= $b['montant_engage'] !== null ? h(format_money((float) $b['montant_engage'])) : '—' ?></td>
                <td><?= enum_badge_html('bailleur_statut', $b['statut']) ?></td>
                <td>
                    <form method="post" action="<?= h(route_url('bailleurs/marquerRapportDu')) ?>">
                        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                        <input type="hidden" name="id" value="<?= h($b['bailleur_code']) ?>">
                        <button type="submit" class="btn btn-outline btn-sm"><?= h($b['statut'] === 'RAPPORT_DU' ? t('bailleurs.mark_ok_btn') : t('bailleurs.mark_rapport_du_btn')) ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
