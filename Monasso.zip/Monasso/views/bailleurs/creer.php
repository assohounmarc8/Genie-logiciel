<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h($organisation['nom']) ?></p>
        <h1 class="page-title"><?= h(t('bailleurs.index.new')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('bailleurs/creer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom"><?= h(t('bailleurs.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="montant_engage"><?= h(t('bailleurs.field.montant')) ?></label>
                <input type="number" min="0" step="1" id="montant_engage" name="montant_engage" value="<?= h(old_input('montant_engage')) ?>">
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('common.save')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
