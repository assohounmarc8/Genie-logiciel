<?php
$errors = flash_get('errors', []);
$pays = PaysModel::all();
$metiers = MetierModel::all();
$success = $success ?? null;
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('common.register')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-split">
        <div class="auth-form-side" style="overflow-y:auto; max-height:100vh;">
            <?php render_back_home_btn(); ?>
            <div class="row between" style="margin-bottom:18px;">
                <div class="auth-brand-block">
                    <div class="auth-brand" style="margin-bottom:0;">
                        <div class="sidebar-logo">M</div>
                        <div>
                            <p class="auth-brand-name">MON<span class="accent">ASSO</span></p>
                        </div>
                    </div>
                    <?php render_coat_of_arms(old_input('pays_code') ?: null, 'auth-coat-of-arms', true); ?>
                </div>
                <?php render_country_switcher('light'); ?>
            </div>

            <?php if ($success): ?>
            <div class="auth-success">
                <div class="auth-success-icon">✓</div>
                <h1 class="page-title" style="margin-bottom:14px;"><?= h(t('auth.register.success_title')) ?></h1>
                <p class="text-faint" style="margin-bottom:28px;">
                    <?= h($success === 'membre' ? t('auth.register.membre_success_info') : t('auth.register.admin_success_info')) ?>
                </p>
                <?php if ($success === 'membre'): ?>
                    <a href="<?= h(route_url('auth/login')) ?>" class="btn btn-primary btn-block"><?= h(t('common.login')) ?></a>
                <?php else: ?>
                    <a href="<?= h(route_url('organisations/creer')) ?>" class="btn btn-primary btn-block"><?= h(t('nav.create_org')) ?></a>
                <?php endif; ?>
            </div>
            <?php else: ?>

            <h1 class="page-title" style="margin-bottom:22px;"><?= h(t('common.register')) ?></h1>

            <?php if ($errors): ?>
            <div class="auth-error">
                <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
            </div>
            <?php endif; ?>

            <form method="post" action="<?= h(route_url('auth/register')) ?>" enctype="multipart/form-data">
                <select id="type_compte" name="type_compte" required style="display:none;">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <option value="ADMIN_ORGA" <?= old_input('type_compte') === 'ADMIN_ORGA' ? 'selected' : '' ?>><?= h(t('auth.register.type_admin')) ?></option>
                    <option value="MEMBRE" <?= old_input('type_compte') === 'MEMBRE' ? 'selected' : '' ?>><?= h(t('auth.register.type_membre')) ?></option>
                </select>
                <p class="form-section-title" style="border-top:none; padding-top:0; margin-top:0;"><?= h(t('auth.register.as')) ?></p>
                <div class="tile-grid" id="role-tiles" style="grid-template-columns:1fr 1fr;">
                    <div class="tile" data-role="ADMIN_ORGA">
                        <div class="tile-icon">▦</div>
                        <p class="tile-title"><?= h(t('auth.register.type_admin')) ?></p>
                    </div>
                    <div class="tile" data-role="MEMBRE">
                        <div class="tile-icon" style="border-radius:999px; background:var(--orange);">●</div>
                        <p class="tile-title"><?= h(t('auth.register.type_membre')) ?></p>
                    </div>
                </div>

                <div id="registration-fields"<?= old_input('type_compte') ? '' : ' style="display:none;"' ?>>
                    <div class="field">
                        <label for="nom"><?= h(t('common.fullname')) ?></label>
                        <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
                    </div>
                    <div class="form-grid">
                        <div class="field">
                            <label for="email"><?= h(t('common.email')) ?></label>
                            <input type="email" id="email" name="email" required value="<?= h(old_input('email')) ?>">
                        </div>
                        <div class="field">
                            <label for="telephone"><?= h(t('common.phone')) ?></label>
                            <input type="tel" id="telephone" name="telephone" value="<?= h(old_input('telephone')) ?>">
                        </div>
                    </div>
                    <div id="admin-fields">
                        <div class="field">
                            <label for="password"><?= h(t('auth.register.password_hint')) ?></label>
                            <input type="password" id="password" name="password" minlength="8">
                        </div>
                        <p class="text-faint mt-2"><?= h(t('auth.register.admin_org_next_hint')) ?></p>
                    </div>
                    <p id="membre-password-hint" class="text-faint"><?= h(t('auth.register.membre_password_hint')) ?></p>
                    <div class="form-grid">
                        <div class="field">
                            <label for="pays_code"><?= h(t('common.country')) ?></label>
                            <select id="pays_code" name="pays_code" required data-coat-of-arms="<?= h(coat_of_arms_urls_json()) ?>">
                                <option value=""><?= h(t('common.choose')) ?></option>
                                <?php foreach ($pays as $info): ?>
                                    <option value="<?= h($info['pays_code']) ?>" <?= old_input('pays_code') === $info['pays_code'] ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="field">
                            <label for="sexe"><?= h(t('common.sexe')) ?></label>
                            <select id="sexe" name="sexe" required>
                                <option value=""><?= h(t('common.choose')) ?></option>
                                <option value="M" <?= old_input('sexe') === 'M' ? 'selected' : '' ?>><?= h(t('enum.sexe.M')) ?></option>
                                <option value="F" <?= old_input('sexe') === 'F' ? 'selected' : '' ?>><?= h(t('enum.sexe.F')) ?></option>
                            </select>
                        </div>
                    </div>
                    <div id="membre-fields">
                        <div class="form-grid">
                            <div class="field">
                                <label for="date_naissance"><?= h(t('common.date_naissance')) ?></label>
                                <input type="date" id="date_naissance" name="date_naissance" value="<?= h(old_input('date_naissance')) ?>">
                            </div>
                            <div class="field">
                                <label for="lieu_naissance"><?= h(t('common.lieu_naissance')) ?></label>
                                <input type="text" id="lieu_naissance" name="lieu_naissance" value="<?= h(old_input('lieu_naissance')) ?>">
                            </div>
                        </div>
                        <div class="field">
                            <label for="metier"><?= h(t('common.metier')) ?></label>
                            <select id="metier" name="metier">
                                <option value=""><?= h(t('common.choose')) ?></option>
                                <?php foreach ($metiers as $metier): ?>
                                    <option value="<?= h($metier['metier_code']) ?>" <?= old_input('metier') === $metier['metier_code'] ? 'selected' : '' ?>><?= h(t('enum.metier.' . $metier['metier_code'])) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block"><?= h(t('auth.register.submit')) ?></button>
                </div>
            </form>

            <p class="auth-switch"><?= h(t('auth.register.has_account')) ?> <a href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a></p>
            <?php endif; ?>
        </div>

        <div class="auth-side">
            <div>
                <p class="page-eyebrow" style="color:var(--orange);"><?= h(t('nav.create_org')) ?></p>
                <div style="display:flex; flex-direction:column; gap:22px; margin-top:14px;">
                    <div class="row" style="align-items:flex-start; gap:14px;">
                        <div class="step-number" style="flex-shrink:0;">1</div>
                        <p style="font-family:'Source Serif 4',serif; font-size:15px; line-height:1.5; margin:4px 0 0;"><?= h(t('home.step1.title')) ?></p>
                    </div>
                    <div class="row" style="align-items:flex-start; gap:14px;">
                        <div class="step-number" style="flex-shrink:0;">2</div>
                        <p style="font-family:'Source Serif 4',serif; font-size:15px; line-height:1.5; margin:4px 0 0;"><?= h(t('home.step2.title')) ?></p>
                    </div>
                    <div class="row" style="align-items:flex-start; gap:14px;">
                        <div class="step-number" style="flex-shrink:0;">3</div>
                        <p style="font-family:'Source Serif 4',serif; font-size:15px; line-height:1.5; margin:4px 0 0;"><?= h(t('home.step3.title')) ?></p>
                    </div>
                </div>
            </div>
            <?php render_coat_of_arms(old_input('pays_code') ?: null, 'auth-side-coat-of-arms', true); ?>
            <div class="diamond-strip" style="opacity:.5; max-width:220px;">
                <span style="background:oklch(60% 0.15 45);"></span><span style="background:oklch(75% 0.13 85);"></span><span style="background:#fff;"></span>
                <span style="background:oklch(75% 0.13 85);"></span><span style="background:#fff;"></span><span style="background:oklch(60% 0.15 45);"></span>
            </div>
        </div>
    </div>
</div>
<script>
    (function () {
        var typeSelect = document.getElementById('type_compte');
        var registrationFields = document.getElementById('registration-fields');
        var membreFields = document.getElementById('membre-fields');
        var membreInputs = membreFields.querySelectorAll('input, select');
        var adminFields = document.getElementById('admin-fields');
        var adminInputs = adminFields.querySelectorAll('input, select');
        var membrePasswordHint = document.getElementById('membre-password-hint');
        var tiles = document.querySelectorAll('#role-tiles .tile');

        function updateFields() {
            var isAdmin = typeSelect.value === 'ADMIN_ORGA';

            registrationFields.style.display = typeSelect.value ? '' : 'none';

            membreFields.style.display = isAdmin ? 'none' : '';
            membreInputs.forEach(function (field) {
                field.required = !isAdmin;
            });

            adminFields.style.display = isAdmin ? '' : 'none';
            adminInputs.forEach(function (field) {
                field.required = isAdmin;
            });

            membrePasswordHint.style.display = isAdmin ? 'none' : '';

            tiles.forEach(function (tile) {
                tile.classList.toggle('active', tile.dataset.role === typeSelect.value);
            });
        }

        tiles.forEach(function (tile) {
            tile.addEventListener('click', function () {
                typeSelect.value = tile.dataset.role;
                updateFields();
            });
        });

        typeSelect.addEventListener('change', updateFields);
        updateFields();
    })();
</script>
</body>
</html>
