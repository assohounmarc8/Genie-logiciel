<?php
$errors = flash_get('errors', []);
$info = flash_get('info', []);
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('auth.login.tag')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-split">
        <div class="auth-side">
            <div class="auth-brand">
                <div class="sidebar-logo">M</div>
                <div>
                    <p class="auth-brand-name" style="color:#fff;">MON<span class="accent">ASSO</span></p>
                </div>
            </div>
            <div>
                <p class="auth-quote"><?= h(t('auth.login.quote')) ?></p>
                <p class="auth-quote-by"><?= h(t('auth.login.quote_by')) ?></p>
            </div>
            <div class="diamond-strip" style="opacity:.5; max-width:220px;">
                <span style="background:oklch(60% 0.15 45);"></span><span style="background:oklch(75% 0.13 85);"></span><span style="background:#fff;"></span>
                <span style="background:oklch(75% 0.13 85);"></span><span style="background:#fff;"></span><span style="background:oklch(60% 0.15 45);"></span>
            </div>
        </div>

        <div class="auth-form-side">
            <?php render_back_home_btn(); ?>
            <div class="row between" style="margin-bottom:22px;">
                <p class="page-eyebrow" style="margin:0;"><?= h(t('auth.login.tag')) ?></p>
                <?php render_country_switcher('light'); ?>
            </div>
            <h1 class="page-title" style="margin-bottom:28px;"><?= h(t('auth.login.tag')) ?></h1>

            <?php if ($info): ?>
            <div class="auth-info">
                <?php foreach ($info as $message): ?><p><?= h($message) ?></p><?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($errors): ?>
            <div class="auth-error">
                <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
            </div>
            <?php endif; ?>

            <form method="post" action="<?= h(route_url('auth/login')) ?>">
                <div class="field">
                    <label for="email"><?= h(t('common.email')) ?></label>
                    <input type="email" id="email" name="email" required value="<?= h(old_input('email')) ?>">
                </div>
                <div class="field">
                    <label for="password"><?= h(t('common.password')) ?></label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block"><?= h(t('common.login')) ?></button>
            </form>

            <p class="auth-switch"><?= h(t('auth.login.no_account')) ?> <a href="<?= h(route_url('auth/register')) ?>"><?= h(t('common.register')) ?></a></p>
        </div>
    </div>
</div>
</body>
</html>
