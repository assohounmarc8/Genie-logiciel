    </div>
    <footer class="landing-footer">
        <p><?= h(t('home.footer')) ?></p>
    </footer>
</div>
<script src="<?= h(asset_url('/assets/js/reveal.js')) ?>"></script>
</body>
</html>
