<?php

/** @var array $user */
$user = Auth::user();
if (!$user) {
    redirect_route('auth/login');
}

$currentRoute = current_route();

$sidebarOrg = null;
if ($user['type_compte'] === 'ADMIN_ORGA') {
    $sidebarOrg = OrganisationModel::findByAdmin($user['user_code']);
}

$primaryMembership = null;
if ($user['type_compte'] === 'MEMBRE') {
    $primaryMembership = OrganisationUserModel::primaryActiveMembership($user['user_code']);
}

$unreadNotifCount = NotificationModel::countUnread($user['user_code']);
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO</title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="topbar">
    <div>
        <p class="topbar-title">MONASSO</p>
        <p class="topbar-subtitle"><?= h(t('nav.tagline')) ?></p>
    </div>
    <div class="topbar-right">
        <?php render_country_switcher('dark'); ?>
        <a class="notif-bell" href="<?= h(route_url('notifications/index')) ?>" title="<?= h(t('nav.notifications')) ?>">
            🔔
            <?php if ($unreadNotifCount > 0): ?>
                <span class="notif-badge"><?= h($unreadNotifCount > 9 ? '9+' : (string) $unreadNotifCount) ?></span>
            <?php endif; ?>
        </a>
        <span class="topbar-pill"><?= flag_img_html($user['pays_code']) ?></span>
        <?= badge_html(t('enum.type_compte.' . $user['type_compte']), 'orange') ?>
        <a class="topbar-user" href="<?= h(route_url('profile/index')) ?>">
            <p class="name"><?= h($user['nom']) ?></p>
            <p class="role"><?= h($user['email']) ?></p>
        </a>
        <a href="<?= h(route_url('profile/index')) ?>" title="<?= h(t('nav.profile')) ?>" style="width:32px; height:32px; border-radius:999px; background:var(--orange); color:#fff; display:flex; align-items:center; justify-content:center; font:700 12px 'Work Sans'; flex-shrink:0; text-decoration:none;"><?= h(mb_strtoupper(mb_substr($user['nom'], 0, 1))) ?></a>
        <a class="btn-logout" href="<?= h(route_url('auth/logout')) ?>"><?= h(t('nav.logout')) ?></a>
    </div>
</div>
<div class="body-row">
    <aside class="sidebar">
        <div class="sidebar-brand-block">
            <div class="sidebar-brand">
                <div class="sidebar-logo">M</div>
                <div>
                    <p class="sidebar-brand-name">MON<span class="accent">ASSO</span></p>
                    <p class="sidebar-brand-tag">V1 — MVC + MySQL</p>
                </div>
            </div>
            <?php if (in_array($user['type_compte'], ['MEMBRE', 'ADMIN_ORGA'], true) && !empty($user['pays_code'])): ?>
                <?php render_coat_of_arms($user['pays_code'], 'sidebar-coat-of-arms'); ?>
            <?php endif; ?>
        </div>

        <div class="nav-group">
            <div class="nav-group-label"><span>📊</span><span><?= h(t('nav.group.general')) ?></span></div>
            <a class="nav-link<?= $currentRoute === 'dashboard/index' ? ' active' : '' ?>" href="<?= h(route_url('dashboard/index')) ?>"><?= h(t('nav.dashboard')) ?></a>
            <a class="nav-link<?= $currentRoute === 'notifications/index' ? ' active' : '' ?>" href="<?= h(route_url('notifications/index')) ?>"><?= h(t('nav.notifications')) ?><?= $unreadNotifCount > 0 ? ' (' . h($unreadNotifCount) . ')' : '' ?></a>
            <a class="nav-link<?= $currentRoute === 'audit/index' ? ' active' : '' ?>" href="<?= h(route_url('audit/index')) ?>"><?= h(t('nav.audit')) ?></a>
            <a class="nav-link<?= $currentRoute === 'profile/index' ? ' active' : '' ?>" href="<?= h(route_url('profile/index')) ?>"><?= h(t('nav.profile')) ?></a>
        </div>

        <?php if ($user['type_compte'] === 'SUPER_ADMIN'): ?>
        <div class="nav-group">
            <div class="nav-group-label"><span>🏢</span><span><?= h(t('nav.group.platform')) ?></span></div>
            <a class="nav-link<?= $currentRoute === 'organisations/index' ? ' active' : '' ?>" href="<?= h(route_url('organisations/index')) ?>"><?= h(t('nav.organisations')) ?></a>
            <a class="nav-link<?= in_array($currentRoute, ['opportunites/index', 'opportunites/creer', 'opportunites/detail', 'opportunites/candidatures'], true) ? ' active' : '' ?>" href="<?= h(route_url('opportunites/index')) ?>"><?= h(t('nav.opportunites')) ?></a>
        </div>
        <?php endif; ?>

        <?php if ($user['type_compte'] === 'ADMIN_ORGA'): ?>
        <div class="nav-group">
            <div class="nav-group-label"><span>🏢</span><span><?= h(t('nav.group.my_org')) ?></span></div>
            <?php if ($sidebarOrg && $sidebarOrg['statut_validation'] === 'VAL'): ?>
                <a class="nav-link<?= $currentRoute === 'organisations/detail' ? ' active' : '' ?>" href="<?= h(route_url('organisations/detail', ['id' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.overview')) ?></a>
                <a class="nav-link<?= $currentRoute === 'membres/index' ? ' active' : '' ?>" href="<?= h(route_url('membres/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h($sidebarOrg['type_organisation'] === 'MUTUELLE' ? t('nav.cotisants') : t('nav.membres')) ?></a>
                <a class="nav-link<?= $currentRoute === 'roles/index' ? ' active' : '' ?>" href="<?= h(route_url('roles/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.roles')) ?></a>
                <a class="nav-link<?= $currentRoute === 'cotisations/index' ? ' active' : '' ?>" href="<?= h(route_url('cotisations/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.cotisations')) ?></a>
                <?php if ($sidebarOrg['type_organisation'] === 'MUTUELLE'): ?>
                    <a class="nav-link<?= $currentRoute === 'prestations/index' ? ' active' : '' ?>" href="<?= h(route_url('prestations/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.prestations')) ?></a>
                <?php endif; ?>
                <?php if ($sidebarOrg['type_organisation'] === 'ONG'): ?>
                    <a class="nav-link<?= $currentRoute === 'programmes/index' ? ' active' : '' ?>" href="<?= h(route_url('programmes/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.programmes')) ?></a>
                    <a class="nav-link<?= $currentRoute === 'beneficiaires/index' ? ' active' : '' ?>" href="<?= h(route_url('beneficiaires/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.beneficiaires')) ?></a>
                    <a class="nav-link<?= $currentRoute === 'bailleurs/index' ? ' active' : '' ?>" href="<?= h(route_url('bailleurs/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.bailleurs')) ?></a>
                <?php endif; ?>
                <a class="nav-link<?= $currentRoute === 'depenses/index' ? ' active' : '' ?>" href="<?= h(route_url('depenses/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.depenses')) ?></a>
                <a class="nav-link<?= $currentRoute === 'documents/index' ? ' active' : '' ?>" href="<?= h(route_url('documents/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.documents')) ?></a>
                <a class="nav-link<?= $currentRoute === 'besoins/index' ? ' active' : '' ?>" href="<?= h(route_url('besoins/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.besoins')) ?></a>
                <a class="nav-link<?= $currentRoute === 'evenements/index' ? ' active' : '' ?>" href="<?= h(route_url('evenements/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.evenements')) ?></a>
                <a class="nav-link<?= $currentRoute === 'cartes/index' ? ' active' : '' ?>" href="<?= h(route_url('cartes/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.cartes')) ?></a>
                <a class="nav-link<?= $currentRoute === 'communications/index' ? ' active' : '' ?>" href="<?= h(route_url('communications/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.communications')) ?></a>
                <a class="nav-link<?= $currentRoute === 'chat/index' ? ' active' : '' ?>" href="<?= h(route_url('chat/index', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.discussions')) ?></a>
                <a class="nav-link<?= $currentRoute === 'opportunites/index' ? ' active' : '' ?>" href="<?= h(route_url('opportunites/index')) ?>"><?= h(t('nav.opportunites')) ?></a>
                <a class="nav-link<?= $currentRoute === 'opportunites/mesCandidatures' ? ' active' : '' ?>" href="<?= h(route_url('opportunites/mesCandidatures')) ?>"><?= h(t('nav.mes_candidatures')) ?></a>
                <a class="nav-link<?= $currentRoute === 'organisations/parametres' ? ' active' : '' ?>" href="<?= h(route_url('organisations/parametres', ['org' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.parametres')) ?></a>
            <?php elseif ($sidebarOrg): ?>
                <a class="nav-link<?= $currentRoute === 'organisations/detail' ? ' active' : '' ?>" href="<?= h(route_url('organisations/detail', ['id' => $sidebarOrg['organisation_code']])) ?>"><?= h(t('nav.overview')) ?></a>
            <?php else: ?>
                <a class="nav-link" href="<?= h(route_url('organisations/creer')) ?>"><?= h(t('nav.create_org')) ?></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($user['type_compte'] === 'MEMBRE' && $primaryMembership && $primaryMembership['role_code']): ?>
        <?php $pmOrg = $primaryMembership['organisation_code']; ?>
        <div class="nav-group">
            <div class="nav-group-label"><span>🏢</span><span><?= h($primaryMembership['organisation_nom']) ?></span></div>
            <?php if (Middleware::can($pmOrg, 'gerer_membres') || Middleware::can($pmOrg, 'valider_adherent') || Middleware::can($pmOrg, 'voir_membres')): ?>
                <a class="nav-link<?= $currentRoute === 'membres/index' ? ' active' : '' ?>" href="<?= h(route_url('membres/index', ['org' => $pmOrg])) ?>"><?= h($primaryMembership['organisation_type'] === 'MUTUELLE' ? t('nav.cotisants') : t('nav.membres')) ?></a>
            <?php endif; ?>
            <a class="nav-link<?= $currentRoute === 'roles/index' ? ' active' : '' ?>" href="<?= h(route_url('roles/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.roles')) ?></a>
            <?php if (Middleware::can($pmOrg, 'creer_cotisation') || Middleware::can($pmOrg, 'voir_finances')): ?>
                <a class="nav-link<?= $currentRoute === 'cotisations/index' ? ' active' : '' ?>" href="<?= h(route_url('cotisations/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.cotisations')) ?></a>
            <?php endif; ?>
            <?php if ($primaryMembership['organisation_type'] === 'MUTUELLE' && Middleware::can($pmOrg, 'gerer_prestations')): ?>
                <a class="nav-link<?= $currentRoute === 'prestations/index' ? ' active' : '' ?>" href="<?= h(route_url('prestations/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.prestations')) ?></a>
            <?php elseif ($primaryMembership['organisation_type'] === 'MUTUELLE'): ?>
                <a class="nav-link<?= $currentRoute === 'prestations/creer' ? ' active' : '' ?>" href="<?= h(route_url('prestations/creer', ['org' => $pmOrg])) ?>"><?= h(t('nav.prestations')) ?></a>
            <?php endif; ?>
            <?php if ($primaryMembership['organisation_type'] === 'ONG' && Middleware::can($pmOrg, 'gerer_projets')): ?>
                <a class="nav-link<?= $currentRoute === 'programmes/index' ? ' active' : '' ?>" href="<?= h(route_url('programmes/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.programmes')) ?></a>
            <?php endif; ?>
            <?php if ($primaryMembership['organisation_type'] === 'ONG' && Middleware::can($pmOrg, 'gerer_beneficiaires')): ?>
                <a class="nav-link<?= $currentRoute === 'beneficiaires/index' ? ' active' : '' ?>" href="<?= h(route_url('beneficiaires/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.beneficiaires')) ?></a>
            <?php endif; ?>
            <?php if ($primaryMembership['organisation_type'] === 'ONG' && Middleware::can($pmOrg, 'gerer_bailleurs')): ?>
                <a class="nav-link<?= $currentRoute === 'bailleurs/index' ? ' active' : '' ?>" href="<?= h(route_url('bailleurs/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.bailleurs')) ?></a>
            <?php endif; ?>
            <?php if (Middleware::can($pmOrg, 'gerer_depenses')): ?>
                <a class="nav-link<?= $currentRoute === 'depenses/index' ? ' active' : '' ?>" href="<?= h(route_url('depenses/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.depenses')) ?></a>
            <?php endif; ?>
            <?php if (Middleware::can($pmOrg, 'voir_documents') || Middleware::can($pmOrg, 'gerer_documents')): ?>
                <a class="nav-link<?= $currentRoute === 'documents/index' ? ' active' : '' ?>" href="<?= h(route_url('documents/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.documents')) ?></a>
            <?php endif; ?>
            <?php if (Middleware::can($pmOrg, 'gerer_besoins')): ?>
                <a class="nav-link<?= $currentRoute === 'besoins/index' ? ' active' : '' ?>" href="<?= h(route_url('besoins/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.besoins')) ?></a>
            <?php endif; ?>
            <a class="nav-link<?= $currentRoute === 'opportunites/index' ? ' active' : '' ?>" href="<?= h(route_url('opportunites/index')) ?>"><?= h(t('nav.opportunites')) ?></a>
            <a class="nav-link<?= $currentRoute === 'opportunites/mesCandidatures' ? ' active' : '' ?>" href="<?= h(route_url('opportunites/mesCandidatures')) ?>"><?= h(t('nav.mes_candidatures')) ?></a>
            <?php if (Middleware::can($pmOrg, 'gerer_evenements')): ?>
                <a class="nav-link<?= $currentRoute === 'evenements/index' ? ' active' : '' ?>" href="<?= h(route_url('evenements/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.evenements')) ?></a>
            <?php endif; ?>
            <?php if (Middleware::can($pmOrg, 'gerer_cartes')): ?>
                <a class="nav-link<?= $currentRoute === 'cartes/index' ? ' active' : '' ?>" href="<?= h(route_url('cartes/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.cartes')) ?></a>
            <?php endif; ?>
            <?php if (Middleware::can($pmOrg, 'envoyer_notification')): ?>
                <a class="nav-link<?= $currentRoute === 'communications/index' ? ' active' : '' ?>" href="<?= h(route_url('communications/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.communications')) ?></a>
            <?php endif; ?>
            <a class="nav-link<?= $currentRoute === 'chat/index' ? ' active' : '' ?>" href="<?= h(route_url('chat/index', ['org' => $pmOrg])) ?>"><?= h(t('nav.discussions')) ?></a>
            <?php if (Middleware::can($pmOrg, 'gerer_organisation')): ?>
                <a class="nav-link<?= $currentRoute === 'organisations/parametres' ? ' active' : '' ?>" href="<?= h(route_url('organisations/parametres', ['org' => $pmOrg])) ?>"><?= h(t('nav.parametres')) ?></a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if ($user['type_compte'] === 'MEMBRE'): ?>
        <div class="nav-group">
            <div class="nav-group-label"><span>👤</span><span><?= h(t('nav.group.my_space')) ?></span></div>
            <a class="nav-link<?= $currentRoute === 'membres/organisationsDisponibles' ? ' active' : '' ?>" href="<?= h(route_url('membres/organisationsDisponibles')) ?>"><?= h(t('nav.available_orgs')) ?></a>
            <a class="nav-link<?= $currentRoute === 'cotisations/mes' ? ' active' : '' ?>" href="<?= h(route_url('cotisations/mes')) ?>"><?= h(t('nav.my_cotisations')) ?></a>
            <a class="nav-link<?= $currentRoute === 'evenements/mes' ? ' active' : '' ?>" href="<?= h(route_url('evenements/mes')) ?>"><?= h(t('nav.my_evenements')) ?></a>
            <a class="nav-link<?= $currentRoute === 'cartes/mes' ? ' active' : '' ?>" href="<?= h(route_url('cartes/mes')) ?>"><?= h(t('nav.my_carte')) ?></a>
        </div>
        <?php endif; ?>
    </aside>
    <main class="content">
        <div class="content-inner">
