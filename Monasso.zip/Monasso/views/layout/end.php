        </div>
    </main>
</div>
<script src="<?= h(asset_url('/assets/js/reveal.js')) ?>"></script>
<?php if (!empty($autoRefreshSeconds)): ?>
<script>
(function () {
    var seconds = <?= (int) $autoRefreshSeconds ?>;
    setInterval(function () {
        var active = document.activeElement;
        var isBusy = active && ['INPUT', 'TEXTAREA', 'SELECT'].indexOf(active.tagName) !== -1;
        if (!isBusy) {
            location.reload();
        }
    }, seconds * 1000);
})();
</script>
<?php endif; ?>
</body>
</html>
