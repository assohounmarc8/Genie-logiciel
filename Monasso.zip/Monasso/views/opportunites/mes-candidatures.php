<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('opportunites.mes.title')) ?></h1>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('opportunites.mes.col_opportunite')) ?></th>
            <th><?= h(t('opportunites.field.type')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th><?= h(t('opportunites.candidatures.montant_accorde')) ?></th>
            <th><?= h(t('opportunites.mes.total_verse')) ?></th>
            <th><?= h(t('common.date')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$candidatures): ?><tr><td colspan="6" class="table-empty"><?= h(t('opportunites.mes.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($candidatures as $candidature): ?>
            <tr>
                <td><a class="link-strong" href="<?= h(route_url('opportunites/detail', ['id' => $candidature['opportunite_code']])) ?>"><?= h($candidature['opportunite_titre']) ?></a></td>
                <td><?= badge_html(t('enum.type_opportunite.' . $candidature['type_opportunite']), 'orange') ?></td>
                <td><?= enum_badge_html('candidature_statut', $candidature['statut']) ?></td>
                <td><?= $candidature['montant_accorde'] !== null ? h(format_money((float) $candidature['montant_accorde'])) : '—' ?></td>
                <td><?= h(format_money($totalVerseByCandidature[$candidature['candidature_code']] ?? 0)) ?></td>
                <td><?= h(format_date($candidature['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
