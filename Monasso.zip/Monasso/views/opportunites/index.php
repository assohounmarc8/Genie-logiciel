<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('nav.group.platform')) ?></p>
            <h1 class="page-title"><?= h(t('opportunites.index.title')) ?></h1>
            <p class="page-subtitle"><?= h(t('opportunites.index.subtitle', ['count' => count($opportunites)])) ?></p>
        </div>
        <?php if ($isSuperAdmin): ?>
        <?php $viewingArchive = ($filters['statut'] ?? '') === 'ARCHIVE'; ?>
        <div class="row">
            <?php if ($viewingArchive): ?>
                <a class="btn btn-outline btn-sm" href="<?= h(route_url('opportunites/index')) ?>"><?= h(t('opportunites.back_to_current_btn')) ?></a>
            <?php else: ?>
                <a class="btn btn-outline btn-sm" href="<?= h(route_url('opportunites/index', ['statut' => 'ARCHIVE'])) ?>"><?= h(t('opportunites.past_opportunities_btn')) ?></a>
            <?php endif; ?>
            <a class="btn btn-primary btn-sm" href="<?= h(route_url('opportunites/creer')) ?>"><?= h(t('opportunites.index.new')) ?></a>
        </div>
        <?php endif; ?>
    </div>

    <div class="card"><div class="card-body">
        <form method="get" action="<?= h(route_url('opportunites/index')) ?>" class="form-grid">
            <div class="field">
                <label for="q"><?= h(t('opportunites.filter.q')) ?></label>
                <input type="text" id="q" name="q" value="<?= h($filters['q']) ?>" placeholder="<?= h(t('opportunites.filter.q_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="type"><?= h(t('opportunites.filter.type')) ?></label>
                <select id="type" name="type">
                    <option value=""><?= h(t('opportunites.filter.type_all')) ?></option>
                    <?php foreach (TypeOpportuniteModel::all() as $type): ?>
                        <option value="<?= h($type['type_opportunite_code']) ?>" <?= $filters['type'] === $type['type_opportunite_code'] ? 'selected' : '' ?>><?= h(t('enum.type_opportunite.' . $type['type_opportunite_code'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="pays"><?= h(t('opportunites.filter.pays')) ?></label>
                <select id="pays" name="pays">
                    <option value=""><?= h(t('opportunites.field.pays_all')) ?></option>
                    <?php foreach (PaysModel::all() as $pays): ?>
                        <option value="<?= h($pays['pays_code']) ?>" <?= $filters['pays'] === $pays['pays_code'] ? 'selected' : '' ?>><?= h($pays['drapeau'] . ' ' . $pays['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($isSuperAdmin): ?>
            <div class="field">
                <label for="statut"><?= h(t('opportunites.filter.statut')) ?></label>
                <select id="statut" name="statut">
                    <option value=""><?= h(t('common.all')) ?></option>
                    <option value="ACTIF" <?= ($filters['statut'] ?? '') === 'ACTIF' ? 'selected' : '' ?>><?= h(t('enum.opportunite_statut.ACTIF')) ?></option>
                    <option value="FERME" <?= ($filters['statut'] ?? '') === 'FERME' ? 'selected' : '' ?>><?= h(t('enum.opportunite_statut.FERME')) ?></option>
                    <option value="ARCHIVE" <?= ($filters['statut'] ?? '') === 'ARCHIVE' ? 'selected' : '' ?>><?= h(t('enum.opportunite_statut.ARCHIVE')) ?></option>
                </select>
            </div>
            <?php endif; ?>
            <div class="field" style="align-self:end;">
                <button type="submit" class="btn btn-primary"><?= h(t('opportunites.filter.submit')) ?></button>
            </div>
        </form>
    </div></div>

    <?php if (!$opportunites): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('opportunites.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="stack">
        <?php foreach ($opportunites as $opp): ?>
        <?php $maCandidature = $candidaturesByOpportunite[$opp['opportunite_code']] ?? null; ?>
        <div class="card"><div class="card-body">
            <div class="row between">
                <div>
                    <p class="card-title">
                        <a class="link-strong" href="<?= h(route_url('opportunites/detail', ['id' => $opp['opportunite_code']])) ?>"><?= h($opp['titre']) ?></a>
                    </p>
                    <p class="text-faint text-mono"><?= h($opp['opportunite_code']) ?></p>
                </div>
                <div class="row">
                    <?= badge_html(t('enum.type_opportunite.' . $opp['type_opportunite']), 'orange') ?>
                    <?= enum_badge_html('opportunite_statut', $opp['statut']) ?>
                    <?php if ($maCandidature): ?>
                        <?= enum_badge_html('candidature_statut', $maCandidature['statut']) ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-grid mt-2">
                <?php if ($opp['montant'] !== null): ?>
                <div><p class="kpi-label"><?= h(t('opportunites.field.montant')) ?></p><p class="mt-2"><?= h(format_money((float) $opp['montant'])) ?></p></div>
                <?php endif; ?>
                <div><p class="kpi-label"><?= h(t('common.country')) ?></p><p class="mt-2"><?= h(pays_label($opp['pays_code'])) ?></p></div>
                <div><p class="kpi-label"><?= h(t('opportunites.field.date_limite')) ?></p><p class="mt-2"><?= h(format_date($opp['date_limite'])) ?></p></div>
            </div>
            <?php if ($isSuperAdmin && $opp['statut'] === 'FERME'): ?>
            <div class="row end mt-2">
                <form method="post" action="<?= h(route_url('opportunites/archiver')) ?>" onsubmit="return confirm('<?= h(t('opportunites.confirm_archive')) ?>');">
                    <input type="hidden" name="id" value="<?= h($opp['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.archive_btn')) ?></button>
                </form>
            </div>
            <?php elseif ($isSuperAdmin && $opp['statut'] === 'ARCHIVE'): ?>
            <div class="row end mt-2">
                <form method="post" action="<?= h(route_url('opportunites/desarchiver')) ?>">
                    <input type="hidden" name="id" value="<?= h($opp['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.unarchive_btn')) ?></button>
                </form>
            </div>
            <?php endif; ?>
        </div></div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
