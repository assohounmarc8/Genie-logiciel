<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.platform')) ?></p>
        <h1 class="page-title"><?= h(t('opportunites.creer.title')) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('opportunites/creer')) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="titre"><?= h(t('opportunites.field.titre')) ?></label>
                <input type="text" id="titre" name="titre" required value="<?= h(old_input('titre')) ?>" placeholder="<?= h(t('opportunites.field.titre_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="description"><?= h(t('opportunites.field.description')) ?></label>
                <textarea id="description" name="description" required><?= h(old_input('description')) ?></textarea>
            </div>
            <div class="form-grid">
                <div class="field">
                    <label for="type_opportunite"><?= h(t('opportunites.field.type')) ?></label>
                    <select id="type_opportunite" name="type_opportunite">
                        <?php foreach (TypeOpportuniteModel::all() as $type): ?>
                            <option value="<?= h($type['type_opportunite_code']) ?>"><?= h(t('enum.type_opportunite.' . $type['type_opportunite_code'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label for="montant"><?= h(t('opportunites.field.montant')) ?></label>
                    <input type="number" id="montant" name="montant" min="1" step="1" value="<?= h(old_input('montant')) ?>">
                </div>
                <div class="field">
                    <label for="pays_code"><?= h(t('opportunites.field.pays')) ?></label>
                    <select id="pays_code" name="pays_code">
                        <option value=""><?= h(t('opportunites.field.pays_all')) ?></option>
                        <?php foreach (PaysModel::all() as $pays): ?>
                            <option value="<?= h($pays['pays_code']) ?>"><?= h($pays['drapeau'] . ' ' . $pays['nom']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="field">
                    <label for="date_limite"><?= h(t('opportunites.field.date_limite')) ?></label>
                    <input type="date" id="date_limite" name="date_limite" value="<?= h(old_input('date_limite')) ?>">
                </div>
            </div>
        </div></div>
        <div class="card mt-2"><div class="card-body">
            <p class="kpi-label"><?= h(t('opportunites.field.contact_section')) ?></p>
            <p class="text-faint mt-0"><?= h(t('opportunites.field.email_contact_hint')) ?></p>
            <div class="form-grid mt-2">
                <div class="field">
                    <label for="nom_contact"><?= h(t('opportunites.field.nom_contact')) ?></label>
                    <input type="text" id="nom_contact" name="nom_contact" value="<?= h(old_input('nom_contact')) ?>">
                </div>
                <div class="field">
                    <label for="email_contact"><?= h(t('opportunites.field.email_contact')) ?></label>
                    <input type="email" id="email_contact" name="email_contact" value="<?= h(old_input('email_contact')) ?>">
                </div>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('opportunites/index')) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('opportunites.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
