<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('nav.group.platform')) ?></p>
            <h1 class="page-title"><?= h($opportunite['titre']) ?></h1>
            <p class="page-subtitle text-mono"><?= h($opportunite['opportunite_code']) ?></p>
        </div>
        <div class="row">
            <?= badge_html(t('enum.type_opportunite.' . $opportunite['type_opportunite']), 'orange') ?>
            <?= enum_badge_html('opportunite_statut', $opportunite['statut']) ?>
            <?php if ($isSuperAdmin): ?>
                <a class="btn btn-outline btn-sm" href="<?= h(route_url('opportunites/candidatures', ['id' => $opportunite['opportunite_code']])) ?>"><?= h(t('opportunites.candidatures.manage_link')) ?></a>
                <?php if ($opportunite['statut'] === 'ACTIF'): ?>
                <form method="post" action="<?= h(route_url('opportunites/fermer')) ?>" onsubmit="return confirm('<?= h(t('opportunites.confirm_close')) ?>');">
                    <input type="hidden" name="id" value="<?= h($opportunite['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.close_btn')) ?></button>
                </form>
                <?php elseif ($opportunite['statut'] === 'FERME'): ?>
                <form method="post" action="<?= h(route_url('opportunites/reouvrir')) ?>">
                    <input type="hidden" name="id" value="<?= h($opportunite['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.reopen_btn')) ?></button>
                </form>
                <?php endif; ?>
                <?php if ($peutArchiver): ?>
                <form method="post" action="<?= h(route_url('opportunites/archiver')) ?>" onsubmit="return confirm('<?= h(t('opportunites.confirm_archive')) ?>');">
                    <input type="hidden" name="id" value="<?= h($opportunite['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.archive_btn')) ?></button>
                </form>
                <?php endif; ?>
                <?php if ($opportunite['statut'] === 'ARCHIVE'): ?>
                <form method="post" action="<?= h(route_url('opportunites/desarchiver')) ?>">
                    <input type="hidden" name="id" value="<?= h($opportunite['opportunite_code']) ?>">
                    <button type="submit" class="btn btn-outline btn-sm"><?= h(t('opportunites.unarchive_btn')) ?></button>
                </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php render_form_errors($errors); ?>

    <div class="card"><div class="card-body">
        <div class="form-grid">
            <?php if ($opportunite['montant'] !== null): ?>
            <div><p class="kpi-label"><?= h(t('opportunites.field.montant')) ?></p><p class="mt-2"><?= h(format_money((float) $opportunite['montant'])) ?></p></div>
            <?php endif; ?>
            <div><p class="kpi-label"><?= h(t('common.country')) ?></p><p class="mt-2"><?= flag_img_html($opportunite['pays_code']) ?></p></div>
            <div><p class="kpi-label"><?= h(t('opportunites.field.date_limite')) ?></p><p class="mt-2"><?= h(format_date($opportunite['date_limite'])) ?></p></div>
            <div><p class="kpi-label"><?= h(t('opportunites.field.publie_par')) ?></p><p class="mt-2"><?= h($opportunite['cree_par_nom']) ?></p></div>
        </div>
        <p class="kpi-label mt-2"><?= h(t('opportunites.field.description')) ?></p>
        <p class="mt-2"><?= nl2br(h($opportunite['description'])) ?></p>
    </div></div>

    <?php if ($candidature): ?>
    <div class="card"><div class="card-body">
        <div class="row between">
            <p class="card-title"><?= h(t('opportunites.ma_candidature_title')) ?></p>
            <?= enum_badge_html('candidature_statut', $candidature['statut']) ?>
        </div>
        <p class="kpi-label mt-2"><?= h(t('opportunites.field.message')) ?></p>
        <p class="mt-2"><?= nl2br(h($candidature['message'])) ?></p>

        <?php if ($candidature['statut'] === 'ACCEPTEE' && !empty($opportunite['email_contact'])): ?>
            <p class="kpi-label mt-2"><?= h(t('opportunites.detail.contact_entreprise')) ?></p>
            <p class="mt-2">
                <?= h($opportunite['nom_contact'] ?: t('common.none')) ?>
                — <a class="link-strong" href="mailto:<?= h($opportunite['email_contact']) ?>"><?= h($opportunite['email_contact']) ?></a>
            </p>
        <?php endif; ?>

        <?php if ($candidature['statut'] === 'REFUSEE' && !empty($candidature['motif_refus'])): ?>
            <p class="kpi-label mt-2"><?= h(t('opportunites.candidatures.motif_refus')) ?></p>
            <p class="mt-2"><?= nl2br(h($candidature['motif_refus'])) ?></p>
        <?php endif; ?>

        <?php if ($candidature['statut'] === 'ACCEPTEE' && $opportunite['type_opportunite'] === 'FINANCEMENT'): ?>
        <div class="form-grid mt-2">
            <div><p class="kpi-label"><?= h(t('opportunites.candidatures.montant_accorde')) ?></p><p class="mt-2"><?= h(format_money((float) $candidature['montant_accorde'])) ?></p></div>
            <div><p class="kpi-label"><?= h(t('opportunites.versements_title')) ?></p><p class="mt-2"><?= h(format_money($totalVerse)) ?></p></div>
        </div>
        <div class="table-wrap mt-2"><table class="data-table">
            <thead><tr><th><?= h(t('common.amount')) ?></th><th><?= h(t('dons.field.mode')) ?></th><th><?= h(t('opportunites.versements.field.reference')) ?></th><th><?= h(t('common.date')) ?></th></tr></thead>
            <tbody>
                <?php if (!$versements): ?><tr><td colspan="4" class="table-empty"><?= h(t('opportunites.versements.empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($versements as $versement): ?>
                <tr>
                    <td><?= h(format_money((float) $versement['montant'])) ?></td>
                    <td><?= h(t('enum.mode_paiement.' . $versement['mode_paiement'])) ?></td>
                    <td><?= h($versement['reference'] ?? '—') ?></td>
                    <td><?= h(format_datetime($versement['date_versement'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php endif; ?>
    </div></div>
    <?php elseif ($peutPostuler): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('opportunites.detail.postuler_title')) ?></p>
        <form method="post" action="<?= h(route_url('opportunites/postuler')) ?>" class="mt-2">
            <input type="hidden" name="id" value="<?= h($opportunite['opportunite_code']) ?>">
            <div class="field">
                <label for="message"><?= h(t('opportunites.field.message')) ?></label>
                <textarea id="message" name="message" required></textarea>
            </div>
            <div class="row end mt-2">
                <button type="submit" class="btn btn-primary"><?= h(t('opportunites.postuler.submit')) ?></button>
            </div>
        </form>
    </div></div>
    <?php elseif ($orgContext && $opportunite['statut'] !== 'ACTIF'): ?>
    <div class="card"><div class="card-body"><?= h(t('opportunites.postuler.closed')) ?></div></div>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
