<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.platform')) ?></p>
        <h1 class="page-title"><?= h(t('opportunites.candidatures_title')) ?></h1>
        <p class="page-subtitle"><?= h($opportunite['titre']) ?></p>
        <p class="text-faint mt-2"><?= h(t('opportunites.candidatures.kanban_hint')) ?></p>
    </div>

    <?php render_form_errors($errors); ?>

    <?php
    $renderCard = function (array $candidature) use ($opportunite, $versementsByCandidature, $totalVerseByCandidature) {
        ?>
        <div class="card"><div class="card-body">
            <div class="row between">
                <div>
                    <p class="card-title"><?= h($candidature['organisation_nom']) ?></p>
                    <p class="text-faint text-mono"><?= h($candidature['candidature_code']) ?> · <?= flag_img_html($candidature['pays_code']) ?></p>
                </div>
                <?= enum_badge_html('candidature_statut', $candidature['statut']) ?>
            </div>
            <p class="kpi-label mt-2"><?= h(t('opportunites.candidatures.col_message')) ?></p>
            <p class="mt-2"><?= nl2br(h($candidature['message'])) ?></p>
            <p class="text-faint mt-2"><?= h(format_datetime($candidature['created_at'])) ?></p>

            <?php if ($candidature['statut'] === 'REFUSEE' && !empty($candidature['motif_refus'])): ?>
                <p class="kpi-label mt-2"><?= h(t('opportunites.candidatures.motif_refus')) ?></p>
                <p class="mt-2"><?= nl2br(h($candidature['motif_refus'])) ?></p>
            <?php endif; ?>

            <?php if ($candidature['statut'] === 'ACCEPTEE' && $opportunite['type_opportunite'] === 'FINANCEMENT'): ?>
            <?php $reste = (float) $candidature['montant_accorde'] - $totalVerseByCandidature[$candidature['candidature_code']]; ?>
            <div class="form-grid mt-2">
                <div><p class="kpi-label"><?= h(t('opportunites.candidatures.montant_accorde')) ?></p><p class="mt-2"><?= h(format_money((float) $candidature['montant_accorde'])) ?></p></div>
                <div><p class="kpi-label"><?= h(t('opportunites.versements_title')) ?></p><p class="mt-2"><?= h(format_money($totalVerseByCandidature[$candidature['candidature_code']])) ?></p></div>
            </div>

            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr><th><?= h(t('common.amount')) ?></th><th><?= h(t('dons.field.mode')) ?></th><th><?= h(t('opportunites.versements.field.reference')) ?></th><th><?= h(t('common.date')) ?></th></tr></thead>
                <tbody>
                    <?php if (!$versementsByCandidature[$candidature['candidature_code']]): ?><tr><td colspan="4" class="table-empty"><?= h(t('opportunites.versements.empty')) ?></td></tr><?php endif; ?>
                    <?php foreach ($versementsByCandidature[$candidature['candidature_code']] as $versement): ?>
                    <tr>
                        <td><?= h(format_money((float) $versement['montant'])) ?></td>
                        <td><?= h(t('enum.mode_paiement.' . $versement['mode_paiement'])) ?></td>
                        <td><?= h($versement['reference'] ?? '—') ?></td>
                        <td><?= h(format_datetime($versement['date_versement'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>

            <?php if ($reste > 0.001): ?>
            <form method="post" action="<?= h(route_url('opportunites/verser')) ?>" class="row mt-2">
                <input type="hidden" name="id" value="<?= h($candidature['candidature_code']) ?>">
                <input type="number" name="montant" min="1" max="<?= h((string) $reste) ?>" step="1" required placeholder="<?= h(t('opportunites.versements.field.montant')) ?>" class="control" style="width:auto;">
                <select name="mode_paiement" class="control" style="width:auto;">
                    <?php foreach (MoyenPaiementModel::all() as $mode): ?>
                        <option value="<?= h($mode['moyen_paiement_code']) ?>"><?= h(t('enum.mode_paiement.' . $mode['moyen_paiement_code'])) ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="text" name="reference" placeholder="<?= h(t('opportunites.versements.field.reference')) ?>" class="control" style="width:auto;">
                <button type="submit" class="btn btn-primary btn-sm"><?= h(t('opportunites.versements.add_btn')) ?></button>
            </form>
            <?php endif; ?>
            <?php endif; ?>
        </div></div>
        <?php
    };
    ?>

    <div class="kanban-board">
        <div class="kanban-column">
            <p class="kanban-column-title"><?= h(t('opportunites.candidatures.kanban_en_attente')) ?> (<?= count($enAttente) ?>)</p>
            <div class="stack">
                <?php if (!$enAttente): ?>
                    <div class="card"><div class="card-body table-empty"><?= h(t('opportunites.candidatures.kanban_en_attente_empty')) ?></div></div>
                <?php endif; ?>
                <?php foreach ($enAttente as $candidature): ?>
                    <?php $renderCard($candidature); ?>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="kanban-column">
            <p class="kanban-column-title"><?= h(t('opportunites.candidatures.kanban_abouties')) ?> (<?= count($abouties) ?>)</p>
            <div class="stack">
                <?php if (!$abouties): ?>
                    <div class="card"><div class="card-body table-empty"><?= h(t('opportunites.candidatures.kanban_abouties_empty')) ?></div></div>
                <?php endif; ?>
                <?php foreach ($abouties as $candidature): ?>
                    <?php $renderCard($candidature); ?>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
