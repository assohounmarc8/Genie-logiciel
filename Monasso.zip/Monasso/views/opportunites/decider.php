<?php
/**
 * Page publique du "magic link" entreprise — aucune connexion requise, accédée via le jeton reçu
 * par e-mail (opportunites/decider?token=...&decision=accept|reject). $etat vaut :
 * 'confirmation' (GET, avant exécution), 'deja_traitee' (candidature déjà tranchée), 'merci' (POST, décision exécutée).
 */
$publicTitle = t('opportunites.decider.title');
require APP_DIR . '/views/layout/public-start.php';
?>
<div class="thankyou-page">
    <div class="card thankyou-card"><div class="card-body">
        <p class="page-eyebrow"><?= h(t('opportunites.decider.eyebrow')) ?></p>

        <?php if ($etat === 'deja_traitee'): ?>
            <h1 class="page-title"><?= h(t('opportunites.decider.deja_traitee_title')) ?></h1>
            <p class="page-subtitle"><?= h(t('opportunites.decider.deja_traitee_subtitle')) ?></p>
            <div class="mt-2"><?= enum_badge_html('candidature_statut', $candidature['statut']) ?></div>

        <?php elseif ($etat === 'merci'): ?>
            <?php if ($decision === 'accept'): ?>
                <h1 class="page-title">✅ <?= h(t('opportunites.decider.merci_accept_title')) ?></h1>
                <p class="page-subtitle"><?= h(t('opportunites.decider.merci_accept_subtitle', ['organisation' => $candidature['organisation_nom']])) ?></p>
            <?php else: ?>
                <h1 class="page-title">🚫 <?= h(t('opportunites.decider.merci_reject_title')) ?></h1>
                <p class="page-subtitle"><?= h(t('opportunites.decider.merci_reject_subtitle', ['organisation' => $candidature['organisation_nom']])) ?></p>
            <?php endif; ?>

        <?php else: /* confirmation */ ?>
            <h1 class="page-title"><?= h($candidature['opportunite_titre']) ?></h1>
            <p class="page-subtitle"><?= h($candidature['organisation_nom']) ?></p>

            <?php if (!empty($errors)): ?>
                <div class="card mt-2"><div class="card-body">
                    <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
                </div></div>
            <?php endif; ?>

            <p class="kpi-label mt-2"><?= h(t('opportunites.candidatures.col_message')) ?></p>
            <p class="mt-2"><?= nl2br(h($candidature['message'])) ?></p>

            <?php if ($decision === 'accept'): ?>
                <p class="mt-2"><?= h(t('opportunites.decider.confirm_accept_hint')) ?></p>
            <?php else: ?>
                <p class="mt-2"><?= h(t('opportunites.decider.confirm_reject_hint')) ?></p>
            <?php endif; ?>

            <form method="post" action="<?= h(route_url('opportunites/decider')) ?>" class="mt-2">
                <input type="hidden" name="token" value="<?= h($candidature['response_token']) ?>">
                <input type="hidden" name="decision" value="<?= h($decision) ?>">

                <?php if ($decision === 'accept' && $opportunite['type_opportunite'] === 'FINANCEMENT'): ?>
                    <div class="field">
                        <label for="montant_accorde"><?= h(t('opportunites.candidatures.montant_accorde')) ?></label>
                        <input type="number" id="montant_accorde" name="montant_accorde" min="1" step="1" required>
                    </div>
                <?php endif; ?>

                <?php if ($decision === 'reject'): ?>
                    <div class="field">
                        <label for="motif_refus"><?= h(t('opportunites.decider.motif_refus_label')) ?></label>
                        <textarea id="motif_refus" name="motif_refus" required placeholder="<?= h(t('opportunites.decider.motif_refus_placeholder')) ?>"></textarea>
                    </div>
                <?php endif; ?>

                <button type="submit" class="btn <?= $decision === 'accept' ? 'btn-primary' : 'btn-outline' ?> mt-2">
                    <?= h($decision === 'accept' ? t('opportunites.candidatures.accept_btn') : t('opportunites.candidatures.refuse_btn')) ?>
                </button>
            </form>
        <?php endif; ?>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/public-end.php'; ?>
