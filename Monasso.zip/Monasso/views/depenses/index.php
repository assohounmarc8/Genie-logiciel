<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('depenses.index.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('depenses.new_title')) ?></p>
        <form method="post" action="<?= h(route_url('depenses/creer')) ?>" class="form-grid mt-2">
            <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
            <div class="field">
                <label><?= h(t('depenses.field.libelle')) ?></label>
                <input type="text" name="libelle" required placeholder="<?= h(t('depenses.field.libelle_placeholder')) ?>">
            </div>
            <div class="field">
                <label><?= h(t('depenses.field.categorie')) ?></label>
                <select name="categorie">
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach (CategorieDepenseModel::all() as $cat): ?>
                        <option value="<?= h($cat['categorie_depense_code']) ?>"><?= h(t('enum.categorie_depense.' . $cat['categorie_depense_code'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label><?= h(t('common.amount')) ?></label>
                <input type="number" name="montant" min="1" step="1" required>
            </div>
            <div class="field">
                <label><?= h(t('depenses.field.date')) ?></label>
                <input type="date" name="date_depense" value="<?= h(date('Y-m-d')) ?>">
            </div>
            <div class="field" style="align-self:end;">
                <button type="submit" class="btn btn-primary"><?= h(t('depenses.add_btn')) ?></button>
            </div>
        </form>
    </div></div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('depenses.field.libelle')) ?></th>
            <th><?= h(t('depenses.field.categorie')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('depenses.field.date')) ?></th>
            <th><?= h(t('common.actions')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$depenses): ?><tr><td colspan="5" class="table-empty"><?= h(t('depenses.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($depenses as $dep): ?>
            <tr>
                <td><?= h($dep['libelle']) ?></td>
                <td><?= $dep['categorie'] ? h(t('enum.categorie_depense.' . $dep['categorie'])) : '—' ?></td>
                <td><?= h(format_money((float) $dep['montant'])) ?></td>
                <td><?= h(format_date($dep['date_depense'])) ?></td>
                <td>
                    <form method="post" action="<?= h(route_url('depenses/supprimer')) ?>" onsubmit="return confirm('<?= h(t('depenses.confirm_delete')) ?>');">
                        <input type="hidden" name="id" value="<?= h($dep['depense_code']) ?>">
                        <button type="submit" class="btn btn-outline btn-sm"><?= h(t('common.delete')) ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
