<?php
$errors = flash_get('errors', []);
$success = flash_get('success');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('communications.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php if ($success): ?>
        <div class="card"><div class="card-body"><p class="text-faint"><?= h($success) ?></p></div></div>
    <?php endif; ?>

    <?php render_form_errors($errors); ?>

    <form method="post" action="<?= h(route_url('communications/envoyer')) ?>">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="cible"><?= h(t('communications.field.cible')) ?></label>
                <select id="cible" name="cible">
                    <option value="TOUS"><?= h(t('communications.cible.TOUS')) ?></option>
                    <option value="MEMBRES"><?= h(t('communications.cible.MEMBRES')) ?></option>
                    <option value="BUREAU"><?= h(t('communications.cible.BUREAU')) ?></option>
                </select>
            </div>
            <div class="field">
                <label for="titre"><?= h(t('communications.field.titre')) ?></label>
                <input type="text" id="titre" name="titre" required value="<?= h(old_input('titre')) ?>">
            </div>
            <div class="field">
                <label for="message"><?= h(t('communications.field.message')) ?></label>
                <textarea id="message" name="message" required><?= h(old_input('message')) ?></textarea>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('common.send')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
