<?php
/** @var array $user */
$errors = flash_get('errors', []);
$success = flash_get('success');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('profile.tag')) ?></p>
        <h1 class="page-title"><?= h(t('profile.title')) ?></h1>
    </div>

    <?php render_form_errors($errors); ?>

    <?php if ($success): ?>
        <div class="card" style="border-color:var(--green-line); background:var(--green-light);"><div class="card-body">
            <p><?= h($success) ?></p>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('profile/update')) ?>" enctype="multipart/form-data">
        <div class="card"><div class="card-body">
            <div class="profile-photo-row">
                <?php if (!empty($user['photo_chemin'])): ?>
                    <img class="profile-photo" src="<?= h(asset_url('/' . $user['photo_chemin'])) ?>" alt="">
                <?php else: ?>
                    <div class="profile-photo">👤</div>
                <?php endif; ?>
                <div>
                    <p class="card-title" style="margin-bottom:4px;"><?= h(t('profile.field.photo')) ?></p>
                    <p class="page-subtitle" style="margin-bottom:8px;"><?= h(t('profile.field.photo_hint')) ?></p>
                    <input type="file" name="photo" accept="image/jpeg,image/png">
                </div>
            </div>

            <div class="form-grid">
                <div class="field">
                    <label for="nom"><?= h(t('common.fullname')) ?></label>
                    <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom', $user['nom'])) ?>">
                </div>
                <div class="field">
                    <label for="telephone"><?= h(t('common.phone')) ?></label>
                    <input type="tel" id="telephone" name="telephone" value="<?= h(old_input('telephone', $user['telephone'] ?? '')) ?>">
                </div>
            </div>

            <div class="field">
                <label for="email_display"><?= h(t('common.email')) ?></label>
                <input type="text" id="email_display" value="<?= h($user['email']) ?>" disabled>
            </div>

            <div class="form-grid">
                <div class="field">
                    <label for="date_naissance"><?= h(t('common.date_naissance')) ?></label>
                    <input type="date" id="date_naissance" name="date_naissance" value="<?= h(old_input('date_naissance', $user['date_naissance'] ?? '')) ?>">
                </div>
                <div class="field">
                    <label for="lieu_naissance"><?= h(t('common.lieu_naissance')) ?></label>
                    <input type="text" id="lieu_naissance" name="lieu_naissance" value="<?= h(old_input('lieu_naissance', $user['lieu_naissance'] ?? '')) ?>">
                </div>
            </div>

            <p class="form-section-title"><?= h(t('profile.section.security')) ?></p>
            <div class="form-grid">
                <div class="field">
                    <label for="new_password"><?= h(t('profile.field.new_password')) ?></label>
                    <input type="password" id="new_password" name="new_password" placeholder="<?= h(t('profile.field.password_hint')) ?>">
                </div>
                <div class="field">
                    <label for="confirm_password"><?= h(t('profile.field.confirm_password')) ?></label>
                    <input type="password" id="confirm_password" name="confirm_password">
                </div>
            </div>
            <div class="field">
                <label for="current_password"><?= h(t('profile.field.current_password')) ?></label>
                <input type="password" id="current_password" name="current_password">
            </div>
        </div></div>

        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('profile.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
