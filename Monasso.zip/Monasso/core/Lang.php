<?php

class Lang
{
    public const AVAILABLE = ['fr' => 'Français', 'en' => 'English', 'mg' => 'Malagasy'];
    public const DEFAULT = 'fr';

    /** Langue officielle / principale de chaque pays de la plateforme. */
    public const COUNTRY_LANG = [
        'CIV' => 'fr',
        'MLI' => 'fr',
        'BEN' => 'fr',
        'NGA' => 'en',
        'BFA' => 'fr',
        'MDG' => 'mg',
    ];

    private static ?string $current = null;
    private static array $strings = [];

    public static function boot(): void
    {
        if (!empty($_SESSION['pays']) && PaysModel::exists($_SESSION['pays'])) {
            $lang = self::langForCountry($_SESSION['pays']);
            $_SESSION['lang'] = $lang;
        } else {
            $lang = $_SESSION['lang'] ?? self::DEFAULT;
        }
        if (!array_key_exists($lang, self::AVAILABLE)) {
            $lang = self::DEFAULT;
        }
        self::$current = $lang;
        self::$strings = require APP_DIR . "/lang/$lang.php";
    }

    public static function current(): string
    {
        return self::$current ?? self::DEFAULT;
    }

    public static function set(string $lang): void
    {
        if (array_key_exists($lang, self::AVAILABLE)) {
            $_SESSION['lang'] = $lang;
        }
    }

    public static function currentCountry(): ?string
    {
        $pays = $_SESSION['pays'] ?? null;
        return $pays && PaysModel::exists($pays) ? $pays : null;
    }

    public static function langForCountry(string $paysCode): string
    {
        return self::COUNTRY_LANG[$paysCode] ?? self::DEFAULT;
    }

    public static function setCountry(string $paysCode): void
    {
        if (!PaysModel::exists($paysCode)) {
            return;
        }
        $_SESSION['pays'] = $paysCode;
        self::set(self::langForCountry($paysCode));
    }

    public static function get(string $key, array $params = []): string
    {
        $value = self::$strings[$key] ?? $key;
        foreach ($params as $name => $replacement) {
            $value = str_replace(':' . $name, (string) $replacement, $value);
        }
        return $value;
    }
}
