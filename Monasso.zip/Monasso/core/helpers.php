<?php

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function base_url(string $path = ''): string
{
    return BASE_URL . $path;
}

function route_url(string $route, array $params = []): string
{
    $params = array_merge(['r' => $route], $params);
    return base_url('/index.php') . '?' . http_build_query($params);
}

function asset_url(string $path): string
{
    return base_url($path);
}

function current_route(): string
{
    return $_GET['r'] ?? 'home/index';
}

function config_get(string $key)
{
    return $GLOBALS['CONFIG_CONSTANTS'][$key] ?? null;
}

function t(string $key, array $params = []): string
{
    return Lang::get($key, $params);
}

/** Bloc d'erreurs de formulaire, style unifié (remplace les foreach répétés dans chaque vue). */
function render_form_errors(array $errors): void
{
    if (!$errors) {
        return;
    }
    ?>
    <div class="form-errors">
        <span class="form-errors-icon">!</span>
        <ul>
            <?php foreach ($errors as $error): ?><li><?= h($error) ?></li><?php endforeach; ?>
        </ul>
    </div>
    <?php
}

/** Champ de sélection de fichier stylé (zone cliquable + nom du fichier choisi affiché dynamiquement). */
function render_file_field(string $id, string $name, string $accept, string $chooseText): void
{
    static $scriptQueued = false;
    ?>
    <div class="file-upload" data-file-upload>
        <input type="file" id="<?= h($id) ?>" name="<?= h($name) ?>" accept="<?= h($accept) ?>" class="file-upload-input">
        <label for="<?= h($id) ?>" class="file-upload-trigger">
            <span class="file-upload-icon" aria-hidden="true">📎</span>
            <span class="file-upload-text" data-file-upload-text><?= h($chooseText) ?></span>
        </label>
    </div>
    <?php
    if (!$scriptQueued) {
        echo '<script src="' . h(asset_url('/assets/js/file-upload.js')) . '" defer></script>';
        $scriptQueued = true;
    }
}

function render_country_switcher(string $variant = 'dark'): void
{
    static $scriptQueued = false;

    $currentPays = Lang::currentCountry();
    $countries = PaysModel::all();
    $back = $_SERVER['REQUEST_URI'] ?? '/';
    $currentInfo = $currentPays ? PaysModel::find($currentPays) : null;
    ?>
    <div class="country-switcher<?= $variant === 'light' ? ' light' : '' ?>" data-country-switcher>
        <button type="button" class="country-switcher-btn" aria-haspopup="listbox" aria-expanded="false">
            <span class="country-switcher-current">
                <?php if ($currentInfo): ?>
                    <?= flag_img_html($currentPays, true) ?>
                <?php else: ?>
                    <span class="country-switcher-placeholder">🌍 <?= h(t('common.select_country')) ?></span>
                <?php endif; ?>
            </span>
            <span class="country-switcher-chevron" aria-hidden="true">▾</span>
        </button>
        <ul class="country-switcher-menu" role="listbox" hidden>
            <?php foreach ($countries as $info): ?>
                <li role="option"<?= $currentPays === $info['pays_code'] ? ' aria-selected="true"' : '' ?>>
                    <a
                        href="<?= h(route_url('language/country', ['pays' => $info['pays_code'], 'back' => $back])) ?>"
                        class="country-switcher-option<?= $currentPays === $info['pays_code'] ? ' active' : '' ?>"
                    ><?= flag_img_html($info['pays_code'], true) ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
    if (!$scriptQueued) {
        echo '<script src="' . h(asset_url('/assets/js/country-switcher.js')) . '"></script>';
        $scriptQueued = true;
    }
}

function render_back_home_btn(string $extraClass = ''): void
{
    $classes = trim('btn btn-ghost auth-back-home ' . $extraClass);
    ?>
    <a class="<?= h($classes) ?>" href="<?= h(route_url('home/index')) ?>"><?= h(t('common.back_home')) ?></a>
    <?php
}

function progress_percent(float $collecte, float $recherche): int
{
    if ($recherche <= 0) {
        return 0;
    }
    return (int) min(100, round(($collecte / $recherche) * 100));
}

function render_progress_bar(float $collecte, float $recherche): void
{
    $percent = progress_percent($collecte, $recherche);
    ?>
    <div class="progress-track">
        <div class="progress-fill<?= $percent >= 100 ? ' complete' : '' ?>" style="width: <?= $percent ?>%;"></div>
    </div>
    <div class="progress-meta">
        <span><?= h(format_money($collecte)) ?></span>
        <span><?= $percent ?>% · <?= h(format_money($recherche)) ?></span>
    </div>
    <?php
}

function pays_label(?string $code): string
{
    if (!$code) {
        return '🌍 ' . t('common.all_countries');
    }
    $info = PaysModel::find($code);
    return $info ? $info['drapeau'] . ' ' . $info['nom'] : $code;
}

/** Fichier drapeau auto-hébergé (assets/flags/*.svg) associé à un pays_code (3 lettres) du projet. */
function flag_file_slug(string $paysCode): ?string
{
    $map = ['CIV' => 'ci', 'MLI' => 'ml', 'BEN' => 'bj', 'NER' => 'ne', 'NGA' => 'ng', 'MDG' => 'mg', 'BFA' => 'bf'];
    return $map[$paysCode] ?? null;
}

/**
 * Rendu HTML d'un drapeau + nom de pays (image auto-hébergée, pas d'emoji) — retourne du HTML brut,
 * ne PAS passer le résultat dans h(). Si le pays est inconnu, se rabat sur pays_label() échappé.
 */
function flag_img_html(?string $paysCode, bool $withName = true): string
{
    $slug = $paysCode ? flag_file_slug($paysCode) : null;
    if (!$slug) {
        return h(pays_label($paysCode));
    }
    $info = PaysModel::find($paysCode);
    $name = $info['nom'] ?? $paysCode;
    $img = '<img src="' . h(asset_url('/assets/flags/' . $slug . '.svg')) . '" alt="' . h($name) . '" class="flag-icon">';
    return $withName ? $img . ' ' . h($name) : $img;
}

/** Fichier armoiries (assets/armoiries/*.png) associé à un pays_code. */
function coat_of_arms_file(string $paysCode): ?string
{
    $map = [
        'BEN' => 'ben.png',
        'BFA' => 'bf.png',
        'CIV' => 'ci.png',
        'MDG' => 'mg.png',
        'MLI' => 'ml.png',
        'NGA' => 'ng.svg',
    ];

    return $map[$paysCode] ?? null;
}

function coat_of_arms_url(?string $paysCode): ?string
{
    if (!$paysCode) {
        return null;
    }
    $file = coat_of_arms_file($paysCode);
    return $file ? asset_url('/assets/armoiries/' . $file) : null;
}

/** URLs des armoiries par pays — pour mise à jour dynamique côté client. */
function coat_of_arms_urls_json(): string
{
    $urls = [];
    foreach (PaysModel::all() as $info) {
        $url = coat_of_arms_url($info['pays_code']);
        if ($url) {
            $urls[$info['pays_code']] = $url;
        }
    }
    return json_encode($urls, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
}

/**
 * Armoiries du pays sous le logo (sidebar, inscription…).
 * @param bool $dynamic Si true, le conteneur réagit au changement du select #pays_code.
 */
function render_coat_of_arms(?string $paysCode, string $extraClass = '', bool $dynamic = false): void
{
    $url = coat_of_arms_url($paysCode);
    $info = $paysCode ? PaysModel::find($paysCode) : null;
    $name = $info['nom'] ?? '';
    $classes = trim('coat-of-arms ' . $extraClass);
    $attrs = $dynamic ? ' data-coat-of-arms-dynamic' : '';
    ?>
    <div class="<?= h($classes) ?>"<?= $attrs ?><?= !$url ? ' hidden' : '' ?>>
        <?php if ($url): ?>
            <img
                src="<?= h($url) ?>"
                alt="<?= h(t('common.coat_of_arms', ['country' => $name])) ?>"
                class="coat-of-arms-img"
            >
        <?php else: ?>
            <img src="" alt="" class="coat-of-arms-img" hidden>
        <?php endif; ?>
    </div>
    <?php
    if ($dynamic) {
        static $scriptQueued = false;
        if (!$scriptQueued) {
            echo '<script src="' . h(asset_url('/assets/js/coat-of-arms.js')) . '" defer></script>';
            $scriptQueued = true;
        }
    }
}

function enum_label(string $group, string $code): string
{
    return t("enum.$group.$code");
}

/** Moyens de paiement proposés à tout paiement effectué par un membre (adhésion, cotisation, don). */
function modes_paiement(): array
{
    return array_column(MoyenPaiementModel::all(), 'moyen_paiement_code');
}

/** Icône décorative associée à un code de moyen de paiement (par préfixe, sans dépendre d'une liste figée). */
function mode_paiement_icon(string $code): string
{
    if (str_contains($code, 'MONEY') || str_contains($code, 'WAVE') || str_contains($code, 'MOBILE')) {
        return '📱';
    }
    if (str_contains($code, 'ESPECE') || str_contains($code, 'CASH')) {
        return '💵';
    }
    return '💳';
}

/** Sélecteur de moyen de paiement en tuiles cliquables (recharge visuellement un <select name="mode_paiement"> caché). */
function render_mode_paiement_picker(string $uid = 'mode_paiement'): void
{
    $modes = modes_paiement();
    ?>
    <div class="field">
        <label><?= h(t('dons.field.mode')) ?></label>
        <select id="<?= h($uid) ?>" name="mode_paiement" required style="display:none;">
            <?php foreach ($modes as $mode): ?>
                <option value="<?= h($mode) ?>"><?= h(t('enum.mode_paiement.' . $mode)) ?></option>
            <?php endforeach; ?>
        </select>
        <div class="tile-grid" id="<?= h($uid) ?>-tiles" style="grid-template-columns:repeat(auto-fit, minmax(120px, 1fr));">
            <?php foreach ($modes as $i => $mode): ?>
                <div class="tile<?= $i === 0 ? ' active' : '' ?>" data-mode="<?= h($mode) ?>" style="text-align:center; padding:14px 10px;">
                    <div class="tile-icon" style="margin:0 auto 8px; font-size:16px;"><?= h(mode_paiement_icon($mode)) ?></div>
                    <p class="tile-title" style="font-size:12.5px;"><?= h(t('enum.mode_paiement.' . $mode)) ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script>
        (function () {
            var select = document.getElementById('<?= h($uid) ?>');
            var tiles = document.querySelectorAll('#<?= h($uid) ?>-tiles .tile');
            if (tiles.length) { select.value = tiles[0].dataset.mode; }
            tiles.forEach(function (tile) {
                tile.addEventListener('click', function () {
                    select.value = tile.dataset.mode;
                    tiles.forEach(function (t) { t.classList.toggle('active', t === tile); });
                });
            });
        })();
    </script>
    <?php
}

function enum_variant(string $group, string $code): string
{
    $map = config_get($group);
    return $map[$code]['variant'] ?? 'neutral';
}

function badge_html(string $label, string $variant = 'default'): string
{
    return '<span class="badge badge-' . h($variant) . '">' . h($label) . '</span>';
}

function enum_badge_html(string $group, string $code): string
{
    return badge_html(enum_label($group, $code), enum_variant($group, $code));
}

function format_date(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $datePart = substr($value, 0, 10);
    $parts = explode('-', $datePart);
    if (count($parts) !== 3) {
        return $value;
    }
    [$year, $month, $day] = $parts;
    return sprintf('%d %s %s', (int) $day, t("month.$month"), $year);
}

function format_datetime(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $date = format_date($value);
    $time = substr($value, 11, 5);
    return $time ? "$date " . t('common.at_time') . " $time" : $date;
}

function format_money(float $amount, string $devise = 'XOF'): string
{
    return number_format($amount, 0, ',', ' ') . ' ' . $devise;
}

function flash_set(string $key, $value): void
{
    $_SESSION['flash'][$key] = $value;
}

function flash_get(string $key, $default = null)
{
    return $GLOBALS['FLASH'][$key] ?? $default;
}

function old_input(string $key, $default = '')
{
    $old = $GLOBALS['FLASH']['old'] ?? [];
    return $old[$key] ?? $default;
}

/** Génère un mot de passe aléatoire lisible (sans caractères ambigus 0/O, 1/l) — envoyé par e-mail. */
function generate_random_password(int $length = 10): string
{
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    $password = '';
    for ($i = 0; $i < $length; $i++) {
        $password .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $password;
}

function redirect_route(string $route, array $params = []): void
{
    header('Location: ' . route_url($route, $params));
    exit;
}

function safe_filename(string $name): string
{
    return preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
}

/** Valide un fichier $_FILES contre la liste blanche d'extensions/taille + un contrôle finfo anti-exécutable. */
function validate_uploaded_file(?array $file, ?array $allowedExtensions = null): array
{
    $config = config_get('upload');
    $allowed = $allowedExtensions ?? array_keys($config['allowed']);

    if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [t('validation.file_required')];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [t('validation.file_upload_failed')];
    }

    $errors = [];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowed, true)) {
        $errors[] = t('validation.file_type_invalid');
    }
    if ($file['size'] > $config['max_size']) {
        $errors[] = t('validation.file_too_large');
    }

    if (!$errors) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedMime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (preg_match('/php|executable|x-sh|x-dosexec|x-msdownload/i', (string) $detectedMime)) {
            $errors[] = t('validation.file_type_invalid');
        }
    }

    return $errors;
}

/** Déplace un fichier uploadé validé vers sa destination finale et détecte son vrai type MIME. */
function store_uploaded_file(array $file, string $destinationDir, string $diskFilename): ?array
{
    if (!is_dir($destinationDir)) {
        mkdir($destinationDir, 0755, true);
    }
    $destination = rtrim($destinationDir, '/') . '/' . $diskFilename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return null;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $destination) ?: 'application/octet-stream';
    finfo_close($finfo);

    return ['path' => $destination, 'mime' => $mime];
}

function send_csv(string $filename, array $headers, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $headers, ';');
    foreach ($rows as $row) {
        fputcsv($out, $row, ';');
    }
    fclose($out);
    exit;
}

/** Gabarit HTML minimal (styles en ligne, requis par la plupart des clients mail) pour les emails transactionnels. */
function mail_template(string $titre, string $bodyHtml): string
{
    return '<div style="font-family:Georgia,\'Times New Roman\',serif;background:#f2efe6;padding:32px 16px;">'
        . '<div style="max-width:480px;margin:0 auto;background:#ffffff;border-radius:14px;overflow:hidden;border:1px solid #e6e0d0;">'
        . '<div style="background:#16281f;color:#ffffff;padding:22px 28px;text-align:center;">'
        . '<span style="font-size:19px;font-weight:bold;">MON<span style="color:#d97a42;">ASSO</span></span>'
        . '</div>'
        . '<div style="padding:28px 28px 24px;color:#20281f;font-family:Arial,Helvetica,sans-serif;">'
        . '<h2 style="margin:0 0 16px;font-size:18px;font-family:Georgia,serif;font-weight:normal;">' . h($titre) . '</h2>'
        . '<div style="font-size:14px;line-height:1.6;">' . $bodyHtml . '</div>'
        . '</div>'
        . '<div style="padding:14px 28px;border-top:1px solid #ece7d8;text-align:center;">'
        . '<span style="font-size:11px;color:#c97a42;font-family:Arial,Helvetica,sans-serif;">© ' . date('Y') . ' MONASSO</span>'
        . '</div>'
        . '</div></div>';
}

/** Rendu visuel partagé d'une carte adhérent (recto + verso) — utilisé sur la fiche membre, l'impression en lot et l'admin. */
function render_carte_visual(array $carte, array $organisation, array $membre, string $numeroAdherent): void
{
    $scanUrl = route_url('cartes/verifier', ['token' => $carte['qr_token']]);
    ?>
    <div class="id-card-pair">
    <div class="id-card">
        <div class="id-card-header">
            <?php if (!empty($organisation['logo_chemin'])): ?>
                <img class="id-card-logo" src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="">
            <?php endif; ?>
            <p class="id-card-org-name"><?= h($organisation['nom']) ?></p>
        </div>
        <div class="id-card-body">
            <?php if (!empty($membre['photo_chemin'])): ?>
                <img class="id-card-photo" src="<?= h(asset_url('/' . $membre['photo_chemin'])) ?>" alt="">
            <?php else: ?>
                <div class="id-card-photo">👤</div>
            <?php endif; ?>
            <div class="id-card-info">
                <p class="id-card-name"><?= h($membre['nom']) ?></p>
                <p class="id-card-numero"><?= h($numeroAdherent ?: '—') ?></p>
                <?= enum_badge_html('carte_statut', $carte['statut']) ?>
            </div>
        </div>
        <div class="id-card-footer">
            <span><?= h(t('cartes.field.valide_jusquau')) ?></span>
            <span><?= h($carte['valide_jusqu_au'] ? format_date($carte['valide_jusqu_au']) : '—') ?></span>
        </div>
    </div>
    <div class="id-card">
        <div class="id-card-header">
            <p class="id-card-org-name"><?= h($organisation['nom']) ?></p>
        </div>
        <div class="id-card-back-body">
            <?php if (!empty($organisation['description'])): ?>
                <p class="id-card-back-desc"><?= h($organisation['description']) ?></p>
            <?php else: ?>
                <p class="id-card-back-desc"><?= h(t('cartes.carte.back_default_desc')) ?></p>
            <?php endif; ?>
            <div class="id-card-back-meta">
                <div>
                    <p class="id-card-numero" style="margin-bottom:2px;"><?= h(t('cartes.carte.issued_on')) ?></p>
                    <span style="font-size:12.5px; font-weight:600;"><?= h(format_date($carte['created_at'] ?? null)) ?></span>
                </div>
                <img class="id-card-qr" src="<?= h('https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=' . urlencode($scanUrl)) ?>" alt="QR">
            </div>
        </div>
    </div>
    </div>
    <?php
}
