<?php

class CodeGenerator
{
    public static function userCode(string $paysCode): string
    {
        $prefix = "USR-$paysCode-";
        return self::sequential('users', 'user_code', $prefix, 5, 'pays_code = :pays', ['pays' => $paysCode]);
    }

    public static function organisationCode(string $paysCode): string
    {
        $year = date('Y');
        $prefix = "ORG-$paysCode-$year-";
        return self::sequential(
            'organisations',
            'organisation_code',
            $prefix,
            4,
            'organisation_code LIKE :prefix',
            ['prefix' => $prefix . '%']
        );
    }

    public static function roleCode(string $organisationCode, string $nomRole): string
    {
        return $organisationCode . '-' . self::slug($nomRole);
    }

    public static function cotisationCode(): string
    {
        return self::sequential('cotisations', 'cotisation_code', 'COTI-', 5);
    }

    public static function paiementCode(): string
    {
        return self::sequential('paiements_cotisations', 'paiement_code', 'PAY-', 5);
    }

    public static function abonnementCode(): string
    {
        return self::sequential('abonnements_orga', 'abonnement_code', 'ABO-', 5);
    }

    public static function auditCode(): string
    {
        $day = date('Ymd');
        $prefix = "AUD-$day-";
        return self::sequential('audit_logs', 'audit_code', $prefix, 5, 'audit_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function notificationCode(): string
    {
        return self::sequential('notifications', 'notification_code', 'NOTIF-', 6);
    }

    public static function chatMessageCode(): string
    {
        return self::sequential('chat_messages', 'message_code', 'MSG-', 8);
    }

    public static function programmeCode(): string
    {
        $year = date('Y');
        $prefix = "PRG-$year-";
        return self::sequential('programmes', 'programme_code', $prefix, 4, 'programme_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function beneficiaireCode(): string
    {
        $year = date('Y');
        $prefix = "BNF-$year-";
        return self::sequential('beneficiaires', 'beneficiaire_code', $prefix, 5, 'beneficiaire_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function bailleurCode(): string
    {
        $year = date('Y');
        $prefix = "BLF-$year-";
        return self::sequential('bailleurs_fonds', 'bailleur_code', $prefix, 4, 'bailleur_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function prestationCode(): string
    {
        $year = date('Y');
        $prefix = "PRS-$year-";
        return self::sequential('prestations', 'prestation_code', $prefix, 5, 'prestation_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function documentCode(): string
    {
        return self::sequential('documents', 'document_code', 'DOC-', 6);
    }

    public static function besoinCode(): string
    {
        $year = date('Y');
        $prefix = "BES-$year-";
        return self::sequential('besoins', 'besoin_code', $prefix, 5, 'besoin_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function donCode(): string
    {
        $year = date('Y');
        $prefix = "DON-$year-";
        return self::sequential('dons', 'don_code', $prefix, 5, 'don_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function besoinDocumentCode(): string
    {
        return self::sequential('besoin_documents', 'besoin_document_code', 'BESDOC-', 6);
    }

    public static function evenementCode(): string
    {
        $year = date('Y');
        $prefix = "EVT-$year-";
        return self::sequential('evenements', 'evenement_code', $prefix, 5, 'evenement_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function evenementConfirmationCode(): string
    {
        return self::sequential('evenement_confirmations', 'confirmation_code', 'CONF-', 6);
    }

    public static function presenceCode(): string
    {
        return self::sequential('presences', 'presence_code', 'PRES-', 6);
    }

    public static function qrToken(): string
    {
        return bin2hex(random_bytes(16));
    }

    public static function carteCode(): string
    {
        $year = date('Y');
        $prefix = "CARTE-$year-";
        return self::sequential('cartes_adherents', 'carte_code', $prefix, 5, 'carte_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function depenseCode(): string
    {
        $year = date('Y');
        $prefix = "DEP-$year-";
        return self::sequential('depenses', 'depense_code', $prefix, 5, 'depense_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function adhesionPaiementCode(): string
    {
        $year = date('Y');
        $prefix = "ADHPAY-$year-";
        return self::sequential('adhesion_paiements', 'adhesion_paiement_code', $prefix, 5, 'adhesion_paiement_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function mailCode(): string
    {
        return self::sequential('mails_envoyes', 'mail_code', 'MAIL-', 6);
    }

    public static function opportuniteCode(): string
    {
        $year = date('Y');
        $prefix = "OPP-$year-";
        return self::sequential('opportunites', 'opportunite_code', $prefix, 5, 'opportunite_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function candidatureCode(): string
    {
        $year = date('Y');
        $prefix = "CAND-$year-";
        return self::sequential('opportunite_candidatures', 'candidature_code', $prefix, 5, 'candidature_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function versementCode(): string
    {
        $year = date('Y');
        $prefix = "VERS-$year-";
        return self::sequential('opportunite_versements', 'versement_code', $prefix, 5, 'versement_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    /**
     * Format : PAYS(3c)-TYPE(1c)-ORGA(4c)-PERSO(4c), ex. CIV-A-ASSO-7K3M. TYPE vient de
     * types_organisation.code_court (A/O/M) ; ORGA est dérivé du nom de l'organisation
     * (orgAbbreviation()) ; PERSO est l'identifiant personnel de l'utilisateur
     * (UserModel::ensureCodePerso()), le même pour toutes ses organisations. Unique de fait car
     * PERSO est unique par utilisateur et chaque utilisateur n'a qu'une ligne par organisation.
     */
    public static function numeroAdherent(string $organisationCode, string $userCode): string
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare(
            'SELECT o.pays_code, t.code_court, o.nom
             FROM organisations o
             JOIN types_organisation t ON t.type_organisation_code = o.type_organisation
             WHERE o.organisation_code = :code'
        );
        $stmt->execute(['code' => $organisationCode]);
        $org = $stmt->fetch();

        $codePerso = UserModel::ensureCodePerso($userCode);

        return $org['pays_code'] . '-' . $org['code_court'] . '-' . self::orgAbbreviation($org['nom']) . '-' . $codePerso;
    }

    /** Abrégé de 4 caractères dérivé du nom de l'organisation (ex. "Association Solidarité" -> "ASSO"). */
    public static function orgAbbreviation(string $nom): string
    {
        $clean = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $nom));
        return str_pad(substr($clean, 0, 4), 4, 'X');
    }

    /**
     * Identifiant personnel de 4 caractères attribué une seule fois par utilisateur (jamais
     * réattribué même s'il rejoint plusieurs organisations, cf. numeroAdherent()). Alphabet sans
     * caractères ambigus (0/O/1/I/l), identique à generate_random_password().
     */
    public static function codePerso(): string
    {
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $pdo = Database::connection();
        do {
            $code = '';
            for ($i = 0; $i < 4; $i++) {
                $code .= $chars[random_int(0, strlen($chars) - 1)];
            }
            $stmt = $pdo->prepare('SELECT 1 FROM users WHERE code_perso = :c');
            $stmt->execute(['c' => $code]);
        } while ($stmt->fetchColumn());

        return $code;
    }

    private static function slug(string $value): string
    {
        $value = strtoupper($value);
        $value = preg_replace('/[^A-Z0-9]+/', '_', $value);
        return trim($value, '_');
    }

    private static function sequential(string $table, string $column, string $prefix, int $padLength, string $where = '', array $params = []): string
    {
        $pdo = Database::connection();
        $sql = "SELECT $column FROM $table";
        if ($where !== '') {
            $sql .= " WHERE $where";
        }
        $sql .= " ORDER BY $column DESC LIMIT 1";
        if ($pdo->inTransaction()) {
            $sql .= ' FOR UPDATE';
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $last = $stmt->fetchColumn();

        $next = 1;
        if ($last) {
            $numericPart = substr($last, strlen($prefix));
            $next = (int) $numericPart + 1;
        }

        return $prefix . str_pad((string) $next, $padLength, '0', STR_PAD_LEFT);
    }
}
