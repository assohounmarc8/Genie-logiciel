<?php

// Identifiants SMTP réels — tant que 'host' est vide, Mailer::send() se contente de journaliser
// les emails dans la table mails_envoyes (mode simulé) sans tenter d'envoi réseau.
return [
    'host' => 'sandbox.smtp.mailtrap.io',
    'port' => 2525,
    'encryption' => 'tls', // 'tls' ou 'ssl'
    'username' => '9c01909ee6f9d2',
    'password' => 'e858cf2376863e',
    'from_email' => 'monasso2026@gmail.com',
    'from_name' => 'Monasso',
];
