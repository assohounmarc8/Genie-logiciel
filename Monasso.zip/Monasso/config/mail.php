<?php

// Identifiants SMTP réels — tant que 'host' est vide, Mailer::send() se contente de journaliser
// les emails dans la table mails_envoyes (mode simulé) sans tenter d'envoi réseau.
return [
     'host' => 'smtp.gmail.com',
    'port' => 587,
    'encryption' => 'tls', // 'tls' ou 'ssl'
    'username' => 'monasso2026@gmail.com',
    'password' => 'kjbstztxhcshoaal',
    'from_email' => 'monasso2026@gmail.com',
    'from_name' => 'Monasso',
];
