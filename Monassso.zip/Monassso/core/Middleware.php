<?php

class Middleware
{
    public static function requireLogin(): array
    {
        $user = Auth::user();
        if (!$user) {
            redirect_route('auth/login');
        }
        return $user;
    }

    public static function requireGuest(): void
    {
        if (Auth::user()) {
            redirect_route('dashboard/index');
        }
    }

    public static function requireType(array $types): array
    {
        $user = self::requireLogin();
        if (!in_array($user['type_compte'], $types, true)) {
            self::forbidden();
        }
        return $user;
    }

    /**
     * Autorise si : Super Admin, OU administrateur propriétaire de l'organisation
     * (organisations.admin_user_code), OU membre actif dont le rôle porte la permission
     * (avec remontée de la hiérarchie parent_role_code).
     */
    public static function requirePermission(string $organisationCode, string $permissionCode): array
    {
        $user = self::requireLogin();

        if (!self::hasPermission($user, $organisationCode, $permissionCode)) {
            self::forbidden();
        }

        return $user;
    }

    /**
     * Variante non bloquante de requirePermission(), pour conditionner l'affichage d'un bouton/lien
     * dans une vue sans provoquer de 403. Ne redirige jamais, ne fait pas planter la page si l'appelant
     * n'est pas connecté (retourne simplement false).
     */
    public static function can(string $organisationCode, string $permissionCode): bool
    {
        $user = Auth::user();
        if (!$user) {
            return false;
        }

        return self::hasPermission($user, $organisationCode, $permissionCode);
    }

    private static function hasPermission(array $user, string $organisationCode, string $permissionCode): bool
    {
        if ($user['type_compte'] === 'SUPER_ADMIN') {
            return true;
        }

        $org = OrganisationModel::findByCode($organisationCode);
        if ($org && $org['admin_user_code'] === $user['user_code']) {
            return true;
        }

        $membership = OrganisationUserModel::find($user['user_code'], $organisationCode);
        if (!$membership || $membership['statut'] !== 'ACT' || !$membership['role_code']) {
            return false;
        }

        return RoleModel::roleHasPermission($membership['role_code'], $permissionCode);
    }

    /** Autorise si Super Admin, admin propriétaire de l'organisation, ou membre ACT (sans exiger de permission précise). */
    public static function requireMembership(string $organisationCode): array
    {
        $user = self::requireLogin();

        if ($user['type_compte'] === 'SUPER_ADMIN') {
            return $user;
        }

        $org = OrganisationModel::findByCode($organisationCode);
        if ($org && $org['admin_user_code'] === $user['user_code']) {
            return $user;
        }

        $membership = OrganisationUserModel::find($user['user_code'], $organisationCode);
        if (!$membership || $membership['statut'] !== 'ACT') {
            self::forbidden();
        }

        return $user;
    }

    private static function forbidden(): void
    {
        http_response_code(403);
        View::render('errors/forbidden', []);
        exit;
    }
}
