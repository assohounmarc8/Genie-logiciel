<?php

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function base_url(string $path = ''): string
{
    return BASE_URL . $path;
}

function route_url(string $route, array $params = []): string
{
    $params = array_merge(['r' => $route], $params);
    return base_url('/index.php') . '?' . http_build_query($params);
}

function asset_url(string $path): string
{
    return base_url($path);
}

function current_route(): string
{
    return $_GET['r'] ?? 'home/index';
}

function config_get(string $key)
{
    return $GLOBALS['CONFIG_CONSTANTS'][$key] ?? null;
}

function t(string $key, array $params = []): string
{
    return Lang::get($key, $params);
}

function render_language_switcher(string $variant = 'dark'): void
{
    $current = Lang::current();
    $back = $_SERVER['REQUEST_URI'] ?? '/';
    ?>
    <div class="lang-switcher<?= $variant === 'light' ? ' light' : '' ?>">
        <?php foreach (Lang::AVAILABLE as $code => $label): ?>
            <a
                href="<?= h(route_url('language/switch', ['lang' => $code, 'back' => $back])) ?>"
                class="lang-option<?= $code === $current ? ' active' : '' ?>"
                title="<?= h($label) ?>"
            ><?= h(strtoupper($code)) ?></a>
        <?php endforeach; ?>
    </div>
    <?php
}

function pays_label(?string $code): string
{
    if (!$code) {
        return '🌍 ' . t('common.all_countries');
    }
    $pays = config_get('pays');
    $info = $pays[$code] ?? null;
    return $info ? $info['drapeau'] . ' ' . $info['nom'] : $code;
}

function enum_label(string $group, string $code): string
{
    return t("enum.$group.$code");
}

function enum_variant(string $group, string $code): string
{
    $map = config_get($group);
    return $map[$code]['variant'] ?? 'neutral';
}

function badge_html(string $label, string $variant = 'default'): string
{
    return '<span class="badge badge-' . h($variant) . '">' . h($label) . '</span>';
}

function enum_badge_html(string $group, string $code): string
{
    return badge_html(enum_label($group, $code), enum_variant($group, $code));
}

function format_date(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $datePart = substr($value, 0, 10);
    $parts = explode('-', $datePart);
    if (count($parts) !== 3) {
        return $value;
    }
    [$year, $month, $day] = $parts;
    return sprintf('%d %s %s', (int) $day, t("month.$month"), $year);
}

function format_datetime(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $date = format_date($value);
    $time = substr($value, 11, 5);
    return $time ? "$date " . t('common.at_time') . " $time" : $date;
}

function format_money(float $amount, string $devise = 'XOF'): string
{
    return number_format($amount, 0, ',', ' ') . ' ' . $devise;
}

function flash_set(string $key, $value): void
{
    $_SESSION['flash'][$key] = $value;
}

function flash_get(string $key, $default = null)
{
    return $GLOBALS['FLASH'][$key] ?? $default;
}

function old_input(string $key, $default = '')
{
    $old = $GLOBALS['FLASH']['old'] ?? [];
    return $old[$key] ?? $default;
}

function redirect_route(string $route, array $params = []): void
{
    header('Location: ' . route_url($route, $params));
    exit;
}
