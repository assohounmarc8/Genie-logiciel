<?php

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function base_url(string $path = ''): string
{
    return BASE_URL . $path;
}

function route_url(string $route, array $params = []): string
{
    $params = array_merge(['r' => $route], $params);
    return base_url('/index.php') . '?' . http_build_query($params);
}

function asset_url(string $path): string
{
    return base_url($path);
}

function current_route(): string
{
    return $_GET['r'] ?? 'home/index';
}

function config_get(string $key)
{
    return $GLOBALS['CONFIG_CONSTANTS'][$key] ?? null;
}

function t(string $key, array $params = []): string
{
    return Lang::get($key, $params);
}

function render_language_switcher(string $variant = 'dark'): void
{
    $current = Lang::current();
    $back = $_SERVER['REQUEST_URI'] ?? '/';
    ?>
    <div class="lang-switcher<?= $variant === 'light' ? ' light' : '' ?>">
        <?php foreach (Lang::AVAILABLE as $code => $label): ?>
            <a
                href="<?= h(route_url('language/switch', ['lang' => $code, 'back' => $back])) ?>"
                class="lang-option<?= $code === $current ? ' active' : '' ?>"
                title="<?= h($label) ?>"
            ><?= h(strtoupper($code)) ?></a>
        <?php endforeach; ?>
    </div>
    <?php
}

function progress_percent(float $collecte, float $recherche): int
{
    if ($recherche <= 0) {
        return 0;
    }
    return (int) min(100, round(($collecte / $recherche) * 100));
}

function render_progress_bar(float $collecte, float $recherche): void
{
    $percent = progress_percent($collecte, $recherche);
    ?>
    <div class="progress-track">
        <div class="progress-fill<?= $percent >= 100 ? ' complete' : '' ?>" style="width: <?= $percent ?>%;"></div>
    </div>
    <div class="progress-meta">
        <span><?= h(format_money($collecte)) ?></span>
        <span><?= $percent ?>% · <?= h(format_money($recherche)) ?></span>
    </div>
    <?php
}

function pays_label(?string $code): string
{
    if (!$code) {
        return '🌍 ' . t('common.all_countries');
    }
    $pays = config_get('pays');
    $info = $pays[$code] ?? null;
    return $info ? $info['drapeau'] . ' ' . $info['nom'] : $code;
}

function enum_label(string $group, string $code): string
{
    return t("enum.$group.$code");
}

function enum_variant(string $group, string $code): string
{
    $map = config_get($group);
    return $map[$code]['variant'] ?? 'neutral';
}

function badge_html(string $label, string $variant = 'default'): string
{
    return '<span class="badge badge-' . h($variant) . '">' . h($label) . '</span>';
}

function enum_badge_html(string $group, string $code): string
{
    return badge_html(enum_label($group, $code), enum_variant($group, $code));
}

function format_date(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $datePart = substr($value, 0, 10);
    $parts = explode('-', $datePart);
    if (count($parts) !== 3) {
        return $value;
    }
    [$year, $month, $day] = $parts;
    return sprintf('%d %s %s', (int) $day, t("month.$month"), $year);
}

function format_datetime(?string $value): string
{
    if (!$value) {
        return '—';
    }
    $date = format_date($value);
    $time = substr($value, 11, 5);
    return $time ? "$date " . t('common.at_time') . " $time" : $date;
}

function format_money(float $amount, string $devise = 'XOF'): string
{
    return number_format($amount, 0, ',', ' ') . ' ' . $devise;
}

function flash_set(string $key, $value): void
{
    $_SESSION['flash'][$key] = $value;
}

function flash_get(string $key, $default = null)
{
    return $GLOBALS['FLASH'][$key] ?? $default;
}

function old_input(string $key, $default = '')
{
    $old = $GLOBALS['FLASH']['old'] ?? [];
    return $old[$key] ?? $default;
}

function redirect_route(string $route, array $params = []): void
{
    header('Location: ' . route_url($route, $params));
    exit;
}

function safe_filename(string $name): string
{
    return preg_replace('/[^A-Za-z0-9._-]/', '_', $name);
}

/** Valide un fichier $_FILES contre la liste blanche d'extensions/taille + un contrôle finfo anti-exécutable. */
function validate_uploaded_file(?array $file, ?array $allowedExtensions = null): array
{
    $config = config_get('upload');
    $allowed = $allowedExtensions ?? array_keys($config['allowed']);

    if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [t('validation.file_required')];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [t('validation.file_upload_failed')];
    }

    $errors = [];
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowed, true)) {
        $errors[] = t('validation.file_type_invalid');
    }
    if ($file['size'] > $config['max_size']) {
        $errors[] = t('validation.file_too_large');
    }

    if (!$errors) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $detectedMime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (preg_match('/php|executable|x-sh|x-dosexec|x-msdownload/i', (string) $detectedMime)) {
            $errors[] = t('validation.file_type_invalid');
        }
    }

    return $errors;
}

/** Déplace un fichier uploadé validé vers sa destination finale et détecte son vrai type MIME. */
function store_uploaded_file(array $file, string $destinationDir, string $diskFilename): ?array
{
    if (!is_dir($destinationDir)) {
        mkdir($destinationDir, 0755, true);
    }
    $destination = rtrim($destinationDir, '/') . '/' . $diskFilename;
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return null;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $destination) ?: 'application/octet-stream';
    finfo_close($finfo);

    return ['path' => $destination, 'mime' => $mime];
}

function send_csv(string $filename, array $headers, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $headers, ';');
    foreach ($rows as $row) {
        fputcsv($out, $row, ';');
    }
    fclose($out);
    exit;
}

/** Gabarit HTML minimal (styles en ligne, requis par la plupart des clients mail) pour les 4 emails du parcours d'adhésion. */
function mail_template(string $titre, string $bodyHtml): string
{
    return '<div style="font-family:Arial,sans-serif;background:#f6f4ec;padding:24px;">'
        . '<div style="max-width:480px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e6e2d6;">'
        . '<div style="background:#1f7a4d;color:#fff;padding:16px 24px;font-weight:bold;font-size:16px;">MONASSO</div>'
        . '<div style="padding:24px;color:#1f2937;">'
        . '<h2 style="margin-top:0;font-size:18px;">' . h($titre) . '</h2>'
        . $bodyHtml
        . '</div></div></div>';
}

/** Rendu visuel partagé d'une carte adhérent — utilisé sur la fiche membre, l'impression en lot et l'admin. */
function render_carte_visual(array $carte, array $organisation, array $membre, string $numeroAdherent): void
{
    $scanUrl = route_url('cartes/verifier', ['token' => $carte['qr_token']]);
    ?>
    <div class="id-card">
        <div class="id-card-header">
            <?php if (!empty($organisation['logo_chemin'])): ?>
                <img class="id-card-logo" src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="">
            <?php endif; ?>
            <p class="id-card-org-name"><?= h($organisation['nom']) ?></p>
        </div>
        <div class="id-card-body">
            <?php if (!empty($membre['photo_chemin'])): ?>
                <img class="id-card-photo" src="<?= h(asset_url('/' . $membre['photo_chemin'])) ?>" alt="">
            <?php else: ?>
                <div class="id-card-photo">👤</div>
            <?php endif; ?>
            <div class="id-card-info">
                <p class="id-card-name"><?= h($membre['nom']) ?></p>
                <p class="id-card-numero"><?= h($numeroAdherent ?: '—') ?></p>
                <?= enum_badge_html('carte_statut', $carte['statut']) ?>
            </div>
            <img class="id-card-qr" src="<?= h('https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=' . urlencode($scanUrl)) ?>" alt="QR">
        </div>
        <div class="id-card-footer">
            <span><?= h(t('cartes.field.valide_jusquau')) ?></span>
            <span><?= h($carte['valide_jusqu_au'] ? format_date($carte['valide_jusqu_au']) : '—') ?></span>
        </div>
    </div>
    <?php
}
