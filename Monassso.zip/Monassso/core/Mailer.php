<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Envoie un email et journalise systématiquement le résultat dans mails_envoyes. Tant que
 * config/mail.php n'a pas de 'host' renseigné, aucun envoi réseau n'est tenté : l'email est
 * simplement marqué ENVOYE (mode simulé), comme le paiement des dons en V1.
 */
class Mailer
{
    public static function send(
        string $toEmail,
        string $toName,
        string $subject,
        string $bodyHtml,
        string $typeCode,
        ?string $userCode = null,
        ?string $organisationCode = null
    ): bool {
        $config = $GLOBALS['CONFIG_MAIL'];

        if (empty($config['host'])) {
            MailLogModel::create([
                'destinataire_email' => $toEmail,
                'destinataire_user_code' => $userCode,
                'organisation_code' => $organisationCode,
                'type_code' => $typeCode,
                'objet' => $subject,
                'corps' => $bodyHtml,
                'statut' => 'ENVOYE',
            ]);
            return true;
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = $config['host'];
            $mail->Port = $config['port'];
            $mail->SMTPAuth = true;
            $mail->Username = $config['username'];
            $mail->Password = $config['password'];
            $mail->SMTPSecure = $config['encryption'];
            $mail->CharSet = 'UTF-8';

            $mail->setFrom($config['from_email'], $config['from_name']);
            $mail->addAddress($toEmail, $toName);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $bodyHtml;

            $mail->send();

            MailLogModel::create([
                'destinataire_email' => $toEmail,
                'destinataire_user_code' => $userCode,
                'organisation_code' => $organisationCode,
                'type_code' => $typeCode,
                'objet' => $subject,
                'corps' => $bodyHtml,
                'statut' => 'ENVOYE',
            ]);
            return true;
        } catch (PHPMailerException $e) {
            MailLogModel::create([
                'destinataire_email' => $toEmail,
                'destinataire_user_code' => $userCode,
                'organisation_code' => $organisationCode,
                'type_code' => $typeCode,
                'objet' => $subject,
                'corps' => $bodyHtml,
                'statut' => 'ECHEC',
                'erreur' => $mail->ErrorInfo,
            ]);
            return false;
        }
    }
}
