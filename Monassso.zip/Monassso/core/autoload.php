<?php

spl_autoload_register(function (string $class): void {
    $dirs = ['core', 'models', 'controllers'];
    foreach ($dirs as $dir) {
        $path = APP_DIR . "/$dir/$class.php";
        if (is_file($path)) {
            require_once $path;
            return;
        }
    }
});
