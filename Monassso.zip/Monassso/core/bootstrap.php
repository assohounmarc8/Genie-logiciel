<?php

session_start();

define('APP_DIR', dirname(__DIR__));

$docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? rtrim(str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']), '/') : '';
$appDirNormalized = rtrim(str_replace('\\', '/', APP_DIR), '/');
$computedBase = '';
if ($docRoot !== '' && strpos($appDirNormalized, $docRoot) === 0) {
    $computedBase = substr($appDirNormalized, strlen($docRoot));
}
define('BASE_URL', $computedBase);

$GLOBALS['FLASH'] = $_SESSION['flash'] ?? [];
unset($_SESSION['flash']);

require_once APP_DIR . '/core/autoload.php';
require_once APP_DIR . '/core/helpers.php';

$GLOBALS['CONFIG_DATABASE'] = require APP_DIR . '/config/database.php';
$GLOBALS['CONFIG_CONSTANTS'] = require APP_DIR . '/config/constants.php';

Lang::boot();
