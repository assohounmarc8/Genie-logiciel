<?php

class Router
{
    public static function dispatch(): void
    {
        $route = current_route();
        $parts = explode('/', trim($route, '/'), 2);
        $controllerName = ucfirst($parts[0] !== '' ? $parts[0] : 'home') . 'Controller';
        $action = ($parts[1] ?? '') !== '' ? $parts[1] : 'index';

        if (!class_exists($controllerName)) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $controller = new $controllerName();
        if (!method_exists($controller, $action)) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $controller->$action();
    }
}
