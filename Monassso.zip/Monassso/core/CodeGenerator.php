<?php

class CodeGenerator
{
    public static function userCode(string $paysCode): string
    {
        $prefix = "USR-$paysCode-";
        return self::sequential('users', 'user_code', $prefix, 5, 'pays_code = :pays', ['pays' => $paysCode]);
    }

    public static function organisationCode(string $paysCode): string
    {
        $year = date('Y');
        $prefix = "ORG-$paysCode-$year-";
        return self::sequential(
            'organisations',
            'organisation_code',
            $prefix,
            4,
            'organisation_code LIKE :prefix',
            ['prefix' => $prefix . '%']
        );
    }

    public static function roleCode(string $organisationCode, string $nomRole): string
    {
        return $organisationCode . '-' . self::slug($nomRole);
    }

    public static function cotisationCode(): string
    {
        return self::sequential('cotisations', 'cotisation_code', 'COTI-', 5);
    }

    public static function paiementCode(): string
    {
        return self::sequential('paiements_cotisations', 'paiement_code', 'PAY-', 5);
    }

    public static function abonnementCode(): string
    {
        return self::sequential('abonnements_orga', 'abonnement_code', 'ABO-', 5);
    }

    public static function auditCode(): string
    {
        $day = date('Ymd');
        $prefix = "AUD-$day-";
        return self::sequential('audit_logs', 'audit_code', $prefix, 5, 'audit_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function notificationCode(): string
    {
        return self::sequential('notifications', 'notification_code', 'NOTIF-', 6);
    }

    public static function documentCode(): string
    {
        return self::sequential('documents', 'document_code', 'DOC-', 6);
    }

    public static function besoinCode(): string
    {
        $year = date('Y');
        $prefix = "BES-$year-";
        return self::sequential('besoins', 'besoin_code', $prefix, 5, 'besoin_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function donCode(): string
    {
        $year = date('Y');
        $prefix = "DON-$year-";
        return self::sequential('dons', 'don_code', $prefix, 5, 'don_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function besoinDocumentCode(): string
    {
        return self::sequential('besoin_documents', 'besoin_document_code', 'BESDOC-', 6);
    }

    public static function evenementCode(): string
    {
        $year = date('Y');
        $prefix = "EVT-$year-";
        return self::sequential('evenements', 'evenement_code', $prefix, 5, 'evenement_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function evenementConfirmationCode(): string
    {
        return self::sequential('evenement_confirmations', 'confirmation_code', 'CONF-', 6);
    }

    public static function presenceCode(): string
    {
        return self::sequential('presences', 'presence_code', 'PRES-', 6);
    }

    public static function qrToken(): string
    {
        return bin2hex(random_bytes(16));
    }

    public static function carteCode(): string
    {
        $year = date('Y');
        $prefix = "CARTE-$year-";
        return self::sequential('cartes_adherents', 'carte_code', $prefix, 5, 'carte_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function depenseCode(): string
    {
        $year = date('Y');
        $prefix = "DEP-$year-";
        return self::sequential('depenses', 'depense_code', $prefix, 5, 'depense_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function adhesionPaiementCode(): string
    {
        $year = date('Y');
        $prefix = "ADHPAY-$year-";
        return self::sequential('adhesion_paiements', 'adhesion_paiement_code', $prefix, 5, 'adhesion_paiement_code LIKE :prefix', ['prefix' => $prefix . '%']);
    }

    public static function mailCode(): string
    {
        return self::sequential('mails_envoyes', 'mail_code', 'MAIL-', 6);
    }

    /**
     * Format : PAYS-TYPE_ORGANISATION-NOM_ORGANISATION-XXXX-YYYY (XXXX = n° séquentiel de
     * l'adhérent dans l'organisation, YYYY = année d'adhésion).
     */
    public static function numeroAdherent(string $organisationCode): string
    {
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT pays_code, type_organisation, nom FROM organisations WHERE organisation_code = :code');
        $stmt->execute(['code' => $organisationCode]);
        $org = $stmt->fetch();

        $prefix = $org['pays_code'] . '-' . $org['type_organisation'] . '-' . substr(self::slug($org['nom']), 0, 20) . '-';

        $sql = 'SELECT numero_adherent FROM organisation_users
                WHERE organisation_code = :org AND numero_adherent LIKE :prefix
                ORDER BY numero_adherent DESC LIMIT 1';
        if ($pdo->inTransaction()) {
            $sql .= ' FOR UPDATE';
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['org' => $organisationCode, 'prefix' => $prefix . '%']);
        $last = $stmt->fetchColumn();

        $next = 1;
        if ($last) {
            $sequencePart = explode('-', substr($last, strlen($prefix)))[0];
            $next = (int) $sequencePart + 1;
        }

        return $prefix . str_pad((string) $next, 4, '0', STR_PAD_LEFT) . '-' . date('Y');
    }

    private static function slug(string $value): string
    {
        $value = strtoupper($value);
        $value = preg_replace('/[^A-Z0-9]+/', '_', $value);
        return trim($value, '_');
    }

    private static function sequential(string $table, string $column, string $prefix, int $padLength, string $where = '', array $params = []): string
    {
        $pdo = Database::connection();
        $sql = "SELECT $column FROM $table";
        if ($where !== '') {
            $sql .= " WHERE $where";
        }
        $sql .= " ORDER BY $column DESC LIMIT 1";
        if ($pdo->inTransaction()) {
            $sql .= ' FOR UPDATE';
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $last = $stmt->fetchColumn();

        $next = 1;
        if ($last) {
            $numericPart = substr($last, strlen($prefix));
            $next = (int) $numericPart + 1;
        }

        return $prefix . str_pad((string) $next, $padLength, '0', STR_PAD_LEFT);
    }
}
