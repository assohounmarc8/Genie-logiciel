<?php

class Audit
{
    public static function log(
        ?string $actorUserCode,
        ?string $organisationCode,
        string $actionCode,
        ?string $targetCode = null,
        array $details = []
    ): void {
        $pdo = Database::connection();
        $code = CodeGenerator::auditCode();

        $stmt = $pdo->prepare(
            'INSERT INTO audit_logs (audit_code, actor_user_code, organisation_code, action_code, target_code, details_json, ip, created_at)
             VALUES (:code, :actor, :org, :action, :target, :details, :ip, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'actor' => $actorUserCode,
            'org' => $organisationCode,
            'action' => $actionCode,
            'target' => $targetCode,
            'details' => $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    }
}
