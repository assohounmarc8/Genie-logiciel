<?php

class View
{
    public static function render(string $view, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        $path = APP_DIR . "/views/$view.php";
        if (!is_file($path)) {
            throw new RuntimeException("Vue introuvable : $view");
        }
        require $path;
    }
}
