<?php

class Auth
{
    private static ?array $cachedUser = null;
    private static bool $resolved = false;

    public static function attempt(string $email, string $password): bool
    {
        $user = UserModel::findByEmail($email);

        if (!$user || $user['statut'] !== 'ACT' || !password_verify($password, $user['password_hash'])) {
            if ($user) {
                UserModel::incrementFailedLogin($user['user_code']);
                Audit::log($user['user_code'], null, 'LOGIN_FAILED', $user['user_code'], ['email' => $email]);
            } else {
                Audit::log(null, null, 'LOGIN_FAILED', null, ['email' => $email]);
            }
            return false;
        }

        UserModel::resetFailedLogin($user['user_code']);
        $_SESSION['user_code'] = $user['user_code'];
        self::$cachedUser = $user;
        self::$resolved = true;
        Audit::log($user['user_code'], null, 'LOGIN_SUCCESS', $user['user_code']);

        return true;
    }

    /** Ouvre une session pour un utilisateur déjà authentifié (ex. juste après inscription). */
    public static function login(array $user): void
    {
        $_SESSION['user_code'] = $user['user_code'];
        self::$cachedUser = $user;
        self::$resolved = true;
    }

    public static function logout(): void
    {
        $user = self::user();
        if ($user) {
            Audit::log($user['user_code'], null, 'LOGOUT', $user['user_code']);
        }
        unset($_SESSION['user_code']);
        self::$cachedUser = null;
        self::$resolved = true;
    }

    public static function user(): ?array
    {
        if (self::$resolved) {
            return self::$cachedUser;
        }
        self::$resolved = true;

        if (empty($_SESSION['user_code'])) {
            return null;
        }

        $user = UserModel::findByCode($_SESSION['user_code']);
        if (!$user || $user['statut'] !== 'ACT') {
            unset($_SESSION['user_code']);
            return null;
        }

        self::$cachedUser = $user;
        return $user;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }
}
