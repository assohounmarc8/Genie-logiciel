<?php

class Lang
{
    public const AVAILABLE = ['fr' => 'Français', 'en' => 'English', 'mg' => 'Malagasy'];
    public const DEFAULT = 'fr';

    private static ?string $current = null;
    private static array $strings = [];

    public static function boot(): void
    {
        $lang = $_SESSION['lang'] ?? self::DEFAULT;
        if (!array_key_exists($lang, self::AVAILABLE)) {
            $lang = self::DEFAULT;
        }
        self::$current = $lang;
        self::$strings = require APP_DIR . "/lang/$lang.php";
    }

    public static function current(): string
    {
        return self::$current ?? self::DEFAULT;
    }

    public static function set(string $lang): void
    {
        if (array_key_exists($lang, self::AVAILABLE)) {
            $_SESSION['lang'] = $lang;
        }
    }

    public static function get(string $key, array $params = []): string
    {
        $value = self::$strings[$key] ?? $key;
        foreach ($params as $name => $replacement) {
            $value = str_replace(':' . $name, (string) $replacement, $value);
        }
        return $value;
    }
}
