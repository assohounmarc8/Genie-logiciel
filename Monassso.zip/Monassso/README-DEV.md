# Outils de développement (dev uniquement)

Ce projet reste un site **100% PHP statique** (voir `README.md` : sans framework, sans Composer,
sans Node.js). Node.js n'intervient ici que comme **outil de build local**, jamais comme dépendance
de production — aucun processus Node ne tourne sur le serveur, et le serveur de prod n'a pas besoin
d'avoir Node installé.

## Polices (Manrope, Source Sans 3)

Les fichiers de police sont **livrés directement dans le dépôt** (`assets/fonts/*.woff2` +
`assets/css/fonts.css`) : ils ne sont pas régénérés à chaque déploiement. Node ne sert qu'à les
(re)télécharger en cas de besoin (changement de poids, mise à jour de version…).

```
npm install
npm run fetch-fonts
```

- `npm install` : aucune dépendance à installer (Node ≥ 18 fournit nativement `fetch`), la commande
  existe surtout pour la cohérence avec le workflow npm habituel.
- `npm run fetch-fonts` : télécharge les woff2 de Manrope (500/700/800) et Source Sans 3
  (400/500/600/700) depuis Google Fonts, les place dans `assets/fonts/`, et régénère
  `assets/css/fonts.css`. À relancer uniquement si vous changez les polices ou les poids utilisés.

**En production : aucune étape Node requise.** Il suffit que `assets/fonts/` et
`assets/css/fonts.css` soient présents (committés) — le PHP les sert comme n'importe quel autre
fichier statique.
