<?php

class AbonnementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM abonnements_orga WHERE abonnement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM abonnements_orga WHERE organisation_code = :o ORDER BY created_at DESC');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(string $organisationCode, float $montant, int $dureeJours): array
    {
        $code = CodeGenerator::abonnementCode();
        $debut = date('Y-m-d');
        $fin = date('Y-m-d', strtotime("+$dureeJours days"));
        $stmt = Database::connection()->prepare(
            "INSERT INTO abonnements_orga (abonnement_code, organisation_code, statut, montant, date_debut, date_fin, created_at)
             VALUES (:code, :org, 'ACT', :montant, :debut, :fin, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $organisationCode,
            'montant' => $montant,
            'debut' => $debut,
            'fin' => $fin,
        ]);
        return self::findByCode($code);
    }
}
