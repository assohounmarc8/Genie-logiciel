<?php

class EvenementConfirmationModel
{
    public static function exists(string $evenementCode, string $userCode): bool
    {
        $stmt = Database::connection()->prepare(
            'SELECT 1 FROM evenement_confirmations WHERE evenement_code = :e AND user_code = :u'
        );
        $stmt->execute(['e' => $evenementCode, 'u' => $userCode]);
        return (bool) $stmt->fetchColumn();
    }

    public static function create(string $evenementCode, string $userCode): void
    {
        if (self::exists($evenementCode, $userCode)) {
            return;
        }
        $code = CodeGenerator::evenementConfirmationCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO evenement_confirmations (confirmation_code, evenement_code, user_code, created_at)
             VALUES (:code, :e, :u, NOW())'
        );
        $stmt->execute(['code' => $code, 'e' => $evenementCode, 'u' => $userCode]);
    }

    public static function countByEvenement(string $evenementCode): int
    {
        $stmt = Database::connection()->prepare(
            'SELECT COUNT(*) FROM evenement_confirmations WHERE evenement_code = :e'
        );
        $stmt->execute(['e' => $evenementCode]);
        return (int) $stmt->fetchColumn();
    }
}
