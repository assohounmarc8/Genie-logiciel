<?php

class CategorieDocumentModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM categories_document ORDER BY nom')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM categories_document WHERE categorie_document_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
