<?php

class DepenseModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM depenses WHERE depense_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM depenses WHERE organisation_code = :o ORDER BY date_depense DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::depenseCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO depenses (depense_code, organisation_code, cree_par_user_code, libelle, categorie, montant, date_depense, created_at)
             VALUES (:code, :org, :user, :libelle, :categorie, :montant, :date, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'user' => $data['cree_par_user_code'],
            'libelle' => $data['libelle'],
            'categorie' => $data['categorie'] !== '' ? $data['categorie'] : null,
            'montant' => $data['montant'],
            'date' => $data['date_depense'],
        ]);
        return self::findByCode($code);
    }

    public static function totalForMonth(string $organisationCode, int $year, int $month): float
    {
        $stmt = Database::connection()->prepare(
            'SELECT COALESCE(SUM(montant), 0) FROM depenses
             WHERE organisation_code = :o AND YEAR(date_depense) = :y AND MONTH(date_depense) = :m'
        );
        $stmt->execute(['o' => $organisationCode, 'y' => $year, 'm' => $month]);
        return (float) $stmt->fetchColumn();
    }

    public static function totalUpTo(string $organisationCode, string $dateEnd): float
    {
        $stmt = Database::connection()->prepare(
            'SELECT COALESCE(SUM(montant), 0) FROM depenses WHERE organisation_code = :o AND date_depense <= :d'
        );
        $stmt->execute(['o' => $organisationCode, 'd' => $dateEnd]);
        return (float) $stmt->fetchColumn();
    }

    public static function topForMonth(string $organisationCode, int $year, int $month, int $limit = 5): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM depenses
             WHERE organisation_code = :o AND YEAR(date_depense) = :y AND MONTH(date_depense) = :m
             ORDER BY montant DESC LIMIT :limit'
        );
        $stmt->bindValue('o', $organisationCode);
        $stmt->bindValue('y', $year, PDO::PARAM_INT);
        $stmt->bindValue('m', $month, PDO::PARAM_INT);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function recent(string $organisationCode, int $limit = 5): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM depenses WHERE organisation_code = :o ORDER BY created_at DESC LIMIT :limit'
        );
        $stmt->bindValue('o', $organisationCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
