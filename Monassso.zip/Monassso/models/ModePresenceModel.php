<?php

class ModePresenceModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM modes_presence ORDER BY mode_presence_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM modes_presence WHERE mode_presence_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
