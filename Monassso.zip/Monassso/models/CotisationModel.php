<?php

class CotisationModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM cotisations WHERE cotisation_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM cotisations WHERE organisation_code = :o ORDER BY created_at DESC');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(string $organisationCode, string $libelle, float $montant, string $devise): array
    {
        $code = CodeGenerator::cotisationCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO cotisations (cotisation_code, organisation_code, libelle, annee, montant, devise, statut, created_at)
             VALUES (:code, :org, :libelle, :annee, :montant, :devise, 'ACT', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $organisationCode,
            'libelle' => $libelle,
            'annee' => (int) date('Y'),
            'montant' => $montant,
            'devise' => $devise,
        ]);
        return self::findByCode($code);
    }

    public static function delete(string $code): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM paiements_cotisations WHERE cotisation_code = :code')->execute(['code' => $code]);
            $pdo->prepare('DELETE FROM cotisations WHERE cotisation_code = :code')->execute(['code' => $code]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
