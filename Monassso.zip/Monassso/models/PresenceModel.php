<?php

class PresenceModel
{
    public static function exists(string $evenementCode, string $userCode): bool
    {
        $stmt = Database::connection()->prepare(
            'SELECT 1 FROM presences WHERE evenement_code = :e AND user_code = :u'
        );
        $stmt->execute(['e' => $evenementCode, 'u' => $userCode]);
        return (bool) $stmt->fetchColumn();
    }

    public static function create(string $evenementCode, string $userCode, string $mode): ?array
    {
        if (self::exists($evenementCode, $userCode)) {
            return null;
        }
        $code = CodeGenerator::presenceCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO presences (presence_code, evenement_code, user_code, heure_arrivee, mode, created_at)
             VALUES (:code, :e, :u, NOW(), :mode, NOW())'
        );
        $stmt->execute(['code' => $code, 'e' => $evenementCode, 'u' => $userCode, 'mode' => $mode]);

        $find = Database::connection()->prepare('SELECT * FROM presences WHERE presence_code = :code');
        $find->execute(['code' => $code]);
        return $find->fetch() ?: null;
    }

    public static function listByEvenement(string $evenementCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, u.nom, u.email
             FROM presences p
             JOIN users u ON u.user_code = p.user_code
             WHERE p.evenement_code = :e
             ORDER BY p.heure_arrivee ASC'
        );
        $stmt->execute(['e' => $evenementCode]);
        return $stmt->fetchAll();
    }

    public static function countByEvenement(string $evenementCode): int
    {
        $stmt = Database::connection()->prepare('SELECT COUNT(*) FROM presences WHERE evenement_code = :e');
        $stmt->execute(['e' => $evenementCode]);
        return (int) $stmt->fetchColumn();
    }
}
