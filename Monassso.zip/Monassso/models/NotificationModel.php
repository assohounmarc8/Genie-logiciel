<?php

class NotificationModel
{
    public static function create(string $userCode, ?string $organisationCode, string $typeCode, string $titre, string $message, ?string $lien = null): array
    {
        $code = CodeGenerator::notificationCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO notifications (notification_code, user_code, organisation_code, type_code, titre, message, lien, lue, created_at)
             VALUES (:code, :user, :org, :type, :titre, :message, :lien, 0, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'user' => $userCode,
            'org' => $organisationCode,
            'type' => $typeCode,
            'titre' => $titre,
            'message' => $message,
            'lien' => $lien,
        ]);
        return self::findByCode($code);
    }

    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM notifications WHERE notification_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listForUser(string $userCode, int $limit = 50): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM notifications WHERE user_code = :user ORDER BY created_at DESC LIMIT :limit'
        );
        $stmt->bindValue('user', $userCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function countUnread(string $userCode): int
    {
        $stmt = Database::connection()->prepare(
            'SELECT COUNT(*) FROM notifications WHERE user_code = :user AND lue = 0'
        );
        $stmt->execute(['user' => $userCode]);
        return (int) $stmt->fetchColumn();
    }

    public static function markRead(string $notificationCode, string $userCode): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE notifications SET lue = 1 WHERE notification_code = :code AND user_code = :user'
        );
        $stmt->execute(['code' => $notificationCode, 'user' => $userCode]);
    }

    public static function markAllRead(string $userCode): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE notifications SET lue = 1 WHERE user_code = :user AND lue = 0'
        );
        $stmt->execute(['user' => $userCode]);
    }

    public static function delete(string $notificationCode, string $userCode): void
    {
        $stmt = Database::connection()->prepare(
            'DELETE FROM notifications WHERE notification_code = :code AND user_code = :user'
        );
        $stmt->execute(['code' => $notificationCode, 'user' => $userCode]);
    }

    public static function deleteAllForUser(string $userCode): void
    {
        $stmt = Database::connection()->prepare('DELETE FROM notifications WHERE user_code = :user');
        $stmt->execute(['user' => $userCode]);
    }
}
