<?php

class StatutDonModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_don ORDER BY statut_don_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_don WHERE statut_don_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
