<?php

class MetierModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM metiers ORDER BY metier_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM metiers WHERE metier_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
