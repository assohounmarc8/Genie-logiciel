<?php

class StatutEvenementModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_evenement ORDER BY statut_evenement_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_evenement WHERE statut_evenement_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
