<?php

class PlanAbonnementModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM plans_abonnement ORDER BY duree_jours')->fetchAll();
    }

    public static function find(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM plans_abonnement WHERE plan_abonnement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function exists(string $code): bool
    {
        return self::find($code) !== null;
    }
}
