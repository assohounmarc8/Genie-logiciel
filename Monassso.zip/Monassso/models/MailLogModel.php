<?php

class MailLogModel
{
    public static function create(array $data): array
    {
        $code = CodeGenerator::mailCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO mails_envoyes
                (mail_code, destinataire_email, destinataire_user_code, organisation_code, type_code, objet, corps, statut, erreur, created_at)
             VALUES
                (:code, :email, :user, :org, :type, :objet, :corps, :statut, :erreur, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'email' => $data['destinataire_email'],
            'user' => $data['destinataire_user_code'] ?? null,
            'org' => $data['organisation_code'] ?? null,
            'type' => $data['type_code'],
            'objet' => $data['objet'],
            'corps' => $data['corps'],
            'statut' => $data['statut'] ?? 'ENVOYE',
            'erreur' => $data['erreur'] ?? null,
        ]);

        $stmt = Database::connection()->prepare('SELECT * FROM mails_envoyes WHERE mail_code = :code');
        $stmt->execute(['code' => $code]);
        return $stmt->fetch();
    }
}
