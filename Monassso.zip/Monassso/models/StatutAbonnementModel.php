<?php

class StatutAbonnementModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_abonnement ORDER BY statut_abonnement_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_abonnement WHERE statut_abonnement_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
