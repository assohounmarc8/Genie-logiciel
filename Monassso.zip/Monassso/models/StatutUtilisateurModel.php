<?php

class StatutUtilisateurModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_utilisateur ORDER BY statut_utilisateur_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_utilisateur WHERE statut_utilisateur_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
