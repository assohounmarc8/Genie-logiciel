<?php

class AuditModel
{
    public static function forSuperAdmin(int $limit = 200): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT :limit');
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function forOrganisation(string $organisationCode, int $limit = 200): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM audit_logs WHERE organisation_code = :o ORDER BY created_at DESC LIMIT :limit'
        );
        $stmt->bindValue('o', $organisationCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public static function forActor(string $userCode, int $limit = 200): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM audit_logs WHERE actor_user_code = :u ORDER BY created_at DESC LIMIT :limit'
        );
        $stmt->bindValue('u', $userCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
