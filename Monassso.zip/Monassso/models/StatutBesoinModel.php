<?php

class StatutBesoinModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_besoin ORDER BY statut_besoin_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_besoin WHERE statut_besoin_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
