<?php

class PaiementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM paiements_cotisations WHERE paiement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findForUser(string $cotisationCode, string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM paiements_cotisations WHERE cotisation_code = :c AND user_code = :u'
        );
        $stmt->execute(['c' => $cotisationCode, 'u' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByCotisation(string $cotisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, u.nom, u.email FROM paiements_cotisations p
             JOIN users u ON u.user_code = p.user_code
             WHERE p.cotisation_code = :c ORDER BY u.nom'
        );
        $stmt->execute(['c' => $cotisationCode]);
        return $stmt->fetchAll();
    }

    public static function listByUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, c.libelle, c.devise, c.organisation_code, o.nom AS organisation_nom
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             JOIN organisations o ON o.organisation_code = c.organisation_code
             WHERE p.user_code = :u ORDER BY p.created_at DESC'
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    /** Statistiques de recouvrement pour une organisation (montant dû, montant payé, nombre de lignes). */
    public static function statsForOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT
                COUNT(*) AS total_count,
                SUM(CASE WHEN p.statut_paiement = 'DU' THEN 1 ELSE 0 END) AS due_count,
                SUM(CASE WHEN p.statut_paiement = 'PAY' THEN 1 ELSE 0 END) AS paid_count,
                COALESCE(SUM(CASE WHEN p.statut_paiement = 'DU' THEN p.montant ELSE 0 END), 0) AS due_amount
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o"
        );
        $stmt->execute(['o' => $organisationCode]);
        $row = $stmt->fetch();

        $total = (int) ($row['total_count'] ?? 0);
        $paid = (int) ($row['paid_count'] ?? 0);

        return [
            'total_count' => $total,
            'due_count' => (int) ($row['due_count'] ?? 0),
            'paid_count' => $paid,
            'due_amount' => (float) ($row['due_amount'] ?? 0),
            'paid_rate' => $total > 0 ? round(($paid / $total) * 100) : 0,
        ];
    }

    public static function createDue(string $cotisationCode, string $userCode, float $montant): array
    {
        $code = CodeGenerator::paiementCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO paiements_cotisations (paiement_code, cotisation_code, user_code, montant, statut_paiement, mode_paiement, created_at)
             VALUES (:code, :coti, :user, :montant, 'DU', 'CASH', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'coti' => $cotisationCode,
            'user' => $userCode,
            'montant' => $montant,
        ]);
        return self::findByCode($code);
    }

    public static function markPaid(string $paiementCode): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE paiements_cotisations SET statut_paiement = 'PAY', date_paiement = NOW() WHERE paiement_code = :code"
        );
        $stmt->execute(['code' => $paiementCode]);
    }

    public static function markExonere(string $paiementCode): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE paiements_cotisations SET statut_paiement = 'EXO' WHERE paiement_code = :code"
        );
        $stmt->execute(['code' => $paiementCode]);
    }

    /** Répartition (nombre de lignes) par statut pour les cotisations créées durant un mois donné — alimente le camembert du tableau de bord. */
    public static function countByStatutForMonth(string $organisationCode, int $year, int $month): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT p.statut_paiement, COUNT(*) AS n
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o AND YEAR(p.created_at) = :y AND MONTH(p.created_at) = :m
             GROUP BY p.statut_paiement"
        );
        $stmt->execute(['o' => $organisationCode, 'y' => $year, 'm' => $month]);
        $counts = ['DU' => 0, 'PAY' => 0, 'EXO' => 0];
        foreach ($stmt->fetchAll() as $row) {
            if (isset($counts[$row['statut_paiement']])) {
                $counts[$row['statut_paiement']] = (int) $row['n'];
            }
        }
        return $counts;
    }

    public static function totalPaidUpTo(string $organisationCode, string $dateEnd): float
    {
        $stmt = Database::connection()->prepare(
            "SELECT COALESCE(SUM(p.montant), 0)
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o AND p.statut_paiement = 'PAY' AND DATE(p.date_paiement) <= :d"
        );
        $stmt->execute(['o' => $organisationCode, 'd' => $dateEnd]);
        return (float) $stmt->fetchColumn();
    }

    /** Membres actifs ayant au moins un paiement dû, du plus ancien au plus récent (les plus en retard d'abord). */
    public static function listLateMembers(string $organisationCode, int $limit = 5): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT u.user_code, u.nom, u.email, MIN(p.created_at) AS depuis, COUNT(*) AS nb_impayes,
                    SUM(p.montant) AS montant_du
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             JOIN users u ON u.user_code = p.user_code
             JOIN organisation_users ou ON ou.user_code = p.user_code AND ou.organisation_code = c.organisation_code
             WHERE c.organisation_code = :o AND p.statut_paiement = 'DU' AND ou.statut = 'ACT'
             GROUP BY u.user_code, u.nom, u.email
             ORDER BY depuis ASC
             LIMIT :limit"
        );
        $stmt->bindValue('o', $organisationCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** Nombre de membres actifs avec un impayé datant de plus de $months mois — alimente l'alerte du tableau de bord. */
    public static function countLateSinceMonths(string $organisationCode, int $months = 3): int
    {
        $stmt = Database::connection()->prepare(
            "SELECT COUNT(DISTINCT p.user_code)
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             JOIN organisation_users ou ON ou.user_code = p.user_code AND ou.organisation_code = c.organisation_code
             WHERE c.organisation_code = :o AND p.statut_paiement = 'DU' AND ou.statut = 'ACT'
               AND p.created_at <= DATE_SUB(NOW(), INTERVAL :months MONTH)"
        );
        $stmt->execute(['o' => $organisationCode, 'months' => $months]);
        return (int) $stmt->fetchColumn();
    }

    public static function totalDueForUser(string $organisationCode, string $userCode): float
    {
        $stmt = Database::connection()->prepare(
            "SELECT COALESCE(SUM(p.montant), 0)
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o AND p.user_code = :u AND p.statut_paiement = 'DU'"
        );
        $stmt->execute(['o' => $organisationCode, 'u' => $userCode]);
        return (float) $stmt->fetchColumn();
    }

    public static function recentPaid(string $organisationCode, int $limit = 5): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT p.*, u.nom, c.libelle, c.devise
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             JOIN users u ON u.user_code = p.user_code
             WHERE c.organisation_code = :o AND p.statut_paiement = 'PAY'
             ORDER BY p.date_paiement DESC LIMIT :limit"
        );
        $stmt->bindValue('o', $organisationCode);
        $stmt->bindValue('limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
