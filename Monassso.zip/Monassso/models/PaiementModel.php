<?php

class PaiementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM paiements_cotisations WHERE paiement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findForUser(string $cotisationCode, string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM paiements_cotisations WHERE cotisation_code = :c AND user_code = :u'
        );
        $stmt->execute(['c' => $cotisationCode, 'u' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByCotisation(string $cotisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, u.nom, u.email FROM paiements_cotisations p
             JOIN users u ON u.user_code = p.user_code
             WHERE p.cotisation_code = :c ORDER BY u.nom'
        );
        $stmt->execute(['c' => $cotisationCode]);
        return $stmt->fetchAll();
    }

    public static function listByUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT p.*, c.libelle, c.devise, c.organisation_code, o.nom AS organisation_nom
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             JOIN organisations o ON o.organisation_code = c.organisation_code
             WHERE p.user_code = :u ORDER BY p.created_at DESC'
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    /** Statistiques de recouvrement pour une organisation (montant dû, montant payé, nombre de lignes). */
    public static function statsForOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT
                COUNT(*) AS total_count,
                SUM(CASE WHEN p.statut_paiement = 'DU' THEN 1 ELSE 0 END) AS due_count,
                SUM(CASE WHEN p.statut_paiement = 'PAY' THEN 1 ELSE 0 END) AS paid_count,
                COALESCE(SUM(CASE WHEN p.statut_paiement = 'DU' THEN p.montant ELSE 0 END), 0) AS due_amount
             FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o"
        );
        $stmt->execute(['o' => $organisationCode]);
        $row = $stmt->fetch();

        $total = (int) ($row['total_count'] ?? 0);
        $paid = (int) ($row['paid_count'] ?? 0);

        return [
            'total_count' => $total,
            'due_count' => (int) ($row['due_count'] ?? 0),
            'paid_count' => $paid,
            'due_amount' => (float) ($row['due_amount'] ?? 0),
            'paid_rate' => $total > 0 ? round(($paid / $total) * 100) : 0,
        ];
    }

    public static function createDue(string $cotisationCode, string $userCode, float $montant): array
    {
        $code = CodeGenerator::paiementCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO paiements_cotisations (paiement_code, cotisation_code, user_code, montant, statut_paiement, mode_paiement, created_at)
             VALUES (:code, :coti, :user, :montant, 'DU', 'CASH', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'coti' => $cotisationCode,
            'user' => $userCode,
            'montant' => $montant,
        ]);
        return self::findByCode($code);
    }

    public static function markPaid(string $paiementCode): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE paiements_cotisations SET statut_paiement = 'PAY', date_paiement = NOW() WHERE paiement_code = :code"
        );
        $stmt->execute(['code' => $paiementCode]);
    }
}
