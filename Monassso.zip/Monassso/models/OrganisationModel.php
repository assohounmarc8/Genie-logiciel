<?php

class OrganisationModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM organisations WHERE organisation_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByAdmin(string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM organisations WHERE admin_user_code = :code ORDER BY created_at DESC LIMIT 1'
        );
        $stmt->execute(['code' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM organisations ORDER BY created_at DESC')->fetchAll();
    }

    public static function allValidated(): array
    {
        $stmt = Database::connection()->query("SELECT * FROM organisations WHERE statut_validation = 'VAL' ORDER BY nom");
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::organisationCode($data['pays_code']);
        $stmt = Database::connection()->prepare(
            "INSERT INTO organisations (organisation_code, pays_code, nom, admin_user_code, statut_validation, statut_abonnement, created_at)
             VALUES (:code, :pays, :nom, :admin, 'ATT', 'EXP', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'pays' => $data['pays_code'],
            'nom' => $data['nom'],
            'admin' => $data['admin_user_code'],
        ]);
        return self::findByCode($code);
    }

    public static function updateStatutValidation(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE organisations SET statut_validation = :s WHERE organisation_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }

    public static function updateStatutAbonnement(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE organisations SET statut_abonnement = :s WHERE organisation_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
