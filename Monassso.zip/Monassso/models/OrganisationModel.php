<?php

class OrganisationModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM organisations WHERE organisation_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByAdmin(string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM organisations WHERE admin_user_code = :code ORDER BY created_at DESC LIMIT 1'
        );
        $stmt->execute(['code' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM organisations ORDER BY created_at DESC')->fetchAll();
    }

    public static function allValidated(): array
    {
        $stmt = Database::connection()->query("SELECT * FROM organisations WHERE statut_validation = 'VAL' ORDER BY nom");
        return $stmt->fetchAll();
    }

    /** Organisations validées, limitées à un pays — un membre ne doit voir/rejoindre que celles de son pays. */
    public static function allValidatedByPays(string $paysCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT * FROM organisations WHERE statut_validation = 'VAL' AND pays_code = :pays ORDER BY nom"
        );
        $stmt->execute(['pays' => $paysCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::organisationCode($data['pays_code']);
        $stmt = Database::connection()->prepare(
            "INSERT INTO organisations (organisation_code, pays_code, nom, type_organisation, admin_user_code, statut_validation, statut_abonnement, created_at)
             VALUES (:code, :pays, :nom, :type, :admin, 'ATT', 'EXP', NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'pays' => $data['pays_code'],
            'nom' => $data['nom'],
            'type' => $data['type_organisation'],
            'admin' => $data['admin_user_code'],
        ]);
        return self::findByCode($code);
    }

    public static function updateInfo(string $code, array $data): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE organisations SET nom = :nom, email = :email, telephone = :telephone, adresse = :adresse,
                 montant_adhesion = :montant_adhesion
             WHERE organisation_code = :code'
        );
        $stmt->execute([
            'nom' => $data['nom'],
            'email' => $data['email'] !== '' ? $data['email'] : null,
            'telephone' => $data['telephone'] !== '' ? $data['telephone'] : null,
            'adresse' => $data['adresse'] !== '' ? $data['adresse'] : null,
            'montant_adhesion' => $data['montant_adhesion'] ?? null,
            'code' => $code,
        ]);
    }

    public static function updateReglement(string $code, string $chemin, string $nomOriginal): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE organisations SET reglement_interieur_chemin = :chemin, reglement_interieur_nom = :nom WHERE organisation_code = :code'
        );
        $stmt->execute([
            'chemin' => $chemin,
            'nom' => $nomOriginal,
            'code' => $code,
        ]);
    }

    public static function removeReglement(string $code): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE organisations SET reglement_interieur_chemin = NULL, reglement_interieur_nom = NULL WHERE organisation_code = :code'
        );
        $stmt->execute(['code' => $code]);
    }

    public static function updateLogo(string $code, string $logoChemin): void
    {
        $stmt = Database::connection()->prepare('UPDATE organisations SET logo_chemin = :logo WHERE organisation_code = :code');
        $stmt->execute(['logo' => $logoChemin, 'code' => $code]);
    }

    public static function updateStatutValidation(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE organisations SET statut_validation = :s WHERE organisation_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }

    public static function updateStatutAbonnement(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE organisations SET statut_abonnement = :s WHERE organisation_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }

    public static function countCreatedInMonth(int $year, int $month): int
    {
        $stmt = Database::connection()->prepare(
            'SELECT COUNT(*) FROM organisations WHERE YEAR(created_at) = :y AND MONTH(created_at) = :m'
        );
        $stmt->execute(['y' => $year, 'm' => $month]);
        return (int) $stmt->fetchColumn();
    }
}
