<?php

class TypeNotificationModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM types_notification ORDER BY type_notification_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM types_notification WHERE type_notification_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
