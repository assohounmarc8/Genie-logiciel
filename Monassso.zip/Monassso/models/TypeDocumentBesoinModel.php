<?php

class TypeDocumentBesoinModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM types_document_besoin ORDER BY nom')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM types_document_besoin WHERE type_document_besoin_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
