<?php

class StatutCarteModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_carte ORDER BY statut_carte_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_carte WHERE statut_carte_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
