<?php

class DeviseModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM devises ORDER BY devise_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM devises WHERE devise_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
