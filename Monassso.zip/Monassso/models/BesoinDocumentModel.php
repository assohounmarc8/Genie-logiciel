<?php

class BesoinDocumentModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM besoin_documents WHERE besoin_document_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByBesoin(string $besoinCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT d.*, u.nom AS uploaded_by_nom
             FROM besoin_documents d
             JOIN users u ON u.user_code = d.uploaded_by_user_code
             WHERE d.besoin_code = :b
             ORDER BY d.created_at DESC'
        );
        $stmt->execute(['b' => $besoinCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::besoinDocumentCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO besoin_documents
                (besoin_document_code, besoin_code, type, nom_original, chemin_fichier, taille_octets,
                 type_mime, uploaded_by_user_code, created_at)
             VALUES
                (:code, :besoin, :type, :nom, :chemin, :taille, :mime, :user, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'besoin' => $data['besoin_code'],
            'type' => $data['type'],
            'nom' => $data['nom_original'],
            'chemin' => $data['chemin_fichier'],
            'taille' => $data['taille_octets'],
            'mime' => $data['type_mime'],
            'user' => $data['uploaded_by_user_code'],
        ]);
        return self::findByCode($code);
    }

    public static function delete(string $code): void
    {
        $stmt = Database::connection()->prepare('DELETE FROM besoin_documents WHERE besoin_document_code = :code');
        $stmt->execute(['code' => $code]);
    }
}
