<?php

class CarteModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM cartes_adherents WHERE carte_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByToken(string $token): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM cartes_adherents WHERE qr_token = :token');
        $stmt->execute(['token' => $token]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findForMembership(string $userCode, string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM cartes_adherents WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT c.*, u.nom, u.photo_chemin, ou.numero_adherent
             FROM cartes_adherents c
             JOIN users u ON u.user_code = c.user_code
             JOIN organisation_users ou ON ou.user_code = c.user_code AND ou.organisation_code = c.organisation_code
             WHERE c.organisation_code = :o
             ORDER BY u.nom'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function listForUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT c.*, o.nom AS organisation_nom, o.logo_chemin, ou.numero_adherent
             FROM cartes_adherents c
             JOIN organisations o ON o.organisation_code = c.organisation_code
             JOIN organisation_users ou ON ou.user_code = c.user_code AND ou.organisation_code = c.organisation_code
             WHERE c.user_code = :u
             ORDER BY o.nom'
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    /** Un membre est "à jour" pour l'année en cours s'il a un paiement PAY sur une cotisation de son organisation datée de cette année. */
    public static function isUpToDate(string $organisationCode, string $userCode, ?int $year = null): bool
    {
        $year = $year ?? (int) date('Y');
        $stmt = Database::connection()->prepare(
            "SELECT 1 FROM paiements_cotisations p
             JOIN cotisations c ON c.cotisation_code = p.cotisation_code
             WHERE c.organisation_code = :o AND p.user_code = :u AND c.annee = :y AND p.statut_paiement = 'PAY'
             LIMIT 1"
        );
        $stmt->execute(['o' => $organisationCode, 'u' => $userCode, 'y' => $year]);
        return (bool) $stmt->fetchColumn();
    }

    /**
     * Crée ou met à jour la carte d'un membre selon sa situation de cotisation. Une carte BLOQUEE
     * (perdue/volée) n'est jamais réactivée automatiquement — seul un déblocage explicite le permet.
     */
    public static function issueOrUpdate(string $organisationCode, string $userCode): array
    {
        OrganisationUserModel::ensureNumeroAdherent($organisationCode, $userCode);

        $existing = self::findForMembership($userCode, $organisationCode);
        if ($existing && $existing['statut'] === 'BLOQUEE') {
            return $existing;
        }

        $upToDate = self::isUpToDate($organisationCode, $userCode);
        $statut = $upToDate ? 'ACTIF' : 'EXPIRE';
        $valideJusquAu = $upToDate ? date('Y') . '-12-31' : null;

        $pdo = Database::connection();

        if (!$existing) {
            $code = CodeGenerator::carteCode();
            $stmt = $pdo->prepare(
                'INSERT INTO cartes_adherents (carte_code, user_code, organisation_code, qr_token, statut, valide_jusqu_au, created_at)
                 VALUES (:code, :u, :o, :token, :statut, :valide, NOW())'
            );
            $stmt->execute([
                'code' => $code,
                'u' => $userCode,
                'o' => $organisationCode,
                'token' => CodeGenerator::qrToken(),
                'statut' => $statut,
                'valide' => $valideJusquAu,
            ]);
            return self::findByCode($code);
        }

        $stmt = $pdo->prepare(
            'UPDATE cartes_adherents SET statut = :statut, valide_jusqu_au = :valide WHERE carte_code = :code'
        );
        $stmt->execute(['statut' => $statut, 'valide' => $valideJusquAu, 'code' => $existing['carte_code']]);
        return self::findByCode($existing['carte_code']);
    }

    /** Émission en lot : réévalue la carte de chaque membre actif de l'organisation. Retourne des compteurs. */
    public static function emitAllForOrganisation(string $organisationCode): array
    {
        $actifs = 0;
        $expires = 0;
        foreach (OrganisationUserModel::activeMembers($organisationCode) as $membre) {
            $carte = self::issueOrUpdate($organisationCode, $membre['user_code']);
            if ($carte['statut'] === 'ACTIF') {
                $actifs++;
            } else {
                $expires++;
            }
        }
        return ['actifs' => $actifs, 'expires' => $expires, 'total' => $actifs + $expires];
    }

    public static function block(string $carteCode): void
    {
        $stmt = Database::connection()->prepare("UPDATE cartes_adherents SET statut = 'BLOQUEE' WHERE carte_code = :code");
        $stmt->execute(['code' => $carteCode]);
    }

    /** Débloque une carte perdue/retrouvée en générant un nouveau QR (l'ancien devient inutilisable) et en recalculant son statut. */
    public static function reissue(string $carteCode): array
    {
        $carte = self::findByCode($carteCode);
        $pdo = Database::connection();
        $stmt = $pdo->prepare('UPDATE cartes_adherents SET qr_token = :token WHERE carte_code = :code');
        $stmt->execute(['token' => CodeGenerator::qrToken(), 'code' => $carteCode]);

        $upToDate = self::isUpToDate($carte['organisation_code'], $carte['user_code']);
        $statut = $upToDate ? 'ACTIF' : 'EXPIRE';
        $valideJusquAu = $upToDate ? date('Y') . '-12-31' : null;
        $update = $pdo->prepare('UPDATE cartes_adherents SET statut = :statut, valide_jusqu_au = :valide WHERE carte_code = :code');
        $update->execute(['statut' => $statut, 'valide' => $valideJusquAu, 'code' => $carteCode]);

        return self::findByCode($carteCode);
    }

}
