<?php

class AdhesionPaiementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM adhesion_paiements WHERE adhesion_paiement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByToken(string $token): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM adhesion_paiements WHERE token = :token');
        $stmt->execute(['token' => $token]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findForMembership(string $userCode, string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM adhesion_paiements WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(string $userCode, string $organisationCode, float $montant): array
    {
        $existing = self::findForMembership($userCode, $organisationCode);
        if ($existing) {
            return $existing;
        }

        $code = CodeGenerator::adhesionPaiementCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO adhesion_paiements (adhesion_paiement_code, user_code, organisation_code, montant, statut, token, created_at)
             VALUES (:code, :u, :o, :montant, :statut, :token, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'u' => $userCode,
            'o' => $organisationCode,
            'montant' => $montant,
            'statut' => 'EN_ATTENTE',
            'token' => CodeGenerator::qrToken(),
        ]);
        return self::findByCode($code);
    }

    public static function markPaid(string $code, string $modePaiement): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE adhesion_paiements SET statut = 'PAYE', mode_paiement = :mode, date_paiement = NOW() WHERE adhesion_paiement_code = :code"
        );
        $stmt->execute(['mode' => $modePaiement, 'code' => $code]);
    }
}
