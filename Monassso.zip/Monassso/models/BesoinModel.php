<?php

class BesoinModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM besoins WHERE besoin_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Fiche publique d'un besoin, avec le nom et le pays de l'organisation. */
    public static function findPublicByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT b.*, o.nom AS organisation_nom, o.pays_code
             FROM besoins b
             JOIN organisations o ON o.organisation_code = b.organisation_code
             WHERE b.besoin_code = :code'
        );
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM besoins WHERE organisation_code = :o ORDER BY created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    /** Tous les besoins actifs, toutes organisations confondues — pour la page publique de dons. */
    public static function listActifs(): array
    {
        $stmt = Database::connection()->query(
            "SELECT b.*, o.nom AS organisation_nom, o.pays_code
             FROM besoins b
             JOIN organisations o ON o.organisation_code = b.organisation_code
             WHERE b.statut = 'ACTIF'
             ORDER BY b.created_at DESC"
        );
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::besoinCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO besoins
                (besoin_code, organisation_code, cree_par_user_code, titre, description, type_besoin,
                 montant_recherche, montant_collecte, statut, date_fin, photo_chemin, created_at)
             VALUES
                (:code, :org, :user, :titre, :description, :type, :montant, 0, 'ACTIF', :date_fin, :photo, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'user' => $data['cree_par_user_code'],
            'titre' => $data['titre'],
            'description' => $data['description'],
            'type' => $data['type_besoin'],
            'montant' => $data['montant_recherche'],
            'date_fin' => $data['date_fin'] !== '' ? $data['date_fin'] : null,
            'photo' => $data['photo_chemin'] ?? null,
        ]);
        return self::findByCode($code);
    }

    public static function updatePhoto(string $code, string $photoChemin): void
    {
        $stmt = Database::connection()->prepare('UPDATE besoins SET photo_chemin = :p WHERE besoin_code = :code');
        $stmt->execute(['p' => $photoChemin, 'code' => $code]);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE besoins SET statut = :s WHERE besoin_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }

    /**
     * Ajoute un montant au total collecté et bascule automatiquement le besoin en FINANCE si
     * l'objectif est atteint. Verrouille la ligne le temps de la transaction pour éviter une
     * course entre deux dons simultanés.
     */
    public static function incrementCollecte(string $code, float $montant): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('SELECT * FROM besoins WHERE besoin_code = :code FOR UPDATE');
            $stmt->execute(['code' => $code]);
            $besoin = $stmt->fetch();

            $nouveauMontant = (float) $besoin['montant_collecte'] + $montant;
            $nouveauStatut = $besoin['statut'];
            if ($nouveauStatut === 'ACTIF' && $nouveauMontant >= (float) $besoin['montant_recherche']) {
                $nouveauStatut = 'FINANCE';
            }

            $update = $pdo->prepare('UPDATE besoins SET montant_collecte = :m, statut = :s WHERE besoin_code = :code');
            $update->execute(['m' => $nouveauMontant, 's' => $nouveauStatut, 'code' => $code]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return self::findByCode($code);
    }

    public static function delete(string $code): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM besoin_documents WHERE besoin_code = :code')->execute(['code' => $code]);
            $pdo->prepare('DELETE FROM dons WHERE besoin_code = :code')->execute(['code' => $code]);
            $pdo->prepare('DELETE FROM besoins WHERE besoin_code = :code')->execute(['code' => $code]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}
