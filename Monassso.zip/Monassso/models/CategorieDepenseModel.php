<?php

class CategorieDepenseModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM categories_depenses ORDER BY nom')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM categories_depenses WHERE categorie_depense_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
