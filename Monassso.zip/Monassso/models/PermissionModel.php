<?php

class PermissionModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM permissions ORDER BY nom')->fetchAll();
    }
}
