<?php

class EvenementModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM evenements WHERE evenement_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByToken(string $token): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM evenements WHERE qr_token = :token');
        $stmt->execute(['token' => $token]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Événement dont l'appel est en cours (QR généré, pas encore clôturé) — utilisé pour le pointage par carte. */
    public static function findLiveForOrganisation(string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            "SELECT * FROM evenements
             WHERE organisation_code = :o AND statut = 'PLANIFIE' AND qr_token IS NOT NULL
             ORDER BY date_heure ASC LIMIT 1"
        );
        $stmt->execute(['o' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM evenements WHERE organisation_code = :o ORDER BY date_heure DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    /** Événements à venir (PLANIFIE) pour toutes les organisations dont l'utilisateur est membre actif. */
    public static function listUpcomingForUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT e.*, o.nom AS organisation_nom
             FROM evenements e
             JOIN organisation_users ou ON ou.organisation_code = e.organisation_code
             JOIN organisations o ON o.organisation_code = e.organisation_code
             WHERE ou.user_code = :u AND ou.statut = 'ACT' AND e.statut = 'PLANIFIE'
             ORDER BY e.date_heure ASC"
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::evenementCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO evenements
                (evenement_code, organisation_code, cree_par_user_code, titre, description, lieu, date_heure, statut, created_at)
             VALUES
                (:code, :org, :user, :titre, :description, :lieu, :date_heure, :statut, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'user' => $data['cree_par_user_code'],
            'titre' => $data['titre'],
            'description' => $data['description'],
            'lieu' => $data['lieu'],
            'date_heure' => $data['date_heure'],
            'statut' => $data['statut'] ?? 'PLANIFIE',
        ]);
        return self::findByCode($code);
    }

    public static function setToken(string $code, string $token): void
    {
        $stmt = Database::connection()->prepare('UPDATE evenements SET qr_token = :token WHERE evenement_code = :code');
        $stmt->execute(['token' => $token, 'code' => $code]);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE evenements SET statut = :s WHERE evenement_code = :code');
        $stmt->execute(['s' => $statut, 'code' => $code]);
    }
}
