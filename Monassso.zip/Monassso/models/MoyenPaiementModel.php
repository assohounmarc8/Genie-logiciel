<?php

class MoyenPaiementModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM moyens_paiement ORDER BY moyen_paiement_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM moyens_paiement WHERE moyen_paiement_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
