<?php

/**
 * Agrégations financières transverses (cotisations + dons - dépenses) pour le tableau de bord —
 * ne correspond à aucune table unique, contrairement aux autres modèles.
 */
class FinanceModel
{
    public static function treasuryBalanceAsOf(string $organisationCode, string $dateEnd): float
    {
        return PaiementModel::totalPaidUpTo($organisationCode, $dateEnd)
            + DonModel::totalPaidUpTo($organisationCode, $dateEnd)
            - DepenseModel::totalUpTo($organisationCode, $dateEnd);
    }

    /** Solde de trésorerie cumulé à la fin de chacun des $monthsBack derniers mois (du plus ancien au plus récent). */
    public static function treasuryTrend(string $organisationCode, int $monthsBack = 6): array
    {
        $trend = [];
        for ($i = $monthsBack - 1; $i >= 0; $i--) {
            $timestamp = strtotime("first day of -$i month");
            $lastDayOfMonth = date('Y-m-t', $timestamp);
            $trend[] = [
                'label' => t('month.' . date('m', $timestamp)) . ' ' . date('Y', $timestamp),
                'balance' => self::treasuryBalanceAsOf($organisationCode, $lastDayOfMonth),
            ];
        }
        return $trend;
    }

    /** Fusionne cotisations payées, dons reçus et dépenses en un seul flux d'activité récente, trié par date décroissante. */
    public static function recentActivity(string $organisationCode, int $limit = 5): array
    {
        $items = [];

        foreach (PaiementModel::recentPaid($organisationCode, $limit) as $p) {
            $items[] = [
                'date' => $p['date_paiement'],
                'type' => 'IN',
                'label' => t('finance.activity.cotisation_paid', ['nom' => $p['nom'], 'montant' => format_money((float) $p['montant'], $p['devise'])]),
            ];
        }

        foreach (DonModel::recentForOrganisation($organisationCode, $limit) as $d) {
            $items[] = [
                'date' => $d['created_at'],
                'type' => 'IN',
                'label' => t('finance.activity.don_received', ['montant' => format_money((float) $d['montant']), 'besoin' => $d['besoin_titre']]),
            ];
        }

        foreach (DepenseModel::recent($organisationCode, $limit) as $dep) {
            $items[] = [
                'date' => $dep['created_at'],
                'type' => 'OUT',
                'label' => t('finance.activity.depense', ['montant' => format_money((float) $dep['montant']), 'libelle' => $dep['libelle']]),
            ];
        }

        usort($items, fn ($a, $b) => strcmp($b['date'], $a['date']));

        return array_slice($items, 0, $limit);
    }
}
