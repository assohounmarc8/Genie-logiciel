<?php

class StatutPaiementCotisationModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_paiement_cotisation ORDER BY statut_paiement_cotisation_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_paiement_cotisation WHERE statut_paiement_cotisation_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
