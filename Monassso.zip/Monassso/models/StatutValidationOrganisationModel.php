<?php

class StatutValidationOrganisationModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_validation_organisation ORDER BY statut_validation_organisation_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_validation_organisation WHERE statut_validation_organisation_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
