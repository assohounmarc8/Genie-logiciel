<?php

class RoleModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM roles WHERE role_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM roles WHERE organisation_code = :o ORDER BY nom_role');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(string $organisationCode, string $nomRole, ?string $parentRoleCode, array $permissionCodes): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $code = CodeGenerator::roleCode($organisationCode, $nomRole);
            $stmt = $pdo->prepare(
                'INSERT INTO roles (role_code, organisation_code, nom_role, parent_role_code, created_at)
                 VALUES (:code, :org, :nom, :parent, NOW())'
            );
            $stmt->execute([
                'code' => $code,
                'org' => $organisationCode,
                'nom' => $nomRole,
                'parent' => $parentRoleCode ?: null,
            ]);

            $permStmt = $pdo->prepare('INSERT INTO role_permissions (role_code, permission_code) VALUES (:role, :perm)');
            foreach ($permissionCodes as $permissionCode) {
                $permStmt->execute(['role' => $code, 'perm' => $permissionCode]);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return self::findByCode($code);
    }

    public static function existsByOrganisationAndName(string $organisationCode, string $nomRole): bool
    {
        $stmt = Database::connection()->prepare(
            'SELECT 1 FROM roles WHERE organisation_code = :o AND nom_role = :n'
        );
        $stmt->execute(['o' => $organisationCode, 'n' => $nomRole]);
        return (bool) $stmt->fetchColumn();
    }

    /**
     * Crée les rôles standards (PRESIDENT, TRESORIER, SECRETAIRE, MEMBRE) avec leurs permissions
     * par défaut pour une organisation, en sautant ceux qui existent déjà (idempotent).
     */
    public static function ensureDefaultRoles(string $organisationCode): void
    {
        $defaults = config_get('default_role_permissions');
        foreach ($defaults as $nomRole => $permissionCodes) {
            if (!self::existsByOrganisationAndName($organisationCode, $nomRole)) {
                self::create($organisationCode, $nomRole, null, $permissionCodes);
            }
        }
    }

    public static function permissionsFor(string $roleCode): array
    {
        $stmt = Database::connection()->prepare('SELECT permission_code FROM role_permissions WHERE role_code = :r');
        $stmt->execute(['r' => $roleCode]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public static function roleHasPermission(string $roleCode, string $permissionCode): bool
    {
        $current = $roleCode;
        $visited = [];
        while ($current && !in_array($current, $visited, true)) {
            $visited[] = $current;

            $stmt = Database::connection()->prepare(
                'SELECT 1 FROM role_permissions WHERE role_code = :r AND permission_code = :p'
            );
            $stmt->execute(['r' => $current, 'p' => $permissionCode]);
            if ($stmt->fetchColumn()) {
                return true;
            }

            $role = self::findByCode($current);
            $current = $role['parent_role_code'] ?? null;
        }

        return false;
    }
}
