<?php

class RoleModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM roles WHERE role_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM roles WHERE organisation_code = :o ORDER BY nom_role');
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(string $organisationCode, string $nomRole, ?string $parentRoleCode, array $permissionCodes): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $code = CodeGenerator::roleCode($organisationCode, $nomRole);
            $stmt = $pdo->prepare(
                'INSERT INTO roles (role_code, organisation_code, nom_role, parent_role_code, created_at)
                 VALUES (:code, :org, :nom, :parent, NOW())'
            );
            $stmt->execute([
                'code' => $code,
                'org' => $organisationCode,
                'nom' => $nomRole,
                'parent' => $parentRoleCode ?: null,
            ]);

            $permStmt = $pdo->prepare('INSERT INTO role_permissions (role_code, permission_code) VALUES (:role, :perm)');
            foreach ($permissionCodes as $permissionCode) {
                $permStmt->execute(['role' => $code, 'perm' => $permissionCode]);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return self::findByCode($code);
    }

    /**
     * Remplace le rôle parent et l'ensemble des permissions d'un rôle existant — c'est ce qui permet
     * à chaque organisation de personnaliser ses rôles (une organisation peut donner plus ou moins
     * d'accès à son rôle "MEMBRE" qu'une autre, par exemple).
     */
    public static function update(string $roleCode, ?string $parentRoleCode, array $permissionCodes): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('UPDATE roles SET parent_role_code = :parent WHERE role_code = :code');
            $stmt->execute(['parent' => $parentRoleCode ?: null, 'code' => $roleCode]);

            $pdo->prepare('DELETE FROM role_permissions WHERE role_code = :r')->execute(['r' => $roleCode]);

            $permStmt = $pdo->prepare('INSERT INTO role_permissions (role_code, permission_code) VALUES (:role, :perm)');
            foreach ($permissionCodes as $permissionCode) {
                $permStmt->execute(['role' => $roleCode, 'perm' => $permissionCode]);
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return self::findByCode($roleCode);
    }

    public static function existsByOrganisationAndName(string $organisationCode, string $nomRole): bool
    {
        $stmt = Database::connection()->prepare(
            'SELECT 1 FROM roles WHERE organisation_code = :o AND nom_role = :n'
        );
        $stmt->execute(['o' => $organisationCode, 'n' => $nomRole]);
        return (bool) $stmt->fetchColumn();
    }

    /**
     * Crée les rôles standards (PRESIDENT, TRESORIER, SECRETAIRE, MEMBRE) avec leurs permissions
     * par défaut pour une organisation, en sautant ceux qui existent déjà (idempotent).
     */
    public static function ensureDefaultRoles(string $organisationCode): void
    {
        $defaults = config_get('default_role_permissions');
        foreach ($defaults as $nomRole => $permissionCodes) {
            if (!self::existsByOrganisationAndName($organisationCode, $nomRole)) {
                self::create($organisationCode, $nomRole, null, $permissionCodes);
            }
        }
    }

    public static function permissionsFor(string $roleCode): array
    {
        $stmt = Database::connection()->prepare('SELECT permission_code FROM role_permissions WHERE role_code = :r');
        $stmt->execute(['r' => $roleCode]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /** Un rôle standard (Président/Trésorier/Secrétaire/Membre) ne peut pas être supprimé, seulement personnalisé. */
    public static function isDefault(array $role): bool
    {
        return array_key_exists($role['nom_role'], config_get('default_role_permissions') ?? []);
    }

    /**
     * Supprime un rôle personnalisé : les membres qui l'avaient perdent leur rôle (deviennent
     * "Sans rôle") et les rôles qui l'avaient comme parent perdent cet héritage, plutôt que de
     * bloquer la suppression pour une contrainte de clé étrangère.
     */
    public static function delete(string $roleCode): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $pdo->prepare('UPDATE organisation_users SET role_code = NULL WHERE role_code = :r')->execute(['r' => $roleCode]);
            $pdo->prepare('UPDATE roles SET parent_role_code = NULL WHERE parent_role_code = :r')->execute(['r' => $roleCode]);
            $pdo->prepare('DELETE FROM role_permissions WHERE role_code = :r')->execute(['r' => $roleCode]);
            $pdo->prepare('DELETE FROM roles WHERE role_code = :r')->execute(['r' => $roleCode]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function roleHasPermission(string $roleCode, string $permissionCode): bool
    {
        $current = $roleCode;
        $visited = [];
        while ($current && !in_array($current, $visited, true)) {
            $visited[] = $current;

            $stmt = Database::connection()->prepare(
                'SELECT 1 FROM role_permissions WHERE role_code = :r AND permission_code = :p'
            );
            $stmt->execute(['r' => $current, 'p' => $permissionCode]);
            if ($stmt->fetchColumn()) {
                return true;
            }

            $role = self::findByCode($current);
            $current = $role['parent_role_code'] ?? null;
        }

        return false;
    }
}
