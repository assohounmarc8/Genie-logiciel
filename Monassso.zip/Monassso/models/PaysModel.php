<?php

class PaysModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM pays ORDER BY nom')->fetchAll();
    }

    public static function find(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM pays WHERE pays_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function exists(string $code): bool
    {
        return self::find($code) !== null;
    }
}
