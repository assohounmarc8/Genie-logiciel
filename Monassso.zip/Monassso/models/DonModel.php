<?php

class DonModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM dons WHERE don_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByBesoin(string $besoinCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM dons WHERE besoin_code = :b ORDER BY created_at DESC'
        );
        $stmt->execute(['b' => $besoinCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::donCode();
        $stmt = Database::connection()->prepare(
            "INSERT INTO dons
                (don_code, besoin_code, donateur_nom, donateur_email, montant, mode_paiement, statut,
                 anonyme, message, created_at)
             VALUES
                (:code, :besoin, :nom, :email, :montant, :mode, 'PAYE', :anonyme, :message, NOW())"
        );
        $stmt->execute([
            'code' => $code,
            'besoin' => $data['besoin_code'],
            'nom' => $data['donateur_nom'],
            'email' => $data['donateur_email'] !== '' ? $data['donateur_email'] : null,
            'montant' => $data['montant'],
            'mode' => $data['mode_paiement'],
            'anonyme' => $data['anonyme'] ? 1 : 0,
            'message' => $data['message'] !== '' ? $data['message'] : null,
        ]);
        return self::findByCode($code);
    }
}
