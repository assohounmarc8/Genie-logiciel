<?php

class TypeBesoinModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM types_besoin ORDER BY type_besoin_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM types_besoin WHERE type_besoin_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
