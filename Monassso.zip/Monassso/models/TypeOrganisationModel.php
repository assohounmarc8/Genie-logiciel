<?php

class TypeOrganisationModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM types_organisation ORDER BY type_organisation_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM types_organisation WHERE type_organisation_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
