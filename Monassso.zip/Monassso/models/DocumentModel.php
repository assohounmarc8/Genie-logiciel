<?php

class DocumentModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM documents WHERE document_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT d.*, u.nom AS uploaded_by_nom
             FROM documents d
             JOIN users u ON u.user_code = d.uploaded_by_user_code
             WHERE d.organisation_code = :o
             ORDER BY d.created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function create(array $data): array
    {
        $code = CodeGenerator::documentCode();
        $stmt = Database::connection()->prepare(
            'INSERT INTO documents
                (document_code, organisation_code, uploaded_by_user_code, categorie, nom_original,
                 chemin_fichier, taille_octets, type_mime, visibilite, created_at)
             VALUES
                (:code, :org, :user, :categorie, :nom, :chemin, :taille, :mime, :visibilite, NOW())'
        );
        $stmt->execute([
            'code' => $code,
            'org' => $data['organisation_code'],
            'user' => $data['uploaded_by_user_code'],
            'categorie' => $data['categorie'],
            'nom' => $data['nom_original'],
            'chemin' => $data['chemin_fichier'],
            'taille' => $data['taille_octets'],
            'mime' => $data['type_mime'],
            'visibilite' => $data['visibilite'],
        ]);
        return self::findByCode($code);
    }

    public static function delete(string $code): void
    {
        $stmt = Database::connection()->prepare('DELETE FROM documents WHERE document_code = :code');
        $stmt->execute(['code' => $code]);
    }
}
