<?php

class UserModel
{
    public static function findByCode(string $code): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM users WHERE user_code = :code');
        $stmt->execute(['code' => $code]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function findByEmail(string $email): ?array
    {
        $stmt = Database::connection()->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function emailExists(string $email): bool
    {
        return self::findByEmail($email) !== null;
    }

    public static function create(array $data): array
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        try {
            $userCode = CodeGenerator::userCode($data['pays_code']);
            $stmt = $pdo->prepare(
                'INSERT INTO users (user_code, pays_code, nom, email, password_hash, type_compte, sexe, date_naissance, lieu_naissance, metier, statut, created_at)
                 VALUES (:code, :pays, :nom, :email, :hash, :type, :sexe, :date_naissance, :lieu_naissance, :metier, :statut, NOW())'
            );
            $stmt->execute([
                'code' => $userCode,
                'pays' => $data['pays_code'],
                'nom' => $data['nom'],
                'email' => $data['email'],
                'hash' => password_hash($data['password'], PASSWORD_DEFAULT),
                'type' => $data['type_compte'],
                'sexe' => $data['sexe'],
                'date_naissance' => $data['date_naissance'],
                'lieu_naissance' => $data['lieu_naissance'],
                'metier' => $data['metier'],
                'statut' => 'ACT',
            ]);
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        return self::findByCode($userCode);
    }

    public static function incrementFailedLogin(string $code): void
    {
        $stmt = Database::connection()->prepare('UPDATE users SET failed_login_count = failed_login_count + 1 WHERE user_code = :code');
        $stmt->execute(['code' => $code]);
    }

    public static function resetFailedLogin(string $code): void
    {
        $stmt = Database::connection()->prepare('UPDATE users SET failed_login_count = 0 WHERE user_code = :code');
        $stmt->execute(['code' => $code]);
    }

    public static function updateStatut(string $code, string $statut): void
    {
        $stmt = Database::connection()->prepare('UPDATE users SET statut = :statut WHERE user_code = :code');
        $stmt->execute(['statut' => $statut, 'code' => $code]);
    }

    public static function listSuperAdmins(): array
    {
        return Database::connection()
            ->query("SELECT * FROM users WHERE type_compte = 'SUPER_ADMIN' AND statut = 'ACT'")
            ->fetchAll();
    }

    public static function countAll(): int
    {
        return (int) Database::connection()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    }

    /** Répartition des comptes par type (SUPER_ADMIN/ADMIN_ORGA/MEMBRE), toujours avec les 3 clés présentes. */
    public static function countByType(): array
    {
        $counts = ['SUPER_ADMIN' => 0, 'ADMIN_ORGA' => 0, 'MEMBRE' => 0];
        $stmt = Database::connection()->query('SELECT type_compte, COUNT(*) AS nb FROM users GROUP BY type_compte');
        foreach ($stmt->fetchAll() as $row) {
            $counts[$row['type_compte']] = (int) $row['nb'];
        }
        return $counts;
    }
}
