<?php

class StatutAbonnementOrganisationModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_abonnement_organisation ORDER BY statut_abonnement_organisation_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_abonnement_organisation WHERE statut_abonnement_organisation_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
