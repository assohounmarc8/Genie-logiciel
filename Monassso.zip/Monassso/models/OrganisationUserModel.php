<?php

class OrganisationUserModel
{
    public static function find(string $userCode, string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM organisation_users WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT ou.*, u.nom, u.email, r.nom_role
             FROM organisation_users ou
             JOIN users u ON u.user_code = ou.user_code
             LEFT JOIN roles r ON r.role_code = ou.role_code
             WHERE ou.organisation_code = :o
             ORDER BY ou.created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function listByUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT ou.*, o.nom AS organisation_nom
             FROM organisation_users ou
             JOIN organisations o ON o.organisation_code = ou.organisation_code
             WHERE ou.user_code = :u
             ORDER BY ou.created_at DESC'
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    /** Adhésion active la plus récente d'un membre, avec le nom de l'organisation et du rôle — utilisée pour le menu/tableau de bord. */
    public static function primaryActiveMembership(string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            "SELECT ou.*, o.nom AS organisation_nom, r.nom_role
             FROM organisation_users ou
             JOIN organisations o ON o.organisation_code = ou.organisation_code
             LEFT JOIN roles r ON r.role_code = ou.role_code
             WHERE ou.user_code = :u AND ou.statut = 'ACT'
             ORDER BY ou.date_adhesion DESC, ou.created_at DESC
             LIMIT 1"
        );
        $stmt->execute(['u' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function activeMembers(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT ou.*, u.nom, u.email FROM organisation_users ou
             JOIN users u ON u.user_code = ou.user_code
             WHERE ou.organisation_code = :o AND ou.statut = 'ACT'"
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function createRequest(string $userCode, string $organisationCode): void
    {
        $stmt = Database::connection()->prepare(
            "INSERT INTO organisation_users (user_code, organisation_code, statut, created_at)
             VALUES (:u, :o, 'ATT', NOW())"
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
    }

    public static function updateStatutRole(string $userCode, string $organisationCode, string $statut, ?string $roleCode): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE organisation_users
             SET statut = :s,
                 role_code = :r,
                 date_adhesion = IF(:s2 = "ACT" AND date_adhesion IS NULL, NOW(), date_adhesion)
             WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute([
            's' => $statut,
            'r' => $roleCode,
            's2' => $statut,
            'u' => $userCode,
            'o' => $organisationCode,
        ]);
    }
}
