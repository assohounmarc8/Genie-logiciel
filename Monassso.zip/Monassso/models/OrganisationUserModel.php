<?php

class OrganisationUserModel
{
    public static function find(string $userCode, string $organisationCode): ?array
    {
        $stmt = Database::connection()->prepare(
            'SELECT * FROM organisation_users WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function listByOrganisation(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT ou.*, u.nom, u.email, r.nom_role
             FROM organisation_users ou
             JOIN users u ON u.user_code = ou.user_code
             LEFT JOIN roles r ON r.role_code = ou.role_code
             WHERE ou.organisation_code = :o
             ORDER BY ou.created_at DESC'
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    public static function listByUser(string $userCode): array
    {
        $stmt = Database::connection()->prepare(
            'SELECT ou.*, o.nom AS organisation_nom
             FROM organisation_users ou
             JOIN organisations o ON o.organisation_code = ou.organisation_code
             WHERE ou.user_code = :u
             ORDER BY ou.created_at DESC'
        );
        $stmt->execute(['u' => $userCode]);
        return $stmt->fetchAll();
    }

    /** Adhésion active la plus récente d'un membre, avec le nom de l'organisation et du rôle — utilisée pour le menu/tableau de bord. */
    public static function primaryActiveMembership(string $userCode): ?array
    {
        $stmt = Database::connection()->prepare(
            "SELECT ou.*, o.nom AS organisation_nom, r.nom_role
             FROM organisation_users ou
             JOIN organisations o ON o.organisation_code = ou.organisation_code
             LEFT JOIN roles r ON r.role_code = ou.role_code
             WHERE ou.user_code = :u AND ou.statut = 'ACT'
             ORDER BY ou.date_adhesion DESC, ou.created_at DESC
             LIMIT 1"
        );
        $stmt->execute(['u' => $userCode]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function activeMembers(string $organisationCode): array
    {
        $stmt = Database::connection()->prepare(
            "SELECT ou.*, u.nom, u.email FROM organisation_users ou
             JOIN users u ON u.user_code = ou.user_code
             WHERE ou.organisation_code = :o AND ou.statut = 'ACT'"
        );
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    /**
     * Membres actifs ciblés pour une communication :
     * - MEMBRES = pas de rôle du tout, ou le rôle de base "MEMBRE" (aucune fonction au bureau)
     * - BUREAU = un rôle autre que "MEMBRE" (PRESIDENT, SECRETAIRE, TRESORIER, ou tout rôle personnalisé)
     * - TOUS = tous les membres actifs
     */
    public static function activeMembersByRoleGroup(string $organisationCode, string $cible): array
    {
        $sql = "SELECT ou.*, u.nom, u.email FROM organisation_users ou
                JOIN users u ON u.user_code = ou.user_code
                LEFT JOIN roles r ON r.role_code = ou.role_code
                WHERE ou.organisation_code = :o AND ou.statut = 'ACT'";

        if ($cible === 'MEMBRES') {
            $sql .= " AND (ou.role_code IS NULL OR r.nom_role = 'MEMBRE')";
        } elseif ($cible === 'BUREAU') {
            $sql .= " AND ou.role_code IS NOT NULL AND r.nom_role <> 'MEMBRE'";
        }

        $stmt = Database::connection()->prepare($sql);
        $stmt->execute(['o' => $organisationCode]);
        return $stmt->fetchAll();
    }

    /** Attribue un numéro d'adhérent séquentiel (par organisation) la première fois qu'il est nécessaire — carte ou adhésion payante. */
    public static function ensureNumeroAdherent(string $organisationCode, string $userCode): void
    {
        $stmt = Database::connection()->prepare(
            'SELECT numero_adherent FROM organisation_users WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
        if ($stmt->fetchColumn()) {
            return;
        }

        $numero = CodeGenerator::numeroAdherent($organisationCode);
        $update = Database::connection()->prepare(
            'UPDATE organisation_users SET numero_adherent = :n WHERE user_code = :u AND organisation_code = :o'
        );
        $update->execute(['n' => $numero, 'u' => $userCode, 'o' => $organisationCode]);
    }

    public static function createRequest(string $userCode, string $organisationCode): void
    {
        $stmt = Database::connection()->prepare(
            "INSERT INTO organisation_users (user_code, organisation_code, statut, created_at)
             VALUES (:u, :o, 'ATT', NOW())"
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
    }

    public static function updateStatutRole(string $userCode, string $organisationCode, string $statut, ?string $roleCode): void
    {
        $stmt = Database::connection()->prepare(
            'UPDATE organisation_users
             SET statut = :s,
                 role_code = :r,
                 date_adhesion = IF(:s2 = "ACT" AND date_adhesion IS NULL, NOW(), date_adhesion)
             WHERE user_code = :u AND organisation_code = :o'
        );
        $stmt->execute([
            's' => $statut,
            'r' => $roleCode,
            's2' => $statut,
            'u' => $userCode,
            'o' => $organisationCode,
        ]);
    }

    public static function refuse(string $userCode, string $organisationCode, string $motif): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE organisation_users SET statut = 'REF', role_code = NULL, motif_refus = :motif
             WHERE user_code = :u AND organisation_code = :o"
        );
        $stmt->execute(['motif' => $motif !== '' ? $motif : null, 'u' => $userCode, 'o' => $organisationCode]);
    }

    /** Active un membre après paiement du droit d'adhésion (ou immédiatement si l'organisation n'en exige pas). */
    public static function activate(string $userCode, string $organisationCode): void
    {
        $stmt = Database::connection()->prepare(
            "UPDATE organisation_users
             SET statut = 'ACT', date_adhesion = IF(date_adhesion IS NULL, NOW(), date_adhesion)
             WHERE user_code = :u AND organisation_code = :o"
        );
        $stmt->execute(['u' => $userCode, 'o' => $organisationCode]);
    }
}
