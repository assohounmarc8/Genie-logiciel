<?php

class StatutAdhesionPaiementModel
{
    public static function all(): array
    {
        return Database::connection()->query('SELECT * FROM statuts_adhesion_paiement ORDER BY statut_adhesion_paiement_code')->fetchAll();
    }

    public static function exists(string $code): bool
    {
        $stmt = Database::connection()->prepare('SELECT 1 FROM statuts_adhesion_paiement WHERE statut_adhesion_paiement_code = :code');
        $stmt->execute(['code' => $code]);
        return (bool) $stmt->fetchColumn();
    }
}
