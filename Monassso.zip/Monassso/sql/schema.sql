-- Monasso V1 — schéma MySQL/MariaDB
--
-- Correspondance avec le cahier des charges "10 tables clés gpotb001 à gpotb010" :
-- les noms de table ci-dessous sont les noms sémantiques donnés après chaque code
-- (ex. "gpotb001 users" -> table `users`) ; le numéro gpotbXXX est conservé en commentaire
-- au-dessus de chaque CREATE TABLE pour la traçabilité.
--
-- Règles respectées : pas d'AUTO_INCREMENT, clé primaire = code métier (ou clé composite
-- de codes métier pour les deux tables de liaison pures), ENUM en libellés courts lisibles.
--
-- Import : "C:\xampp\mysql\bin\mysql.exe" -u root < sql/schema.sql

CREATE DATABASE IF NOT EXISTS monasso CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE monasso;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS abonnements_orga;
DROP TABLE IF EXISTS paiements_cotisations;
DROP TABLE IF EXISTS cotisations;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS organisation_users;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS organisations;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- gpotb001
CREATE TABLE users (
    user_code           VARCHAR(20)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(150) NOT NULL,
    email               VARCHAR(190) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    type_compte         ENUM('SUPER_ADMIN', 'ADMIN_ORGA', 'MEMBRE') NOT NULL,
    sexe                ENUM('M', 'F') NOT NULL,
    statut              ENUM('ACT', 'SUS', 'SUP') NOT NULL DEFAULT 'ACT',
    failed_login_count  INT UNSIGNED NOT NULL DEFAULT 0,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb002
CREATE TABLE organisations (
    organisation_code   VARCHAR(40)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(190) NOT NULL,
    admin_user_code     VARCHAR(20)  NOT NULL,
    statut_validation   ENUM('ATT', 'VAL', 'REF') NOT NULL DEFAULT 'ATT',
    statut_abonnement   ENUM('EXP', 'ACT', 'SUS') NOT NULL DEFAULT 'EXP',
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_org_admin FOREIGN KEY (admin_user_code) REFERENCES users (user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb004
CREATE TABLE roles (
    role_code           VARCHAR(80)  NOT NULL PRIMARY KEY,
    organisation_code   VARCHAR(40)  NOT NULL,
    nom_role             VARCHAR(100) NOT NULL,
    parent_role_code     VARCHAR(80)  NULL,
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_role_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_role_parent FOREIGN KEY (parent_role_code) REFERENCES roles (role_code),
    UNIQUE KEY uq_role_org_nom (organisation_code, nom_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb005
CREATE TABLE permissions (
    permission_code      VARCHAR(50)  NOT NULL PRIMARY KEY,
    nom                  VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb003 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE organisation_users (
    user_code           VARCHAR(20)  NOT NULL,
    organisation_code   VARCHAR(40)  NOT NULL,
    role_code           VARCHAR(80)  NULL,
    statut              ENUM('ATT', 'ACT', 'SUS', 'REF') NOT NULL DEFAULT 'ATT',
    date_adhesion       DATETIME NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_code, organisation_code),
    CONSTRAINT fk_ou_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_ou_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_ou_role FOREIGN KEY (role_code) REFERENCES roles (role_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb006 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE role_permissions (
    role_code           VARCHAR(80) NOT NULL,
    permission_code      VARCHAR(50) NOT NULL,
    PRIMARY KEY (role_code, permission_code),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_code) REFERENCES roles (role_code),
    CONSTRAINT fk_rp_perm FOREIGN KEY (permission_code) REFERENCES permissions (permission_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb007
CREATE TABLE cotisations (
    cotisation_code      VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code    VARCHAR(40)  NOT NULL,
    libelle              VARCHAR(190) NOT NULL,
    montant              DECIMAL(14,2) NOT NULL,
    devise               VARCHAR(10)  NOT NULL DEFAULT 'XOF',
    statut               ENUM('ACT', 'CLO') NOT NULL DEFAULT 'ACT',
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coti_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb008
CREATE TABLE paiements_cotisations (
    paiement_code        VARCHAR(30) NOT NULL PRIMARY KEY,
    cotisation_code       VARCHAR(30) NOT NULL,
    user_code             VARCHAR(20) NOT NULL,
    montant                DECIMAL(14,2) NOT NULL,
    statut_paiement        ENUM('DU', 'PAY', 'ANN') NOT NULL DEFAULT 'DU',
    mode_paiement           ENUM('CASH') NOT NULL DEFAULT 'CASH',
    date_paiement            DATETIME NULL,
    created_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_paiement_coti_user (cotisation_code, user_code),
    CONSTRAINT fk_pay_coti FOREIGN KEY (cotisation_code) REFERENCES cotisations (cotisation_code),
    CONSTRAINT fk_pay_user FOREIGN KEY (user_code) REFERENCES users (user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb009
CREATE TABLE abonnements_orga (
    abonnement_code       VARCHAR(30) NOT NULL PRIMARY KEY,
    organisation_code      VARCHAR(40) NOT NULL,
    statut                  ENUM('ACT', 'EXP', 'SUS') NOT NULL DEFAULT 'ACT',
    montant                  DECIMAL(14,2) NOT NULL DEFAULT 0,
    date_debut                DATE NOT NULL,
    date_fin                   DATE NOT NULL,
    created_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_abo_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb010
CREATE TABLE audit_logs (
    audit_code             VARCHAR(30) NOT NULL PRIMARY KEY,
    actor_user_code         VARCHAR(20) NULL,
    organisation_code        VARCHAR(40) NULL,
    action_code                VARCHAR(50) NOT NULL,
    target_code                  VARCHAR(60) NULL,
    details_json                  JSON NULL,
    ip                              VARCHAR(45) NULL,
    created_at                       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_code) REFERENCES users (user_code) ON DELETE SET NULL,
    CONSTRAINT fk_audit_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_audit_actor (actor_user_code),
    INDEX idx_audit_org (organisation_code),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- notifications : boîte de notifications in-app par utilisateur (ex. adhésion acceptée/refusée)
CREATE TABLE notifications (
    notification_code   VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code            VARCHAR(20)  NOT NULL,
    organisation_code     VARCHAR(40)  NULL,
    type_code               VARCHAR(50)  NOT NULL,
    titre                     VARCHAR(190) NOT NULL,
    message                    TEXT NOT NULL,
    lue                          TINYINT(1) NOT NULL DEFAULT 0,
    created_at                    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_notif_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_notif_user (user_code, lue),
    INDEX idx_notif_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed : catalogue des permissions (gpotb005) — matrice V1 (Président/Secrétaire/Trésorier/Membre)
INSERT INTO permissions (permission_code, nom) VALUES
    ('gerer_membres', 'Gérer les membres'),
    ('valider_adherent', 'Valider un adhérent'),
    ('gerer_roles', 'Gérer les rôles'),
    ('creer_cotisation', 'Créer une cotisation'),
    ('voir_finances', 'Voir les finances'),
    ('gerer_projets', 'Gérer les projets'),
    ('gerer_documents', 'Gérer les documents'),
    ('envoyer_notification', 'Envoyer une notification'),
    ('voir_audit', "Voir l'audit"),
    ('gerer_organisation', "Modifier les informations de l'organisation"),
    ('voir_membres', 'Voir la liste des membres'),
    ('valider_paiement', 'Valider un paiement'),
    ('voir_profil', 'Voir son profil'),
    ('payer_cotisation', 'Payer une cotisation'),
    ('voir_documents', 'Voir les documents'),
    ('voir_projets', 'Voir les projets'),
    ('voir_mes_audit', 'Voir son propre historique');

-- Seed : compte Super Admin
-- Email  : superadmin@monasso.test
-- Mot de passe : SuperAdmin@2026
INSERT INTO users (user_code, pays_code, nom, email, password_hash, type_compte, sexe, statut) VALUES
    ('USR-CIV-00001', 'CIV', 'Super Administrateur', 'superadmin@monasso.test',
     '$2y$10$vYmglQIWS.o3PZLhVLkDCOTmdVsBSGU9Ta2E0wWWN9.prM3vDhARS',
     'SUPER_ADMIN', 'M', 'ACT');
