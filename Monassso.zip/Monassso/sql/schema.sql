
-- "C:\xampp\mysql\bin\mysql.exe" -u root < sql/schema.sql

CREATE DATABASE IF NOT EXISTS monasso CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE monasso;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS mails_envoyes;
DROP TABLE IF EXISTS depenses;
DROP TABLE IF EXISTS adhesion_paiements;
DROP TABLE IF EXISTS cartes_adherents;
DROP TABLE IF EXISTS presences;
DROP TABLE IF EXISTS evenement_confirmations;
DROP TABLE IF EXISTS evenements;
DROP TABLE IF EXISTS besoin_documents;
DROP TABLE IF EXISTS dons;
DROP TABLE IF EXISTS besoins;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS abonnements_orga;
DROP TABLE IF EXISTS paiements_cotisations;
DROP TABLE IF EXISTS cotisations;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS organisation_users;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS organisations;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS categories_depenses;
DROP TABLE IF EXISTS types_besoin;
DROP TABLE IF EXISTS devises;
DROP TABLE IF EXISTS moyens_paiement;
DROP TABLE IF EXISTS pays;
DROP TABLE IF EXISTS metiers;
DROP TABLE IF EXISTS types_organisation;
DROP TABLE IF EXISTS plans_abonnement;
DROP TABLE IF EXISTS modes_presence;
DROP TABLE IF EXISTS statuts_mail;
DROP TABLE IF EXISTS statuts_adhesion_paiement;
DROP TABLE IF EXISTS statuts_carte;
DROP TABLE IF EXISTS statuts_evenement;
DROP TABLE IF EXISTS statuts_don;
DROP TABLE IF EXISTS statuts_besoin;
DROP TABLE IF EXISTS statuts_abonnement;
DROP TABLE IF EXISTS statuts_paiement_cotisation;
DROP TABLE IF EXISTS statuts_cotisation;
DROP TABLE IF EXISTS statuts_adhesion;
DROP TABLE IF EXISTS statuts_abonnement_organisation;
DROP TABLE IF EXISTS statuts_validation_organisation;
DROP TABLE IF EXISTS statuts_utilisateur;
DROP TABLE IF EXISTS types_document_besoin;
DROP TABLE IF EXISTS categories_document;
DROP TABLE IF EXISTS types_notification;
SET FOREIGN_KEY_CHECKS = 1;

-- pays : liste des pays gérés par la plateforme (référence pour users.pays_code / organisations.pays_code)
CREATE TABLE pays (
    pays_code    VARCHAR(3)   NOT NULL PRIMARY KEY,
    nom          VARCHAR(100) NOT NULL,
    drapeau      VARCHAR(10)  NOT NULL,
    indicatif    VARCHAR(6)   NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO pays (pays_code, nom, drapeau, indicatif) VALUES
    ('CIV', "Côte d'Ivoire", '🇨🇮', '+225'),
    ('MLI', 'Mali', '🇲🇱', '+223'),
    ('BEN', 'Bénin', '🇧🇯', '+229'),
    ('NER', 'Niger', '🇳🇪', '+227'),
    ('MDG', 'Madagascar', '🇲🇬', '+261'),
    ('BFA', 'Burkina Faso', '🇧🇫', '+226');

-- moyens_paiement : moyens de paiement proposés pour toute cotisation, adhésion ou don
CREATE TABLE moyens_paiement (
    moyen_paiement_code VARCHAR(30)  NOT NULL PRIMARY KEY,
    nom                  VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO moyens_paiement (moyen_paiement_code, nom) VALUES
    ('ORANGE_MONEY', 'Orange Money'),
    ('VISA', 'Carte Visa'),
    ('ESPECES', 'Espèces');

-- devises : devises utilisables pour une cotisation
CREATE TABLE devises (
    devise_code   VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom           VARCHAR(100) NOT NULL,
    symbole       VARCHAR(10)  NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO devises (devise_code, nom, symbole) VALUES
    ('XOF', 'Franc CFA (UEMOA)', 'CFA'),
    ('MGA', 'Ariary malgache', 'Ar'),
    ('EUR', 'Euro', '€'),
    ('USD', 'Dollar américain', '$');

-- types_besoin : nature d'un appel à financement publié par une organisation
CREATE TABLE types_besoin (
    type_besoin_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom              VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO types_besoin (type_besoin_code, nom) VALUES
    ('FINANCIER', 'Financier'),
    ('MATERIEL', 'Matériel'),
    ('SERVICE', 'Service');

-- categories_depenses : catégorisation des dépenses enregistrées par une organisation
CREATE TABLE categories_depenses (
    categorie_depense_code VARCHAR(40)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categories_depenses (categorie_depense_code, nom) VALUES
    ('LOYER', 'Loyer'),
    ('MATERIEL', 'Matériel'),
    ('EVENEMENT', 'Événement'),
    ('COMMUNICATION', 'Communication'),
    ('TRANSPORT', 'Transport'),
    ('ADMINISTRATIF', 'Administratif'),
    ('AUTRE', 'Autre');

-- types_notification : nature d'une notification in-app ou d'un email automatique (partagée par
-- notifications.type_code et mails_envoyes.type_code)
CREATE TABLE types_notification (
    type_notification_code VARCHAR(50)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO types_notification (type_notification_code, nom) VALUES
    ('MEMBER_ACCEPTED_PENDING_PAYMENT', "Adhésion acceptée, en attente de paiement"),
    ('MEMBER_ACCEPTED', 'Adhésion acceptée'),
    ('MEMBER_REFUSED', 'Adhésion refusée'),
    ('BROADCAST', 'Diffusion générale'),
    ('COTISATION_PAIEMENT_REQUIS', 'Paiement de cotisation requis'),
    ('RELANCE_COTISATION', 'Relance de cotisation'),
    ('BESOIN_FINANCE', 'Besoin entièrement financé'),
    ('NOUVEL_EVENEMENT', 'Nouvel événement'),
    ('ADHESION_PAYEE', 'Adhésion payée'),
    ('ADHESION_ACCEPTEE', 'Adhésion acceptée'),
    ('ADHESION_RAPPEL', "Rappel de paiement d'adhésion"),
    ('ADHESION_REFUSEE', 'Adhésion refusée'),
    ('ORGANISATION_CREEE', 'Nouvelle organisation à valider'),
    ('DEMANDE_ADHESION', 'Nouvelle demande d\'adhésion'),
    ('IDENTIFIANTS_COMPTE', 'Identifiants de connexion envoyés par e-mail'),
    ('ROLE_MODIFIE', 'Rôle modifié dans une organisation');

-- categories_document : nature d'un document déposé par une organisation
CREATE TABLE categories_document (
    categorie_document_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom                       VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO categories_document (categorie_document_code, nom) VALUES
    ('PV', 'Procès-verbal'),
    ('STATUTS', 'Statuts'),
    ('RAPPORT', 'Rapport'),
    ('AUTRE', 'Autre');

-- types_document_besoin : nature d'une pièce jointe à un besoin (devis/facture/photo)
CREATE TABLE types_document_besoin (
    type_document_besoin_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom                         VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO types_document_besoin (type_document_besoin_code, nom) VALUES
    ('DEVIS', 'Devis'),
    ('PHOTO', 'Photo'),
    ('FACTURE', 'Facture');

-- statuts_utilisateur : cycle de vie d'un compte utilisateur
CREATE TABLE statuts_utilisateur (
    statut_utilisateur_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                      VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_utilisateur (statut_utilisateur_code, nom) VALUES
    ('ACT', 'Actif'),
    ('SUS', 'Suspendu'),
    ('SUP', 'Supprimé');

-- statuts_validation_organisation : validation d'une organisation par le super admin
CREATE TABLE statuts_validation_organisation (
    statut_validation_organisation_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                                  VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_validation_organisation (statut_validation_organisation_code, nom) VALUES
    ('ATT', 'En attente'),
    ('VAL', 'Validée'),
    ('REF', 'Refusée');

-- statuts_abonnement_organisation : état d'abonnement courant affiché sur l'organisation
CREATE TABLE statuts_abonnement_organisation (
    statut_abonnement_organisation_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                                  VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_abonnement_organisation (statut_abonnement_organisation_code, nom) VALUES
    ('EXP', 'Expiré'),
    ('ACT', 'Actif'),
    ('SUS', 'Suspendu');

-- statuts_adhesion : statut d'un membre au sein d'une organisation
CREATE TABLE statuts_adhesion (
    statut_adhesion_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                   VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_adhesion (statut_adhesion_code, nom) VALUES
    ('ATT', 'En attente de validation'),
    ('PAI', 'En attente de paiement'),
    ('ACT', 'Actif'),
    ('SUS', 'Suspendu'),
    ('REF', 'Refusé');

-- statuts_cotisation : cycle de vie d'une cotisation créée par une organisation
CREATE TABLE statuts_cotisation (
    statut_cotisation_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_cotisation (statut_cotisation_code, nom) VALUES
    ('ACT', 'Active'),
    ('CLO', 'Clôturée');

-- statuts_paiement_cotisation : statut du paiement d'une cotisation par un membre
CREATE TABLE statuts_paiement_cotisation (
    statut_paiement_cotisation_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                              VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_paiement_cotisation (statut_paiement_cotisation_code, nom) VALUES
    ('DU', 'Dû'),
    ('PAY', 'Payé'),
    ('ANN', 'Annulé'),
    ('EXO', 'Exonéré');

-- statuts_abonnement : statut d'une période d'abonnement de l'organisation à la plateforme
CREATE TABLE statuts_abonnement (
    statut_abonnement_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_abonnement (statut_abonnement_code, nom) VALUES
    ('ACT', 'Actif'),
    ('EXP', 'Expiré'),
    ('SUS', 'Suspendu');

-- statuts_besoin : cycle de vie d'un appel à financement
CREATE TABLE statuts_besoin (
    statut_besoin_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                 VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_besoin (statut_besoin_code, nom) VALUES
    ('ACTIF', 'Actif'),
    ('FINANCE', 'Financé'),
    ('FERME', 'Fermé');

-- statuts_don : statut du paiement d'un don reçu sur un besoin
CREATE TABLE statuts_don (
    statut_don_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom              VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_don (statut_don_code, nom) VALUES
    ('PAYE', 'Payé'),
    ('EN_ATTENTE', 'En attente');

-- statuts_evenement : cycle de vie d'un événement organisé par une organisation
CREATE TABLE statuts_evenement (
    statut_evenement_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_evenement (statut_evenement_code, nom) VALUES
    ('PLANIFIE', 'Planifié'),
    ('TERMINE', 'Terminé'),
    ('ANNULE', 'Annulé');

-- statuts_carte : état d'une carte adhérent
CREATE TABLE statuts_carte (
    statut_carte_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_carte (statut_carte_code, nom) VALUES
    ('ACTIF', 'Active'),
    ('EXPIRE', 'Expirée'),
    ('BLOQUEE', 'Bloquée');

-- statuts_adhesion_paiement : statut du droit d'adhésion à payer une fois par un membre
CREATE TABLE statuts_adhesion_paiement (
    statut_adhesion_paiement_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom                            VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_adhesion_paiement (statut_adhesion_paiement_code, nom) VALUES
    ('EN_ATTENTE', 'En attente'),
    ('PAYE', 'Payé');

-- statuts_mail : résultat d'envoi d'un email automatique
CREATE TABLE statuts_mail (
    statut_mail_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom               VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO statuts_mail (statut_mail_code, nom) VALUES
    ('ENVOYE', 'Envoyé'),
    ('ECHEC', 'Échec');

-- modes_presence : moyen par lequel une présence à un événement a été enregistrée
CREATE TABLE modes_presence (
    mode_presence_code VARCHAR(10)  NOT NULL PRIMARY KEY,
    nom                  VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO modes_presence (mode_presence_code, nom) VALUES
    ('QR', 'Scan QR'),
    ('MANUEL', 'Pointage manuel'),
    ('CARTE', 'Carte adhérent');

-- metiers : liste fermée de métiers/situations proposée à l'inscription (users.metier)
CREATE TABLE metiers (
    metier_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom          VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO metiers (metier_code, nom) VALUES
    ('ETUDIANT', 'Étudiant(e)'),
    ('FONCTIONNAIRE', 'Fonctionnaire'),
    ('SALARIE_PRIVE', 'Salarié(e) du privé'),
    ('COMMERCANT', 'Commerçant(e)'),
    ('ENTREPRENEUR', 'Entrepreneur / Indépendant'),
    ('AGRICULTEUR', 'Agriculteur / Éleveur'),
    ('ARTISAN', 'Artisan'),
    ('SANS_EMPLOI', 'Sans emploi'),
    ('RETRAITE', 'Retraité(e)'),
    ('AUTRE', 'Autre');

-- types_organisation : nature juridique d'une organisation (association, ONG, mutuelle)
CREATE TABLE types_organisation (
    type_organisation_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom                     VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO types_organisation (type_organisation_code, nom) VALUES
    ('ASSOCIATION', 'Association'),
    ('ONG', 'ONG'),
    ('MUTUELLE', 'Mutuelle');

-- plans_abonnement : périodicités proposées pour l'abonnement plateforme d'une organisation
-- (le Super Admin choisit un plan à l'encaissement ; le montant suggéré reste modifiable)
CREATE TABLE plans_abonnement (
    plan_abonnement_code VARCHAR(20)  NOT NULL PRIMARY KEY,
    nom                   VARCHAR(100) NOT NULL,
    duree_jours           INT UNSIGNED NOT NULL,
    montant_suggere        DECIMAL(14,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO plans_abonnement (plan_abonnement_code, nom, duree_jours, montant_suggere) VALUES
    ('HEBDOMADAIRE', 'Hebdomadaire', 7, 2000),
    ('MENSUEL', 'Mensuel', 30, 5000),
    ('ANNUEL', 'Annuel', 365, 50000);

-- gpotb001
CREATE TABLE users (
    user_code           VARCHAR(20)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(150) NOT NULL,
    email               VARCHAR(190) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    type_compte         ENUM('SUPER_ADMIN', 'ADMIN_ORGA', 'MEMBRE') NOT NULL,
    sexe                ENUM('M', 'F') NOT NULL,
    date_naissance      DATE NULL,
    lieu_naissance      VARCHAR(150) NULL,
    metier              VARCHAR(20) NULL,
    photo_chemin        VARCHAR(500) NULL,
    statut              VARCHAR(10) NOT NULL DEFAULT 'ACT',
    failed_login_count  INT UNSIGNED NOT NULL DEFAULT 0,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email),
    CONSTRAINT fk_user_pays FOREIGN KEY (pays_code) REFERENCES pays (pays_code),
    CONSTRAINT fk_user_statut FOREIGN KEY (statut) REFERENCES statuts_utilisateur (statut_utilisateur_code),
    CONSTRAINT fk_user_metier FOREIGN KEY (metier) REFERENCES metiers (metier_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb002
CREATE TABLE organisations (
    organisation_code   VARCHAR(40)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(190) NOT NULL,
    type_organisation   VARCHAR(20) NOT NULL DEFAULT 'ASSOCIATION',
    email               VARCHAR(150) NULL,
    telephone           VARCHAR(30)  NULL,
    adresse             TEXT NULL,
    logo_chemin         VARCHAR(500) NULL,
    montant_adhesion    DECIMAL(14,2) NULL,
    reglement_interieur_chemin VARCHAR(500) NULL,
    reglement_interieur_nom    VARCHAR(255) NULL,
    admin_user_code     VARCHAR(20)  NOT NULL,
    statut_validation   VARCHAR(10) NOT NULL DEFAULT 'ATT',
    statut_abonnement   VARCHAR(10) NOT NULL DEFAULT 'EXP',
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_org_admin FOREIGN KEY (admin_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_org_pays FOREIGN KEY (pays_code) REFERENCES pays (pays_code),
    CONSTRAINT fk_org_statut_validation FOREIGN KEY (statut_validation) REFERENCES statuts_validation_organisation (statut_validation_organisation_code),
    CONSTRAINT fk_org_statut_abonnement FOREIGN KEY (statut_abonnement) REFERENCES statuts_abonnement_organisation (statut_abonnement_organisation_code),
    CONSTRAINT fk_org_type FOREIGN KEY (type_organisation) REFERENCES types_organisation (type_organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb004
CREATE TABLE roles (
    role_code           VARCHAR(80)  NOT NULL PRIMARY KEY,
    organisation_code   VARCHAR(40)  NOT NULL,
    nom_role             VARCHAR(100) NOT NULL,
    parent_role_code     VARCHAR(80)  NULL,
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_role_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_role_parent FOREIGN KEY (parent_role_code) REFERENCES roles (role_code),
    UNIQUE KEY uq_role_org_nom (organisation_code, nom_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb005
CREATE TABLE permissions (
    permission_code      VARCHAR(50)  NOT NULL PRIMARY KEY,
    nom                  VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb003 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE organisation_users (
    user_code           VARCHAR(20)  NOT NULL,
    organisation_code   VARCHAR(40)  NOT NULL,
    role_code           VARCHAR(80)  NULL,
    numero_adherent     VARCHAR(100) NULL,
    statut              VARCHAR(10) NOT NULL DEFAULT 'ATT',
    motif_refus         TEXT NULL,
    date_adhesion       DATETIME NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_code, organisation_code),
    CONSTRAINT fk_ou_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_ou_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_ou_role FOREIGN KEY (role_code) REFERENCES roles (role_code),
    CONSTRAINT fk_ou_statut FOREIGN KEY (statut) REFERENCES statuts_adhesion (statut_adhesion_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb006 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE role_permissions (
    role_code           VARCHAR(80) NOT NULL,
    permission_code      VARCHAR(50) NOT NULL,
    PRIMARY KEY (role_code, permission_code),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_code) REFERENCES roles (role_code),
    CONSTRAINT fk_rp_perm FOREIGN KEY (permission_code) REFERENCES permissions (permission_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb007
CREATE TABLE cotisations (
    cotisation_code      VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code    VARCHAR(40)  NOT NULL,
    libelle              VARCHAR(190) NOT NULL,
    annee                SMALLINT UNSIGNED NOT NULL,
    montant              DECIMAL(14,2) NOT NULL,
    devise               VARCHAR(10)  NOT NULL DEFAULT 'XOF',
    statut               VARCHAR(10) NOT NULL DEFAULT 'ACT',
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coti_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_coti_devise FOREIGN KEY (devise) REFERENCES devises (devise_code),
    CONSTRAINT fk_coti_statut FOREIGN KEY (statut) REFERENCES statuts_cotisation (statut_cotisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb008
CREATE TABLE paiements_cotisations (
    paiement_code        VARCHAR(30) NOT NULL PRIMARY KEY,
    cotisation_code       VARCHAR(30) NOT NULL,
    user_code             VARCHAR(20) NOT NULL,
    montant                DECIMAL(14,2) NOT NULL,
    statut_paiement        VARCHAR(10) NOT NULL DEFAULT 'DU',
    mode_paiement           VARCHAR(30) NOT NULL DEFAULT 'ORANGE_MONEY',
    date_paiement            DATETIME NULL,
    created_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_paiement_coti_user (cotisation_code, user_code),
    CONSTRAINT fk_pay_coti FOREIGN KEY (cotisation_code) REFERENCES cotisations (cotisation_code),
    CONSTRAINT fk_pay_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_pay_mode FOREIGN KEY (mode_paiement) REFERENCES moyens_paiement (moyen_paiement_code),
    CONSTRAINT fk_pay_statut FOREIGN KEY (statut_paiement) REFERENCES statuts_paiement_cotisation (statut_paiement_cotisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb009
CREATE TABLE abonnements_orga (
    abonnement_code       VARCHAR(30) NOT NULL PRIMARY KEY,
    organisation_code      VARCHAR(40) NOT NULL,
    statut                  VARCHAR(10) NOT NULL DEFAULT 'ACT',
    montant                  DECIMAL(14,2) NOT NULL DEFAULT 0,
    date_debut                DATE NOT NULL,
    date_fin                   DATE NOT NULL,
    created_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_abo_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_abo_statut FOREIGN KEY (statut) REFERENCES statuts_abonnement (statut_abonnement_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb010
CREATE TABLE audit_logs (
    audit_code             VARCHAR(30) NOT NULL PRIMARY KEY,
    actor_user_code         VARCHAR(20) NULL,
    organisation_code        VARCHAR(40) NULL,
    action_code                VARCHAR(50) NOT NULL,
    target_code                  VARCHAR(60) NULL,
    details_json                  JSON NULL,
    ip                              VARCHAR(45) NULL,
    created_at                       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_code) REFERENCES users (user_code) ON DELETE SET NULL,
    CONSTRAINT fk_audit_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_audit_actor (actor_user_code),
    INDEX idx_audit_org (organisation_code),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- notifications : boîte de notifications in-app par utilisateur (ex. adhésion acceptée/refusée)
CREATE TABLE notifications (
    notification_code   VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code            VARCHAR(20)  NOT NULL,
    organisation_code     VARCHAR(40)  NULL,
    type_code               VARCHAR(50)  NOT NULL,
    titre                     VARCHAR(190) NOT NULL,
    message                    TEXT NOT NULL,
    lien                         VARCHAR(500) NULL,
    lue                          TINYINT(1) NOT NULL DEFAULT 0,
    created_at                    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_notif_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    CONSTRAINT fk_notif_type FOREIGN KEY (type_code) REFERENCES types_notification (type_notification_code),
    INDEX idx_notif_user (user_code, lue),
    INDEX idx_notif_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- documents : PV, statuts, rapports uploadés par une organisation (fichiers sous uploads/documents/)
CREATE TABLE documents (
    document_code          VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code       VARCHAR(40)  NOT NULL,
    uploaded_by_user_code    VARCHAR(20)  NOT NULL,
    categorie                  VARCHAR(20) NOT NULL DEFAULT 'AUTRE',
    nom_original                 VARCHAR(255) NOT NULL,
    chemin_fichier                 VARCHAR(500) NOT NULL,
    taille_octets                    INT UNSIGNED NOT NULL,
    type_mime                          VARCHAR(100) NOT NULL,
    visibilite                            ENUM('PUBLIC', 'PRIVE') NOT NULL DEFAULT 'PUBLIC',
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_doc_user FOREIGN KEY (uploaded_by_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_doc_categorie FOREIGN KEY (categorie) REFERENCES categories_document (categorie_document_code),
    INDEX idx_doc_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- besoins : appels à financement/dons publiés par une organisation (financement participatif)
CREATE TABLE besoins (
    besoin_code             VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code        VARCHAR(40)  NOT NULL,
    cree_par_user_code         VARCHAR(20)  NOT NULL,
    titre                         VARCHAR(190) NOT NULL,
    description                     TEXT NOT NULL,
    type_besoin                       VARCHAR(20) NOT NULL DEFAULT 'FINANCIER',
    montant_recherche                   DECIMAL(14,2) NOT NULL,
    montant_collecte                      DECIMAL(14,2) NOT NULL DEFAULT 0,
    statut                                   VARCHAR(10) NOT NULL DEFAULT 'ACTIF',
    date_fin                                    DATE NULL,
    photo_chemin                                   VARCHAR(500) NULL,
    created_at                                        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_besoin_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_besoin_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_besoin_type FOREIGN KEY (type_besoin) REFERENCES types_besoin (type_besoin_code),
    CONSTRAINT fk_besoin_statut FOREIGN KEY (statut) REFERENCES statuts_besoin (statut_besoin_code),
    INDEX idx_besoin_org (organisation_code),
    INDEX idx_besoin_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- dons : dons publics reçus sur un besoin (pas de compte requis pour donner ; V1 = paiement simulé)
CREATE TABLE dons (
    don_code            VARCHAR(30)  NOT NULL PRIMARY KEY,
    besoin_code          VARCHAR(30)  NOT NULL,
    donateur_nom           VARCHAR(150) NOT NULL,
    donateur_email            VARCHAR(190) NULL,
    montant                     DECIMAL(14,2) NOT NULL,
    mode_paiement                 VARCHAR(30) NOT NULL DEFAULT 'ORANGE_MONEY',
    statut                          VARCHAR(20) NOT NULL DEFAULT 'PAYE',
    anonyme                            TINYINT(1) NOT NULL DEFAULT 0,
    message                              TEXT NULL,
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_don_besoin FOREIGN KEY (besoin_code) REFERENCES besoins (besoin_code),
    CONSTRAINT fk_don_mode FOREIGN KEY (mode_paiement) REFERENCES moyens_paiement (moyen_paiement_code),
    CONSTRAINT fk_don_statut FOREIGN KEY (statut) REFERENCES statuts_don (statut_don_code),
    INDEX idx_don_besoin (besoin_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- besoin_documents : preuves (devis/factures/photos) attachées à un besoin
CREATE TABLE besoin_documents (
    besoin_document_code  VARCHAR(30)  NOT NULL PRIMARY KEY,
    besoin_code            VARCHAR(30)  NOT NULL,
    type                      VARCHAR(20) NOT NULL DEFAULT 'PHOTO',
    nom_original                VARCHAR(255) NOT NULL,
    chemin_fichier                 VARCHAR(500) NOT NULL,
    taille_octets                    INT UNSIGNED NOT NULL,
    type_mime                          VARCHAR(100) NOT NULL,
    uploaded_by_user_code                 VARCHAR(20) NOT NULL,
    created_at                               DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_besoindoc_besoin FOREIGN KEY (besoin_code) REFERENCES besoins (besoin_code),
    CONSTRAINT fk_besoindoc_user FOREIGN KEY (uploaded_by_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_besoindoc_type FOREIGN KEY (type) REFERENCES types_document_besoin (type_document_besoin_code),
    INDEX idx_besoindoc_besoin (besoin_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- evenements : Assemblées générales et autres rencontres organisées par une organisation
CREATE TABLE evenements (
    evenement_code             VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code            VARCHAR(40)  NOT NULL,
    cree_par_user_code             VARCHAR(20)  NOT NULL,
    titre                             VARCHAR(190) NOT NULL,
    description                         TEXT NULL,
    lieu                                   VARCHAR(190) NULL,
    date_heure                               DATETIME NOT NULL,
    qr_token                                    VARCHAR(64) NULL,
    statut                                         VARCHAR(10) NOT NULL DEFAULT 'PLANIFIE',
    created_at                                        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_evt_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_evt_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_evt_statut FOREIGN KEY (statut) REFERENCES statuts_evenement (statut_evenement_code),
    INDEX idx_evt_org (organisation_code),
    INDEX idx_evt_statut (statut),
    UNIQUE KEY uq_evt_token (qr_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- evenement_confirmations : membres ayant cliqué "Je confirme ma présence" avant l'événement
CREATE TABLE evenement_confirmations (
    confirmation_code       VARCHAR(30) NOT NULL PRIMARY KEY,
    evenement_code            VARCHAR(30) NOT NULL,
    user_code                    VARCHAR(20) NOT NULL,
    created_at                      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_evtconf_evt FOREIGN KEY (evenement_code) REFERENCES evenements (evenement_code),
    CONSTRAINT fk_evtconf_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    UNIQUE KEY uq_evtconf_evt_user (evenement_code, user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- presences : feuille de présence réelle (scan QR le jour J, ou pointage manuel par le bureau)
CREATE TABLE presences (
    presence_code           VARCHAR(30) NOT NULL PRIMARY KEY,
    evenement_code            VARCHAR(30) NOT NULL,
    user_code                    VARCHAR(20) NOT NULL,
    heure_arrivee                   DATETIME NOT NULL,
    mode                                VARCHAR(10) NOT NULL DEFAULT 'QR',
    created_at                            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_presence_evt FOREIGN KEY (evenement_code) REFERENCES evenements (evenement_code),
    CONSTRAINT fk_presence_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_presence_mode FOREIGN KEY (mode) REFERENCES modes_presence (mode_presence_code),
    UNIQUE KEY uq_presence_evt_user (evenement_code, user_code),
    INDEX idx_presence_evt (evenement_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- cartes_adherents : carte de membre à jour de cotisation (une ligne par couple membre/organisation,
-- mise à jour à chaque émission plutôt que recréée)
CREATE TABLE cartes_adherents (
    carte_code              VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code                 VARCHAR(20)  NOT NULL,
    organisation_code           VARCHAR(40)  NOT NULL,
    qr_token                       VARCHAR(64)  NOT NULL,
    statut                            VARCHAR(10) NOT NULL DEFAULT 'EXPIRE',
    valide_jusqu_au                     DATE NULL,
    created_at                             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                                DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_carte_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_carte_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_carte_statut FOREIGN KEY (statut) REFERENCES statuts_carte (statut_carte_code),
    UNIQUE KEY uq_carte_user_org (user_code, organisation_code),
    UNIQUE KEY uq_carte_token (qr_token),
    INDEX idx_carte_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- adhesion_paiements : droit d'adhésion à payer une fois, après acceptation, avant de devenir membre actif
-- (organisations.montant_adhesion NULL/0 => pas de droit d'entrée, activation immédiate à l'acceptation)
CREATE TABLE adhesion_paiements (
    adhesion_paiement_code   VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code                  VARCHAR(20)  NOT NULL,
    organisation_code            VARCHAR(40)  NOT NULL,
    montant                        DECIMAL(14,2) NOT NULL,
    statut                            VARCHAR(20) NOT NULL DEFAULT 'EN_ATTENTE',
    mode_paiement                       VARCHAR(30) NULL,
    token                               VARCHAR(64) NOT NULL,
    date_paiement                         DATETIME NULL,
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_adhpay_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_adhpay_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_adhpay_mode FOREIGN KEY (mode_paiement) REFERENCES moyens_paiement (moyen_paiement_code),
    CONSTRAINT fk_adhpay_statut FOREIGN KEY (statut) REFERENCES statuts_adhesion_paiement (statut_adhesion_paiement_code),
    UNIQUE KEY uq_adhpay_user_org (user_code, organisation_code),
    UNIQUE KEY uq_adhpay_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- depenses : sorties d'argent enregistrées par l'organisation (loyer, événements, matériel...) —
-- alimente la trésorerie et le tableau de bord financier
CREATE TABLE depenses (
    depense_code            VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code         VARCHAR(40)  NOT NULL,
    cree_par_user_code          VARCHAR(20)  NOT NULL,
    libelle                        VARCHAR(190) NOT NULL,
    categorie                        VARCHAR(40) NULL,
    montant                             DECIMAL(14,2) NOT NULL,
    date_depense                           DATE NOT NULL,
    created_at                                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_depense_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_depense_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    CONSTRAINT fk_depense_categorie FOREIGN KEY (categorie) REFERENCES categories_depenses (categorie_depense_code),
    INDEX idx_depense_org (organisation_code),
    INDEX idx_depense_date (date_depense)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- mails_envoyes : journal des emails automatiques (accepté/refusé/adhésion payée/rappel) — sert aussi
-- de trace même une fois l'envoi SMTP réel branché
CREATE TABLE mails_envoyes (
    mail_code                 VARCHAR(30)  NOT NULL PRIMARY KEY,
    destinataire_email          VARCHAR(190) NOT NULL,
    destinataire_user_code        VARCHAR(20)  NULL,
    organisation_code               VARCHAR(40)  NULL,
    type_code                         VARCHAR(50)  NOT NULL,
    objet                                VARCHAR(255) NOT NULL,
    corps                                  TEXT NOT NULL,
    statut                                    VARCHAR(10) NOT NULL DEFAULT 'ENVOYE',
    erreur                                      TEXT NULL,
    created_at                                    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mail_user FOREIGN KEY (destinataire_user_code) REFERENCES users (user_code) ON DELETE SET NULL,
    CONSTRAINT fk_mail_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    CONSTRAINT fk_mail_type FOREIGN KEY (type_code) REFERENCES types_notification (type_notification_code),
    CONSTRAINT fk_mail_statut FOREIGN KEY (statut) REFERENCES statuts_mail (statut_mail_code),
    INDEX idx_mail_user (destinataire_user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed : catalogue des permissions — matrice V1 (Président/Secrétaire/Trésorier/Membre)
INSERT INTO permissions (permission_code, nom) VALUES
    ('gerer_membres', 'Gérer les membres'),
    ('valider_adherent', 'Valider un adhérent'),
    ('gerer_roles', 'Gérer les rôles'),
    ('creer_cotisation', 'Créer une cotisation'),
    ('voir_finances', 'Voir les finances'),
    ('gerer_projets', 'Gérer les projets'),
    ('gerer_documents', 'Gérer les documents'),
    ('envoyer_notification', 'Envoyer une notification'),
    ('voir_audit', "Voir l'audit"),
    ('gerer_organisation', "Modifier les informations de l'organisation"),
    ('voir_membres', 'Voir la liste des membres'),
    ('valider_paiement', 'Valider un paiement'),
    ('voir_profil', 'Voir son profil'),
    ('payer_cotisation', 'Payer une cotisation'),
    ('voir_documents', 'Voir les documents'),
    ('voir_projets', 'Voir les projets'),
    ('voir_mes_audit', 'Voir son propre historique'),
    ('gerer_besoins', 'Gérer les besoins et dons'),
    ('gerer_evenements', 'Gérer les événements'),
    ('voir_evenements', 'Voir les événements'),
    ('gerer_cartes', 'Gérer les cartes adhérents'),
    ('gerer_depenses', 'Gérer les dépenses');

-- Seed : compte Super Admin
-- Email  : superadmin@monasso.test
-- Mot de passe : SuperAdmin@2026
INSERT INTO users (user_code, pays_code, nom, email, password_hash, type_compte, sexe, statut) VALUES
    ('USR-CIV-00001', 'CIV', 'Super Administrateur', 'superadmin@monasso.test',
     '$2y$10$vYmglQIWS.o3PZLhVLkDCOTmdVsBSGU9Ta2E0wWWN9.prM3vDhARS',
     'SUPER_ADMIN', 'M', 'ACT');
