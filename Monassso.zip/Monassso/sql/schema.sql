-- ============================================================================
-- ATTENTION — NE JAMAIS RÉ-EXÉCUTER CE FICHIER SUR LA BASE `monasso` EN COURS
-- D'UTILISATION.
--
-- Ce script commence par DROP TABLE sur toutes les tables Monasso puis les
-- recrée VIDES (seul le Super Admin de départ est réinséminé). L'exécuter
-- sur une base qui contient déjà des données (organisations, membres,
-- cotisations...) les EFFACE DÉFINITIVEMENT, sans sauvegarde possible.
--
-- Ce fichier sert uniquement de RÉFÉRENCE/DOCUMENTATION de la structure
-- actuelle, et à installer le projet sur une base neuve et vide la toute
-- première fois. Pour faire évoluer la base `monasso` déjà en service,
-- on utilise des scripts séparés avec CREATE TABLE / ALTER TABLE ADD COLUMN
-- uniquement (jamais de DROP), appliqués manuellement.
-- ============================================================================
--
-- Monasso V1 — schéma MySQL/MariaDB
--
-- Historique : les commentaires "-- gpotbXXX" ci-dessous ne désignent PAS de
-- vraies tables — ce sont des annotations vers la toute première ébauche du
-- projet ("10 tables clés gpotb001 à gpotb010"). Ne pas confondre avec les
-- tables gpotb001-gpotb068 qui existent réellement dans la base `monasso` :
-- celles-ci viennent d'un projet antérieur sans rapport, à titre de référence
-- uniquement, et ne sont jamais créées ni modifiées par ce fichier.
--
-- Règles respectées : pas d'AUTO_INCREMENT, clé primaire = code métier (ou clé composite
-- de codes métier pour les deux tables de liaison pures), ENUM en libellés courts lisibles.
--
-- Import (uniquement sur une base neuve et vide) :
-- "C:\xampp\mysql\bin\mysql.exe" -u root < sql/schema.sql

CREATE DATABASE IF NOT EXISTS monasso CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE monasso;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS mails_envoyes;
DROP TABLE IF EXISTS depenses;
DROP TABLE IF EXISTS adhesion_paiements;
DROP TABLE IF EXISTS cartes_adherents;
DROP TABLE IF EXISTS presences;
DROP TABLE IF EXISTS evenement_confirmations;
DROP TABLE IF EXISTS evenements;
DROP TABLE IF EXISTS besoin_documents;
DROP TABLE IF EXISTS dons;
DROP TABLE IF EXISTS besoins;
DROP TABLE IF EXISTS documents;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS abonnements_orga;
DROP TABLE IF EXISTS paiements_cotisations;
DROP TABLE IF EXISTS cotisations;
DROP TABLE IF EXISTS role_permissions;
DROP TABLE IF EXISTS organisation_users;
DROP TABLE IF EXISTS permissions;
DROP TABLE IF EXISTS roles;
DROP TABLE IF EXISTS organisations;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- gpotb001
CREATE TABLE users (
    user_code           VARCHAR(20)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(150) NOT NULL,
    email               VARCHAR(190) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    type_compte         ENUM('SUPER_ADMIN', 'ADMIN_ORGA', 'MEMBRE') NOT NULL,
    sexe                ENUM('M', 'F') NOT NULL,
    photo_chemin        VARCHAR(500) NULL,
    statut              ENUM('ACT', 'SUS', 'SUP') NOT NULL DEFAULT 'ACT',
    failed_login_count  INT UNSIGNED NOT NULL DEFAULT 0,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb002
CREATE TABLE organisations (
    organisation_code   VARCHAR(40)  NOT NULL PRIMARY KEY,
    pays_code           VARCHAR(3)   NOT NULL,
    nom                 VARCHAR(190) NOT NULL,
    email               VARCHAR(150) NULL,
    telephone           VARCHAR(30)  NULL,
    adresse             TEXT NULL,
    logo_chemin         VARCHAR(500) NULL,
    montant_adhesion    DECIMAL(14,2) NULL,
    admin_user_code     VARCHAR(20)  NOT NULL,
    statut_validation   ENUM('ATT', 'VAL', 'REF') NOT NULL DEFAULT 'ATT',
    statut_abonnement   ENUM('EXP', 'ACT', 'SUS') NOT NULL DEFAULT 'EXP',
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_org_admin FOREIGN KEY (admin_user_code) REFERENCES users (user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb004
CREATE TABLE roles (
    role_code           VARCHAR(80)  NOT NULL PRIMARY KEY,
    organisation_code   VARCHAR(40)  NOT NULL,
    nom_role             VARCHAR(100) NOT NULL,
    parent_role_code     VARCHAR(80)  NULL,
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_role_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_role_parent FOREIGN KEY (parent_role_code) REFERENCES roles (role_code),
    UNIQUE KEY uq_role_org_nom (organisation_code, nom_role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb005
CREATE TABLE permissions (
    permission_code      VARCHAR(50)  NOT NULL PRIMARY KEY,
    nom                  VARCHAR(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb003 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE organisation_users (
    user_code           VARCHAR(20)  NOT NULL,
    organisation_code   VARCHAR(40)  NOT NULL,
    role_code           VARCHAR(80)  NULL,
    numero_adherent     VARCHAR(40)  NULL,
    statut              ENUM('ATT', 'PAI', 'ACT', 'SUS', 'REF') NOT NULL DEFAULT 'ATT',
    motif_refus         TEXT NULL,
    date_adhesion       DATETIME NULL,
    created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_code, organisation_code),
    CONSTRAINT fk_ou_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_ou_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_ou_role FOREIGN KEY (role_code) REFERENCES roles (role_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb006 (table de liaison pure -> clé composite, pas de colonne code dédiée)
CREATE TABLE role_permissions (
    role_code           VARCHAR(80) NOT NULL,
    permission_code      VARCHAR(50) NOT NULL,
    PRIMARY KEY (role_code, permission_code),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_code) REFERENCES roles (role_code),
    CONSTRAINT fk_rp_perm FOREIGN KEY (permission_code) REFERENCES permissions (permission_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb007
CREATE TABLE cotisations (
    cotisation_code      VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code    VARCHAR(40)  NOT NULL,
    libelle              VARCHAR(190) NOT NULL,
    annee                SMALLINT UNSIGNED NOT NULL,
    montant              DECIMAL(14,2) NOT NULL,
    devise               VARCHAR(10)  NOT NULL DEFAULT 'XOF',
    statut               ENUM('ACT', 'CLO') NOT NULL DEFAULT 'ACT',
    created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coti_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb008
CREATE TABLE paiements_cotisations (
    paiement_code        VARCHAR(30) NOT NULL PRIMARY KEY,
    cotisation_code       VARCHAR(30) NOT NULL,
    user_code             VARCHAR(20) NOT NULL,
    montant                DECIMAL(14,2) NOT NULL,
    statut_paiement        ENUM('DU', 'PAY', 'ANN', 'EXO') NOT NULL DEFAULT 'DU',
    mode_paiement           ENUM('CASH') NOT NULL DEFAULT 'CASH',
    date_paiement            DATETIME NULL,
    created_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_paiement_coti_user (cotisation_code, user_code),
    CONSTRAINT fk_pay_coti FOREIGN KEY (cotisation_code) REFERENCES cotisations (cotisation_code),
    CONSTRAINT fk_pay_user FOREIGN KEY (user_code) REFERENCES users (user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb009
CREATE TABLE abonnements_orga (
    abonnement_code       VARCHAR(30) NOT NULL PRIMARY KEY,
    organisation_code      VARCHAR(40) NOT NULL,
    statut                  ENUM('ACT', 'EXP', 'SUS') NOT NULL DEFAULT 'ACT',
    montant                  DECIMAL(14,2) NOT NULL DEFAULT 0,
    date_debut                DATE NOT NULL,
    date_fin                   DATE NOT NULL,
    created_at                  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_abo_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- gpotb010
CREATE TABLE audit_logs (
    audit_code             VARCHAR(30) NOT NULL PRIMARY KEY,
    actor_user_code         VARCHAR(20) NULL,
    organisation_code        VARCHAR(40) NULL,
    action_code                VARCHAR(50) NOT NULL,
    target_code                  VARCHAR(60) NULL,
    details_json                  JSON NULL,
    ip                              VARCHAR(45) NULL,
    created_at                       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_code) REFERENCES users (user_code) ON DELETE SET NULL,
    CONSTRAINT fk_audit_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_audit_actor (actor_user_code),
    INDEX idx_audit_org (organisation_code),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- notifications : boîte de notifications in-app par utilisateur (ex. adhésion acceptée/refusée)
CREATE TABLE notifications (
    notification_code   VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code            VARCHAR(20)  NOT NULL,
    organisation_code     VARCHAR(40)  NULL,
    type_code               VARCHAR(50)  NOT NULL,
    titre                     VARCHAR(190) NOT NULL,
    message                    TEXT NOT NULL,
    lien                         VARCHAR(500) NULL,
    lue                          TINYINT(1) NOT NULL DEFAULT 0,
    created_at                    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notif_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_notif_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_notif_user (user_code, lue),
    INDEX idx_notif_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- documents : PV, statuts, rapports uploadés par une organisation (fichiers sous uploads/documents/)
CREATE TABLE documents (
    document_code          VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code       VARCHAR(40)  NOT NULL,
    uploaded_by_user_code    VARCHAR(20)  NOT NULL,
    categorie                  ENUM('PV', 'STATUTS', 'RAPPORT', 'AUTRE') NOT NULL DEFAULT 'AUTRE',
    nom_original                 VARCHAR(255) NOT NULL,
    chemin_fichier                 VARCHAR(500) NOT NULL,
    taille_octets                    INT UNSIGNED NOT NULL,
    type_mime                          VARCHAR(100) NOT NULL,
    visibilite                            ENUM('PUBLIC', 'PRIVE') NOT NULL DEFAULT 'PUBLIC',
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doc_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_doc_user FOREIGN KEY (uploaded_by_user_code) REFERENCES users (user_code),
    INDEX idx_doc_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- besoins : appels à financement/dons publiés par une organisation (financement participatif)
CREATE TABLE besoins (
    besoin_code             VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code        VARCHAR(40)  NOT NULL,
    cree_par_user_code         VARCHAR(20)  NOT NULL,
    titre                         VARCHAR(190) NOT NULL,
    description                     TEXT NOT NULL,
    type_besoin                       ENUM('FINANCIER', 'MATERIEL', 'SERVICE') NOT NULL DEFAULT 'FINANCIER',
    montant_recherche                   DECIMAL(14,2) NOT NULL,
    montant_collecte                      DECIMAL(14,2) NOT NULL DEFAULT 0,
    statut                                   ENUM('ACTIF', 'FINANCE', 'FERME') NOT NULL DEFAULT 'ACTIF',
    date_fin                                    DATE NULL,
    photo_chemin                                   VARCHAR(500) NULL,
    created_at                                        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_besoin_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_besoin_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    INDEX idx_besoin_org (organisation_code),
    INDEX idx_besoin_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- dons : dons publics reçus sur un besoin (pas de compte requis pour donner ; V1 = paiement simulé)
CREATE TABLE dons (
    don_code            VARCHAR(30)  NOT NULL PRIMARY KEY,
    besoin_code          VARCHAR(30)  NOT NULL,
    donateur_nom           VARCHAR(150) NOT NULL,
    donateur_email            VARCHAR(190) NULL,
    montant                     DECIMAL(14,2) NOT NULL,
    mode_paiement                 ENUM('ORANGE_MONEY', 'VISA', 'ESPECES') NOT NULL DEFAULT 'ORANGE_MONEY',
    statut                          ENUM('PAYE', 'EN_ATTENTE') NOT NULL DEFAULT 'PAYE',
    anonyme                            TINYINT(1) NOT NULL DEFAULT 0,
    message                              TEXT NULL,
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_don_besoin FOREIGN KEY (besoin_code) REFERENCES besoins (besoin_code),
    INDEX idx_don_besoin (besoin_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- besoin_documents : preuves (devis/factures/photos) attachées à un besoin
CREATE TABLE besoin_documents (
    besoin_document_code  VARCHAR(30)  NOT NULL PRIMARY KEY,
    besoin_code            VARCHAR(30)  NOT NULL,
    type                      ENUM('DEVIS', 'PHOTO', 'FACTURE') NOT NULL DEFAULT 'PHOTO',
    nom_original                VARCHAR(255) NOT NULL,
    chemin_fichier                 VARCHAR(500) NOT NULL,
    taille_octets                    INT UNSIGNED NOT NULL,
    type_mime                          VARCHAR(100) NOT NULL,
    uploaded_by_user_code                 VARCHAR(20) NOT NULL,
    created_at                               DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_besoindoc_besoin FOREIGN KEY (besoin_code) REFERENCES besoins (besoin_code),
    CONSTRAINT fk_besoindoc_user FOREIGN KEY (uploaded_by_user_code) REFERENCES users (user_code),
    INDEX idx_besoindoc_besoin (besoin_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- evenements : Assemblées générales et autres rencontres organisées par une organisation
CREATE TABLE evenements (
    evenement_code             VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code            VARCHAR(40)  NOT NULL,
    cree_par_user_code             VARCHAR(20)  NOT NULL,
    titre                             VARCHAR(190) NOT NULL,
    description                         TEXT NULL,
    lieu                                   VARCHAR(190) NULL,
    date_heure                               DATETIME NOT NULL,
    qr_token                                    VARCHAR(64) NULL,
    statut                                         ENUM('PLANIFIE', 'TERMINE', 'ANNULE') NOT NULL DEFAULT 'PLANIFIE',
    created_at                                        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_evt_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_evt_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    INDEX idx_evt_org (organisation_code),
    INDEX idx_evt_statut (statut),
    UNIQUE KEY uq_evt_token (qr_token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- evenement_confirmations : membres ayant cliqué "Je confirme ma présence" avant l'événement
CREATE TABLE evenement_confirmations (
    confirmation_code       VARCHAR(30) NOT NULL PRIMARY KEY,
    evenement_code            VARCHAR(30) NOT NULL,
    user_code                    VARCHAR(20) NOT NULL,
    created_at                      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_evtconf_evt FOREIGN KEY (evenement_code) REFERENCES evenements (evenement_code),
    CONSTRAINT fk_evtconf_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    UNIQUE KEY uq_evtconf_evt_user (evenement_code, user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- presences : feuille de présence réelle (scan QR le jour J, ou pointage manuel par le bureau)
CREATE TABLE presences (
    presence_code           VARCHAR(30) NOT NULL PRIMARY KEY,
    evenement_code            VARCHAR(30) NOT NULL,
    user_code                    VARCHAR(20) NOT NULL,
    heure_arrivee                   DATETIME NOT NULL,
    mode                                ENUM('QR', 'MANUEL', 'CARTE') NOT NULL DEFAULT 'QR',
    created_at                            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_presence_evt FOREIGN KEY (evenement_code) REFERENCES evenements (evenement_code),
    CONSTRAINT fk_presence_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    UNIQUE KEY uq_presence_evt_user (evenement_code, user_code),
    INDEX idx_presence_evt (evenement_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- cartes_adherents : carte de membre à jour de cotisation (une ligne par couple membre/organisation,
-- mise à jour à chaque émission plutôt que recréée)
CREATE TABLE cartes_adherents (
    carte_code              VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code                 VARCHAR(20)  NOT NULL,
    organisation_code           VARCHAR(40)  NOT NULL,
    qr_token                       VARCHAR(64)  NOT NULL,
    statut                            ENUM('ACTIF', 'EXPIRE', 'BLOQUEE') NOT NULL DEFAULT 'EXPIRE',
    valide_jusqu_au                     DATE NULL,
    created_at                             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at                                DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_carte_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_carte_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    UNIQUE KEY uq_carte_user_org (user_code, organisation_code),
    UNIQUE KEY uq_carte_token (qr_token),
    INDEX idx_carte_org (organisation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- adhesion_paiements : droit d'adhésion à payer une fois, après acceptation, avant de devenir membre actif
-- (organisations.montant_adhesion NULL/0 => pas de droit d'entrée, activation immédiate à l'acceptation)
CREATE TABLE adhesion_paiements (
    adhesion_paiement_code   VARCHAR(30)  NOT NULL PRIMARY KEY,
    user_code                  VARCHAR(20)  NOT NULL,
    organisation_code            VARCHAR(40)  NOT NULL,
    montant                        DECIMAL(14,2) NOT NULL,
    statut                            ENUM('EN_ATTENTE', 'PAYE') NOT NULL DEFAULT 'EN_ATTENTE',
    token                               VARCHAR(64) NOT NULL,
    date_paiement                         DATETIME NULL,
    created_at                              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_adhpay_user FOREIGN KEY (user_code) REFERENCES users (user_code),
    CONSTRAINT fk_adhpay_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    UNIQUE KEY uq_adhpay_user_org (user_code, organisation_code),
    UNIQUE KEY uq_adhpay_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- depenses : sorties d'argent enregistrées par l'organisation (loyer, événements, matériel...) —
-- alimente la trésorerie et le tableau de bord financier
CREATE TABLE depenses (
    depense_code            VARCHAR(30)  NOT NULL PRIMARY KEY,
    organisation_code         VARCHAR(40)  NOT NULL,
    cree_par_user_code          VARCHAR(20)  NOT NULL,
    libelle                        VARCHAR(190) NOT NULL,
    categorie                        VARCHAR(100) NULL,
    montant                             DECIMAL(14,2) NOT NULL,
    date_depense                           DATE NOT NULL,
    created_at                                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_depense_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code),
    CONSTRAINT fk_depense_user FOREIGN KEY (cree_par_user_code) REFERENCES users (user_code),
    INDEX idx_depense_org (organisation_code),
    INDEX idx_depense_date (date_depense)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- mails_envoyes : journal des emails automatiques (accepté/refusé/adhésion payée/rappel) — sert aussi
-- de trace même une fois l'envoi SMTP réel branché
CREATE TABLE mails_envoyes (
    mail_code                 VARCHAR(30)  NOT NULL PRIMARY KEY,
    destinataire_email          VARCHAR(190) NOT NULL,
    destinataire_user_code        VARCHAR(20)  NULL,
    organisation_code               VARCHAR(40)  NULL,
    type_code                         VARCHAR(50)  NOT NULL,
    objet                                VARCHAR(255) NOT NULL,
    corps                                  TEXT NOT NULL,
    statut                                    ENUM('ENVOYE', 'ECHEC') NOT NULL DEFAULT 'ENVOYE',
    erreur                                      TEXT NULL,
    created_at                                    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mail_user FOREIGN KEY (destinataire_user_code) REFERENCES users (user_code) ON DELETE SET NULL,
    CONSTRAINT fk_mail_org FOREIGN KEY (organisation_code) REFERENCES organisations (organisation_code) ON DELETE SET NULL,
    INDEX idx_mail_user (destinataire_user_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed : catalogue des permissions — matrice V1 (Président/Secrétaire/Trésorier/Membre)
INSERT INTO permissions (permission_code, nom) VALUES
    ('gerer_membres', 'Gérer les membres'),
    ('valider_adherent', 'Valider un adhérent'),
    ('gerer_roles', 'Gérer les rôles'),
    ('creer_cotisation', 'Créer une cotisation'),
    ('voir_finances', 'Voir les finances'),
    ('gerer_projets', 'Gérer les projets'),
    ('gerer_documents', 'Gérer les documents'),
    ('envoyer_notification', 'Envoyer une notification'),
    ('voir_audit', "Voir l'audit"),
    ('gerer_organisation', "Modifier les informations de l'organisation"),
    ('voir_membres', 'Voir la liste des membres'),
    ('valider_paiement', 'Valider un paiement'),
    ('voir_profil', 'Voir son profil'),
    ('payer_cotisation', 'Payer une cotisation'),
    ('voir_documents', 'Voir les documents'),
    ('voir_projets', 'Voir les projets'),
    ('voir_mes_audit', 'Voir son propre historique'),
    ('gerer_besoins', 'Gérer les besoins et dons'),
    ('gerer_evenements', 'Gérer les événements'),
    ('voir_evenements', 'Voir les événements'),
    ('gerer_cartes', 'Gérer les cartes adhérents'),
    ('gerer_depenses', 'Gérer les dépenses');

-- Seed : compte Super Admin
-- Email  : superadmin@monasso.test
-- Mot de passe : SuperAdmin@2026
INSERT INTO users (user_code, pays_code, nom, email, password_hash, type_compte, sexe, statut) VALUES
    ('USR-CIV-00001', 'CIV', 'Super Administrateur', 'superadmin@monasso.test',
     '$2y$10$vYmglQIWS.o3PZLhVLkDCOTmdVsBSGU9Ta2E0wWWN9.prM3vDhARS',
     'SUPER_ADMIN', 'M', 'ACT');
