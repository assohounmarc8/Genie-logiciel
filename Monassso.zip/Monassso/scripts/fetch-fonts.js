#!/usr/bin/env node

/**
 * Outil de build DEV UNIQUEMENT — jamais exécuté en production.
 *
 * Télécharge les fichiers woff2 (sous-ensemble "latin", suffisant pour le français/anglais/malgache
 * de ce projet) de Manrope et Source Sans 3 depuis Google Fonts, les enregistre dans assets/fonts/,
 * puis régénère assets/css/fonts.css avec les règles @font-face correspondantes.
 *
 * Usage : npm run fetch-fonts
 * Ne nécessite aucune dépendance tierce (fetch/fs sont fournis nativement par Node >= 18).
 */

const fs = require('fs/promises');
const path = require('path');

const ROOT_DIR = path.join(__dirname, '..');
const FONTS_DIR = path.join(ROOT_DIR, 'assets', 'fonts');
const CSS_OUTPUT_PATH = path.join(ROOT_DIR, 'assets', 'css', 'fonts.css');

// User-Agent d'un navigateur récent : indispensable pour que l'API Google Fonts renvoie du woff2
// (sans cet en-tête, elle sert par défaut d'anciens formats compatibles IE9/EOT/TTF).
const MODERN_BROWSER_USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const FONT_FAMILIES = [
    { family: 'Manrope', slug: 'manrope', weights: [500, 700, 800] },
    { family: 'Source Sans 3', slug: 'source-sans-3', weights: [400, 500, 600, 700] },
];

function buildGoogleFontsCssUrl(families) {
    const familyParams = families
        .map((f) => `family=${encodeURIComponent(f.family)}:wght@${f.weights.join(';')}`)
        .join('&');
    return `https://fonts.googleapis.com/css2?${familyParams}&display=swap`;
}

/**
 * Google Fonts renvoie un bloc @font-face par (famille, poids, sous-ensemble linguistique). On ne
 * garde que le sous-ensemble "latin", repérable de façon fiable par une unicode-range qui commence
 * par U+0000-00FF (les autres sous-ensembles — cyrillic, greek, vietnamese... — commencent ailleurs).
 */
function parseLatinFontFaces(cssText) {
    const blocks = cssText.split('@font-face').slice(1);
    const faces = [];

    for (const block of blocks) {
        const familyMatch = block.match(/font-family:\s*'([^']+)'/);
        const weightMatch = block.match(/font-weight:\s*(\d+)/);
        const urlMatch = block.match(/url\((https:\/\/fonts\.gstatic\.com[^)]+\.woff2)\)\s*format\('woff2'\)/);
        const rangeMatch = block.match(/unicode-range:\s*([^;]+);/);

        if (!familyMatch || !weightMatch || !urlMatch || !rangeMatch) {
            continue;
        }
        if (!rangeMatch[1].trim().startsWith('U+0000-00FF')) {
            continue;
        }

        faces.push({
            family: familyMatch[1],
            weight: Number(weightMatch[1]),
            url: urlMatch[1],
        });
    }

    return faces;
}

async function downloadFile(url, destPath) {
    const response = await fetch(url, { headers: { 'User-Agent': MODERN_BROWSER_USER_AGENT } });
    if (!response.ok) {
        throw new Error(`Échec du téléchargement de ${url} : HTTP ${response.status}`);
    }
    const buffer = Buffer.from(await response.arrayBuffer());
    await fs.writeFile(destPath, buffer);
}

function fontFaceCssRule(family, weight, fileName) {
    return `@font-face {
  font-family: '${family}';
  font-style: normal;
  font-weight: ${weight};
  font-display: swap;
  src: url('../fonts/${fileName}') format('woff2');
}`;
}

async function main() {
    await fs.mkdir(FONTS_DIR, { recursive: true });

    const cssUrl = buildGoogleFontsCssUrl(FONT_FAMILIES);
    console.log(`Récupération de la feuille de style Google Fonts…\n  ${cssUrl}`);
    const cssResponse = await fetch(cssUrl, { headers: { 'User-Agent': MODERN_BROWSER_USER_AGENT } });
    if (!cssResponse.ok) {
        throw new Error(`Échec de la requête Google Fonts CSS : HTTP ${cssResponse.status}`);
    }
    const cssText = await cssResponse.text();

    const latinFaces = parseLatinFontFaces(cssText);

    const expectedCount = FONT_FAMILIES.reduce((sum, f) => sum + f.weights.length, 0);
    if (latinFaces.length !== expectedCount) {
        throw new Error(
            `Attendu ${expectedCount} fichiers (sous-ensemble latin), ${latinFaces.length} trouvés. ` +
            'Google a peut-être changé le format de sa réponse CSS — vérifier scripts/fetch-fonts.js.'
        );
    }

    // Manrope et Source Sans 3 sont des polices variables chez Google Fonts : pour un navigateur
    // récent, l'API renvoie la MÊME URL de fichier pour tous les poids d'une famille (un seul
    // fichier woff2 couvre tout l'axe de graisse). On déduplique donc par URL pour ne télécharger
    // et stocker qu'un seul fichier physique par famille, référencé par plusieurs règles @font-face.
    const urlToFileName = new Map();
    for (const face of latinFaces) {
        if (!urlToFileName.has(face.url)) {
            const spec = FONT_FAMILIES.find((f) => f.family === face.family);
            const sameUrlCount = latinFaces.filter((f) => f.url === face.url).length;
            const fileName = sameUrlCount > 1
                ? `${spec.slug}-variable.woff2`
                : `${spec.slug}-${face.weight}.woff2`;
            urlToFileName.set(face.url, fileName);
        }
    }

    for (const [url, fileName] of urlToFileName) {
        const destPath = path.join(FONTS_DIR, fileName);
        console.log(`Téléchargement -> assets/fonts/${fileName}`);
        await downloadFile(url, destPath);
    }

    const cssRules = latinFaces.map((face) =>
        fontFaceCssRule(face.family, face.weight, urlToFileName.get(face.url))
    );

    const header =
        '/* Généré par scripts/fetch-fonts.js (npm run fetch-fonts) — ne pas éditer à la main. */\n' +
        '/* Fichiers servis localement depuis assets/fonts/, aucune dépendance réseau en production. */\n\n';
    await fs.writeFile(CSS_OUTPUT_PATH, header + cssRules.join('\n\n') + '\n');

    console.log(`\nOK — ${urlToFileName.size} fichier(s) de police écrits dans assets/fonts/`);
    console.log(`OK — assets/css/fonts.css régénéré (${cssRules.length} règles @font-face)`);
}

main().catch((err) => {
    console.error(err.message);
    process.exitCode = 1;
});
