# Monasso V1

Plateforme de gestion d'associations et mutuelles multi-pays (Côte d'Ivoire, Mali, Bénin, Niger,
Madagascar, Burkina Faso). V1 : PHP MVC natif (sans framework, sans Composer/Node.js) + MySQL/MariaDB
réel, construit à partir du cahier des charges "Workflow GLO Monasso V1 + Audit" (3 acteurs, 5 flux
métier). Le socle initial avait 10 tables à clés métier ; d'autres tables (ex. `notifications`)
s'ajoutent au fil des besoins, sans limite de nombre imposée.

Interface disponible en **français, anglais et malgache** (sélecteur en haut de chaque page).

## Démarrer

**Option 1 — via XAMPP (recommandé sur cette machine)**

1. Démarrer **Apache** et **MySQL** dans le panneau de contrôle XAMPP.
2. Importer le schéma (une seule fois, ou pour repartir de zéro) :
   ```powershell
   Get-Content sql\schema.sql -Raw | C:\xampp\mysql\bin\mysql.exe -u root
   ```
3. Ouvrir http://localhost/Monassso/

**Option 2 — serveur PHP intégré** (sans toucher à Apache)

```powershell
C:\xampp\php\php.exe -S localhost:8010 -t .
```
Puis ouvrir http://localhost:8010/ (MySQL doit quand même tourner).

### Compte Super Admin (semé par `sql/schema.sql`)

- E-mail : `superadmin@monasso.test`
- Mot de passe : `SuperAdmin@2026`

Les autres comptes (Admin Organisation, Membre) se créent via **Créer un compte** sur l'écran de
connexion.

## Structure du dépôt

```
Monassso/
├── sql/schema.sql       Tables (CREATE TABLE + seed permissions + Super Admin) — 11 à ce jour
├── config/               database.php (connexion PDO), constants.php (pays, variantes de badge ENUM)
├── lang/                 fr.php, en.php, mg.php — dictionnaires de traduction
├── core/                 bootstrap, autoload, helpers, Database, CodeGenerator, Auth, Middleware, Audit,
│                            Lang, Router, View
├── models/                UserModel, OrganisationModel, OrganisationUserModel, RoleModel, PermissionModel,
│                            CotisationModel, PaiementModel, AbonnementModel, AuditModel, NotificationModel
├── controllers/            AuthController, DashboardController, OrganisationsController, RolesController,
│                            MembresController, CotisationsController, AbonnementsController, AuditController,
│                            NotificationsController, LanguageController, HomeController
├── views/                  home, layout, auth, dashboard, organisations, roles, membres, cotisations,
│                            audit, notifications, errors
├── assets/css/app.css      Design system (cartes, badges, tableaux, formulaires — pas de dépendance externe)
└── index.php               Front controller (routage par query string : ?r=controller/action)
```

Pas de `mod_rewrite` requis : toutes les URLs passent par `index.php?r=...`, ce qui fonctionne
identiquement sous Apache/XAMPP et sous le serveur PHP intégré.

## Ce qui est implémenté (mapping avec le cahier des charges)

- **Flux 1 — Onboarding organisation** : inscription (choix Admin Organisation / Membre) → création
  d'organisation (statut `ATT`) → validation/refus par le Super Admin (`VAL`/`REF`) → encaissement de
  l'abonnement plateforme par le Super Admin (`ACT`).
- **Flux 2 — Membres & rôles** : création de rôles par organisation avec cases à cocher de permissions
  (suggestions PRESIDENT/TRESORIER/SECRETAIRE/MEMBRE pré-remplies) → demande d'adhésion → acceptation
  avec attribution de rôle → suspension/refus.
- **Flux 3 — Cotisations** : création d'une cotisation → génération automatique d'une ligne "Dû" pour
  chaque membre actif → paiement (cash, V1) → suivi par l'organisation.
- **Flux 4 — Audit** : `Audit::log()` appelé à chaque action d'écriture ; visibilité à 3 niveaux
  (Membre = ses actions, Admin Organisation = son organisation, Super Admin = tout).
- **Flux 5 — Sécurité** : middleware de connexion + de permission (avec remontée de la hiérarchie de
  rôles `parent_role_code`) sur chaque action sensible ; tentatives de connexion échouées journalisées.

- **Notifications** : un membre est notifié in-app (cloche dans la barre du haut + page dédiée) quand sa
  demande d'adhésion est acceptée ou refusée. Table `notifications`, extensible à d'autres types
  d'événements plus tard.

Testé de bout en bout (inscription → validation → rôles → adhésion → cotisation → paiement → visibilité
d'audit → contrôle des permissions → notifications) via le serveur PHP intégré avant livraison.

### Choix d'implémentation à connaître

Le cahier des charges laissait quelques détails ouverts ; voir l'en-tête de `sql/schema.sql` et le
plan de cette session pour le détail. En résumé : `organisation_users` et `role_permissions` ont une
clé primaire composite (ce sont de pures tables de liaison) ; `role_code` est généré sous la forme
`<organisation_code>-<NOM_ROLE>` pour éviter les collisions entre organisations ; deux actions d'audit
non listées ont été ajoutées (`LOGIN_SUCCESS`, `LOGOUT`) pour un journal cohérent.

## ⚠️ Base de données existante à connaître

La base MySQL `monasso` contenait déjà, avant ce V1, **104 tables** d'un autre travail antérieur
(`gpotb001` à `gpotb068`, plus des tables `gpotb_organisation`, `gpotb_membre`, `gpotb_tontine`,
`gpotb_don`, `gpotb_evenement`, `gpotb_plan_abonnement`, etc., avec des clés primaires
`AUTO_INCREMENT`). Ce V1 ne les utilise pas et ne les a pas modifiées — les 10 tables de ce V1
(`users`, `organisations`, `roles`, `permissions`, `organisation_users`, `role_permissions`,
`cotisations`, `paiements_cotisations`, `abonnements_orga`, `audit_logs`) coexistent avec elles dans
la même base. Cet ancien schéma est plus riche (tontines, dons, événements, plans d'abonnement...) et
pourrait servir de référence pour enrichir les prochaines versions — à discuter si vous voulez
rapprocher les deux.

**Précision** : la contrainte "10 tables" du cahier des charges initial n'est plus une limite — de
nouvelles tables peuvent être ajoutées librement à mesure des besoins (ex. `notifications` ci-dessous).

## Prochaines étapes possibles

- Interface pour éditer/suspendre les utilisateurs (Super Admin)
- Gestion des ayants droit / bénéficiaires (mutuelle)
- Modes de paiement au-delà du cash
- Rapprochement avec l'ancien schéma `gpotb_*` si ses fonctionnalités (tontines, dons, événements) sont
  souhaitées pour la suite
