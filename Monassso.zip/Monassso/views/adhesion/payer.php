<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('adhesion.payer.eyebrow')) ?></p>
        <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
    </div>

    <div class="card"><div class="card-body">
        <?php if (!empty($organisation['logo_chemin'])): ?>
            <img src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="" style="width:64px;height:64px;border-radius:10px;object-fit:cover;margin-bottom:12px;">
        <?php endif; ?>

        <div class="form-grid">
            <div>
                <p class="kpi-label"><?= h(t('cartes.field.numero')) ?></p>
                <p class="mt-2 text-mono"><?= h($numeroAdherent ?: '—') ?></p>
            </div>
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.motif')) ?></p>
                <p class="mt-2"><?= h(t('adhesion.field.motif_droit_adhesion')) ?></p>
            </div>
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.montant')) ?></p>
                <p class="mt-2"><?= h(format_money((float) $paiement['montant'])) ?></p>
            </div>
        </div>

        <?php if ($paiement['statut'] === 'PAYE'): ?>
            <p class="mt-2"><?= h(t('adhesion.payer.already_paid')) ?></p>
        <?php else: ?>
            <?php if ($errors): ?>
                <div class="mt-2">
                    <?php foreach ($errors as $error): ?><p class="text-danger"><?= h($error) ?></p><?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form method="post" action="<?= h(route_url('adhesion/confirmerPaiement')) ?>" class="mt-2">
                <input type="hidden" name="token" value="<?= h($paiement['token']) ?>">
                <div class="field">
                    <label for="mode_paiement"><?= h(t('dons.field.mode')) ?></label>
                    <select id="mode_paiement" name="mode_paiement" class="control" required>
                        <?php foreach (modes_paiement() as $mode): ?>
                            <option value="<?= h($mode) ?>"><?= h(t('enum.mode_paiement.' . $mode)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-accent mt-2"><?= h(t('adhesion.payer.pay_btn')) ?></button>
            </form>
        <?php endif; ?>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
