<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="thankyou-page">
    <div class="card thankyou-card"><div class="card-body">
        <p class="page-eyebrow"><?= h(t('adhesion.merci.eyebrow')) ?></p>
        <h1 class="page-title"><?= h(t('adhesion.merci.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('adhesion.merci.subtitle', ['org' => $organisation['nom'] ?? ''])) ?></p>
        <div class="row mt-2" style="justify-content:center;">
            <a class="btn btn-accent" href="<?= h(route_url('dashboard/index')) ?>"><?= h(t('nav.dashboard')) ?></a>
        </div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
