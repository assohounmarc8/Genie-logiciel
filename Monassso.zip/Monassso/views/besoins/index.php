<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('besoins.index.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('besoins/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('besoins.index.new')) ?></a>
    </div>

    <?php if (!$besoins): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('besoins.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="stack">
        <?php foreach ($besoins as $besoin): ?>
        <div class="card"><div class="card-body">
            <div class="row between">
                <div>
                    <p class="card-title">
                        <a class="link-strong" href="<?= h(route_url('besoins/detail', ['id' => $besoin['besoin_code']])) ?>"><?= h($besoin['titre']) ?></a>
                    </p>
                    <p class="text-faint text-mono"><?= h($besoin['besoin_code']) ?></p>
                </div>
                <?= enum_badge_html('besoin_statut', $besoin['statut']) ?>
            </div>
            <?php render_progress_bar((float) $besoin['montant_collecte'], (float) $besoin['montant_recherche']); ?>
        </div></div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
