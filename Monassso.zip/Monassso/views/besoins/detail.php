<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h($besoin['titre']) ?></h1>
            <p class="page-subtitle text-mono"><?= h($besoin['besoin_code']) ?></p>
        </div>
        <div class="row">
            <?= enum_badge_html('besoin_statut', $besoin['statut']) ?>
            <?php if ($besoin['statut'] !== 'FERME'): ?>
            <form method="post" action="<?= h(route_url('besoins/fermer')) ?>" onsubmit="return confirm('<?= h(t('besoins.confirm_close')) ?>');">
                <input type="hidden" name="id" value="<?= h($besoin['besoin_code']) ?>">
                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('besoins.close_btn')) ?></button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <div class="card"><div class="card-body">
        <?php render_progress_bar((float) $besoin['montant_collecte'], (float) $besoin['montant_recherche']); ?>
        <div class="form-grid mt-2">
            <div><p class="kpi-label"><?= h(t('besoins.field.type')) ?></p><p class="mt-2"><?= h(t('enum.type_besoin.' . $besoin['type_besoin'])) ?></p></div>
            <div><p class="kpi-label"><?= h(t('besoins.field.date_fin')) ?></p><p class="mt-2"><?= h(format_date($besoin['date_fin'])) ?></p></div>
        </div>
        <p class="kpi-label mt-2"><?= h(t('besoins.field.description')) ?></p>
        <p class="mt-2"><?= nl2br(h($besoin['description'])) ?></p>
    </div></div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('besoins.dons_title')) ?></p>
        <div class="table-wrap"><table class="data-table">
            <thead><tr>
                <th><?= h(t('dons.field.donateur')) ?></th>
                <th><?= h(t('common.amount')) ?></th>
                <th><?= h(t('dons.field.mode')) ?></th>
                <th><?= h(t('common.date')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$dons): ?><tr><td colspan="4" class="table-empty"><?= h(t('besoins.dons_empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($dons as $don): ?>
                <tr>
                    <td><?= h($don['donateur_nom']) ?><?= $don['anonyme'] ? ' ' . badge_html(t('dons.anonymous_badge'), 'neutral') : '' ?></td>
                    <td><?= h(format_money((float) $don['montant'])) ?></td>
                    <td><?= h(t('enum.mode_paiement.' . $don['mode_paiement'])) ?></td>
                    <td><?= h(format_datetime($don['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('besoins.documents_title')) ?></p>
        <form method="post" action="<?= h(route_url('besoins/uploadDocument')) ?>" enctype="multipart/form-data" class="row">
            <input type="hidden" name="besoin" value="<?= h($besoin['besoin_code']) ?>">
            <select name="type" class="control" style="width:auto;">
                <option value="DEVIS"><?= h(t('enum.besoin_doc_type.DEVIS')) ?></option>
                <option value="PHOTO"><?= h(t('enum.besoin_doc_type.PHOTO')) ?></option>
                <option value="FACTURE"><?= h(t('enum.besoin_doc_type.FACTURE')) ?></option>
            </select>
            <input type="file" name="fichier" required>
            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('documents.upload_btn')) ?></button>
        </form>

        <div class="table-wrap mt-2"><table class="data-table">
            <thead><tr>
                <th><?= h(t('documents.col_nom')) ?></th>
                <th><?= h(t('besoins.field.type')) ?></th>
                <th><?= h(t('documents.col_ajoute_par')) ?></th>
                <th><?= h(t('common.date')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$documents): ?><tr><td colspan="4" class="table-empty"><?= h(t('documents.empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($documents as $doc): ?>
                <tr>
                    <td><?= h($doc['nom_original']) ?></td>
                    <td><?= h(t('enum.besoin_doc_type.' . $doc['type'])) ?></td>
                    <td><?= h($doc['uploaded_by_nom']) ?></td>
                    <td><?= h(format_date($doc['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
