<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('besoins.creer.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('besoins/creer')) ?>" enctype="multipart/form-data">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="titre"><?= h(t('besoins.field.titre')) ?></label>
                <input type="text" id="titre" name="titre" required value="<?= h(old_input('titre')) ?>" placeholder="<?= h(t('besoins.field.titre_placeholder')) ?>">
            </div>
            <div class="field">
                <label for="description"><?= h(t('besoins.field.description')) ?></label>
                <textarea id="description" name="description" required><?= h(old_input('description')) ?></textarea>
            </div>
            <div class="form-grid">
                <div class="field">
                    <label for="type_besoin"><?= h(t('besoins.field.type')) ?></label>
                    <select id="type_besoin" name="type_besoin">
                        <option value="FINANCIER"><?= h(t('enum.type_besoin.FINANCIER')) ?></option>
                        <option value="MATERIEL"><?= h(t('enum.type_besoin.MATERIEL')) ?></option>
                        <option value="SERVICE"><?= h(t('enum.type_besoin.SERVICE')) ?></option>
                    </select>
                </div>
                <div class="field">
                    <label for="montant_recherche"><?= h(t('besoins.field.montant_recherche')) ?></label>
                    <input type="number" id="montant_recherche" name="montant_recherche" min="1" step="1" required value="<?= h(old_input('montant_recherche')) ?>">
                </div>
                <div class="field">
                    <label for="date_fin"><?= h(t('besoins.field.date_fin')) ?></label>
                    <input type="date" id="date_fin" name="date_fin" value="<?= h(old_input('date_fin')) ?>">
                </div>
                <div class="field">
                    <label for="photo"><?= h(t('besoins.field.photo')) ?></label>
                    <input type="file" id="photo" name="photo" accept="image/png,image/jpeg">
                </div>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('besoins/index', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('besoins.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
