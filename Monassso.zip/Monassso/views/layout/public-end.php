    </div>
    <footer class="landing-footer">
        <p><?= h(t('home.footer')) ?></p>
    </footer>
</div>
</body>
</html>
