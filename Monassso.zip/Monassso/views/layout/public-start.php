<?php
/** @var string $publicTitle */
$publicTitle = $publicTitle ?? t('dons.index.title');
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h($publicTitle) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="public-page">
    <div class="landing-nav">
        <div class="landing-nav-inner">
            <a class="landing-brand" href="<?= h(route_url('home/index')) ?>">
                <div class="sidebar-logo">M</div>
                <p class="landing-brand-name">MON<span class="accent">ASSO</span></p>
            </a>
            <div class="row">
                <?php render_language_switcher('light'); ?>
                <a class="btn btn-ghost" href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a>
            </div>
        </div>
    </div>
    <div class="public-body">
