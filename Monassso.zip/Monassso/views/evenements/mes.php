<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('evenements.mes.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('evenements.mes.subtitle')) ?></p>
    </div>

    <?php if (!$evenements): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('evenements.mes.empty')) ?></div></div>
    <?php endif; ?>

    <div class="stack">
        <?php foreach ($evenements as $evenement): ?>
        <?php $code = $evenement['evenement_code']; ?>
        <div class="card"><div class="card-body">
            <div class="row between">
                <div>
                    <p class="card-title"><?= h($evenement['titre']) ?></p>
                    <p class="text-faint"><?= h($evenement['organisation_nom']) ?> · <?= h(format_datetime($evenement['date_heure'])) ?><?= $evenement['lieu'] ? ' · ' . h($evenement['lieu']) : '' ?></p>
                </div>
                <?php if ($presentAt[$code]): ?>
                    <?= badge_html(t('evenements.mes.presence_badge'), 'success') ?>
                <?php elseif ($confirmed[$code]): ?>
                    <?= badge_html(t('evenements.mes.confirmed_badge'), 'warning') ?>
                <?php endif; ?>
            </div>
            <?php if ($evenement['description']): ?>
                <p class="mt-2"><?= nl2br(h($evenement['description'])) ?></p>
            <?php endif; ?>
            <div class="row mt-2">
                <?php if (!$confirmed[$code] && !$presentAt[$code]): ?>
                <form method="post" action="<?= h(route_url('evenements/confirmer')) ?>">
                    <input type="hidden" name="id" value="<?= h($code) ?>">
                    <button type="submit" class="btn btn-primary btn-sm"><?= h(t('evenements.mes.confirm_btn')) ?></button>
                </form>
                <?php endif; ?>
            </div>
            <?php if (!$presentAt[$code]): ?>
                <p class="text-faint mt-2"><?= h(t('evenements.mes.scan_hint')) ?></p>
            <?php endif; ?>
        </div></div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
