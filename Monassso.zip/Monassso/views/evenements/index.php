<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('evenements.index.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('evenements/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('evenements.index.new')) ?></a>
    </div>

    <?php if (!$evenements): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('evenements.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="stack">
        <?php foreach ($evenements as $evenement): ?>
        <div class="card"><div class="card-body">
            <div class="row between">
                <div>
                    <p class="card-title">
                        <a class="link-strong" href="<?= h(route_url('evenements/detail', ['id' => $evenement['evenement_code']])) ?>"><?= h($evenement['titre']) ?></a>
                    </p>
                    <p class="text-faint"><?= h(format_datetime($evenement['date_heure'])) ?><?= $evenement['lieu'] ? ' · ' . h($evenement['lieu']) : '' ?></p>
                </div>
                <div class="row">
                    <?= enum_badge_html('evenement_statut', $evenement['statut']) ?>
                    <form method="post" action="<?= h(route_url('evenements/supprimer')) ?>" onsubmit="return confirm('<?= h(t('evenements.confirm_delete')) ?>');">
                        <input type="hidden" name="id" value="<?= h($evenement['evenement_code']) ?>">
                        <button type="submit" class="btn btn-outline btn-sm"><?= h(t('common.delete')) ?></button>
                    </form>
                </div>
            </div>
        </div></div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
