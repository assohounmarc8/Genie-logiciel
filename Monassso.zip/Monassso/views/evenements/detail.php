<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h($evenement['titre']) ?></h1>
            <p class="page-subtitle"><?= h(format_datetime($evenement['date_heure'])) ?><?= $evenement['lieu'] ? ' · ' . h($evenement['lieu']) : '' ?></p>
        </div>
        <div class="row">
            <?= enum_badge_html('evenement_statut', $evenement['statut']) ?>
            <a class="btn btn-outline btn-sm" href="<?= h(route_url('evenements/pv', ['id' => $evenement['evenement_code']])) ?>"><?= h(t('evenements.pv_btn')) ?></a>
            <?php if ($evenement['statut'] === 'PLANIFIE'): ?>
            <form method="post" action="<?= h(route_url('evenements/terminer')) ?>" onsubmit="return confirm('<?= h(t('evenements.confirm_terminer')) ?>');">
                <input type="hidden" name="id" value="<?= h($evenement['evenement_code']) ?>">
                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('evenements.terminer_btn')) ?></button>
            </form>
            <form method="post" action="<?= h(route_url('evenements/annuler')) ?>" onsubmit="return confirm('<?= h(t('evenements.confirm_annuler')) ?>');">
                <input type="hidden" name="id" value="<?= h($evenement['evenement_code']) ?>">
                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('evenements.annuler_btn')) ?></button>
            </form>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($evenement['description']): ?>
    <div class="card"><div class="card-body">
        <p class="kpi-label"><?= h(t('evenements.field.description')) ?></p>
        <p class="mt-2"><?= nl2br(h($evenement['description'])) ?></p>
    </div></div>
    <?php endif; ?>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('evenements.appel_title')) ?></p>
        <p class="page-subtitle mt-2"><?= h(t('evenements.confirmations_count', ['count' => $confirmationsCount])) ?></p>

        <?php if ($scanUrl): ?>
            <div class="qr-box mt-2">
                <img src="<?= h('https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=' . urlencode($scanUrl)) ?>" alt="QR code">
                <div>
                    <p class="kpi-label"><?= h(t('evenements.scan_link_label')) ?></p>
                    <p class="qr-link mt-2"><?= h($scanUrl) ?></p>
                </div>
            </div>
        <?php else: ?>
            <form method="post" action="<?= h(route_url('evenements/lancerAppel')) ?>" class="mt-2">
                <input type="hidden" name="id" value="<?= h($evenement['evenement_code']) ?>">
                <button type="submit" class="btn btn-primary"><?= h(t('evenements.lancer_appel_btn')) ?></button>
            </form>
        <?php endif; ?>
    </div></div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('evenements.presence_manuel_title')) ?></p>
        <?php if ($membresRestants): ?>
        <form method="post" action="<?= h(route_url('evenements/marquerPresenceManuel')) ?>" class="row mt-2">
            <input type="hidden" name="evenement" value="<?= h($evenement['evenement_code']) ?>">
            <select name="user" class="control" style="width:auto;">
                <?php foreach ($membresRestants as $membre): ?>
                    <option value="<?= h($membre['user_code']) ?>"><?= h($membre['nom']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('evenements.marquer_present_btn')) ?></button>
        </form>
        <?php else: ?>
            <p class="text-faint mt-2"><?= h(t('evenements.tous_presents')) ?></p>
        <?php endif; ?>
    </div></div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('evenements.feuille_presence_title')) ?></p>
        <div class="table-wrap mt-2"><table class="data-table">
            <thead><tr>
                <th><?= h(t('common.name')) ?></th>
                <th><?= h(t('evenements.field.heure_arrivee')) ?></th>
                <th><?= h(t('evenements.field.mode')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$presences): ?><tr><td colspan="3" class="table-empty"><?= h(t('evenements.presence_empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($presences as $presence): ?>
                <tr>
                    <td><?= h($presence['nom']) ?></td>
                    <td><?= h(format_datetime($presence['heure_arrivee'])) ?></td>
                    <td><?= badge_html(t('enum.presence_mode.' . $presence['mode']), $presence['mode'] === 'QR' ? 'success' : 'neutral') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
