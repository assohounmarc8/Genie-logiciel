<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row end no-print">
        <button type="button" class="btn btn-primary btn-sm" onclick="window.print();"><?= h(t('evenements.pv.print_btn')) ?></button>
    </div>

    <div class="card"><div class="card-body">
        <div class="pv-header">
            <p class="page-eyebrow"><?= h(t('evenements.pv.eyebrow')) ?></p>
            <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
            <p class="page-subtitle"><?= h($evenement['titre']) ?></p>
        </div>

        <div class="pv-meta">
            <div><p class="kpi-label"><?= h(t('evenements.field.date_heure')) ?></p><p class="mt-2"><?= h(format_datetime($evenement['date_heure'])) ?></p></div>
            <div><p class="kpi-label"><?= h(t('evenements.field.lieu')) ?></p><p class="mt-2"><?= h($evenement['lieu'] ?: '—') ?></p></div>
            <div><p class="kpi-label"><?= h(t('evenements.pv.presents_count')) ?></p><p class="mt-2"><?= h((string) count($presences)) ?></p></div>
            <div><p class="kpi-label"><?= h(t('evenements.pv.absents_count')) ?></p><p class="mt-2"><?= h((string) count($absents)) ?></p></div>
        </div>

        <?php if ($evenement['description']): ?>
        <p class="kpi-label"><?= h(t('evenements.pv.ordre_du_jour')) ?></p>
        <p class="mt-2"><?= nl2br(h($evenement['description'])) ?></p>
        <?php endif; ?>

        <p class="kpi-label mt-2"><?= h(t('evenements.pv.presents_title')) ?></p>
        <div class="table-wrap mt-2"><table class="data-table">
            <thead><tr><th><?= h(t('common.name')) ?></th><th><?= h(t('evenements.field.heure_arrivee')) ?></th></tr></thead>
            <tbody>
                <?php if (!$presences): ?><tr><td colspan="2" class="table-empty"><?= h(t('evenements.presence_empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($presences as $presence): ?>
                <tr><td><?= h($presence['nom']) ?></td><td><?= h(format_datetime($presence['heure_arrivee'])) ?></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>

        <p class="kpi-label mt-2"><?= h(t('evenements.pv.absents_title')) ?></p>
        <div class="table-wrap mt-2"><table class="data-table">
            <thead><tr><th><?= h(t('common.name')) ?></th></tr></thead>
            <tbody>
                <?php if (!$absents): ?><tr><td class="table-empty"><?= h(t('evenements.pv.absents_empty')) ?></td></tr><?php endif; ?>
                <?php foreach ($absents as $absent): ?>
                <tr><td><?= h($absent['nom']) ?></td></tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
