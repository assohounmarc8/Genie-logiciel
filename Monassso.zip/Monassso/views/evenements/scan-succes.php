<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="thankyou-page">
    <div class="card thankyou-card"><div class="card-body">
        <p class="page-eyebrow"><?= h(t('evenements.scan.eyebrow')) ?></p>
        <h1 class="page-title"><?= h(t('evenements.scan.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('evenements.scan.subtitle', ['titre' => $evenement['titre']])) ?></p>
        <div class="row mt-2" style="justify-content: center;">
            <a class="btn btn-accent" href="<?= h(route_url('evenements/mes')) ?>"><?= h(t('evenements.scan.back_btn')) ?></a>
        </div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
