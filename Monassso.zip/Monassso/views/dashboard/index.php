<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow">
            <?php if (!empty($roleName)): ?>
                <?= h($roleName) ?><?= !empty($roleOrgName) ? ' — ' . h($roleOrgName) : '' ?>
            <?php else: ?>
                <?= h(t('enum.type_compte.' . $user['type_compte'])) ?>
            <?php endif; ?>
        </p>
        <h1 class="page-title"><?= h(t('dashboard.greeting', ['name' => explode(' ', $user['nom'])[0]])) ?></h1>
    </div>

    <div class="kpi-grid">
        <?php foreach ($kpis as $kpi): ?>
            <div class="card"><div class="card-body">
                <p class="kpi-label"><?= h($kpi['label']) ?></p>
                <p class="kpi-value"><?= h($kpi['value']) ?></p>
            </div></div>
        <?php endforeach; ?>
    </div>

    <?php if ($user['type_compte'] === 'ADMIN_ORGA' && empty($organisation)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.create_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.create_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('organisations/creer')) ?>"><?= h(t('nav.create_org')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if (!empty($showJoinPrompt)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.join_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.join_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('membres/organisationsDisponibles')) ?>"><?= h(t('dashboard.join_org_cta')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if ($richFinance): ?>
    <?php
        $rf = $richFinance;
        $deltaClass = $rf['kpis']['tresorerie_delta'] >= 0 ? 'activity-amount-in' : 'activity-amount-out';
        $deltaSign = $rf['kpis']['tresorerie_delta'] >= 0 ? '+' : '';
    ?>
    <div>
        <p class="page-eyebrow mt-2"><?= h(t('dashboard.finance.eyebrow')) ?></p>
    </div>

    <?php if ($rf['alertCount'] > 0): ?>
        <div class="card alert-card"><div class="card-body">
            <p><?= h(t('dashboard.finance.alert', ['count' => $rf['alertCount']])) ?></p>
        </div></div>
    <?php endif; ?>

    <div class="kpi-grid">
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.total_membres')) ?></p>
            <p class="kpi-value"><?= h((string) $rf['kpis']['total_membres']) ?></p>
            <p class="kpi-hint">+<?= h((string) $rf['kpis']['nouveaux_ce_mois']) ?> <?= h(t('dashboard.finance.this_month')) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.tresorerie')) ?></p>
            <p class="kpi-value"><?= h(format_money($rf['kpis']['tresorerie'])) ?></p>
            <p class="kpi-hint <?= h($deltaClass) ?>"><?= h($deltaSign . format_money($rf['kpis']['tresorerie_delta'])) ?> <?= h(t('dashboard.finance.this_month')) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.taux_cotisations')) ?></p>
            <p class="kpi-value"><?= h((string) $rf['kpis']['taux_cotisations_mois']) ?>%</p>
            <div class="progress-track mt-2"><div class="progress-fill<?= $rf['kpis']['taux_cotisations_mois'] >= 100 ? ' complete' : '' ?>" style="width: <?= h((string) $rf['kpis']['taux_cotisations_mois']) ?>%;"></div></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.depenses_mois')) ?></p>
            <p class="kpi-value"><?= h(format_money($rf['kpis']['depenses_mois'])) ?></p>
        </div></div>
    </div>

    <div class="chart-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_tresorerie')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartTresorerie"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_cotisations')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartCotisations"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_depenses')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartDepenses"></canvas></div>
        </div></div>
    </div>

    <div class="two-col-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.late_members_title')) ?></p>
            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr>
                    <th><?= h(t('common.name')) ?></th>
                    <th><?= h(t('common.amount')) ?></th>
                    <th></th>
                </tr></thead>
                <tbody>
                    <?php if (!$rf['lateMembers']): ?><tr><td colspan="3" class="table-empty"><?= h(t('dashboard.finance.late_members_empty')) ?></td></tr><?php endif; ?>
                    <?php foreach ($rf['lateMembers'] as $lm): ?>
                    <tr>
                        <td><?= h($lm['nom']) ?></td>
                        <td><?= h(format_money((float) $lm['montant_du'])) ?></td>
                        <td>
                            <form method="post" action="<?= h(route_url('cotisations/relancer')) ?>">
                                <input type="hidden" name="org" value="<?= h($rf['orgCode']) ?>">
                                <input type="hidden" name="user" value="<?= h($lm['user_code']) ?>">
                                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('dashboard.finance.relancer_btn')) ?></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>
        </div></div>

        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.activity_title')) ?></p>
            <ul class="activity-list mt-2">
                <?php if (!$rf['recentActivity']): ?><li class="table-empty"><?= h(t('dashboard.finance.activity_empty')) ?></li><?php endif; ?>
                <?php foreach ($rf['recentActivity'] as $activity): ?>
                <li>
                    <span><?= h($activity['label']) ?></span>
                    <span class="<?= $activity['type'] === 'IN' ? 'activity-amount-in' : 'activity-amount-out' ?>"><?= h(format_datetime($activity['date'])) ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        (function () {
            var trendLabels = <?= json_encode(array_column($rf['treasuryTrend'], 'label'), JSON_UNESCAPED_UNICODE) ?>;
            var trendData = <?= json_encode(array_column($rf['treasuryTrend'], 'balance')) ?>;
            new Chart(document.getElementById('chartTresorerie'), {
                type: 'line',
                data: {
                    labels: trendLabels,
                    datasets: [{
                        label: '<?= h(t('dashboard.finance.tresorerie')) ?>',
                        data: trendData,
                        borderColor: '#1f7a4d',
                        backgroundColor: 'rgba(31,122,77,0.12)',
                        tension: 0.3,
                        fill: true,
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartCotisations'), {
                type: 'doughnut',
                data: {
                    labels: [
                        '<?= h(t('enum.paiement_statut.PAY')) ?>',
                        '<?= h(t('enum.paiement_statut.DU')) ?>',
                        '<?= h(t('enum.paiement_statut.EXO')) ?>',
                    ],
                    datasets: [{
                        data: [
                            <?= (int) $rf['cotisationStatus']['PAY'] ?>,
                            <?= (int) $rf['cotisationStatus']['DU'] ?>,
                            <?= (int) $rf['cotisationStatus']['EXO'] ?>,
                        ],
                        backgroundColor: ['#1f7a4d', '#e07b39', '#94a3b8'],
                    }],
                },
                options: { maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartDepenses'), {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_column($rf['topDepenses'], 'libelle'), JSON_UNESCAPED_UNICODE) ?>,
                    datasets: [{
                        label: '<?= h(t('dashboard.finance.depenses_mois')) ?>',
                        data: <?= json_encode(array_map(fn ($d) => (float) $d['montant'], $rf['topDepenses'])) ?>,
                        backgroundColor: '#e07b39',
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false },
            });
        })();
    </script>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
