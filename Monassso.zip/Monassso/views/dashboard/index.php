<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow">
            <?php if (!empty($roleName)): ?>
                <?= h($roleName) ?><?= !empty($roleOrgName) ? ' — ' . h($roleOrgName) : '' ?>
            <?php else: ?>
                <?= h(t('enum.type_compte.' . $user['type_compte'])) ?>
            <?php endif; ?>
        </p>
        <h1 class="page-title"><?= h(t('dashboard.greeting', ['name' => explode(' ', $user['nom'])[0]])) ?></h1>
    </div>

    <div class="kpi-grid">
        <?php foreach ($kpis as $kpi): ?>
            <div class="card"><div class="card-body">
                <p class="kpi-label"><?= h($kpi['label']) ?></p>
                <p class="kpi-value"><?= h($kpi['value']) ?></p>
            </div></div>
        <?php endforeach; ?>
    </div>

    <?php if ($user['type_compte'] === 'ADMIN_ORGA' && empty($organisation)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.create_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.create_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('organisations/creer')) ?>"><?= h(t('nav.create_org')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if (!empty($showJoinPrompt)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.join_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.join_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('membres/organisationsDisponibles')) ?>"><?= h(t('dashboard.join_org_cta')) ?></a>
        </div></div>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
