<?php $autoRefreshSeconds = 20; require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow">
            <?php if (!empty($roleName)): ?>
                <?= h($roleName) ?><?= !empty($roleOrgName) ? ' — ' . h($roleOrgName) : '' ?>
            <?php else: ?>
                <?= h(t('enum.type_compte.' . $user['type_compte'])) ?>
            <?php endif; ?>
        </p>
        <h1 class="page-title"><?= h(t('dashboard.greeting', ['name' => explode(' ', $user['nom'])[0]])) ?></h1>
    </div>

    <div class="kpi-grid">
        <?php foreach ($kpis as $kpi): ?>
            <div class="card"><div class="card-body">
                <p class="kpi-label"><?= h($kpi['label']) ?></p>
                <p class="kpi-value"><?= h($kpi['value']) ?></p>
            </div></div>
        <?php endforeach; ?>
    </div>

    <?php if ($user['type_compte'] === 'ADMIN_ORGA' && empty($organisation)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.create_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.create_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('organisations/creer')) ?>"><?= h(t('nav.create_org')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if ($user['type_compte'] === 'ADMIN_ORGA' && !empty($organisation) && $organisation['statut_validation'] !== 'VAL'): ?>
        <div class="card"><div class="card-body">
            <?php if ($organisation['statut_validation'] === 'ATT'): ?>
                <p class="card-title"><?= h(t('org.pending.title')) ?></p>
                <p class="page-subtitle"><?= h(t('org.pending.text', ['org' => $organisation['nom']])) ?></p>
            <?php else: ?>
                <p class="card-title"><?= h(t('org.refused.title')) ?></p>
                <p class="page-subtitle"><?= h(t('org.refused.text', ['org' => $organisation['nom']])) ?></p>
            <?php endif; ?>
            <a class="btn btn-outline mt-2" href="<?= h(route_url('organisations/detail', ['id' => $organisation['organisation_code']])) ?>"><?= h(t('nav.overview')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if (!empty($showJoinPrompt)): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.join_org_title')) ?></p>
            <p class="page-subtitle"><?= h(t('dashboard.join_org_text')) ?></p>
            <a class="btn btn-primary mt-2" href="<?= h(route_url('membres/organisationsDisponibles')) ?>"><?= h(t('dashboard.join_org_cta')) ?></a>
        </div></div>
    <?php endif; ?>

    <?php if ($richMembre): ?>
    <?php $rm = $richMembre; ?>
    <div>
        <p class="page-eyebrow mt-2"><?= h(t('dashboard.membre.eyebrow')) ?></p>
    </div>

    <div class="kpi-grid">
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.membre.montant_du')) ?></p>
            <p class="kpi-value"><?= h(format_money($rm['montantDu'])) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.membre.cartes')) ?></p>
            <p class="kpi-value"><?= h((string) $rm['cartesActives']) ?> / <?= h((string) $rm['cartesTotal']) ?></p>
        </div></div>
    </div>

    <div class="two-col-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.membre.mes_organisations')) ?></p>
            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr>
                    <th><?= h(t('common.organisation')) ?></th>
                    <th><?= h(t('roles.col_role')) ?></th>
                    <th><?= h(t('common.status')) ?></th>
                </tr></thead>
                <tbody>
                    <?php if (!$rm['memberships']): ?><tr><td colspan="3" class="table-empty"><?= h(t('dashboard.membre.no_orgs')) ?></td></tr><?php endif; ?>
                    <?php foreach ($rm['memberships'] as $m): ?>
                    <tr>
                        <td><?= h($m['organisation_nom']) ?></td>
                        <td><?= h($m['nom_role'] ?? t('membres.no_role')) ?></td>
                        <td><?= enum_badge_html('membre_statut', $m['statut']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>
        </div></div>

        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.membre.cotisations_dues')) ?></p>
            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr>
                    <th><?= h(t('common.organisation')) ?></th>
                    <th><?= h(t('common.amount')) ?></th>
                    <th></th>
                </tr></thead>
                <tbody>
                    <?php if (!$rm['duePaiements']): ?><tr><td colspan="3" class="table-empty"><?= h(t('dashboard.membre.no_dues')) ?></td></tr><?php endif; ?>
                    <?php foreach ($rm['duePaiements'] as $p): ?>
                    <tr>
                        <td><?= h($p['organisation_nom']) ?></td>
                        <td><?= h(format_money((float) $p['montant'], $p['devise'])) ?></td>
                        <td><a class="btn btn-primary btn-sm" href="<?= h(route_url('cotisations/confirmerPaiement', ['id' => $p['paiement_code']])) ?>"><?= h(t('cotisations.pay_btn')) ?></a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>
        </div></div>
    </div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('dashboard.membre.evenements')) ?></p>
        <ul class="activity-list mt-2">
            <?php if (!$rm['evenements']): ?><li class="table-empty"><?= h(t('dashboard.membre.no_evenements')) ?></li><?php endif; ?>
            <?php foreach ($rm['evenements'] as $ev): ?>
            <li>
                <span><?= h($ev['titre']) ?> — <?= h($ev['organisation_nom']) ?></span>
                <span><?= h(format_datetime($ev['date_heure'])) ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
    </div></div>
    <?php endif; ?>

    <?php if ($richPlatform): ?>
    <?php $rp = $richPlatform; ?>
    <div>
        <p class="page-eyebrow mt-2"><?= h(t('dashboard.platform.eyebrow')) ?></p>
    </div>

    <div class="kpi-grid">
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.platform.total_users')) ?></p>
            <p class="kpi-value"><?= h((string) $rp['kpis']['total_users']) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.platform.total_active_members')) ?></p>
            <p class="kpi-value"><?= h((string) $rp['kpis']['total_active_members']) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.platform.validated')) ?></p>
            <p class="kpi-value"><?= h((string) $rp['validationCounts']['VAL']) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.platform.refused')) ?></p>
            <p class="kpi-value"><?= h((string) $rp['validationCounts']['REF']) ?></p>
        </div></div>
    </div>

    <div class="chart-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.platform.chart_trend')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartOrgsTrend"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.platform.chart_validation')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartValidation"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.platform.chart_type')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartType"></canvas></div>
        </div></div>
    </div>

    <div class="two-col-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.platform.chart_pays')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartPays"></canvas></div>
        </div></div>

        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.platform.pending_title', ['count' => $rp['pendingCount']])) ?></p>
            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr>
                    <th><?= h(t('org.index.col_org')) ?></th>
                    <th><?= h(t('common.country')) ?></th>
                    <th></th>
                </tr></thead>
                <tbody>
                    <?php if (!$rp['pendingOrgs']): ?><tr><td colspan="3" class="table-empty"><?= h(t('dashboard.platform.pending_empty')) ?></td></tr><?php endif; ?>
                    <?php foreach ($rp['pendingOrgs'] as $po): ?>
                    <tr>
                        <td><a class="link-strong" href="<?= h(route_url('organisations/detail', ['id' => $po['organisation_code']])) ?>"><?= h($po['nom']) ?></a></td>
                        <td><?= h(pays_label($po['pays_code'])) ?></td>
                        <td>
                            <form method="post" action="<?= h(route_url('organisations/valider')) ?>">
                                <input type="hidden" name="id" value="<?= h($po['organisation_code']) ?>">
                                <button type="submit" class="btn btn-primary btn-sm"><?= h(t('common.approve')) ?></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>
        </div></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        (function () {
            new Chart(document.getElementById('chartOrgsTrend'), {
                type: 'line',
                data: {
                    labels: <?= json_encode(array_column($rp['orgsTrend'], 'label'), JSON_UNESCAPED_UNICODE) ?>,
                    datasets: [{
                        label: '<?= h(t('dashboard.platform.chart_trend')) ?>',
                        data: <?= json_encode(array_column($rp['orgsTrend'], 'count')) ?>,
                        borderColor: '#1f7a4d',
                        backgroundColor: 'rgba(31,122,77,0.12)',
                        tension: 0.3,
                        fill: true,
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } },
            });

            new Chart(document.getElementById('chartValidation'), {
                type: 'doughnut',
                data: {
                    labels: [
                        '<?= h(t('enum.org_statut_validation.ATT')) ?>',
                        '<?= h(t('enum.org_statut_validation.VAL')) ?>',
                        '<?= h(t('enum.org_statut_validation.REF')) ?>',
                    ],
                    datasets: [{
                        data: [
                            <?= (int) $rp['validationCounts']['ATT'] ?>,
                            <?= (int) $rp['validationCounts']['VAL'] ?>,
                            <?= (int) $rp['validationCounts']['REF'] ?>,
                        ],
                        backgroundColor: ['#e07b39', '#1f7a4d', '#dc2626'],
                    }],
                },
                options: { maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartType'), {
                type: 'doughnut',
                data: {
                    labels: [
                        '<?= h(t('enum.type_organisation.ASSOCIATION')) ?>',
                        '<?= h(t('enum.type_organisation.ONG')) ?>',
                        '<?= h(t('enum.type_organisation.MUTUELLE')) ?>',
                    ],
                    datasets: [{
                        data: [
                            <?= (int) $rp['typeCounts']['ASSOCIATION'] ?>,
                            <?= (int) $rp['typeCounts']['ONG'] ?>,
                            <?= (int) $rp['typeCounts']['MUTUELLE'] ?>,
                        ],
                        backgroundColor: ['#94a3b8', '#e07b39', '#1f7a4d'],
                    }],
                },
                options: { maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartPays'), {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_map('pays_label', array_keys($rp['paysCounts'])), JSON_UNESCAPED_UNICODE) ?>,
                    datasets: [{
                        label: '<?= h(t('dashboard.platform.chart_pays')) ?>',
                        data: <?= json_encode(array_values($rp['paysCounts'])) ?>,
                        backgroundColor: '#1f7a4d',
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false, indexAxis: 'y', scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } },
            });
        })();
    </script>
    <?php endif; ?>

    <?php if ($richFinance): ?>
    <?php
        $rf = $richFinance;
        $deltaClass = $rf['kpis']['tresorerie_delta'] >= 0 ? 'activity-amount-in' : 'activity-amount-out';
        $deltaSign = $rf['kpis']['tresorerie_delta'] >= 0 ? '+' : '';
    ?>
    <div>
        <p class="page-eyebrow mt-2"><?= h(t('dashboard.finance.eyebrow')) ?></p>
    </div>

    <?php if ($rf['alertCount'] > 0): ?>
        <div class="card alert-card"><div class="card-body">
            <p><?= h(t('dashboard.finance.alert', ['count' => $rf['alertCount']])) ?></p>
        </div></div>
    <?php endif; ?>

    <div class="kpi-grid">
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.total_membres')) ?></p>
            <p class="kpi-value"><?= h((string) $rf['kpis']['total_membres']) ?></p>
            <p class="kpi-hint">+<?= h((string) $rf['kpis']['nouveaux_ce_mois']) ?> <?= h(t('dashboard.finance.this_month')) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.tresorerie')) ?></p>
            <p class="kpi-value"><?= h(format_money($rf['kpis']['tresorerie'])) ?></p>
            <p class="kpi-hint <?= h($deltaClass) ?>"><?= h($deltaSign . format_money($rf['kpis']['tresorerie_delta'])) ?> <?= h(t('dashboard.finance.this_month')) ?></p>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.taux_cotisations')) ?></p>
            <p class="kpi-value"><?= h((string) $rf['kpis']['taux_cotisations_mois']) ?>%</p>
            <div class="progress-track mt-2"><div class="progress-fill<?= $rf['kpis']['taux_cotisations_mois'] >= 100 ? ' complete' : '' ?>" style="width: <?= h((string) $rf['kpis']['taux_cotisations_mois']) ?>%;"></div></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="kpi-label"><?= h(t('dashboard.finance.depenses_mois')) ?></p>
            <p class="kpi-value"><?= h(format_money($rf['kpis']['depenses_mois'])) ?></p>
        </div></div>
    </div>

    <div class="chart-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_tresorerie')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartTresorerie"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_cotisations')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartCotisations"></canvas></div>
        </div></div>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.chart_depenses')) ?></p>
            <div class="chart-box mt-2"><canvas id="chartDepenses"></canvas></div>
        </div></div>
    </div>

    <div class="two-col-grid">
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.late_members_title')) ?></p>
            <div class="table-wrap mt-2"><table class="data-table">
                <thead><tr>
                    <th><?= h(t('common.name')) ?></th>
                    <th><?= h(t('common.amount')) ?></th>
                    <th></th>
                </tr></thead>
                <tbody>
                    <?php if (!$rf['lateMembers']): ?><tr><td colspan="3" class="table-empty"><?= h(t('dashboard.finance.late_members_empty')) ?></td></tr><?php endif; ?>
                    <?php foreach ($rf['lateMembers'] as $lm): ?>
                    <tr>
                        <td><?= h($lm['nom']) ?></td>
                        <td><?= h(format_money((float) $lm['montant_du'])) ?></td>
                        <td>
                            <form method="post" action="<?= h(route_url('cotisations/relancer')) ?>">
                                <input type="hidden" name="org" value="<?= h($rf['orgCode']) ?>">
                                <input type="hidden" name="user" value="<?= h($lm['user_code']) ?>">
                                <button type="submit" class="btn btn-outline btn-sm"><?= h(t('dashboard.finance.relancer_btn')) ?></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table></div>
        </div></div>

        <div class="card"><div class="card-body">
            <p class="card-title"><?= h(t('dashboard.finance.activity_title')) ?></p>
            <ul class="activity-list mt-2">
                <?php if (!$rf['recentActivity']): ?><li class="table-empty"><?= h(t('dashboard.finance.activity_empty')) ?></li><?php endif; ?>
                <?php foreach ($rf['recentActivity'] as $activity): ?>
                <li>
                    <span><?= h($activity['label']) ?></span>
                    <span class="<?= $activity['type'] === 'IN' ? 'activity-amount-in' : 'activity-amount-out' ?>"><?= h(format_datetime($activity['date'])) ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        (function () {
            var trendLabels = <?= json_encode(array_column($rf['treasuryTrend'], 'label'), JSON_UNESCAPED_UNICODE) ?>;
            var trendData = <?= json_encode(array_column($rf['treasuryTrend'], 'balance')) ?>;
            new Chart(document.getElementById('chartTresorerie'), {
                type: 'line',
                data: {
                    labels: trendLabels,
                    datasets: [{
                        label: '<?= h(t('dashboard.finance.tresorerie')) ?>',
                        data: trendData,
                        borderColor: '#1f7a4d',
                        backgroundColor: 'rgba(31,122,77,0.12)',
                        tension: 0.3,
                        fill: true,
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartCotisations'), {
                type: 'doughnut',
                data: {
                    labels: [
                        '<?= h(t('enum.paiement_statut.PAY')) ?>',
                        '<?= h(t('enum.paiement_statut.DU')) ?>',
                        '<?= h(t('enum.paiement_statut.EXO')) ?>',
                    ],
                    datasets: [{
                        data: [
                            <?= (int) $rf['cotisationStatus']['PAY'] ?>,
                            <?= (int) $rf['cotisationStatus']['DU'] ?>,
                            <?= (int) $rf['cotisationStatus']['EXO'] ?>,
                        ],
                        backgroundColor: ['#1f7a4d', '#e07b39', '#94a3b8'],
                    }],
                },
                options: { maintainAspectRatio: false },
            });

            new Chart(document.getElementById('chartDepenses'), {
                type: 'bar',
                data: {
                    labels: <?= json_encode(array_column($rf['topDepenses'], 'libelle'), JSON_UNESCAPED_UNICODE) ?>,
                    datasets: [{
                        label: '<?= h(t('dashboard.finance.depenses_mois')) ?>',
                        data: <?= json_encode(array_map(fn ($d) => (float) $d['montant'], $rf['topDepenses'])) ?>,
                        backgroundColor: '#e07b39',
                    }],
                },
                options: { plugins: { legend: { display: false } }, maintainAspectRatio: false },
            });
        })();
    </script>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
