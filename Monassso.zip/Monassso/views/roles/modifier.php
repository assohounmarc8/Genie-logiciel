<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('roles.modifier.title', ['role' => $role['nom_role']])) ?></h1>
        <p class="page-subtitle"><?= h(t('roles.modifier.subtitle')) ?></p>
    </div>

    <form method="post" action="<?= h(route_url('roles/modifier')) ?>">
        <input type="hidden" name="id" value="<?= h($role['role_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label><?= h(t('roles.field.nom')) ?></label>
                <input type="text" value="<?= h($role['nom_role']) ?>" disabled>
            </div>
            <div class="field">
                <label for="parent_role_code"><?= h(t('roles.field.parent')) ?></label>
                <select id="parent_role_code" name="parent_role_code">
                    <option value=""><?= h(t('common.none')) ?></option>
                    <?php foreach ($existingRoles as $r): ?>
                        <option value="<?= h($r['role_code']) ?>" <?= $role['parent_role_code'] === $r['role_code'] ? 'selected' : '' ?>><?= h($r['nom_role']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label><?= h(t('common.permissions')) ?></label>
                <?php foreach ($allPermissions as $perm): ?>
                    <label class="field-check">
                        <input type="checkbox" name="permissions[]" value="<?= h($perm['permission_code']) ?>" <?= in_array($perm['permission_code'], $currentPermissions, true) ? 'checked' : '' ?>>
                        <?= h(t('perm.' . $perm['permission_code'])) ?>
                    </label>
                <?php endforeach; ?>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('roles/index', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('roles.modifier.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
