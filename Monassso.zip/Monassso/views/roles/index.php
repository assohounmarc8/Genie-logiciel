<?php
$canGererRoles = Middleware::can($organisation['organisation_code'], 'gerer_roles');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('roles.index.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <?php if ($canGererRoles): ?>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('roles/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('roles.index.new')) ?></a>
        <?php endif; ?>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr><th><?= h(t('roles.col_role')) ?></th><th><?= h(t('roles.col_parent')) ?></th><th><?= h(t('common.permissions')) ?></th></tr></thead>
        <tbody>
            <?php if (!$roles): ?><tr><td colspan="3" class="table-empty"><?= h(t('roles.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($roles as $role): ?>
            <tr>
                <td><?= h($role['nom_role']) ?><br><span class="text-mono text-faint"><?= h($role['role_code']) ?></span></td>
                <td><?= h($role['parent_role_code'] ?? '—') ?></td>
                <td>
                    <?php if (!$role['permissions']): ?>
                        <span class="text-faint"><?= h(t('common.none')) ?></span>
                    <?php endif; ?>
                    <?php foreach ($role['permissions'] as $p): ?><?= badge_html(t("perm.$p"), 'neutral') ?> <?php endforeach; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
