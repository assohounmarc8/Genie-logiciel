<?php
$errors = flash_get('errors', []);
$pays = PaysModel::all();
$metiers = MetierModel::all();
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('common.register')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="row between">
            <div class="auth-brand">
                <div class="sidebar-logo">M</div>
                <div>
                    <p class="auth-brand-name">MON<span class="accent">ASSO</span></p>
                    <p class="auth-tag"><?= h(t('common.register')) ?></p>
                </div>
            </div>
            <?php render_language_switcher('light'); ?>
        </div>

        <?php if ($errors): ?>
        <div class="auth-error">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="post" action="<?= h(route_url('auth/register')) ?>">
            <div class="field">
                <label for="type_compte"><?= h(t('auth.register.as')) ?></label>
                <select id="type_compte" name="type_compte" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <option value="ADMIN_ORGA" <?= old_input('type_compte') === 'ADMIN_ORGA' ? 'selected' : '' ?>><?= h(t('auth.register.type_admin')) ?></option>
                    <option value="MEMBRE" <?= old_input('type_compte') === 'MEMBRE' ? 'selected' : '' ?>><?= h(t('auth.register.type_membre')) ?></option>
                </select>
            </div>
            <div class="field">
                <label for="nom"><?= h(t('common.fullname')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="email"><?= h(t('common.email')) ?></label>
                <input type="email" id="email" name="email" required value="<?= h(old_input('email')) ?>">
            </div>
            <div id="admin-fields">
                <div class="field">
                    <label for="password"><?= h(t('auth.register.password_hint')) ?></label>
                    <input type="password" id="password" name="password" minlength="8">
                </div>
            </div>
            <p id="membre-password-hint" class="text-faint"><?= h(t('auth.register.membre_password_hint')) ?></p>
            <div class="field">
                <label for="pays_code"><?= h(t('common.country')) ?></label>
                <select id="pays_code" name="pays_code" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($pays as $info): ?>
                        <option value="<?= h($info['pays_code']) ?>" <?= old_input('pays_code') === $info['pays_code'] ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="sexe"><?= h(t('common.sexe')) ?></label>
                <select id="sexe" name="sexe" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <option value="M" <?= old_input('sexe') === 'M' ? 'selected' : '' ?>><?= h(t('enum.sexe.M')) ?></option>
                    <option value="F" <?= old_input('sexe') === 'F' ? 'selected' : '' ?>><?= h(t('enum.sexe.F')) ?></option>
                </select>
            </div>
            <div id="membre-fields">
                <div class="field">
                    <label for="date_naissance"><?= h(t('common.date_naissance')) ?></label>
                    <input type="date" id="date_naissance" name="date_naissance" value="<?= h(old_input('date_naissance')) ?>">
                </div>
                <div class="field">
                    <label for="lieu_naissance"><?= h(t('common.lieu_naissance')) ?></label>
                    <input type="text" id="lieu_naissance" name="lieu_naissance" value="<?= h(old_input('lieu_naissance')) ?>">
                </div>
                <div class="field">
                    <label for="metier"><?= h(t('common.metier')) ?></label>
                    <select id="metier" name="metier">
                        <option value=""><?= h(t('common.choose')) ?></option>
                        <?php foreach ($metiers as $metier): ?>
                            <option value="<?= h($metier['metier_code']) ?>" <?= old_input('metier') === $metier['metier_code'] ? 'selected' : '' ?>><?= h(t('enum.metier.' . $metier['metier_code'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block"><?= h(t('auth.register.submit')) ?></button>
        </form>

        <p class="auth-switch"><?= h(t('auth.register.has_account')) ?> <a href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a></p>
    </div>
</div>
<script>
    (function () {
        var typeSelect = document.getElementById('type_compte');
        var membreFields = document.getElementById('membre-fields');
        var membreInputs = membreFields.querySelectorAll('input, select');
        var adminFields = document.getElementById('admin-fields');
        var adminInputs = adminFields.querySelectorAll('input, select');
        var membrePasswordHint = document.getElementById('membre-password-hint');

        function updateFields() {
            var isAdmin = typeSelect.value === 'ADMIN_ORGA';

            membreFields.style.display = isAdmin ? 'none' : '';
            membreInputs.forEach(function (field) {
                field.required = !isAdmin;
            });

            adminFields.style.display = isAdmin ? '' : 'none';
            adminInputs.forEach(function (field) {
                field.required = isAdmin;
            });

            membrePasswordHint.style.display = isAdmin ? 'none' : '';
        }

        typeSelect.addEventListener('change', updateFields);
        updateFields();
    })();
</script>
</body>
</html>
