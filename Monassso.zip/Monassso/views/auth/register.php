<?php
$errors = flash_get('errors', []);
$pays = config_get('pays');
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('common.register')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="row between">
            <div class="auth-brand">
                <div class="sidebar-logo">M</div>
                <div>
                    <p class="auth-brand-name">MON<span class="accent">ASSO</span></p>
                    <p class="auth-tag"><?= h(t('common.register')) ?></p>
                </div>
            </div>
            <?php render_language_switcher('light'); ?>
        </div>

        <?php if ($errors): ?>
        <div class="auth-error">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="post" action="<?= h(route_url('auth/register')) ?>">
            <div class="field">
                <label for="type_compte"><?= h(t('auth.register.as')) ?></label>
                <select id="type_compte" name="type_compte" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <option value="ADMIN_ORGA" <?= old_input('type_compte') === 'ADMIN_ORGA' ? 'selected' : '' ?>><?= h(t('auth.register.type_admin')) ?></option>
                    <option value="MEMBRE" <?= old_input('type_compte') === 'MEMBRE' ? 'selected' : '' ?>><?= h(t('auth.register.type_membre')) ?></option>
                </select>
            </div>
            <div class="field">
                <label for="nom"><?= h(t('common.fullname')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="email"><?= h(t('common.email')) ?></label>
                <input type="email" id="email" name="email" required value="<?= h(old_input('email')) ?>">
            </div>
            <div class="field">
                <label for="password"><?= h(t('auth.register.password_hint')) ?></label>
                <input type="password" id="password" name="password" required minlength="8">
            </div>
            <div class="field">
                <label for="pays_code"><?= h(t('common.country')) ?></label>
                <select id="pays_code" name="pays_code" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($pays as $code => $info): ?>
                        <option value="<?= h($code) ?>" <?= old_input('pays_code') === $code ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="sexe"><?= h(t('common.sexe')) ?></label>
                <select id="sexe" name="sexe" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <option value="M" <?= old_input('sexe') === 'M' ? 'selected' : '' ?>><?= h(t('enum.sexe.M')) ?></option>
                    <option value="F" <?= old_input('sexe') === 'F' ? 'selected' : '' ?>><?= h(t('enum.sexe.F')) ?></option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block"><?= h(t('auth.register.submit')) ?></button>
        </form>

        <p class="auth-switch"><?= h(t('auth.register.has_account')) ?> <a href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a></p>
    </div>
</div>
</body>
</html>
