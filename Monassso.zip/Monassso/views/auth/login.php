<?php
$errors = flash_get('errors', []);
$info = flash_get('info', []);
?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('auth.login.tag')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="auth-page">
    <div class="auth-card">
        <div class="row between">
            <div class="auth-brand">
                <div class="sidebar-logo">M</div>
                <div>
                    <p class="auth-brand-name">MON<span class="accent">ASSO</span></p>
                    <p class="auth-tag"><?= h(t('auth.login.tag')) ?></p>
                </div>
            </div>
            <?php render_language_switcher('light'); ?>
        </div>

        <?php if ($info): ?>
        <div class="auth-info">
            <?php foreach ($info as $message): ?><p><?= h($message) ?></p><?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if ($errors): ?>
        <div class="auth-error">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div>
        <?php endif; ?>

        <form method="post" action="<?= h(route_url('auth/login')) ?>">
            <div class="field">
                <label for="email"><?= h(t('common.email')) ?></label>
                <input type="email" id="email" name="email" required value="<?= h(old_input('email')) ?>">
            </div>
            <div class="field">
                <label for="password"><?= h(t('common.password')) ?></label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block"><?= h(t('common.login')) ?></button>
        </form>

        <p class="auth-switch"><?= h(t('auth.login.no_account')) ?> <a href="<?= h(route_url('auth/register')) ?>"><?= h(t('common.register')) ?></a></p>
    </div>
</div>
</body>
</html>
