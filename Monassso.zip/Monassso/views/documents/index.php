<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('documents.index.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <?php if ($canGerer): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('documents.upload_title')) ?></p>
        <form method="post" action="<?= h(route_url('documents/upload')) ?>" enctype="multipart/form-data">
            <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
            <div class="form-grid">
                <div class="field">
                    <label for="fichier"><?= h(t('documents.field.file')) ?></label>
                    <input type="file" id="fichier" name="fichier" required>
                    <p class="page-subtitle mt-2"><?= h(t('documents.field.file_hint')) ?></p>
                </div>
                <div class="field">
                    <label for="categorie"><?= h(t('documents.field.categorie')) ?></label>
                    <select id="categorie" name="categorie">
                        <option value="PV"><?= h(t('enum.categorie.PV')) ?></option>
                        <option value="STATUTS"><?= h(t('enum.categorie.STATUTS')) ?></option>
                        <option value="RAPPORT"><?= h(t('enum.categorie.RAPPORT')) ?></option>
                        <option value="AUTRE" selected><?= h(t('enum.categorie.AUTRE')) ?></option>
                    </select>
                </div>
                <div class="field">
                    <label for="visibilite"><?= h(t('documents.field.visibilite')) ?></label>
                    <select id="visibilite" name="visibilite">
                        <option value="PUBLIC"><?= h(t('enum.visibilite.PUBLIC')) ?></option>
                        <option value="PRIVE"><?= h(t('enum.visibilite.PRIVE')) ?></option>
                    </select>
                </div>
            </div>
            <div class="row end mt-2">
                <button type="submit" class="btn btn-primary"><?= h(t('documents.upload_btn')) ?></button>
            </div>
        </form>
    </div></div>
    <?php endif; ?>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('documents.col_nom')) ?></th>
            <th><?= h(t('documents.field.categorie')) ?></th>
            <th><?= h(t('documents.field.visibilite')) ?></th>
            <th><?= h(t('documents.col_ajoute_par')) ?></th>
            <th><?= h(t('common.date')) ?></th>
            <th><?= h(t('common.actions')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$documents): ?><tr><td colspan="6" class="table-empty"><?= h(t('documents.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($documents as $doc): ?>
            <tr>
                <td><?= h($doc['nom_original']) ?></td>
                <td><?= h(t('enum.categorie.' . $doc['categorie'])) ?></td>
                <td><?= badge_html(t('enum.visibilite.' . $doc['visibilite']), $doc['visibilite'] === 'PRIVE' ? 'warning' : 'neutral') ?></td>
                <td><?= h($doc['uploaded_by_nom']) ?></td>
                <td><?= h(format_date($doc['created_at'])) ?></td>
                <td>
                    <div class="table-actions">
                        <a class="btn btn-outline btn-sm" href="<?= h(route_url('documents/telecharger', ['id' => $doc['document_code']])) ?>"><?= h(t('documents.download_btn')) ?></a>
                        <?php if ($canGerer): ?>
                        <form method="post" action="<?= h(route_url('documents/supprimer')) ?>" onsubmit="return confirm('<?= h(t('documents.confirm_delete')) ?>');">
                            <input type="hidden" name="id" value="<?= h($doc['document_code']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('common.delete')) ?></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
