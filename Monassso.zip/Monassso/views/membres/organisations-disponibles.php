<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('nav.available_orgs')) ?></h1>
        <p class="page-subtitle"><?= h(t('membres.available.subtitle')) ?></p>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr><th><?= h(t('org.index.col_org')) ?></th><th><?= h(t('common.country')) ?></th><th><?= h(t('common.status')) ?></th><th><?= h(t('common.actions')) ?></th></tr></thead>
        <tbody>
            <?php if (!$organisations): ?><tr><td colspan="4" class="table-empty"><?= h(t('membres.available.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($organisations as $org): ?>
            <?php $joined = in_array($org['organisation_code'], $joinedCodes, true); ?>
            <tr>
                <td><?= h($org['nom']) ?></td>
                <td><?= h(pays_label($org['pays_code'])) ?></td>
                <td><?= $joined ? badge_html(t('membres.request_sent'), 'neutral') : badge_html(t('membres.available_badge'), 'success') ?></td>
                <td>
                    <?php if (!$joined): ?>
                    <form method="post" action="<?= h(route_url('membres/rejoindre')) ?>">
                        <input type="hidden" name="org" value="<?= h($org['organisation_code']) ?>">
                        <button type="submit" class="btn btn-primary btn-sm"><?= h(t('membres.join_btn')) ?></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
