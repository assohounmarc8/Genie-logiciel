<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('nav.available_orgs')) ?></h1>
        <p class="page-subtitle"><?= h(t('membres.available.subtitle', ['pays' => pays_label($user['pays_code'])])) ?></p>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <div class="table-wrap"><table class="data-table">
        <thead><tr><th><?= h(t('org.index.col_org')) ?></th><th><?= h(t('common.country')) ?></th><th><?= h(t('org.field.type_organisation')) ?></th><th><?= h(t('common.status')) ?></th><th><?= h(t('common.actions')) ?></th></tr></thead>
        <tbody>
            <?php if (!$organisations): ?><tr><td colspan="5" class="table-empty"><?= h(t('membres.available.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($organisations as $org): ?>
            <?php $membership = $membershipsByOrg[$org['organisation_code']] ?? null; ?>
            <?php $hasReglement = !empty($org['reglement_interieur_chemin']); ?>
            <tr>
                <td><?= h($org['nom']) ?></td>
                <td><?= h(pays_label($org['pays_code'])) ?></td>
                <td><?= enum_badge_html('type_organisation', $org['type_organisation']) ?></td>
                <td><?= $membership ? enum_badge_html('membre_statut', $membership['statut']) : badge_html(t('membres.available_badge'), 'success') ?></td>
                <td>
                    <?php if (!$membership): ?>
                    <?php if ($hasReglement): ?>
                    <p class="mt-2">
                        <a href="<?= h(asset_url('/' . $org['reglement_interieur_chemin'])) ?>" target="_blank" rel="noopener">📄 <?= h(t('membres.view_reglement')) ?></a>
                    </p>
                    <?php endif; ?>
                    <form method="post" action="<?= h(route_url('membres/rejoindre')) ?>">
                        <input type="hidden" name="org" value="<?= h($org['organisation_code']) ?>">
                        <?php if ($hasReglement): ?>
                        <label class="row mt-2">
                            <input type="checkbox" name="accepte_reglement" value="1" required>
                            <span><?= h(t('membres.accept_reglement')) ?></span>
                        </label>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-primary btn-sm mt-2"><?= h(t('membres.join_btn')) ?></button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
