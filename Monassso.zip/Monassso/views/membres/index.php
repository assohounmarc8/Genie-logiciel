<?php
$orgCode = $organisation['organisation_code'];
$canValiderAdherent = Middleware::can($orgCode, 'valider_adherent');
$canGererMembres = Middleware::can($orgCode, 'gerer_membres');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('membres.index.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr><th><?= h(t('membres.col_membre')) ?></th><th><?= h(t('roles.col_role')) ?></th><th><?= h(t('common.status')) ?></th><th><?= h(t('common.actions')) ?></th></tr></thead>
        <tbody>
            <?php if (!$members): ?><tr><td colspan="4" class="table-empty"><?= h(t('membres.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($members as $m): ?>
            <tr>
                <td><?= h($m['nom']) ?><br><span class="text-faint"><?= h($m['email']) ?></span></td>
                <td>
                    <?php if ($m['statut'] === 'ACT' && $canGererMembres): ?>
                    <form method="post" action="<?= h(route_url('membres/changerRole')) ?>" class="role-form">
                        <input type="hidden" name="org" value="<?= h($orgCode) ?>">
                        <input type="hidden" name="user" value="<?= h($m['user_code']) ?>">
                        <select name="role_code" class="control" onchange="this.form.submit()">
                            <option value=""><?= h(t('membres.no_role')) ?></option>
                            <?php foreach ($roles as $r): ?>
                                <option value="<?= h($r['role_code']) ?>" <?= $m['role_code'] === $r['role_code'] ? 'selected' : '' ?>><?= h($r['nom_role']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                    <?php else: ?>
                        <?= h($m['nom_role'] ?? '—') ?>
                    <?php endif; ?>
                </td>
                <td><?= enum_badge_html('membre_statut', $m['statut']) ?></td>
                <td>
                    <?php if ($m['statut'] === 'ATT' && $canValiderAdherent): ?>
                    <div class="table-actions">
                        <form method="post" action="<?= h(route_url('membres/accepter')) ?>" class="role-form">
                            <input type="hidden" name="org" value="<?= h($orgCode) ?>">
                            <input type="hidden" name="user" value="<?= h($m['user_code']) ?>">
                            <select name="role_code" class="control">
                                <option value=""><?= h(t('membres.no_role')) ?></option>
                                <?php foreach ($roles as $r): ?>
                                    <option value="<?= h($r['role_code']) ?>"><?= h($r['nom_role']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('membres.accept_btn')) ?></button>
                        </form>
                        <form method="post" action="<?= h(route_url('membres/refuser')) ?>">
                            <input type="hidden" name="org" value="<?= h($orgCode) ?>">
                            <input type="hidden" name="user" value="<?= h($m['user_code']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('common.reject')) ?></button>
                        </form>
                    </div>
                    <?php elseif ($m['statut'] === 'ACT' && $canGererMembres): ?>
                    <form method="post" action="<?= h(route_url('membres/suspendre')) ?>" onsubmit="return confirm('<?= h(t('membres.confirm_suspend')) ?>');">
                        <input type="hidden" name="org" value="<?= h($orgCode) ?>">
                        <input type="hidden" name="user" value="<?= h($m['user_code']) ?>">
                        <button type="submit" class="btn btn-outline btn-sm"><?= h(t('membres.suspend_btn')) ?></button>
                    </form>
                    <?php else: ?>
                        <span class="text-faint">—</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
