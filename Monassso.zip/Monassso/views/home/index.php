<?php $pays = PaysModel::all(); ?>
<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>MONASSO — <?= h(t('home.footer')) ?></title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/fonts.css')) ?>">
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="landing-nav">
    <div class="landing-nav-inner">
        <div class="landing-brand">
            <div class="sidebar-logo">M</div>
            <p class="landing-brand-name">MON<span class="accent">ASSO</span></p>
        </div>
        <div class="row">
            <?php render_language_switcher('light'); ?>
            <a class="btn btn-ghost" href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.give_btn')) ?></a>
            <a class="btn btn-ghost" href="<?= h(route_url('auth/login')) ?>"><?= h(t('common.login')) ?></a>
            <a class="btn btn-accent" href="<?= h(route_url('auth/register')) ?>"><?= h(t('common.register')) ?></a>
        </div>
    </div>
</div>

<div class="hero">
    <div class="hero-inner">
        <p class="hero-eyebrow"><?= h(t('home.eyebrow')) ?></p>
        <h1 class="hero-title">MONASSO</h1>
        <p class="hero-tagline"><?= h(t('home.tagline')) ?></p>
        <div class="hero-actions">
            <a class="btn btn-accent btn-lg" href="<?= h(route_url('auth/register')) ?>"><?= h(t('nav.create_org')) ?></a>
            <a class="btn btn-outline btn-lg" href="<?= h(route_url('auth/login')) ?>"><?= h(t('home.have_account')) ?></a>
            <a class="btn btn-outline btn-lg" href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.give_btn')) ?></a>
        </div>
    </div>
</div>

<div class="landing-body">
    <div class="landing-section">
        <h2 class="section-title"><?= h(t('home.section.workflow')) ?></h2>
        <div class="feature-grid">
            <div class="card"><div class="card-body">
                <p class="card-title"><?= h(t('enum.type_compte.SUPER_ADMIN')) ?></p>
                <p class="page-subtitle"><?= h(t('home.feature.super_admin')) ?></p>
            </div></div>
            <div class="card"><div class="card-body">
                <p class="card-title"><?= h(t('enum.type_compte.ADMIN_ORGA')) ?></p>
                <p class="page-subtitle"><?= h(t('home.feature.admin_orga')) ?></p>
            </div></div>
            <div class="card"><div class="card-body">
                <p class="card-title"><?= h(t('enum.type_compte.MEMBRE')) ?></p>
                <p class="page-subtitle"><?= h(t('home.feature.membre')) ?></p>
            </div></div>
        </div>
    </div>

    <div class="landing-section">
        <h2 class="section-title"><?= h(t('home.section.countries')) ?></h2>
        <div class="row">
            <?php foreach ($pays as $info): ?>
                <span class="badge badge-neutral"><?= h($info['drapeau'] . ' ' . $info['nom']) ?></span>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<footer class="landing-footer">
    <p><?= h(t('home.footer')) ?></p>
</footer>
</body>
</html>
