<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('cotisations.eyebrow')) ?></p>
        <h1 class="page-title"><?= h($cotisation['libelle']) ?></h1>
        <p class="page-subtitle"><?= h(t('cotisations.suivi.per_member', ['amount' => format_money((float) $cotisation['montant'], $cotisation['devise'])])) ?></p>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('membres.col_membre')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th><?= h(t('cotisations.col_date_paiement')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$paiements): ?><tr><td colspan="4" class="table-empty"><?= h(t('cotisations.suivi.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($paiements as $p): ?>
            <tr>
                <td><?= h($p['nom']) ?><br><span class="text-faint"><?= h($p['email']) ?></span></td>
                <td><?= h(format_money((float) $p['montant'], $cotisation['devise'])) ?></td>
                <td><?= enum_badge_html('paiement_statut', $p['statut_paiement']) ?></td>
                <td><?= h(format_datetime($p['date_paiement'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
