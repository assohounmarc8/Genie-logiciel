<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('cotisations.eyebrow')) ?></p>
            <h1 class="page-title"><?= h($cotisation['libelle']) ?></h1>
            <p class="page-subtitle"><?= h(t('cotisations.suivi.per_member', ['amount' => format_money((float) $cotisation['montant'], $cotisation['devise'])])) ?></p>
        </div>
        <a class="btn btn-outline btn-sm" href="<?= h(route_url('cotisations/exportSuivi', ['id' => $cotisation['cotisation_code']])) ?>"><?= h(t('common.export')) ?></a>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('membres.col_membre')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th><?= h(t('cotisations.col_date_paiement')) ?></th>
            <?php if ($canValiderPaiement): ?><th><?= h(t('common.actions')) ?></th><?php endif; ?>
        </tr></thead>
        <tbody>
            <?php if (!$paiements): ?><tr><td colspan="5" class="table-empty"><?= h(t('cotisations.suivi.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($paiements as $p): ?>
            <tr>
                <td><?= h($p['nom']) ?><br><span class="text-faint"><?= h($p['email']) ?></span></td>
                <td><?= h(format_money((float) $p['montant'], $cotisation['devise'])) ?></td>
                <td><?= enum_badge_html('paiement_statut', $p['statut_paiement']) ?></td>
                <td><?= h(format_datetime($p['date_paiement'])) ?></td>
                <?php if ($canValiderPaiement): ?>
                <td>
                    <?php if ($p['statut_paiement'] === 'DU'): ?>
                    <div class="table-actions">
                        <form method="post" action="<?= h(route_url('cotisations/marquerPaye')) ?>">
                            <input type="hidden" name="id" value="<?= h($p['paiement_code']) ?>">
                            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('cotisations.mark_paid_btn')) ?></button>
                        </form>
                        <form method="post" action="<?= h(route_url('cotisations/marquerExonere')) ?>">
                            <input type="hidden" name="id" value="<?= h($p['paiement_code']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('cotisations.exonerer_btn')) ?></button>
                        </form>
                    </div>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
