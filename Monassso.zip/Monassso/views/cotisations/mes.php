<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('nav.my_cotisations')) ?></h1>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('org.index.col_org')) ?></th>
            <th><?= h(t('cotisations.eyebrow')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th><?= h(t('common.actions')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$paiements): ?><tr><td colspan="5" class="table-empty"><?= h(t('cotisations.mes.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($paiements as $p): ?>
            <tr>
                <td><?= h($p['organisation_nom']) ?></td>
                <td><?= h($p['libelle']) ?></td>
                <td><?= h(format_money((float) $p['montant'], $p['devise'])) ?></td>
                <td><?= enum_badge_html('paiement_statut', $p['statut_paiement']) ?></td>
                <td>
                    <?php if ($p['statut_paiement'] === 'DU'): ?>
                    <a class="btn btn-primary btn-sm" href="<?= h(route_url('cotisations/confirmerPaiement', ['id' => $p['paiement_code']])) ?>"><?= h(t('cotisations.pay_btn')) ?></a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
