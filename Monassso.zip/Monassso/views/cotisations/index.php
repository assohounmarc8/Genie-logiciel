<?php
$canCreerCotisation = Middleware::can($organisation['organisation_code'], 'creer_cotisation');
$canVoirFinances = Middleware::can($organisation['organisation_code'], 'voir_finances');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('cotisations.index.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <?php if ($canCreerCotisation): ?>
        <a class="btn btn-primary btn-sm" href="<?= h(route_url('cotisations/creer', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('cotisations.index.new')) ?></a>
        <?php endif; ?>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('cotisations.col_libelle')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('common.status')) ?></th>
            <th><?= h(t('org.detail.created_label')) ?></th>
            <th><?= h(t('common.actions')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$cotisations): ?><tr><td colspan="5" class="table-empty"><?= h(t('cotisations.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($cotisations as $c): ?>
            <tr>
                <td><?= h($c['libelle']) ?></td>
                <td><?= h(format_money((float) $c['montant'], $c['devise'])) ?></td>
                <td><?= enum_badge_html('cotisation_statut', $c['statut']) ?></td>
                <td><?= h(format_date($c['created_at'])) ?></td>
                <td>
                    <?php if ($canVoirFinances): ?>
                    <a class="btn btn-outline btn-sm" href="<?= h(route_url('cotisations/suivi', ['id' => $c['cotisation_code']])) ?>"><?= h(t('cotisations.tracking_btn')) ?></a>
                    <?php else: ?>
                        <span class="text-faint">—</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
