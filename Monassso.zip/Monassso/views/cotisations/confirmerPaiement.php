<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('adhesion.payer.eyebrow')) ?></p>
        <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
    </div>

    <div class="card"><div class="card-body">
        <div class="form-grid">
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.motif')) ?></p>
                <p class="mt-2"><?= h($cotisation['libelle']) ?></p>
            </div>
            <div>
                <p class="kpi-label"><?= h(t('adhesion.field.montant')) ?></p>
                <p class="mt-2"><?= h(format_money((float) $paiement['montant'], $cotisation['devise'])) ?></p>
            </div>
        </div>

        <?php if ($paiement['statut_paiement'] !== 'DU'): ?>
            <p class="mt-2"><?= h(t('adhesion.payer.already_paid')) ?></p>
        <?php else: ?>
            <form method="post" action="<?= h(route_url('cotisations/payer')) ?>" class="mt-2">
                <input type="hidden" name="id" value="<?= h($paiement['paiement_code']) ?>">
                <button type="submit" class="btn btn-accent"><?= h(t('adhesion.payer.pay_btn')) ?></button>
            </form>
        <?php endif; ?>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
