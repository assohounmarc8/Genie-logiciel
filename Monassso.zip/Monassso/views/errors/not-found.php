<!DOCTYPE html>
<html lang="<?= h(Lang::current()) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h(t('errors.404.title')) ?> — MONASSO</title>
<link rel="stylesheet" href="<?= h(asset_url('/assets/css/app.css')) ?>">
</head>
<body>
<div class="error-page">
    <p class="page-eyebrow">404</p>
    <h1 class="page-title"><?= h(t('errors.404.title')) ?></h1>
    <p class="page-subtitle"><?= h(t('errors.404.text')) ?></p>
    <a class="btn btn-primary mt-2" href="<?= h(route_url('dashboard/index')) ?>"><?= h(t('errors.back_dashboard')) ?></a>
</div>
</body>
</html>
