<?php
$errors = flash_get('errors', []);
$pays = PaysModel::all();
$typesOrganisation = TypeOrganisationModel::all();
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('nav.create_org')) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('organisations/creer')) ?>" enctype="multipart/form-data">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom"><?= h(t('org.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="pays_code"><?= h(t('common.country')) ?></label>
                <select id="pays_code" name="pays_code" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($pays as $info): ?>
                        <option value="<?= h($info['pays_code']) ?>" <?= old_input('pays_code') === $info['pays_code'] ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="type_organisation"><?= h(t('org.field.type_organisation')) ?></label>
                <select id="type_organisation" name="type_organisation" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($typesOrganisation as $type): ?>
                        <option value="<?= h($type['type_organisation_code']) ?>" <?= old_input('type_organisation') === $type['type_organisation_code'] ? 'selected' : '' ?>><?= h(t('enum.type_organisation.' . $type['type_organisation_code'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="field">
                <label for="reglement_interieur"><?= h(t('org.field.reglement_interieur')) ?></label>
                <input type="file" id="reglement_interieur" name="reglement_interieur" accept="application/pdf,.pdf">
                <p class="text-faint mt-2"><?= h(t('org.field.reglement_interieur_hint')) ?></p>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('org.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
