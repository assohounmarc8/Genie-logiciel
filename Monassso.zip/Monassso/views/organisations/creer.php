<?php
$errors = flash_get('errors', []);
$pays = config_get('pays');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('nav.create_org')) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('organisations/creer')) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label for="nom"><?= h(t('org.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom')) ?>">
            </div>
            <div class="field">
                <label for="pays_code"><?= h(t('common.country')) ?></label>
                <select id="pays_code" name="pays_code" required>
                    <option value=""><?= h(t('common.choose')) ?></option>
                    <?php foreach ($pays as $code => $info): ?>
                        <option value="<?= h($code) ?>" <?= old_input('pays_code') === $code ? 'selected' : '' ?>><?= h($info['drapeau'] . ' ' . $info['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div></div>
        <div class="row end mt-2">
            <button type="submit" class="btn btn-primary"><?= h(t('org.creer.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
