<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('org.parametres.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <form method="post" action="<?= h(route_url('organisations/parametres')) ?>" enctype="multipart/form-data">
        <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
        <div class="card"><div class="card-body">
            <div class="field">
                <label><?= h(t('org.field.logo')) ?></label>
                <?php if (!empty($organisation['logo_chemin'])): ?>
                    <img src="<?= h(asset_url('/' . $organisation['logo_chemin'])) ?>" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:8px;display:block;margin-bottom:8px;">
                <?php endif; ?>
                <input type="file" name="logo" accept="image/png,image/jpeg">
            </div>
            <div class="field">
                <label for="nom"><?= h(t('org.field.nom')) ?></label>
                <input type="text" id="nom" name="nom" required value="<?= h(old_input('nom') ?: $organisation['nom']) ?>">
            </div>
            <div class="field">
                <label for="email"><?= h(t('org.field.email')) ?></label>
                <input type="text" id="email" name="email" value="<?= h(old_input('email') ?: ($organisation['email'] ?? '')) ?>">
            </div>
            <div class="field">
                <label for="telephone"><?= h(t('org.field.telephone')) ?></label>
                <input type="text" id="telephone" name="telephone" value="<?= h(old_input('telephone') ?: ($organisation['telephone'] ?? '')) ?>">
            </div>
            <div class="field">
                <label for="adresse"><?= h(t('org.field.adresse')) ?></label>
                <textarea id="adresse" name="adresse"><?= h(old_input('adresse') ?: ($organisation['adresse'] ?? '')) ?></textarea>
            </div>
            <div class="field">
                <label for="montant_adhesion"><?= h(t('org.field.montant_adhesion')) ?></label>
                <input type="number" min="0" step="1" id="montant_adhesion" name="montant_adhesion" value="<?= h(old_input('montant_adhesion') ?: ($organisation['montant_adhesion'] ?? '')) ?>">
                <p class="text-faint mt-2"><?= h(t('org.field.montant_adhesion_hint')) ?></p>
            </div>
        </div></div>
        <div class="row end mt-2">
            <a class="btn btn-outline" href="<?= h(route_url('organisations/detail', ['id' => $organisation['organisation_code']])) ?>"><?= h(t('common.cancel')) ?></a>
            <button type="submit" class="btn btn-primary"><?= h(t('org.parametres.submit')) ?></button>
        </div>
    </form>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
