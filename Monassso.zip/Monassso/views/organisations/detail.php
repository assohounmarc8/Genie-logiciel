<?php
$orgCode = $organisation['organisation_code'];
$canGererOrganisation = Middleware::can($orgCode, 'gerer_organisation');
$canMembres = Middleware::can($orgCode, 'gerer_membres') || Middleware::can($orgCode, 'valider_adherent') || Middleware::can($orgCode, 'voir_membres');
$canCotisations = Middleware::can($orgCode, 'creer_cotisation') || Middleware::can($orgCode, 'voir_finances');
$canDocuments = Middleware::can($orgCode, 'voir_documents') || Middleware::can($orgCode, 'gerer_documents');
require APP_DIR . '/views/layout/start.php';
?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h($organisation['nom']) ?></h1>
            <p class="page-subtitle text-mono"><?= h($organisation['organisation_code']) ?></p>
        </div>
        <div class="row">
            <?= enum_badge_html('org_statut_validation', $organisation['statut_validation']) ?>
            <?= enum_badge_html('org_statut_abonnement', $organisation['statut_abonnement']) ?>
            <?php if ($canGererOrganisation): ?>
                <a class="btn btn-outline btn-sm" href="<?= h(route_url('organisations/parametres', ['org' => $orgCode])) ?>"><?= h(t('nav.parametres')) ?></a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isSuperAdmin && $organisation['statut_validation'] === 'VAL' && $organisation['statut_abonnement'] !== 'ACT'): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('org.detail.collect_sub')) ?></p>
        <form method="post" action="<?= h(route_url('abonnements/payer')) ?>" class="row">
            <input type="hidden" name="org" value="<?= h($orgCode) ?>">
            <input type="number" name="montant" min="1" step="1" placeholder="<?= h(t('common.amount')) ?>" required style="max-width:160px;">
            <button type="submit" class="btn btn-accent"><?= h(t('org.detail.collect_btn')) ?></button>
        </form>
    </div></div>
    <?php endif; ?>

    <div class="card"><div class="card-body form-grid">
        <div><p class="kpi-label"><?= h(t('common.country')) ?></p><p class="mt-2"><?= h(pays_label($organisation['pays_code'])) ?></p></div>
        <div><p class="kpi-label"><?= h(t('org.detail.admin_label')) ?></p><p class="mt-2 text-mono"><?= h($organisation['admin_user_code']) ?></p></div>
        <div><p class="kpi-label"><?= h(t('org.detail.created_label')) ?></p><p class="mt-2"><?= h(format_date($organisation['created_at'])) ?></p></div>
        <?php if (!empty($organisation['email'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.email')) ?></p><p class="mt-2"><?= h($organisation['email']) ?></p></div>
        <?php endif; ?>
        <?php if (!empty($organisation['telephone'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.telephone')) ?></p><p class="mt-2"><?= h($organisation['telephone']) ?></p></div>
        <?php endif; ?>
        <?php if (!empty($organisation['adresse'])): ?>
        <div><p class="kpi-label"><?= h(t('org.field.adresse')) ?></p><p class="mt-2"><?= h($organisation['adresse']) ?></p></div>
        <?php endif; ?>
    </div></div>

    <div class="row">
        <?php if ($canMembres): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('membres/index', ['org' => $orgCode])) ?>"><?= h(t('nav.membres')) ?></a><?php endif; ?>
        <a class="btn btn-outline btn-sm" href="<?= h(route_url('roles/index', ['org' => $orgCode])) ?>"><?= h(t('nav.roles')) ?></a>
        <?php if ($canCotisations): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('cotisations/index', ['org' => $orgCode])) ?>"><?= h(t('nav.cotisations')) ?></a><?php endif; ?>
        <?php if ($canDocuments): ?><a class="btn btn-outline btn-sm" href="<?= h(route_url('documents/index', ['org' => $orgCode])) ?>"><?= h(t('nav.documents')) ?></a><?php endif; ?>
    </div>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('org.detail.sub_history')) ?></p>
        <div class="table-wrap"><table class="data-table">
            <thead><tr>
                <th><?= h(t('common.code')) ?></th>
                <th><?= h(t('common.status')) ?></th>
                <th><?= h(t('common.amount')) ?></th>
                <th><?= h(t('common.start_date')) ?></th>
                <th><?= h(t('common.end_date')) ?></th>
            </tr></thead>
            <tbody>
                <?php if (!$abonnements): ?><tr><td colspan="5" class="table-empty"><?= h(t('org.detail.no_subscriptions')) ?></td></tr><?php endif; ?>
                <?php foreach ($abonnements as $abo): ?>
                <tr>
                    <td class="text-mono"><?= h($abo['abonnement_code']) ?></td>
                    <td><?= enum_badge_html('abonnement_statut', $abo['statut']) ?></td>
                    <td><?= h(format_money((float) $abo['montant'])) ?></td>
                    <td><?= h(format_date($abo['date_debut'])) ?></td>
                    <td><?= h(format_date($abo['date_fin'])) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
