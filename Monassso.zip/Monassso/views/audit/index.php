<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.audit')) ?></p>
        <h1 class="page-title"><?= h(t('audit.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('audit.scope', ['scope' => $scope])) ?></p>
    </div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('common.date')) ?></th>
            <th><?= h(t('audit.col_actor')) ?></th>
            <th><?= h(t('org.index.col_org')) ?></th>
            <th><?= h(t('common.action')) ?></th>
            <th><?= h(t('common.target')) ?></th>
            <th><?= h(t('audit.col_details')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$logs): ?><tr><td colspan="6" class="table-empty"><?= h(t('audit.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($logs as $log): ?>
            <tr>
                <td><?= h(format_datetime($log['created_at'])) ?></td>
                <td class="text-mono"><?= h($log['actor_user_code'] ?? '—') ?></td>
                <td class="text-mono"><?= h($log['organisation_code'] ?? '—') ?></td>
                <td><?= h($log['action_code']) ?></td>
                <td class="text-mono"><?= h($log['target_code'] ?? '—') ?></td>
                <td class="text-faint"><?= h($log['details_json'] ?? '—') ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
