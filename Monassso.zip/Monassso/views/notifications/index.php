<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('nav.notifications')) ?></p>
            <h1 class="page-title"><?= h(t('notifications.title')) ?></h1>
        </div>
        <?php if ($notifications): ?>
        <form method="post" action="<?= h(route_url('notifications/marquerToutLu')) ?>">
            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('notifications.mark_all_read')) ?></button>
        </form>
        <?php endif; ?>
    </div>

    <div class="stack">
        <?php if (!$notifications): ?>
            <div class="card"><div class="card-body table-empty"><?= h(t('notifications.empty')) ?></div></div>
        <?php endif; ?>
        <?php foreach ($notifications as $notif): ?>
            <div class="alert-item<?= $notif['lue'] ? '' : ' unread' ?>">
                <div class="alert-icon <?= $notif['type_code'] === 'MEMBER_REFUSED' ? 'alert-critique' : 'alert-info' ?>">
                    <?= $notif['type_code'] === 'MEMBER_REFUSED' ? '⛔' : '🔔' ?>
                </div>
                <div class="alert-body">
                    <p class="alert-title"><?= h($notif['titre']) ?></p>
                    <p class="alert-desc"><?= h($notif['message']) ?></p>
                    <p class="alert-date"><?= h(format_datetime($notif['created_at'])) ?></p>
                </div>
                <?php if (!$notif['lue']): ?>
                <form method="post" action="<?= h(route_url('notifications/marquerLu')) ?>">
                    <input type="hidden" name="id" value="<?= h($notif['notification_code']) ?>">
                    <button type="submit" class="btn btn-ghost btn-sm"><?= h(t('notifications.mark_read')) ?></button>
                </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
