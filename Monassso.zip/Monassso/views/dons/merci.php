<?php $publicTitle = t('dons.merci.title'); require APP_DIR . '/views/layout/public-start.php'; ?>
<div class="thankyou-page">
    <div class="card thankyou-card"><div class="card-body">
        <p class="page-eyebrow"><?= h(t('dons.merci.eyebrow')) ?></p>
        <h1 class="page-title"><?= h(t('dons.merci.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('dons.merci.subtitle', ['titre' => $besoin['titre']])) ?></p>

        <div class="mt-2">
            <p class="kpi-label"><?= h(t('common.amount')) ?></p>
            <p class="page-title"><?= h(format_money((float) $don['montant'])) ?></p>
        </div>

        <?php if ($besoin): ?>
        <div class="mt-2">
            <?php render_progress_bar((float) $besoin['montant_collecte'], (float) $besoin['montant_recherche']); ?>
        </div>
        <?php endif; ?>

        <div class="row mt-2">
            <a class="btn btn-accent" href="<?= h(route_url('dons/index')) ?>"><?= h(t('dons.merci.back_to_list')) ?></a>
            <a class="btn btn-ghost" href="<?= h(route_url('home/index')) ?>"><?= h(t('common.back_home')) ?></a>
        </div>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/public-end.php'; ?>
