<?php $publicTitle = t('dons.index.title'); require APP_DIR . '/views/layout/public-start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('dons.index.eyebrow')) ?></p>
        <h1 class="page-title"><?= h(t('dons.index.title')) ?></h1>
        <p class="page-subtitle"><?= h(t('dons.index.subtitle')) ?></p>
    </div>

    <?php if (!$besoins): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('dons.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="besoin-grid">
        <?php foreach ($besoins as $besoin): ?>
        <?php
            $joursRestants = null;
            if (!empty($besoin['date_fin'])) {
                $diff = (strtotime($besoin['date_fin']) - strtotime(date('Y-m-d'))) / 86400;
                $joursRestants = (int) ceil($diff);
            }
        ?>
        <div class="card besoin-card">
            <?php if (!empty($besoin['photo_chemin'])): ?>
                <img class="besoin-photo" src="<?= h(asset_url('/' . $besoin['photo_chemin'])) ?>" alt="">
            <?php else: ?>
                <div class="besoin-photo-placeholder">🤝</div>
            <?php endif; ?>
            <div class="besoin-card-body">
                <p class="besoin-org"><?= h(pays_label($besoin['pays_code'])) ?> · <?= h($besoin['organisation_nom']) ?></p>
                <p class="besoin-title"><?= h($besoin['titre']) ?></p>
                <?php render_progress_bar((float) $besoin['montant_collecte'], (float) $besoin['montant_recherche']); ?>
                <?php if ($joursRestants !== null): ?>
                    <p class="text-faint"><?= h(t('dons.days_left', ['count' => max(0, $joursRestants)])) ?></p>
                <?php endif; ?>
                <a class="btn btn-accent mt-2" href="<?= h(route_url('dons/besoin', ['id' => $besoin['besoin_code']])) ?>"><?= h(t('dons.give_btn')) ?></a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/public-end.php'; ?>
