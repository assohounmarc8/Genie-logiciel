<?php $publicTitle = $besoin['titre']; require APP_DIR . '/views/layout/public-start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(pays_label($besoin['pays_code'])) ?> · <?= h($besoin['organisation_nom']) ?></p>
            <h1 class="page-title"><?= h($besoin['titre']) ?></h1>
        </div>
        <?= enum_badge_html('besoin_statut', $besoin['statut']) ?>
    </div>

    <div class="card"><div class="card-body">
        <?php if (!empty($besoin['photo_chemin'])): ?>
            <img class="besoin-photo" src="<?= h(asset_url('/' . $besoin['photo_chemin'])) ?>" alt="">
        <?php endif; ?>
        <?php render_progress_bar((float) $besoin['montant_collecte'], (float) $besoin['montant_recherche']); ?>
        <p class="kpi-label mt-2"><?= h(t('besoins.field.description')) ?></p>
        <p class="mt-2"><?= nl2br(h($besoin['description'])) ?></p>

        <?php if ($documents): ?>
        <p class="kpi-label mt-2"><?= h(t('besoins.documents_title')) ?></p>
        <ul class="mt-2">
            <?php foreach ($documents as $doc): ?>
            <li><a href="<?= h(route_url('dons/document', ['id' => $doc['besoin_document_code']])) ?>"><?= h($doc['nom_original']) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </div></div>

    <?php if ($besoin['statut'] === 'ACTIF'): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('dons.form.title')) ?></p>
        <?php if ($errors): ?>
            <div class="mt-2">
                <?php foreach ($errors as $error): ?><p class="text-danger"><?= h($error) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?= h(route_url('dons/faireDon')) ?>" class="donor-form-grid mt-2">
            <input type="hidden" name="besoin" value="<?= h($besoin['besoin_code']) ?>">
            <div>
                <label class="control-label"><?= h(t('dons.field.donateur')) ?></label>
                <input type="text" name="donateur_nom" class="control" required>
            </div>
            <div>
                <label class="control-label"><?= h(t('dons.field.email')) ?></label>
                <input type="email" name="donateur_email" class="control">
            </div>
            <div>
                <label class="control-label"><?= h(t('common.amount')) ?></label>
                <input type="number" name="montant" class="control" min="1" step="1" required>
            </div>
            <div>
                <label class="control-label"><?= h(t('dons.field.mode')) ?></label>
                <select name="mode_paiement" class="control">
                    <?php foreach (modes_paiement() as $mode): ?>
                        <option value="<?= h($mode) ?>"><?= h(t('enum.mode_paiement.' . $mode)) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="full-width">
                <label class="control-label"><?= h(t('dons.field.message')) ?></label>
                <textarea name="message" class="control" rows="2"></textarea>
            </div>
            <div class="full-width row">
                <label class="row"><input type="checkbox" name="anonyme" value="1"> <?= h(t('dons.field.anonyme')) ?></label>
            </div>
            <div class="full-width">
                <button type="submit" class="btn btn-accent"><?= h(t('dons.give_btn')) ?></button>
            </div>
        </form>
    </div></div>
    <?php else: ?>
    <div class="card"><div class="card-body"><?= h(t('dons.closed_notice')) ?></div></div>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/public-end.php'; ?>
