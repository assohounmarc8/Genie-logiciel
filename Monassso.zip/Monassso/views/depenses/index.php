<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
        <h1 class="page-title"><?= h(t('depenses.index.title', ['org' => $organisation['nom']])) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('depenses.new_title')) ?></p>
        <form method="post" action="<?= h(route_url('depenses/creer')) ?>" class="form-grid mt-2">
            <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
            <div class="field">
                <label><?= h(t('depenses.field.libelle')) ?></label>
                <input type="text" name="libelle" required placeholder="<?= h(t('depenses.field.libelle_placeholder')) ?>">
            </div>
            <div class="field">
                <label><?= h(t('depenses.field.categorie')) ?></label>
                <input type="text" name="categorie" placeholder="<?= h(t('depenses.field.categorie_placeholder')) ?>">
            </div>
            <div class="field">
                <label><?= h(t('common.amount')) ?></label>
                <input type="number" name="montant" min="1" step="1" required>
            </div>
            <div class="field">
                <label><?= h(t('depenses.field.date')) ?></label>
                <input type="date" name="date_depense" value="<?= h(date('Y-m-d')) ?>">
            </div>
            <div class="field" style="align-self:end;">
                <button type="submit" class="btn btn-primary"><?= h(t('depenses.add_btn')) ?></button>
            </div>
        </form>
    </div></div>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('depenses.field.libelle')) ?></th>
            <th><?= h(t('depenses.field.categorie')) ?></th>
            <th><?= h(t('common.amount')) ?></th>
            <th><?= h(t('depenses.field.date')) ?></th>
        </tr></thead>
        <tbody>
            <?php if (!$depenses): ?><tr><td colspan="4" class="table-empty"><?= h(t('depenses.index.empty')) ?></td></tr><?php endif; ?>
            <?php foreach ($depenses as $dep): ?>
            <tr>
                <td><?= h($dep['libelle']) ?></td>
                <td><?= h($dep['categorie'] ?: '—') ?></td>
                <td><?= h(format_money((float) $dep['montant'])) ?></td>
                <td><?= h(format_date($dep['date_depense'])) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
