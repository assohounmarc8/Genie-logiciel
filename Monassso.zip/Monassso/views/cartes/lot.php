<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between no-print">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('cartes.lot.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <button type="button" class="btn btn-primary btn-sm" onclick="window.print();"><?= h(t('evenements.pv.print_btn')) ?></button>
    </div>

    <?php if (!$cartes): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('cartes.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="cartes-print-grid">
        <?php foreach ($cartes as $carte): ?>
            <?php render_carte_visual($carte, $organisation, ['nom' => $carte['nom'], 'photo_chemin' => $carte['photo_chemin']], $carte['numero_adherent'] ?: ''); ?>
        <?php endforeach; ?>
    </div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
