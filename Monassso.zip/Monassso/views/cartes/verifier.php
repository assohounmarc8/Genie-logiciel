<?php $publicTitle = t('cartes.verifier.title'); require APP_DIR . '/views/layout/public-start.php'; ?>
<div class="thankyou-page">
    <div class="card thankyou-card"><div class="card-body">
        <p class="page-eyebrow"><?= h(t('cartes.verifier.eyebrow')) ?></p>

        <?php if (!empty($membre['photo_chemin'])): ?>
            <img src="<?= h(asset_url('/' . $membre['photo_chemin'])) ?>" alt="" style="width:96px;height:96px;border-radius:50%;object-fit:cover;margin:0 auto 12px;display:block;">
        <?php else: ?>
            <div class="id-card-photo" style="margin:0 auto 12px;border-radius:50%;">👤</div>
        <?php endif; ?>

        <h1 class="page-title"><?= h($membre['nom']) ?></h1>
        <p class="page-subtitle"><?= h($organisation['nom']) ?></p>

        <div class="mt-2"><?= enum_badge_html('carte_statut', $carte['statut']) ?></div>

        <?php if ($carte['valide_jusqu_au']): ?>
            <p class="text-faint mt-2"><?= h(t('cartes.field.valide_jusquau')) ?> : <?= h(format_date($carte['valide_jusqu_au'])) ?></p>
        <?php endif; ?>

        <?php if ($evenementLive): ?>
            <div class="card mt-2"><div class="card-body">
                <?php if ($dejaPresent): ?>
                    <p><?= h(t('cartes.verifier.deja_present', ['titre' => $evenementLive['titre']])) ?></p>
                <?php else: ?>
                    <p class="mt-0"><?= h(t('cartes.verifier.marquer_hint', ['titre' => $evenementLive['titre']])) ?></p>
                    <form method="post" action="<?= h(route_url('cartes/marquerPresenceParCarte')) ?>" class="mt-2">
                        <input type="hidden" name="token" value="<?= h($carte['qr_token']) ?>">
                        <input type="hidden" name="evenement" value="<?= h($evenementLive['evenement_code']) ?>">
                        <button type="submit" class="btn btn-accent" <?= $carte['statut'] !== 'ACTIF' ? 'disabled' : '' ?>><?= h(t('cartes.verifier.marquer_btn')) ?></button>
                    </form>
                <?php endif; ?>
            </div></div>
        <?php endif; ?>
    </div></div>
</div>
<?php require APP_DIR . '/views/layout/public-end.php'; ?>
