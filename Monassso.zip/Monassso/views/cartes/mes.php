<?php $errors = flash_get('errors', []); require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div>
        <p class="page-eyebrow"><?= h(t('nav.group.my_space')) ?></p>
        <h1 class="page-title"><?= h(t('cartes.mes.title')) ?></h1>
    </div>

    <?php if ($errors): ?>
        <div class="card"><div class="card-body">
            <?php foreach ($errors as $error): ?><p><?= h($error) ?></p><?php endforeach; ?>
        </div></div>
    <?php endif; ?>

    <?php if (empty($user['photo_chemin'])): ?>
    <div class="card"><div class="card-body">
        <p class="card-title"><?= h(t('cartes.carte.photo_title')) ?></p>
        <p class="text-faint mt-2"><?= h(t('cartes.carte.photo_hint')) ?></p>
        <form method="post" action="<?= h(route_url('cartes/uploaderPhoto')) ?>" enctype="multipart/form-data" class="row mt-2">
            <input type="file" name="photo" accept="image/png,image/jpeg" required>
            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('cartes.carte.photo_submit')) ?></button>
        </form>
    </div></div>
    <?php endif; ?>

    <?php if (!$cartes && !$orgsSansCarte): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('cartes.mes.empty')) ?></div></div>
    <?php endif; ?>

    <div class="cartes-print-grid">
        <?php foreach ($cartes as $carte): ?>
            <div>
                <?php render_carte_visual($carte, ['nom' => $carte['organisation_nom'], 'logo_chemin' => $carte['logo_chemin']], $user, $carte['numero_adherent'] ?: ''); ?>
                <a class="btn btn-outline btn-sm mt-2" href="<?= h(route_url('cartes/carte', ['id' => $carte['carte_code']])) ?>"><?= h(t('cartes.carte.title')) ?></a>
            </div>
        <?php endforeach; ?>
    </div>

    <?php foreach ($orgsSansCarte as $membership): ?>
        <div class="card"><div class="card-body">
            <p class="card-title"><?= h($membership['organisation_nom']) ?></p>
            <p class="text-faint mt-2"><?= h(t('cartes.mes.no_card_hint', ['annee' => date('Y')])) ?></p>
        </div></div>
    <?php endforeach; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
