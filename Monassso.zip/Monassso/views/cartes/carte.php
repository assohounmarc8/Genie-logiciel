<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between no-print">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('cartes.carte.title')) ?></h1>
        </div>
        <div class="row">
            <button type="button" class="btn btn-primary btn-sm" onclick="window.print();"><?= h(t('cartes.carte.download_btn')) ?></button>
            <button type="button" class="btn btn-outline btn-sm" onclick="window.print();"><?= h(t('cartes.carte.add_to_phone_btn')) ?></button>
        </div>
    </div>

    <?php if ($carte['statut'] !== 'ACTIF'): ?>
        <div class="card"><div class="card-body"><?= h(t('cartes.carte.not_active_hint')) ?></div></div>
    <?php endif; ?>

    <?php render_carte_visual($carte, $organisation, $membre, $numeroAdherent); ?>

    <?php if ($isOwner): ?>
    <div class="card no-print"><div class="card-body">
        <p class="card-title"><?= h(t('cartes.carte.photo_title')) ?></p>
        <p class="text-faint mt-2"><?= h(t('cartes.carte.photo_hint')) ?></p>
        <form method="post" action="<?= h(route_url('cartes/uploaderPhoto')) ?>" enctype="multipart/form-data" class="row mt-2">
            <input type="file" name="photo" accept="image/png,image/jpeg" required>
            <button type="submit" class="btn btn-primary btn-sm"><?= h(t('cartes.carte.photo_submit')) ?></button>
        </form>
    </div></div>
    <?php endif; ?>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
