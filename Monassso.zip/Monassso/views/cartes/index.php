<?php require APP_DIR . '/views/layout/start.php'; ?>
<div class="stack">
    <div class="row between">
        <div>
            <p class="page-eyebrow"><?= h(t('common.organisation')) ?></p>
            <h1 class="page-title"><?= h(t('cartes.index.title', ['org' => $organisation['nom']])) ?></h1>
        </div>
        <div class="row">
            <a class="btn btn-outline btn-sm" href="<?= h(route_url('cartes/lot', ['org' => $organisation['organisation_code']])) ?>"><?= h(t('cartes.lot_btn')) ?></a>
            <form method="post" action="<?= h(route_url('cartes/emettre')) ?>">
                <input type="hidden" name="org" value="<?= h($organisation['organisation_code']) ?>">
                <button type="submit" class="btn btn-primary btn-sm"><?= h(t('cartes.emettre_btn')) ?></button>
            </form>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="card"><div class="card-body"><?= h($success) ?></div></div>
    <?php endif; ?>

    <?php if (!$cartes): ?>
        <div class="card"><div class="card-body table-empty"><?= h(t('cartes.index.empty')) ?></div></div>
    <?php endif; ?>

    <div class="table-wrap"><table class="data-table">
        <thead><tr>
            <th><?= h(t('common.name')) ?></th>
            <th><?= h(t('cartes.field.numero')) ?></th>
            <th><?= h(t('cartes.field.statut')) ?></th>
            <th><?= h(t('cartes.field.valide_jusquau')) ?></th>
            <th><?= h(t('common.actions')) ?></th>
        </tr></thead>
        <tbody>
            <?php foreach ($cartes as $carte): ?>
            <tr>
                <td><?= h($carte['nom']) ?></td>
                <td class="text-mono"><?= h($carte['numero_adherent'] ?: '—') ?></td>
                <td><?= enum_badge_html('carte_statut', $carte['statut']) ?></td>
                <td><?= h($carte['valide_jusqu_au'] ? format_date($carte['valide_jusqu_au']) : '—') ?></td>
                <td class="row">
                    <a class="btn btn-outline btn-sm" href="<?= h(route_url('cartes/carte', ['id' => $carte['carte_code']])) ?>"><?= h(t('cartes.view_btn')) ?></a>
                    <?php if ($carte['statut'] === 'BLOQUEE'): ?>
                        <form method="post" action="<?= h(route_url('cartes/debloquer')) ?>">
                            <input type="hidden" name="id" value="<?= h($carte['carte_code']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('cartes.debloquer_btn')) ?></button>
                        </form>
                    <?php else: ?>
                        <form method="post" action="<?= h(route_url('cartes/bloquer')) ?>" onsubmit="return confirm('<?= h(t('cartes.confirm_bloquer')) ?>');">
                            <input type="hidden" name="id" value="<?= h($carte['carte_code']) ?>">
                            <button type="submit" class="btn btn-outline btn-sm"><?= h(t('cartes.bloquer_btn')) ?></button>
                        </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table></div>
</div>
<?php require APP_DIR . '/views/layout/end.php'; ?>
