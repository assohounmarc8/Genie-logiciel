<?php

return [
    // Codes pays : simple constante applicative (pays n'est pas une des 10 tables imposées)
    'pays' => [
        'CIV' => ['nom' => "Côte d'Ivoire", 'drapeau' => '🇨🇮'],
        'MLI' => ['nom' => 'Mali', 'drapeau' => '🇲🇱'],
        'BEN' => ['nom' => 'Bénin', 'drapeau' => '🇧🇯'],
        'NER' => ['nom' => 'Niger', 'drapeau' => '🇳🇪'],
        'MDG' => ['nom' => 'Madagascar', 'drapeau' => '🇲🇬'],
        'BFA' => ['nom' => 'Burkina Faso', 'drapeau' => '🇧🇫'],
    ],

    // Libellés résolus via t('enum.<groupe>.<code>') dans lang/*.php — seule la couleur du badge
    // (variant) reste ici, car elle ne dépend pas de la langue.
    'user_statut' => [
        'ACT' => ['variant' => 'success'],
        'SUS' => ['variant' => 'danger'],
        'SUP' => ['variant' => 'neutral'],
    ],

    'org_statut_validation' => [
        'ATT' => ['variant' => 'warning'],
        'VAL' => ['variant' => 'success'],
        'REF' => ['variant' => 'danger'],
    ],

    'org_statut_abonnement' => [
        'EXP' => ['variant' => 'danger'],
        'ACT' => ['variant' => 'success'],
        'SUS' => ['variant' => 'warning'],
    ],

    'membre_statut' => [
        'ATT' => ['variant' => 'warning'],
        'ACT' => ['variant' => 'success'],
        'SUS' => ['variant' => 'danger'],
        'REF' => ['variant' => 'neutral'],
    ],

    'cotisation_statut' => [
        'ACT' => ['variant' => 'success'],
        'CLO' => ['variant' => 'neutral'],
    ],

    'paiement_statut' => [
        'DU' => ['variant' => 'warning'],
        'PAY' => ['variant' => 'success'],
        'ANN' => ['variant' => 'neutral'],
    ],

    'abonnement_statut' => [
        'ACT' => ['variant' => 'success'],
        'EXP' => ['variant' => 'danger'],
        'SUS' => ['variant' => 'warning'],
    ],

    'besoin_statut' => [
        'ACTIF' => ['variant' => 'success'],
        'FINANCE' => ['variant' => 'success'],
        'FERME' => ['variant' => 'neutral'],
    ],

    // Contraintes d'upload de documents (Documents — PV, statuts, rapports)
    'upload' => [
        'max_size' => 10 * 1024 * 1024, // 10 Mo
        'allowed' => [
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'png' => 'image/png',
        ],
    ],

    // Matrice de permissions V1 — pré-remplissage à la création d'un rôle ET permissions par défaut
    // seedées automatiquement via RoleModel::ensureDefaultRoles() pour les 4 rôles standards.
    'default_role_permissions' => [
        'PRESIDENT' => [
            'gerer_membres', 'valider_adherent', 'gerer_roles', 'creer_cotisation', 'voir_finances',
            'gerer_projets', 'gerer_documents', 'envoyer_notification', 'voir_audit', 'gerer_organisation',
            'gerer_besoins',
        ],
        'SECRETAIRE' => [
            'gerer_membres', 'valider_adherent', 'gerer_documents', 'gerer_projets',
            'envoyer_notification', 'voir_audit', 'gerer_besoins',
        ],
        'TRESORIER' => [
            'creer_cotisation', 'valider_paiement', 'voir_finances', 'voir_membres', 'voir_audit',
        ],
        'MEMBRE' => [
            'voir_profil', 'payer_cotisation', 'voir_documents', 'voir_projets', 'voir_mes_audit',
        ],
    ],
];
