<?php

return [
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'monasso',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
];
