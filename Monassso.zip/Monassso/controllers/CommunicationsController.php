<?php

class CommunicationsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'envoyer_notification');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('communications/index', ['organisation' => $org]);
    }

    public function envoyer(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'envoyer_notification');
        $org = OrganisationModel::findByCode($orgCode);

        $cible = $_POST['cible'] ?? 'TOUS';
        if (!in_array($cible, ['MEMBRES', 'BUREAU', 'TOUS'], true)) {
            $cible = 'TOUS';
        }
        $titre = trim($_POST['titre'] ?? '');
        $message = trim($_POST['message'] ?? '');

        $errors = [];
        if ($titre === '') {
            $errors[] = t('validation.name_required');
        }
        if ($message === '') {
            $errors[] = t('validation.libelle_required');
        }

        if ($errors) {
            flash_set('errors', $errors);
            flash_set('old', $_POST);
            redirect_route('communications/index', ['org' => $orgCode]);
        }

        $recipients = OrganisationUserModel::activeMembersByRoleGroup($orgCode, $cible);
        foreach ($recipients as $recipient) {
            NotificationModel::create($recipient['user_code'], $orgCode, 'BROADCAST', $titre, $message);
        }

        Audit::log($user['user_code'], $orgCode, 'SEND_NOTIFICATION', null, [
            'cible' => $cible,
            'titre' => $titre,
            'destinataires' => count($recipients),
        ]);

        flash_set('success', t('communications.success', ['count' => count($recipients)]));
        redirect_route('communications/index', ['org' => $orgCode]);
    }
}
