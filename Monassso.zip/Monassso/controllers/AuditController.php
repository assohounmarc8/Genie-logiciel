<?php

class AuditController
{
    public function index(): void
    {
        $user = Middleware::requireLogin();

        if ($user['type_compte'] === 'SUPER_ADMIN') {
            $logs = AuditModel::forSuperAdmin();
            $scope = t('audit.scope.all');
        } elseif ($user['type_compte'] === 'ADMIN_ORGA') {
            $org = OrganisationModel::findByAdmin($user['user_code']);
            $logs = $org ? AuditModel::forOrganisation($org['organisation_code']) : [];
            $scope = $org ? $org['nom'] : t('audit.scope.none');
        } else {
            $membership = OrganisationUserModel::primaryActiveMembership($user['user_code']);
            if ($membership && $membership['role_code'] && Middleware::can($membership['organisation_code'], 'voir_audit')) {
                $logs = AuditModel::forOrganisation($membership['organisation_code']);
                $scope = $membership['organisation_nom'];
            } else {
                $logs = AuditModel::forActor($user['user_code']);
                $scope = t('audit.scope.mine');
            }
        }

        View::render('audit/index', ['logs' => $logs, 'scope' => $scope]);
    }
}
