<?php

class DashboardController
{
    public function index(): void
    {
        $user = Middleware::requireLogin();
        $data = ['user' => $user, 'kpis' => [], 'audit' => []];

        if ($user['type_compte'] === 'SUPER_ADMIN') {
            $orgs = OrganisationModel::all();
            $data['kpis'] = [
                ['label' => t('kpi.organisations'), 'value' => (string) count($orgs)],
                ['label' => t('kpi.pending_validation'), 'value' => (string) count(array_filter($orgs, fn ($o) => $o['statut_validation'] === 'ATT'))],
                ['label' => t('kpi.active_subscriptions'), 'value' => (string) count(array_filter($orgs, fn ($o) => $o['statut_abonnement'] === 'ACT'))],
            ];
            $data['audit'] = AuditModel::forSuperAdmin(10);
        } elseif ($user['type_compte'] === 'ADMIN_ORGA') {
            $org = OrganisationModel::findByAdmin($user['user_code']);
            $data['organisation'] = $org;
            if ($org) {
                $members = OrganisationUserModel::listByOrganisation($org['organisation_code']);
                $stats = PaiementModel::statsForOrganisation($org['organisation_code']);
                $data['kpis'] = [
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                    ['label' => t('kpi.subscription_status'), 'value' => enum_label('org_statut_abonnement', $org['statut_abonnement'])],
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                ];
                $data['audit'] = AuditModel::forOrganisation($org['organisation_code'], 10);
            }
        } else {
            $membership = OrganisationUserModel::primaryActiveMembership($user['user_code']);
            $roleName = $membership['nom_role'] ?? null;
            $orgCode = $membership['organisation_code'] ?? null;
            $data['roleName'] = $roleName;
            $data['roleOrgName'] = $membership['organisation_nom'] ?? null;
            $data['showJoinPrompt'] = !$membership;

            if ($membership && $roleName === 'PRESIDENT') {
                $members = OrganisationUserModel::listByOrganisation($orgCode);
                $stats = PaiementModel::statsForOrganisation($orgCode);
                $org = OrganisationModel::findByCode($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                    ['label' => t('kpi.subscription_status'), 'value' => enum_label('org_statut_abonnement', $org['statut_abonnement'] ?? 'EXP')],
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                ];
            } elseif ($membership && $roleName === 'SECRETAIRE') {
                $members = OrganisationUserModel::listByOrganisation($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.pending_requests'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ATT'))],
                    ['label' => t('kpi.active_members'), 'value' => (string) count(array_filter($members, fn ($m) => $m['statut'] === 'ACT'))],
                ];
            } elseif ($membership && $roleName === 'TRESORIER') {
                $stats = PaiementModel::statsForOrganisation($orgCode);
                $data['kpis'] = [
                    ['label' => t('kpi.amount_to_collect'), 'value' => format_money($stats['due_amount'])],
                    ['label' => t('kpi.payment_rate'), 'value' => $stats['paid_rate'] . '%'],
                    ['label' => t('kpi.dues_unpaid'), 'value' => (string) $stats['due_count']],
                ];
            } else {
                $memberships = OrganisationUserModel::listByUser($user['user_code']);
                $paiements = PaiementModel::listByUser($user['user_code']);
                $data['memberships'] = $memberships;
                $data['kpis'] = [
                    ['label' => t('kpi.joined_orgs'), 'value' => (string) count($memberships)],
                    ['label' => t('kpi.dues_due'), 'value' => (string) count(array_filter($paiements, fn ($p) => $p['statut_paiement'] === 'DU'))],
                    ['label' => t('kpi.dues_paid'), 'value' => (string) count(array_filter($paiements, fn ($p) => $p['statut_paiement'] === 'PAY'))],
                ];
            }

            if ($orgCode && Middleware::can($orgCode, 'voir_audit')) {
                $data['audit'] = AuditModel::forOrganisation($orgCode, 10);
            } else {
                $data['audit'] = AuditModel::forActor($user['user_code'], 10);
            }
        }

        View::render('dashboard/index', $data);
    }
}
