<?php

class CotisationsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('cotisations/index', [
            'organisation' => $org,
            'cotisations' => CotisationModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'creer_cotisation');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $libelle = trim($_POST['libelle'] ?? '');
            $montant = (float) ($_POST['montant'] ?? 0);
            $devise = trim($_POST['devise'] ?? '') ?: 'XOF';

            $errors = [];
            if ($libelle === '') {
                $errors[] = t('validation.libelle_required');
            }
            if ($montant <= 0) {
                $errors[] = t('validation.montant_positive');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('cotisations/creer', ['org' => $orgCode]);
            }

            $cotisation = CotisationModel::create($orgCode, $libelle, $montant, $devise);
            Audit::log($user['user_code'], $orgCode, 'CREATE_COTI', $cotisation['cotisation_code'], [
                'libelle' => $libelle,
                'montant' => $montant,
            ]);

            $members = OrganisationUserModel::activeMembers($orgCode);
            foreach ($members as $member) {
                $paiement = PaiementModel::createDue($cotisation['cotisation_code'], $member['user_code'], $montant);
                NotificationModel::create(
                    $member['user_code'],
                    $orgCode,
                    'COTISATION_PAIEMENT_REQUIS',
                    t('notif.cotisation_a_payer.title'),
                    t('notif.cotisation_a_payer.message', ['org' => $org['nom'], 'libelle' => $libelle]),
                    route_url('cotisations/confirmerPaiement', ['id' => $paiement['paiement_code']])
                );
            }

            redirect_route('cotisations/suivi', ['id' => $cotisation['cotisation_code']]);
        }

        View::render('cotisations/creer', ['organisation' => $org]);
    }

    public function suivi(): void
    {
        $code = $_GET['id'] ?? '';
        $cotisation = CotisationModel::findByCode($code);
        if (!$cotisation) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requirePermission($cotisation['organisation_code'], 'voir_finances');

        View::render('cotisations/suivi', [
            'cotisation' => $cotisation,
            'paiements' => PaiementModel::listByCotisation($code),
            'canValiderPaiement' => Middleware::can($cotisation['organisation_code'], 'valider_paiement'),
        ]);
    }

    public function marquerPaye(): void
    {
        $paiementCode = $_POST['id'] ?? '';
        $paiement = PaiementModel::findByCode($paiementCode);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $cotisation = CotisationModel::findByCode($paiement['cotisation_code']);
        $user = Middleware::requirePermission($cotisation['organisation_code'], 'valider_paiement');

        if ($paiement['statut_paiement'] === 'DU') {
            PaiementModel::markPaid($paiementCode);
            Audit::log($user['user_code'], $cotisation['organisation_code'], 'PAY_COTI', $paiementCode, [
                'montant' => $paiement['montant'],
                'encaisse_par' => $user['user_code'],
            ]);
            CarteModel::issueOrUpdate($cotisation['organisation_code'], $paiement['user_code']);
        }

        redirect_route('cotisations/suivi', ['id' => $paiement['cotisation_code']]);
    }

    public function marquerExonere(): void
    {
        $paiementCode = $_POST['id'] ?? '';
        $paiement = PaiementModel::findByCode($paiementCode);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $cotisation = CotisationModel::findByCode($paiement['cotisation_code']);
        $user = Middleware::requirePermission($cotisation['organisation_code'], 'valider_paiement');

        if ($paiement['statut_paiement'] === 'DU') {
            PaiementModel::markExonere($paiementCode);
            Audit::log($user['user_code'], $cotisation['organisation_code'], 'EXONERE_COTI', $paiementCode, [
                'montant' => $paiement['montant'],
            ]);
        }

        redirect_route('cotisations/suivi', ['id' => $paiement['cotisation_code']]);
    }

    /** Relance un membre en retard par mail + notification in-app (pas de SMS) — utilisé depuis le tableau de bord. */
    public function relancer(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $memberUserCode = $_POST['user'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_paiement');

        $org = OrganisationModel::findByCode($orgCode);
        $membre = UserModel::findByCode($memberUserCode);
        $montantDu = PaiementModel::totalDueForUser($orgCode, $memberUserCode);

        if ($org && $membre && $montantDu > 0) {
            NotificationModel::create(
                $memberUserCode,
                $orgCode,
                'RELANCE_COTISATION',
                t('notif.relance_cotisation.title'),
                t('notif.relance_cotisation.message', ['org' => $org['nom'], 'montant' => format_money($montantDu)])
            );

            Mailer::send(
                $membre['email'],
                $membre['nom'],
                t('mail.relance_cotisation.subject', ['org' => $org['nom']]),
                mail_template(
                    t('mail.relance_cotisation.subject', ['org' => $org['nom']]),
                    '<p>' . t('mail.relance_cotisation.body', ['montant' => format_money($montantDu)]) . '</p>'
                ),
                'RELANCE_COTISATION',
                $memberUserCode,
                $orgCode
            );

            Audit::log($user['user_code'], $orgCode, 'RELANCE_COTISATION', $memberUserCode, ['montant' => $montantDu]);
        }

        redirect_route('dashboard/index');
    }

    public function exportSuivi(): void
    {
        $code = $_GET['id'] ?? '';
        $cotisation = CotisationModel::findByCode($code);
        if (!$cotisation) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requirePermission($cotisation['organisation_code'], 'voir_finances');

        $rows = [];
        foreach (PaiementModel::listByCotisation($code) as $p) {
            $rows[] = [
                $p['nom'],
                $p['email'],
                $p['montant'],
                enum_label('paiement_statut', $p['statut_paiement']),
                $p['date_paiement'] ?? '',
            ];
        }

        send_csv(
            'cotisation-' . $code . '.csv',
            ['Nom', 'Email', 'Montant', 'Statut', 'Date de paiement'],
            $rows
        );
    }

    public function mes(): void
    {
        $user = Middleware::requireLogin();
        View::render('cotisations/mes', ['paiements' => PaiementModel::listByUser($user['user_code'])]);
    }

    /** Écran de confirmation avant paiement — organisation, motif (libellé de la cotisation), montant. */
    public function confirmerPaiement(): void
    {
        $user = Middleware::requireLogin();
        $paiementCode = $_GET['id'] ?? '';
        $paiement = PaiementModel::findByCode($paiementCode);

        if (!$paiement || $paiement['user_code'] !== $user['user_code']) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $cotisation = CotisationModel::findByCode($paiement['cotisation_code']);
        $org = OrganisationModel::findByCode($cotisation['organisation_code']);

        View::render('cotisations/confirmerPaiement', [
            'paiement' => $paiement,
            'cotisation' => $cotisation,
            'organisation' => $org,
        ]);
    }

    public function payer(): void
    {
        $user = Middleware::requireLogin();
        $paiementCode = $_POST['id'] ?? '';
        $paiement = PaiementModel::findByCode($paiementCode);

        if (!$paiement || $paiement['user_code'] !== $user['user_code']) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        if ($paiement['statut_paiement'] === 'DU') {
            PaiementModel::markPaid($paiementCode);
            $cotisation = CotisationModel::findByCode($paiement['cotisation_code']);
            Audit::log($user['user_code'], $cotisation['organisation_code'], 'PAY_COTI', $paiementCode, [
                'montant' => $paiement['montant'],
            ]);
            CarteModel::issueOrUpdate($cotisation['organisation_code'], $user['user_code']);
        }

        redirect_route('cotisations/mes');
    }
}
