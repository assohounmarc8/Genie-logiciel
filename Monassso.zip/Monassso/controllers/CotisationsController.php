<?php

class CotisationsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('cotisations/index', [
            'organisation' => $org,
            'cotisations' => CotisationModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'creer_cotisation');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $libelle = trim($_POST['libelle'] ?? '');
            $montant = (float) ($_POST['montant'] ?? 0);
            $devise = trim($_POST['devise'] ?? '') ?: 'XOF';

            $errors = [];
            if ($libelle === '') {
                $errors[] = t('validation.libelle_required');
            }
            if ($montant <= 0) {
                $errors[] = t('validation.montant_positive');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('cotisations/creer', ['org' => $orgCode]);
            }

            $cotisation = CotisationModel::create($orgCode, $libelle, $montant, $devise);
            Audit::log($user['user_code'], $orgCode, 'CREATE_COTI', $cotisation['cotisation_code'], [
                'libelle' => $libelle,
                'montant' => $montant,
            ]);

            $members = OrganisationUserModel::activeMembers($orgCode);
            foreach ($members as $member) {
                PaiementModel::createDue($cotisation['cotisation_code'], $member['user_code'], $montant);
            }

            redirect_route('cotisations/suivi', ['id' => $cotisation['cotisation_code']]);
        }

        View::render('cotisations/creer', ['organisation' => $org]);
    }

    public function suivi(): void
    {
        $code = $_GET['id'] ?? '';
        $cotisation = CotisationModel::findByCode($code);
        if (!$cotisation) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requirePermission($cotisation['organisation_code'], 'voir_finances');

        View::render('cotisations/suivi', [
            'cotisation' => $cotisation,
            'paiements' => PaiementModel::listByCotisation($code),
        ]);
    }

    public function mes(): void
    {
        $user = Middleware::requireLogin();
        View::render('cotisations/mes', ['paiements' => PaiementModel::listByUser($user['user_code'])]);
    }

    public function payer(): void
    {
        $user = Middleware::requireLogin();
        $paiementCode = $_POST['id'] ?? '';
        $paiement = PaiementModel::findByCode($paiementCode);

        if (!$paiement || $paiement['user_code'] !== $user['user_code']) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        if ($paiement['statut_paiement'] === 'DU') {
            PaiementModel::markPaid($paiementCode);
            $cotisation = CotisationModel::findByCode($paiement['cotisation_code']);
            Audit::log($user['user_code'], $cotisation['organisation_code'], 'PAY_COTI', $paiementCode, [
                'montant' => $paiement['montant'],
            ]);
        }

        redirect_route('cotisations/mes');
    }
}
