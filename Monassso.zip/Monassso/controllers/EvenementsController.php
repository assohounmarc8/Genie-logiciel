<?php

class EvenementsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_evenements');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('evenements/index', [
            'organisation' => $org,
            'evenements' => EvenementModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_evenements');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titre = trim($_POST['titre'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $lieu = trim($_POST['lieu'] ?? '');
            $dateHeure = trim($_POST['date_heure'] ?? '');

            $errors = [];
            if ($titre === '') {
                $errors[] = t('validation.name_required');
            }
            if ($dateHeure === '') {
                $errors[] = t('validation.date_required');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('evenements/creer', ['org' => $orgCode]);
            }

            $evenement = EvenementModel::create([
                'organisation_code' => $orgCode,
                'cree_par_user_code' => $user['user_code'],
                'titre' => $titre,
                'description' => $description,
                'lieu' => $lieu,
                'date_heure' => str_replace('T', ' ', $dateHeure),
            ]);

            Audit::log($user['user_code'], $orgCode, 'EVENT_CREATE', $evenement['evenement_code'], [
                'titre' => $titre,
                'date_heure' => $evenement['date_heure'],
            ]);

            foreach (OrganisationUserModel::activeMembers($orgCode) as $membre) {
                NotificationModel::create(
                    $membre['user_code'],
                    $orgCode,
                    'NOUVEL_EVENEMENT',
                    t('notif.nouvel_evenement.title'),
                    t('notif.nouvel_evenement.message', ['titre' => $titre, 'date' => format_datetime($evenement['date_heure'])])
                );
            }

            redirect_route('evenements/detail', ['id' => $evenement['evenement_code']]);
        }

        View::render('evenements/creer', ['organisation' => $org]);
    }

    public function detail(): void
    {
        $code = $_GET['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');
        $org = OrganisationModel::findByCode($evenement['organisation_code']);

        $presences = PresenceModel::listByEvenement($code);
        $presentUserCodes = array_column($presences, 'user_code');
        $membresRestants = array_filter(
            OrganisationUserModel::activeMembers($evenement['organisation_code']),
            fn ($m) => !in_array($m['user_code'], $presentUserCodes, true)
        );

        View::render('evenements/detail', [
            'organisation' => $org,
            'evenement' => $evenement,
            'presences' => $presences,
            'membresRestants' => array_values($membresRestants),
            'confirmationsCount' => EvenementConfirmationModel::countByEvenement($code),
            'scanUrl' => $evenement['qr_token'] ? route_url('evenements/scanner', ['token' => $evenement['qr_token']]) : null,
        ]);
    }

    public function lancerAppel(): void
    {
        $code = $_POST['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');

        if (!$evenement['qr_token']) {
            EvenementModel::setToken($code, CodeGenerator::qrToken());
            Audit::log($user['user_code'], $evenement['organisation_code'], 'APPEL_LANCE', $code);
        }

        redirect_route('evenements/detail', ['id' => $code]);
    }

    public function marquerPresenceManuel(): void
    {
        $evenementCode = $_POST['evenement'] ?? '';
        $userCode = $_POST['user'] ?? '';
        $evenement = EvenementModel::findByCode($evenementCode);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');
        $membre = OrganisationUserModel::find($userCode, $evenement['organisation_code']);
        if ($membre && $membre['statut'] === 'ACT') {
            $presence = PresenceModel::create($evenementCode, $userCode, 'MANUEL');
            if ($presence) {
                Audit::log($user['user_code'], $evenement['organisation_code'], 'PRESENCE_MARQUEE', $presence['presence_code'], [
                    'user' => $userCode,
                    'mode' => 'MANUEL',
                ]);
            }
        }

        redirect_route('evenements/detail', ['id' => $evenementCode]);
    }

    public function terminer(): void
    {
        $code = $_POST['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');
        EvenementModel::updateStatut($code, 'TERMINE');
        Audit::log($user['user_code'], $evenement['organisation_code'], 'EVENT_TERMINE', $code);

        redirect_route('evenements/detail', ['id' => $code]);
    }

    public function annuler(): void
    {
        $code = $_POST['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');
        EvenementModel::updateStatut($code, 'ANNULE');
        Audit::log($user['user_code'], $evenement['organisation_code'], 'EVENT_ANNULE', $code);

        redirect_route('evenements/detail', ['id' => $code]);
    }

    public function pv(): void
    {
        $code = $_GET['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');
        $org = OrganisationModel::findByCode($evenement['organisation_code']);

        $presences = PresenceModel::listByEvenement($code);
        $presentUserCodes = array_column($presences, 'user_code');
        $absents = array_filter(
            OrganisationUserModel::activeMembers($evenement['organisation_code']),
            fn ($m) => !in_array($m['user_code'], $presentUserCodes, true)
        );

        Audit::log($user['user_code'], $evenement['organisation_code'], 'RAPPORT_GENERE', $code, ['type' => 'PV']);

        View::render('evenements/pv', [
            'organisation' => $org,
            'evenement' => $evenement,
            'presences' => $presences,
            'absents' => array_values($absents),
        ]);
    }

    public function mes(): void
    {
        $user = Middleware::requireLogin();
        $evenements = EvenementModel::listUpcomingForUser($user['user_code']);

        $confirmed = [];
        $presentAt = [];
        foreach ($evenements as $evenement) {
            $confirmed[$evenement['evenement_code']] = EvenementConfirmationModel::exists($evenement['evenement_code'], $user['user_code']);
            $presentAt[$evenement['evenement_code']] = PresenceModel::exists($evenement['evenement_code'], $user['user_code']);
        }

        View::render('evenements/mes', [
            'evenements' => $evenements,
            'confirmed' => $confirmed,
            'presentAt' => $presentAt,
        ]);
    }

    public function confirmer(): void
    {
        $user = Middleware::requireLogin();
        $code = $_POST['id'] ?? '';
        $evenement = EvenementModel::findByCode($code);
        if (!$evenement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requireMembership($evenement['organisation_code']);
        EvenementConfirmationModel::create($code, $user['user_code']);
        Audit::log($user['user_code'], $evenement['organisation_code'], 'EVENT_CONFIRME', $code);

        redirect_route('evenements/mes');
    }

    public function scanner(): void
    {
        $user = Middleware::requireLogin();
        $token = $_GET['token'] ?? '';
        $evenement = EvenementModel::findByToken($token);
        if (!$evenement || $evenement['statut'] !== 'PLANIFIE') {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requireMembership($evenement['organisation_code']);

        $presence = PresenceModel::create($evenement['evenement_code'], $user['user_code'], 'QR');
        if ($presence) {
            Audit::log($user['user_code'], $evenement['organisation_code'], 'PRESENCE_MARQUEE', $presence['presence_code'], [
                'user' => $user['user_code'],
                'mode' => 'QR',
            ]);
        }

        View::render('evenements/scan-succes', ['evenement' => $evenement]);
    }
}
