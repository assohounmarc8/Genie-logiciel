<?php

class AbonnementsController
{
    public function payer(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $orgCode = $_POST['org'] ?? '';
        $montant = (float) ($_POST['montant'] ?? 0);
        $org = OrganisationModel::findByCode($orgCode);

        if ($org) {
            $abonnement = AbonnementModel::create($orgCode, $montant);
            OrganisationModel::updateStatutAbonnement($orgCode, 'ACT');
            Audit::log($user['user_code'], $orgCode, 'PAY_ABO', $abonnement['abonnement_code'], ['montant' => $montant]);
        }

        redirect_route('organisations/detail', ['id' => $orgCode]);
    }
}
