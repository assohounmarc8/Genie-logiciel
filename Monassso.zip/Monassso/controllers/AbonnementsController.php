<?php

class AbonnementsController
{
    public function payer(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $orgCode = $_POST['org'] ?? '';
        $planCode = $_POST['plan_code'] ?? '';
        $montant = (float) ($_POST['montant'] ?? 0);
        $org = OrganisationModel::findByCode($orgCode);
        $plan = PlanAbonnementModel::find($planCode);

        $errors = [];
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }
        if (!$plan) {
            $errors[] = t('validation.plan_abonnement_invalid');
        }
        if ($montant <= 0) {
            $errors[] = t('validation.montant_positive');
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('organisations/detail', ['id' => $orgCode]);
        }

        $abonnement = AbonnementModel::create($orgCode, $montant, $plan['duree_jours']);
        OrganisationModel::updateStatutAbonnement($orgCode, 'ACT');
        Audit::log($user['user_code'], $orgCode, 'PAY_ABO', $abonnement['abonnement_code'], [
            'montant' => $montant,
            'plan' => $planCode,
        ]);

        redirect_route('organisations/detail', ['id' => $orgCode]);
    }
}
