<?php

class DocumentsController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $canGerer = Middleware::can($orgCode, 'gerer_documents');
        $canVoir = Middleware::can($orgCode, 'voir_documents');

        $documents = DocumentModel::listByOrganisation($orgCode);
        if (!$canGerer) {
            $documents = array_values(array_filter($documents, fn ($d) => $d['visibilite'] === 'PUBLIC'));
        }

        View::render('documents/index', [
            'organisation' => $org,
            'documents' => $documents,
            'canGerer' => $canGerer,
            'canVoir' => $canVoir || $canGerer,
        ]);
    }

    public function upload(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_documents');

        $categorie = $_POST['categorie'] ?? 'AUTRE';
        if (!in_array($categorie, ['PV', 'STATUTS', 'RAPPORT', 'AUTRE'], true)) {
            $categorie = 'AUTRE';
        }
        $visibilite = ($_POST['visibilite'] ?? 'PUBLIC') === 'PRIVE' ? 'PRIVE' : 'PUBLIC';

        $errors = [];
        $file = $_FILES['fichier'] ?? null;
        $config = config_get('upload');

        if (!$file || $file['error'] === UPLOAD_ERR_NO_FILE) {
            $errors[] = t('validation.file_required');
        } elseif ($file['error'] !== UPLOAD_ERR_OK) {
            $errors[] = t('validation.file_upload_failed');
        } else {
            $originalName = $file['name'];
            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

            if (!array_key_exists($extension, $config['allowed'])) {
                $errors[] = t('validation.file_type_invalid');
            }
            if ($file['size'] > $config['max_size']) {
                $errors[] = t('validation.file_too_large');
            }

            if (!$errors) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $detectedMime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
                if (preg_match('/php|executable|x-sh|x-dosexec|x-msdownload/i', (string) $detectedMime)) {
                    $errors[] = t('validation.file_type_invalid');
                }
            }
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('documents/index', ['org' => $orgCode]);
        }

        $code = CodeGenerator::documentCode();
        $safeName = preg_replace('/[^A-Za-z0-9._-]/', '_', $file['name']);
        $extension = strtolower(pathinfo($safeName, PATHINFO_EXTENSION));
        $dir = APP_DIR . '/uploads/documents/' . $orgCode;
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $diskFilename = $code . '_' . $safeName;
        $destination = $dir . '/' . $diskFilename;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            flash_set('errors', [t('validation.file_upload_failed')]);
            redirect_route('documents/index', ['org' => $orgCode]);
        }

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $storedMime = finfo_file($finfo, $destination) ?: ($config['allowed'][$extension] ?? 'application/octet-stream');
        finfo_close($finfo);

        DocumentModel::create([
            'organisation_code' => $orgCode,
            'uploaded_by_user_code' => $user['user_code'],
            'categorie' => $categorie,
            'nom_original' => $file['name'],
            'chemin_fichier' => 'uploads/documents/' . $orgCode . '/' . $diskFilename,
            'taille_octets' => $file['size'],
            'type_mime' => $storedMime,
            'visibilite' => $visibilite,
        ]);

        Audit::log($user['user_code'], $orgCode, 'UPLOAD_DOCUMENT', $code, ['nom' => $file['name'], 'categorie' => $categorie]);

        redirect_route('documents/index', ['org' => $orgCode]);
    }

    public function telecharger(): void
    {
        $code = $_GET['id'] ?? '';
        $doc = DocumentModel::findByCode($code);
        if (!$doc) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgCode = $doc['organisation_code'];
        $canGerer = Middleware::can($orgCode, 'gerer_documents');
        $canVoir = Middleware::can($orgCode, 'voir_documents');

        $allowed = $canGerer || ($canVoir && $doc['visibilite'] === 'PUBLIC');
        if (!$allowed) {
            Middleware::requireLogin();
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $path = APP_DIR . '/' . $doc['chemin_fichier'];
        if (!is_file($path)) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        header('Content-Type: ' . $doc['type_mime']);
        header('Content-Disposition: attachment; filename="' . $doc['nom_original'] . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    public function supprimer(): void
    {
        $code = $_POST['id'] ?? '';
        $doc = DocumentModel::findByCode($code);
        if (!$doc) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgCode = $doc['organisation_code'];
        $user = Middleware::requirePermission($orgCode, 'gerer_documents');

        $path = APP_DIR . '/' . $doc['chemin_fichier'];
        if (is_file($path)) {
            unlink($path);
        }
        DocumentModel::delete($code);
        Audit::log($user['user_code'], $orgCode, 'DELETE_DOCUMENT', $code, ['nom' => $doc['nom_original']]);

        redirect_route('documents/index', ['org' => $orgCode]);
    }
}
