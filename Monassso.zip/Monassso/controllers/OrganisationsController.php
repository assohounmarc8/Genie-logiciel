<?php

class OrganisationsController
{
    public function index(): void
    {
        Middleware::requireType(['SUPER_ADMIN']);
        $organisations = OrganisationModel::all();
        View::render('organisations/index', ['organisations' => $organisations]);
    }

    public function creer(): void
    {
        $user = Middleware::requireType(['ADMIN_ORGA']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $paysCode = $_POST['pays_code'] ?? '';

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.org_name_required');
            }
            if (!array_key_exists($paysCode, config_get('pays'))) {
                $errors[] = t('validation.country_invalid');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('organisations/creer');
            }

            $org = OrganisationModel::create([
                'nom' => $nom,
                'pays_code' => $paysCode,
                'admin_user_code' => $user['user_code'],
            ]);

            Audit::log($user['user_code'], $org['organisation_code'], 'CREATE_ORGA', $org['organisation_code'], ['nom' => $nom]);

            RoleModel::ensureDefaultRoles($org['organisation_code']);

            redirect_route('organisations/detail', ['id' => $org['organisation_code']]);
        }

        View::render('organisations/creer', []);
    }

    public function detail(): void
    {
        $user = Middleware::requireLogin();
        $code = $_GET['id'] ?? '';
        $org = OrganisationModel::findByCode($code);

        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $isSuperAdmin = $user['type_compte'] === 'SUPER_ADMIN';
        $isOwner = $org['admin_user_code'] === $user['user_code'];
        $membership = OrganisationUserModel::find($user['user_code'], $org['organisation_code']);

        if (!$isSuperAdmin && !$isOwner && (!$membership || $membership['statut'] !== 'ACT')) {
            http_response_code(403);
            View::render('errors/forbidden', []);
            return;
        }

        $roles = RoleModel::listByOrganisation($org['organisation_code']);
        $abonnements = AbonnementModel::listByOrganisation($org['organisation_code']);

        View::render('organisations/detail', [
            'organisation' => $org,
            'isOwner' => $isOwner,
            'isSuperAdmin' => $isSuperAdmin,
            'roles' => $roles,
            'abonnements' => $abonnements,
        ]);
    }

    public function parametres(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_organisation');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $telephone = trim($_POST['telephone'] ?? '');
            $adresse = trim($_POST['adresse'] ?? '');
            $montantAdhesion = trim($_POST['montant_adhesion'] ?? '');

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.org_name_required');
            }
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = t('validation.email_invalid');
            }
            if ($montantAdhesion !== '' && (!is_numeric($montantAdhesion) || (float) $montantAdhesion < 0)) {
                $errors[] = t('validation.montant_positive');
            }

            $logoFile = $_FILES['logo'] ?? null;
            if ($logoFile && $logoFile['error'] !== UPLOAD_ERR_NO_FILE) {
                $errors = array_merge($errors, validate_uploaded_file($logoFile, ['jpg', 'jpeg', 'png']));
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('organisations/parametres', ['org' => $orgCode]);
            }

            OrganisationModel::updateInfo($orgCode, [
                'nom' => $nom,
                'email' => $email,
                'telephone' => $telephone,
                'adresse' => $adresse,
                'montant_adhesion' => $montantAdhesion !== '' ? (float) $montantAdhesion : null,
            ]);

            if ($logoFile && $logoFile['error'] !== UPLOAD_ERR_NO_FILE) {
                $diskName = $orgCode . '_' . safe_filename($logoFile['name']);
                $stored = store_uploaded_file($logoFile, APP_DIR . '/uploads/logos', $diskName);
                if ($stored) {
                    OrganisationModel::updateLogo($orgCode, 'uploads/logos/' . $diskName);
                }
            }

            Audit::log($user['user_code'], $orgCode, 'UPDATE_ORGA', $orgCode, ['nom' => $nom]);

            redirect_route('organisations/detail', ['id' => $orgCode]);
        }

        View::render('organisations/parametres', ['organisation' => $org]);
    }

    public function valider(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        if (OrganisationModel::findByCode($code)) {
            OrganisationModel::updateStatutValidation($code, 'VAL');
            Audit::log($user['user_code'], $code, 'VALIDATE_ORGA', $code);
        }
        redirect_route('organisations/index');
    }

    public function refuser(): void
    {
        $user = Middleware::requireType(['SUPER_ADMIN']);
        $code = $_POST['id'] ?? '';
        if (OrganisationModel::findByCode($code)) {
            OrganisationModel::updateStatutValidation($code, 'REF');
            Audit::log($user['user_code'], $code, 'REFUSE_ORGA', $code);
        }
        redirect_route('organisations/index');
    }
}
