<?php

class CartesController
{
    private const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png'];

    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_cartes');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('cartes/index', [
            'organisation' => $org,
            'cartes' => CarteModel::listByOrganisation($orgCode),
            'success' => flash_get('success'),
        ]);
    }

    public function emettre(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_cartes');

        $resultat = CarteModel::emitAllForOrganisation($orgCode);

        Audit::log($user['user_code'], $orgCode, 'CARTES_EMISES', null, $resultat);

        flash_set('success', t('cartes.emettre_success', [
            'actifs' => $resultat['actifs'],
            'total' => $resultat['total'],
        ]));
        redirect_route('cartes/index', ['org' => $orgCode]);
    }

    public function lot(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_cartes');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('cartes/lot', [
            'organisation' => $org,
            'cartes' => CarteModel::listByOrganisation($orgCode),
        ]);
    }

    public function bloquer(): void
    {
        $code = $_POST['id'] ?? '';
        $carte = CarteModel::findByCode($code);
        if (!$carte) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($carte['organisation_code'], 'gerer_cartes');
        CarteModel::block($code);
        Audit::log($user['user_code'], $carte['organisation_code'], 'CARTE_BLOQUEE', $code);

        redirect_route('cartes/index', ['org' => $carte['organisation_code']]);
    }

    public function debloquer(): void
    {
        $code = $_POST['id'] ?? '';
        $carte = CarteModel::findByCode($code);
        if (!$carte) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($carte['organisation_code'], 'gerer_cartes');
        CarteModel::reissue($code);
        Audit::log($user['user_code'], $carte['organisation_code'], 'CARTE_DEBLOQUEE', $code);

        redirect_route('cartes/index', ['org' => $carte['organisation_code']]);
    }

    public function mes(): void
    {
        $user = Middleware::requireLogin();
        $cartes = CarteModel::listForUser($user['user_code']);
        $carteOrgCodes = array_column($cartes, 'organisation_code');

        $memberships = array_filter(
            OrganisationUserModel::listByUser($user['user_code']),
            fn ($m) => $m['statut'] === 'ACT' && !in_array($m['organisation_code'], $carteOrgCodes, true)
        );

        View::render('cartes/mes', [
            'user' => $user,
            'cartes' => $cartes,
            'orgsSansCarte' => array_values($memberships),
        ]);
    }

    public function carte(): void
    {
        $user = Middleware::requireLogin();
        $code = $_GET['id'] ?? '';
        $carte = CarteModel::findByCode($code);
        if (!$carte) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $isOwner = $carte['user_code'] === $user['user_code'];
        if (!$isOwner) {
            Middleware::requirePermission($carte['organisation_code'], 'gerer_cartes');
        }

        $org = OrganisationModel::findByCode($carte['organisation_code']);
        $membre = UserModel::findByCode($carte['user_code']);
        $membership = OrganisationUserModel::find($carte['user_code'], $carte['organisation_code']);

        View::render('cartes/carte', [
            'organisation' => $org,
            'membre' => $membre,
            'carte' => $carte,
            'numeroAdherent' => $membership['numero_adherent'] ?? '',
            'isOwner' => $isOwner,
        ]);
    }

    public function uploaderPhoto(): void
    {
        $user = Middleware::requireLogin();

        $photoFile = $_FILES['photo'] ?? null;
        $errors = validate_uploaded_file($photoFile, self::IMAGE_EXTENSIONS);

        if (!$errors) {
            $diskName = $user['user_code'] . '_' . safe_filename($photoFile['name']);
            $stored = store_uploaded_file($photoFile, APP_DIR . '/uploads/photos', $diskName);
            if ($stored) {
                $stmt = Database::connection()->prepare('UPDATE users SET photo_chemin = :p WHERE user_code = :u');
                $stmt->execute(['p' => 'uploads/photos/' . $diskName, 'u' => $user['user_code']]);
                Audit::log($user['user_code'], null, 'UPDATE_PHOTO_PROFIL', $user['user_code']);
            }
        } else {
            flash_set('errors', $errors);
        }

        redirect_route('cartes/mes');
    }

    /** Vérification publique d'une carte — aucune connexion requise. */
    public function verifier(): void
    {
        $token = $_GET['token'] ?? '';
        $carte = CarteModel::findByToken($token);
        if (!$carte) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $membre = UserModel::findByCode($carte['user_code']);
        $org = OrganisationModel::findByCode($carte['organisation_code']);

        $evenementLive = null;
        if (Middleware::can($carte['organisation_code'], 'gerer_evenements')) {
            $evenementLive = EvenementModel::findLiveForOrganisation($carte['organisation_code']);
        }

        View::render('cartes/verifier', [
            'carte' => $carte,
            'membre' => $membre,
            'organisation' => $org,
            'evenementLive' => $evenementLive,
            'dejaPresent' => $evenementLive ? PresenceModel::exists($evenementLive['evenement_code'], $carte['user_code']) : false,
        ]);
    }

    public function marquerPresenceParCarte(): void
    {
        $token = $_POST['token'] ?? '';
        $evenementCode = $_POST['evenement'] ?? '';

        $carte = CarteModel::findByToken($token);
        $evenement = EvenementModel::findByCode($evenementCode);
        if (!$carte || !$evenement || $carte['organisation_code'] !== $evenement['organisation_code']) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($evenement['organisation_code'], 'gerer_evenements');

        if ($carte['statut'] === 'ACTIF' && $evenement['statut'] === 'PLANIFIE') {
            $presence = PresenceModel::create($evenementCode, $carte['user_code'], 'CARTE');
            if ($presence) {
                Audit::log($user['user_code'], $evenement['organisation_code'], 'PRESENCE_MARQUEE', $presence['presence_code'], [
                    'user' => $carte['user_code'],
                    'mode' => 'CARTE',
                ]);
            }
        }

        redirect_route('cartes/verifier', ['token' => $token]);
    }
}
