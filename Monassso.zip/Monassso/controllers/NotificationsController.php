<?php

class NotificationsController
{
    public function index(): void
    {
        $user = Middleware::requireLogin();
        $notifications = NotificationModel::listForUser($user['user_code']);
        View::render('notifications/index', ['notifications' => $notifications]);
    }

    public function marquerLu(): void
    {
        $user = Middleware::requireLogin();
        $code = $_POST['id'] ?? '';
        NotificationModel::markRead($code, $user['user_code']);
        redirect_route('notifications/index');
    }

    public function marquerToutLu(): void
    {
        $user = Middleware::requireLogin();
        NotificationModel::markAllRead($user['user_code']);
        redirect_route('notifications/index');
    }
}
