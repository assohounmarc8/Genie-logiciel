<?php

class AuthController
{
    public function login(): void
    {
        Middleware::requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = trim($_POST['password'] ?? '');

            if (Auth::attempt($email, $password)) {
                redirect_route('dashboard/index');
            }

            flash_set('errors', [t('auth.error.invalid_credentials')]);
            flash_set('old', ['email' => $email]);
            redirect_route('auth/login');
        }

        View::render('auth/login', []);
    }

    public function register(): void
    {
        Middleware::requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $paysCode = $_POST['pays_code'] ?? '';
            $sexe = $_POST['sexe'] ?? '';
            $typeCompte = $_POST['type_compte'] ?? '';
            $dateNaissance = trim($_POST['date_naissance'] ?? '');
            $lieuNaissance = trim($_POST['lieu_naissance'] ?? '');
            $metier = trim($_POST['metier'] ?? '');

            $isMembre = $typeCompte === 'MEMBRE';
            // Un membre ne choisit pas son mot de passe : il est généré et envoyé par e-mail, ce qui
            // évite qu'il se connecte directement après l'inscription (voir plus bas).
            $password = $isMembre ? generate_random_password() : ($_POST['password'] ?? '');

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.name_required');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = t('validation.email_invalid');
            } elseif (UserModel::emailExists($email)) {
                $errors[] = t('validation.email_taken');
            }
            if (!$isMembre && strlen($password) < 8) {
                $errors[] = t('validation.password_min');
            }
            if (!PaysModel::exists($paysCode)) {
                $errors[] = t('validation.country_invalid');
            }
            if (!in_array($sexe, ['M', 'F'], true)) {
                $errors[] = t('validation.sexe_invalid');
            }
            if (!in_array($typeCompte, ['ADMIN_ORGA', 'MEMBRE'], true)) {
                $errors[] = t('validation.type_compte_invalid');
            }

            if ($isMembre) {
                if ($dateNaissance === '' || !DateTime::createFromFormat('Y-m-d', $dateNaissance)) {
                    $errors[] = t('validation.date_naissance_invalid');
                }
                if ($lieuNaissance === '') {
                    $errors[] = t('validation.lieu_naissance_required');
                }
                if (!MetierModel::exists($metier)) {
                    $errors[] = t('validation.metier_invalid');
                }
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('auth/register');
            }

            $user = UserModel::create([
                'nom' => $nom,
                'email' => $email,
                'password' => $password,
                'pays_code' => $paysCode,
                'sexe' => $sexe,
                'type_compte' => $typeCompte,
                'date_naissance' => $isMembre ? $dateNaissance : null,
                'lieu_naissance' => $isMembre ? $lieuNaissance : null,
                'metier' => $isMembre ? $metier : null,
            ]);

            Audit::log($user['user_code'], null, 'CREATE_USER', $user['user_code'], ['type_compte' => $typeCompte]);

            if ($isMembre) {
                Mailer::send(
                    $email,
                    $nom,
                    t('mail.identifiants_compte.subject'),
                    mail_template(
                        t('mail.identifiants_compte.subject'),
                        '<p>' . t('mail.identifiants_compte.body', ['email' => $email, 'password' => $password]) . '</p>'
                    ),
                    'IDENTIFIANTS_COMPTE',
                    $user['user_code']
                );

                flash_set('info', [t('auth.register.membre_success_info')]);
                redirect_route('auth/login');
            }

            Auth::login($user);
            redirect_route('organisations/creer');
        }

        View::render('auth/register', []);
    }

    public function logout(): void
    {
        Auth::logout();
        redirect_route('auth/login');
    }
}
