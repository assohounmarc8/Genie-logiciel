<?php

class AuthController
{
    public function login(): void
    {
        Middleware::requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';

            if (Auth::attempt($email, $password)) {
                redirect_route('dashboard/index');
            }

            flash_set('errors', [t('auth.error.invalid_credentials')]);
            flash_set('old', ['email' => $email]);
            redirect_route('auth/login');
        }

        View::render('auth/login', []);
    }

    public function register(): void
    {
        Middleware::requireGuest();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom = trim($_POST['nom'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $password = $_POST['password'] ?? '';
            $paysCode = $_POST['pays_code'] ?? '';
            $sexe = $_POST['sexe'] ?? '';
            $typeCompte = $_POST['type_compte'] ?? '';

            $errors = [];
            if ($nom === '') {
                $errors[] = t('validation.name_required');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = t('validation.email_invalid');
            } elseif (UserModel::emailExists($email)) {
                $errors[] = t('validation.email_taken');
            }
            if (strlen($password) < 8) {
                $errors[] = t('validation.password_min');
            }
            if (!array_key_exists($paysCode, config_get('pays'))) {
                $errors[] = t('validation.country_invalid');
            }
            if (!in_array($sexe, ['M', 'F'], true)) {
                $errors[] = t('validation.sexe_invalid');
            }
            if (!in_array($typeCompte, ['ADMIN_ORGA', 'MEMBRE'], true)) {
                $errors[] = t('validation.type_compte_invalid');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('auth/register');
            }

            $user = UserModel::create([
                'nom' => $nom,
                'email' => $email,
                'password' => $password,
                'pays_code' => $paysCode,
                'sexe' => $sexe,
                'type_compte' => $typeCompte,
            ]);

            Audit::log($user['user_code'], null, 'CREATE_USER', $user['user_code'], ['type_compte' => $typeCompte]);

            Auth::login($user);

            if ($typeCompte === 'ADMIN_ORGA') {
                redirect_route('organisations/creer');
            }

            redirect_route('dashboard/index');
        }

        View::render('auth/register', []);
    }

    public function logout(): void
    {
        Auth::logout();
        redirect_route('auth/login');
    }
}
