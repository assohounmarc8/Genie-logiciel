<?php

class DepensesController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_depenses');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('depenses/index', [
            'organisation' => $org,
            'depenses' => DepenseModel::listByOrganisation($orgCode),
            'errors' => flash_get('errors', []),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_depenses');

        $libelle = trim($_POST['libelle'] ?? '');
        $categorie = trim($_POST['categorie'] ?? '');
        $montant = (float) ($_POST['montant'] ?? 0);
        $dateDepense = trim($_POST['date_depense'] ?? '') ?: date('Y-m-d');

        $errors = [];
        if ($libelle === '') {
            $errors[] = t('validation.libelle_required');
        }
        if ($montant <= 0) {
            $errors[] = t('validation.montant_positive');
        }
        if ($categorie !== '' && !CategorieDepenseModel::exists($categorie)) {
            $errors[] = t('validation.categorie_invalid');
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('depenses/index', ['org' => $orgCode]);
        }

        $depense = DepenseModel::create([
            'organisation_code' => $orgCode,
            'cree_par_user_code' => $user['user_code'],
            'libelle' => $libelle,
            'categorie' => $categorie,
            'montant' => $montant,
            'date_depense' => $dateDepense,
        ]);

        Audit::log($user['user_code'], $orgCode, 'CREATE_DEPENSE', $depense['depense_code'], [
            'libelle' => $libelle,
            'montant' => $montant,
        ]);

        redirect_route('depenses/index', ['org' => $orgCode]);
    }

    public function supprimer(): void
    {
        $code = $_POST['id'] ?? '';
        $depense = DepenseModel::findByCode($code);
        if (!$depense) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgCode = $depense['organisation_code'];
        $user = Middleware::requirePermission($orgCode, 'gerer_depenses');

        DepenseModel::delete($code);
        Audit::log($user['user_code'], $orgCode, 'DELETE_DEPENSE', $code, ['libelle' => $depense['libelle']]);

        redirect_route('depenses/index', ['org' => $orgCode]);
    }
}
