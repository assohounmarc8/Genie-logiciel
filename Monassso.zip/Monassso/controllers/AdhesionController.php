<?php

/**
 * Contrôleur public — page de paiement du droit d'adhésion accessible via le lien envoyé par mail
 * après acceptation. Aucune connexion requise : le token fait office de clé d'accès sécurisée.
 */
class AdhesionController
{
    public function payer(): void
    {
        $token = $_GET['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $org = OrganisationModel::findByCode($paiement['organisation_code']);
        $membre = UserModel::findByCode($paiement['user_code']);
        $membership = OrganisationUserModel::find($paiement['user_code'], $paiement['organisation_code']);

        View::render('adhesion/payer', [
            'paiement' => $paiement,
            'organisation' => $org,
            'membre' => $membre,
            'numeroAdherent' => $membership['numero_adherent'] ?? '',
        ]);
    }

    public function confirmerPaiement(): void
    {
        $token = $_POST['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($paiement['statut'] === 'EN_ATTENTE') {
            AdhesionPaiementModel::markPaid($paiement['adhesion_paiement_code']);
            OrganisationUserModel::activate($paiement['user_code'], $paiement['organisation_code']);

            Audit::log($paiement['user_code'], $paiement['organisation_code'], 'PAY_ADHESION', $paiement['adhesion_paiement_code'], [
                'montant' => $paiement['montant'],
            ]);

            $org = OrganisationModel::findByCode($paiement['organisation_code']);
            $membre = UserModel::findByCode($paiement['user_code']);

            Mailer::send(
                $membre['email'],
                $membre['nom'],
                t('mail.adhesion_payee.subject', ['org' => $org['nom']]),
                mail_template(t('mail.adhesion_payee.subject', ['org' => $org['nom']]), '<p>' . t('mail.adhesion_payee.body') . '</p>'),
                'ADHESION_PAYEE',
                $paiement['user_code'],
                $paiement['organisation_code']
            );

            NotificationModel::create(
                $paiement['user_code'],
                $paiement['organisation_code'],
                'MEMBER_ACCEPTED',
                t('notif.member_accepted.title'),
                t('notif.member_accepted.message', ['org' => $org['nom'] ?? $paiement['organisation_code']])
            );
        }

        redirect_route('adhesion/merci', ['token' => $token]);
    }

    public function merci(): void
    {
        $token = $_GET['token'] ?? '';
        $paiement = AdhesionPaiementModel::findByToken($token);
        if (!$paiement) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $org = OrganisationModel::findByCode($paiement['organisation_code']);
        View::render('adhesion/merci', ['paiement' => $paiement, 'organisation' => $org]);
    }
}
