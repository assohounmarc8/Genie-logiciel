<?php

class BesoinsController
{
    private const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png'];

    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requirePermission($orgCode, 'gerer_besoins');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('besoins/index', [
            'organisation' => $org,
            'besoins' => BesoinModel::listByOrganisation($orgCode),
        ]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_besoins');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titre = trim($_POST['titre'] ?? '');
            $description = trim($_POST['description'] ?? '');
            $typeBesoin = $_POST['type_besoin'] ?? 'FINANCIER';
            if (!in_array($typeBesoin, ['FINANCIER', 'MATERIEL', 'SERVICE'], true)) {
                $typeBesoin = 'FINANCIER';
            }
            $montant = (float) ($_POST['montant_recherche'] ?? 0);
            $dateFin = trim($_POST['date_fin'] ?? '');

            $errors = [];
            if ($titre === '') {
                $errors[] = t('validation.name_required');
            }
            if ($description === '') {
                $errors[] = t('validation.libelle_required');
            }
            if ($montant <= 0) {
                $errors[] = t('validation.montant_positive');
            }

            $photoFile = $_FILES['photo'] ?? null;
            if ($photoFile && $photoFile['error'] !== UPLOAD_ERR_NO_FILE) {
                $errors = array_merge($errors, validate_uploaded_file($photoFile, self::IMAGE_EXTENSIONS));
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('besoins/creer', ['org' => $orgCode]);
            }

            $besoin = BesoinModel::create([
                'organisation_code' => $orgCode,
                'cree_par_user_code' => $user['user_code'],
                'titre' => $titre,
                'description' => $description,
                'type_besoin' => $typeBesoin,
                'montant_recherche' => $montant,
                'date_fin' => $dateFin,
                'photo_chemin' => null,
            ]);

            if ($photoFile && $photoFile['error'] !== UPLOAD_ERR_NO_FILE) {
                $extension = strtolower(pathinfo($photoFile['name'], PATHINFO_EXTENSION));
                $dir = APP_DIR . '/uploads/besoins/' . $besoin['besoin_code'];
                $stored = store_uploaded_file($photoFile, $dir, 'photo.' . $extension);
                if ($stored) {
                    BesoinModel::updatePhoto($besoin['besoin_code'], 'uploads/besoins/' . $besoin['besoin_code'] . '/photo.' . $extension);
                }
            }

            Audit::log($user['user_code'], $orgCode, 'CREATE_BESOIN', $besoin['besoin_code'], [
                'titre' => $titre,
                'montant_recherche' => $montant,
            ]);

            redirect_route('besoins/detail', ['id' => $besoin['besoin_code']]);
        }

        View::render('besoins/creer', ['organisation' => $org]);
    }

    public function detail(): void
    {
        $code = $_GET['id'] ?? '';
        $besoin = BesoinModel::findByCode($code);
        if (!$besoin) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        Middleware::requirePermission($besoin['organisation_code'], 'gerer_besoins');
        $org = OrganisationModel::findByCode($besoin['organisation_code']);

        View::render('besoins/detail', [
            'organisation' => $org,
            'besoin' => $besoin,
            'dons' => DonModel::listByBesoin($code),
            'documents' => BesoinDocumentModel::listByBesoin($code),
        ]);
    }

    public function uploadDocument(): void
    {
        $besoinCode = $_POST['besoin'] ?? '';
        $besoin = BesoinModel::findByCode($besoinCode);
        if (!$besoin) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($besoin['organisation_code'], 'gerer_besoins');

        $type = $_POST['type'] ?? 'PHOTO';
        if (!in_array($type, ['DEVIS', 'PHOTO', 'FACTURE'], true)) {
            $type = 'PHOTO';
        }

        $file = $_FILES['fichier'] ?? null;
        $errors = validate_uploaded_file($file);
        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('besoins/detail', ['id' => $besoinCode]);
        }

        $code = CodeGenerator::besoinDocumentCode();
        $safeName = safe_filename($file['name']);
        $dir = APP_DIR . '/uploads/besoins/' . $besoinCode . '/documents';
        $diskFilename = $code . '_' . $safeName;
        $stored = store_uploaded_file($file, $dir, $diskFilename);

        if (!$stored) {
            flash_set('errors', [t('validation.file_upload_failed')]);
            redirect_route('besoins/detail', ['id' => $besoinCode]);
        }

        BesoinDocumentModel::create([
            'besoin_code' => $besoinCode,
            'type' => $type,
            'nom_original' => $file['name'],
            'chemin_fichier' => 'uploads/besoins/' . $besoinCode . '/documents/' . $diskFilename,
            'taille_octets' => $file['size'],
            'type_mime' => $stored['mime'],
            'uploaded_by_user_code' => $user['user_code'],
        ]);

        Audit::log($user['user_code'], $besoin['organisation_code'], 'UPLOAD_BESOIN_DOCUMENT', $code, [
            'nom' => $file['name'],
            'type' => $type,
        ]);

        redirect_route('besoins/detail', ['id' => $besoinCode]);
    }

    public function fermer(): void
    {
        $besoinCode = $_POST['id'] ?? '';
        $besoin = BesoinModel::findByCode($besoinCode);
        if (!$besoin) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $user = Middleware::requirePermission($besoin['organisation_code'], 'gerer_besoins');
        BesoinModel::updateStatut($besoinCode, 'FERME');
        Audit::log($user['user_code'], $besoin['organisation_code'], 'CLOSE_BESOIN', $besoinCode);

        redirect_route('besoins/detail', ['id' => $besoinCode]);
    }
}
