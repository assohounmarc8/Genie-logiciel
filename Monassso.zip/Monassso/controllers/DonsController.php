<?php

/**
 * Contrôleur public — aucune action ici n'appelle Middleware::requireLogin(). N'importe quel
 * visiteur, sans compte, peut consulter les besoins actifs et faire un don.
 */
class DonsController
{
    public function index(): void
    {
        View::render('dons/index', ['besoins' => BesoinModel::listActifs()]);
    }

    public function besoin(): void
    {
        $code = $_GET['id'] ?? '';
        $besoin = BesoinModel::findPublicByCode($code);
        if (!$besoin || $besoin['statut'] === 'FERME') {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('dons/besoin', [
            'besoin' => $besoin,
            'documents' => BesoinDocumentModel::listByBesoin($code),
            'errors' => flash_get('errors', []),
        ]);
    }

    public function faireDon(): void
    {
        $besoinCode = $_POST['besoin'] ?? '';
        $besoin = BesoinModel::findByCode($besoinCode);
        if (!$besoin || $besoin['statut'] !== 'ACTIF') {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $donateurNom = trim($_POST['donateur_nom'] ?? '');
        $donateurEmail = trim($_POST['donateur_email'] ?? '');
        $montant = (float) ($_POST['montant'] ?? 0);
        $modePaiement = $_POST['mode_paiement'] ?? 'ORANGE_MONEY';
        if (!in_array($modePaiement, ['ORANGE_MONEY', 'VISA', 'ESPECES'], true)) {
            $modePaiement = 'ORANGE_MONEY';
        }
        $anonyme = !empty($_POST['anonyme']);
        $message = trim($_POST['message'] ?? '');

        $errors = [];
        if ($donateurNom === '') {
            $errors[] = t('validation.name_required');
        }
        if ($donateurEmail !== '' && !filter_var($donateurEmail, FILTER_VALIDATE_EMAIL)) {
            $errors[] = t('validation.email_invalid');
        }
        if ($montant <= 0 || $montant > 100000000) {
            $errors[] = t('validation.montant_positive');
        }

        if ($errors) {
            flash_set('errors', $errors);
            redirect_route('dons/besoin', ['id' => $besoinCode]);
        }

        $don = DonModel::create([
            'besoin_code' => $besoinCode,
            'donateur_nom' => $donateurNom,
            'donateur_email' => $donateurEmail,
            'montant' => $montant,
            'mode_paiement' => $modePaiement,
            'anonyme' => $anonyme,
            'message' => $message,
        ]);

        Audit::log(null, $besoin['organisation_code'], 'DON_EFFECTUE', $don['don_code'], [
            'besoin' => $besoinCode,
            'montant' => $montant,
        ]);

        $besoinMisAJour = BesoinModel::incrementCollecte($besoinCode, $montant);

        if ($besoinMisAJour['statut'] === 'FINANCE' && $besoin['statut'] !== 'FINANCE') {
            Audit::log(null, $besoin['organisation_code'], 'BESOIN_FINANCE', $besoinCode);
            NotificationModel::create(
                $besoin['cree_par_user_code'],
                $besoin['organisation_code'],
                'BESOIN_FINANCE',
                t('notif.besoin_finance.title'),
                t('notif.besoin_finance.message', ['titre' => $besoin['titre']])
            );
        }

        redirect_route('dons/merci', ['id' => $don['don_code']]);
    }

    public function document(): void
    {
        $code = $_GET['id'] ?? '';
        $doc = BesoinDocumentModel::findByCode($code);
        if (!$doc) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $path = APP_DIR . '/' . $doc['chemin_fichier'];
        if (!is_file($path)) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        header('Content-Type: ' . $doc['type_mime']);
        header('Content-Disposition: attachment; filename="' . $doc['nom_original'] . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }

    public function merci(): void
    {
        $donCode = $_GET['id'] ?? '';
        $don = DonModel::findByCode($donCode);
        if (!$don) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $besoin = BesoinModel::findPublicByCode($don['besoin_code']);

        View::render('dons/merci', ['don' => $don, 'besoin' => $besoin]);
    }
}
