<?php

class HomeController
{
    public function index(): void
    {
        if (Auth::user()) {
            redirect_route('dashboard/index');
        }
        View::render('home/index', []);
    }
}
