<?php

class RolesController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $roles = RoleModel::listByOrganisation($orgCode);
        $roles = array_map(function ($role) {
            $role['permissions'] = RoleModel::permissionsFor($role['role_code']);
            return $role;
        }, $roles);

        View::render('roles/index', ['organisation' => $org, 'roles' => $roles]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_roles');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nomRole = trim($_POST['nom_role'] ?? '');
            $parentRoleCode = $_POST['parent_role_code'] ?? '';
            $permissions = $_POST['permissions'] ?? [];

            $errors = [];
            if ($nomRole === '') {
                $errors[] = t('validation.role_name_required');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('roles/creer', ['org' => $orgCode]);
            }

            $role = RoleModel::create($orgCode, $nomRole, $parentRoleCode ?: null, $permissions);
            Audit::log($user['user_code'], $orgCode, 'CREATE_ROLE', $role['role_code'], [
                'nom_role' => $nomRole,
                'permissions' => $permissions,
            ]);

            redirect_route('roles/index', ['org' => $orgCode]);
        }

        View::render('roles/creer', [
            'organisation' => $org,
            'existingRoles' => RoleModel::listByOrganisation($orgCode),
            'allPermissions' => PermissionModel::all(),
            'defaults' => config_get('default_role_permissions'),
        ]);
    }

    public function modifier(): void
    {
        $roleCode = $_GET['id'] ?? $_POST['id'] ?? '';
        $role = RoleModel::findByCode($roleCode);
        if (!$role) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgCode = $role['organisation_code'];
        $user = Middleware::requirePermission($orgCode, 'gerer_roles');
        $org = OrganisationModel::findByCode($orgCode);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $parentRoleCode = $_POST['parent_role_code'] ?? '';
            if ($parentRoleCode === $roleCode) {
                $parentRoleCode = '';
            }
            $permissions = $_POST['permissions'] ?? [];

            RoleModel::update($roleCode, $parentRoleCode ?: null, $permissions);
            Audit::log($user['user_code'], $orgCode, 'UPDATE_ROLE', $roleCode, ['permissions' => $permissions]);

            redirect_route('roles/index', ['org' => $orgCode]);
        }

        $otherRoles = array_values(array_filter(
            RoleModel::listByOrganisation($orgCode),
            fn ($r) => $r['role_code'] !== $roleCode
        ));

        View::render('roles/modifier', [
            'organisation' => $org,
            'role' => $role,
            'currentPermissions' => RoleModel::permissionsFor($roleCode),
            'existingRoles' => $otherRoles,
            'allPermissions' => PermissionModel::all(),
        ]);
    }

    public function supprimer(): void
    {
        $roleCode = $_POST['id'] ?? '';
        $role = RoleModel::findByCode($roleCode);
        if (!$role) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $orgCode = $role['organisation_code'];
        $user = Middleware::requirePermission($orgCode, 'gerer_roles');

        if (RoleModel::isDefault($role)) {
            flash_set('errors', [t('validation.role_default_not_deletable')]);
            redirect_route('roles/index', ['org' => $orgCode]);
        }

        RoleModel::delete($roleCode);
        Audit::log($user['user_code'], $orgCode, 'DELETE_ROLE', $roleCode, ['nom_role' => $role['nom_role']]);

        redirect_route('roles/index', ['org' => $orgCode]);
    }
}
