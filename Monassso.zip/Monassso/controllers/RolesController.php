<?php

class RolesController
{
    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        $roles = RoleModel::listByOrganisation($orgCode);
        $roles = array_map(function ($role) {
            $role['permissions'] = RoleModel::permissionsFor($role['role_code']);
            return $role;
        }, $roles);

        View::render('roles/index', ['organisation' => $org, 'roles' => $roles]);
    }

    public function creer(): void
    {
        $orgCode = $_GET['org'] ?? $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_roles');
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nomRole = trim($_POST['nom_role'] ?? '');
            $parentRoleCode = $_POST['parent_role_code'] ?? '';
            $permissions = $_POST['permissions'] ?? [];

            $errors = [];
            if ($nomRole === '') {
                $errors[] = t('validation.role_name_required');
            }

            if ($errors) {
                flash_set('errors', $errors);
                flash_set('old', $_POST);
                redirect_route('roles/creer', ['org' => $orgCode]);
            }

            $role = RoleModel::create($orgCode, $nomRole, $parentRoleCode ?: null, $permissions);
            Audit::log($user['user_code'], $orgCode, 'CREATE_ROLE', $role['role_code'], [
                'nom_role' => $nomRole,
                'permissions' => $permissions,
            ]);

            redirect_route('roles/index', ['org' => $orgCode]);
        }

        View::render('roles/creer', [
            'organisation' => $org,
            'existingRoles' => RoleModel::listByOrganisation($orgCode),
            'allPermissions' => PermissionModel::all(),
            'defaults' => config_get('default_role_permissions'),
        ]);
    }
}
