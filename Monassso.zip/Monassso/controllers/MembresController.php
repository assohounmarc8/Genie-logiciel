<?php

class MembresController
{
    public function organisationsDisponibles(): void
    {
        $user = Middleware::requireType(['MEMBRE']);
        $organisations = OrganisationModel::allValidatedByPays($user['pays_code']);
        $memberships = OrganisationUserModel::listByUser($user['user_code']);
        $membershipsByOrg = array_column($memberships, null, 'organisation_code');

        View::render('membres/organisations-disponibles', [
            'organisations' => $organisations,
            'membershipsByOrg' => $membershipsByOrg,
        ]);
    }

    public function rejoindre(): void
    {
        $user = Middleware::requireType(['MEMBRE']);
        $orgCode = $_POST['org'] ?? $_GET['org'] ?? '';
        $org = OrganisationModel::findByCode($orgCode);

        if (!$org || $org['statut_validation'] !== 'VAL' || $org['pays_code'] !== $user['pays_code']) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if (!empty($org['reglement_interieur_chemin']) && ($_POST['accepte_reglement'] ?? '') !== '1') {
            flash_set('errors', [t('validation.reglement_required')]);
            redirect_route('membres/organisationsDisponibles');
        }

        if (!OrganisationUserModel::find($user['user_code'], $orgCode)) {
            OrganisationUserModel::createRequest($user['user_code'], $orgCode);
            Audit::log($user['user_code'], $orgCode, 'JOIN_REQUEST', $user['user_code']);

            NotificationModel::create(
                $org['admin_user_code'],
                $orgCode,
                'DEMANDE_ADHESION',
                t('notif.demande_adhesion.title'),
                t('notif.demande_adhesion.message', ['nom' => $user['nom'], 'org' => $org['nom']]),
                route_url('membres/index', ['org' => $orgCode])
            );
        }

        redirect_route('membres/organisationsDisponibles');
    }

    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('membres/index', [
            'organisation' => $org,
            'members' => OrganisationUserModel::listByOrganisation($orgCode),
            'roles' => RoleModel::listByOrganisation($orgCode),
        ]);
    }

    public function accepter(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_adherent');
        $memberUserCode = $_POST['user'] ?? '';
        $roleCode = $_POST['role_code'] ?? '';

        if (OrganisationUserModel::find($memberUserCode, $orgCode)) {
            $org = OrganisationModel::findByCode($orgCode);
            $membre = UserModel::findByCode($memberUserCode);
            $montantAdhesion = (float) ($org['montant_adhesion'] ?? 0);

            if ($montantAdhesion > 0) {
                OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'PAI', $roleCode ?: null);
                OrganisationUserModel::ensureNumeroAdherent($orgCode, $memberUserCode);
                $paiement = AdhesionPaiementModel::create($memberUserCode, $orgCode, $montantAdhesion);
                $membership = OrganisationUserModel::find($memberUserCode, $orgCode);

                Audit::log($user['user_code'], $orgCode, 'ACCEPT_MEMBER', $memberUserCode, ['statut' => 'PAI']);

                $lienPaiement = route_url('adhesion/payer', ['token' => $paiement['token']]);
                Mailer::send(
                    $membre['email'],
                    $membre['nom'],
                    t('mail.adhesion_acceptee.subject', ['org' => $org['nom']]),
                    mail_template(
                        t('mail.adhesion_acceptee.subject', ['org' => $org['nom']]),
                        '<p>' . t('mail.adhesion_acceptee.body', ['numero' => $membership['numero_adherent'] ?? '']) . '</p>'
                    ),
                    'ADHESION_ACCEPTEE',
                    $memberUserCode,
                    $orgCode
                );

                NotificationModel::create(
                    $memberUserCode,
                    $orgCode,
                    'MEMBER_ACCEPTED_PENDING_PAYMENT',
                    t('notif.member_accepted_pending.title'),
                    t('notif.member_accepted_pending.message', ['org' => $org['nom'] ?? $orgCode]),
                    $lienPaiement
                );
            } else {
                OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'ACT', $roleCode ?: null);
                OrganisationUserModel::ensureNumeroAdherent($orgCode, $memberUserCode);
                Audit::log($user['user_code'], $orgCode, 'ACCEPT_MEMBER', $memberUserCode, ['statut' => 'ACT']);

                Mailer::send(
                    $membre['email'],
                    $membre['nom'],
                    t('mail.adhesion_payee.subject', ['org' => $org['nom']]),
                    mail_template(t('mail.adhesion_payee.subject', ['org' => $org['nom']]), '<p>' . t('mail.adhesion_payee.body') . '</p>'),
                    'ADHESION_ACCEPTEE',
                    $memberUserCode,
                    $orgCode
                );

                NotificationModel::create(
                    $memberUserCode,
                    $orgCode,
                    'MEMBER_ACCEPTED',
                    t('notif.member_accepted.title'),
                    t('notif.member_accepted.message', ['org' => $org['nom'] ?? $orgCode])
                );
            }

            if ($roleCode) {
                Audit::log($user['user_code'], $orgCode, 'ASSIGN_ROLE', $memberUserCode, ['role_code' => $roleCode]);
            }
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function rappelPaiement(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_adherent');
        $memberUserCode = $_POST['user'] ?? '';

        $paiement = AdhesionPaiementModel::findForMembership($memberUserCode, $orgCode);
        $membre = UserModel::findByCode($memberUserCode);
        $org = OrganisationModel::findByCode($orgCode);

        if ($paiement && $paiement['statut'] === 'EN_ATTENTE' && $membre && $org) {
            $lienPaiement = route_url('adhesion/payer', ['token' => $paiement['token']]);
            Mailer::send(
                $membre['email'],
                $membre['nom'],
                t('mail.adhesion_rappel.subject', ['org' => $org['nom']]),
                mail_template(t('mail.adhesion_rappel.subject', ['org' => $org['nom']]), '<p>' . t('mail.adhesion_rappel.body') . '</p>'),
                'ADHESION_RAPPEL',
                $memberUserCode,
                $orgCode
            );

            NotificationModel::create(
                $memberUserCode,
                $orgCode,
                'MEMBER_ACCEPTED_PENDING_PAYMENT',
                t('notif.member_accepted_pending.title'),
                t('notif.member_accepted_pending.message', ['org' => $org['nom'] ?? $orgCode]),
                $lienPaiement
            );

            Audit::log($user['user_code'], $orgCode, 'ADHESION_RAPPEL_ENVOYE', $memberUserCode);
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function changerRole(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_membres');
        $memberUserCode = $_POST['user'] ?? '';
        $roleCode = $_POST['role_code'] ?? '';

        $membership = OrganisationUserModel::find($memberUserCode, $orgCode);
        if ($membership && $membership['statut'] === 'ACT') {
            $roleChanged = ($membership['role_code'] ?? '') !== ($roleCode ?: '');

            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'ACT', $roleCode ?: null);
            Audit::log($user['user_code'], $orgCode, 'ASSIGN_ROLE', $memberUserCode, ['role_code' => $roleCode]);

            if ($roleChanged) {
                $org = OrganisationModel::findByCode($orgCode);
                $role = $roleCode ? RoleModel::findByCode($roleCode) : null;
                $roleName = $role['nom_role'] ?? t('membres.no_role');

                NotificationModel::create(
                    $memberUserCode,
                    $orgCode,
                    'ROLE_MODIFIE',
                    t('notif.role_modifie.title'),
                    t('notif.role_modifie.message', ['org' => $org['nom'] ?? $orgCode, 'role' => $roleName]),
                    route_url('roles/index', ['org' => $orgCode])
                );
            }
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function suspendre(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_membres');
        $memberUserCode = $_POST['user'] ?? '';

        $membership = OrganisationUserModel::find($memberUserCode, $orgCode);
        if ($membership) {
            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'SUS', $membership['role_code']);
            Audit::log($user['user_code'], $orgCode, 'SUSPEND_MEMBER', $memberUserCode, ['statut' => 'SUS']);
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function refuser(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_adherent');
        $memberUserCode = $_POST['user'] ?? '';
        $motif = trim($_POST['motif'] ?? '');

        if (OrganisationUserModel::find($memberUserCode, $orgCode)) {
            OrganisationUserModel::refuse($memberUserCode, $orgCode, $motif);
            Audit::log($user['user_code'], $orgCode, 'SUSPEND_MEMBER', $memberUserCode, ['statut' => 'REF', 'motif' => $motif]);

            $org = OrganisationModel::findByCode($orgCode);
            $membre = UserModel::findByCode($memberUserCode);
            NotificationModel::create(
                $memberUserCode,
                $orgCode,
                'MEMBER_REFUSED',
                t('notif.member_refused.title'),
                t('notif.member_refused.message', ['org' => $org['nom'] ?? $orgCode])
            );

            if ($membre) {
                Mailer::send(
                    $membre['email'],
                    $membre['nom'],
                    t('mail.adhesion_refusee.subject', ['org' => $org['nom'] ?? $orgCode]),
                    mail_template(
                        t('mail.adhesion_refusee.subject', ['org' => $org['nom'] ?? $orgCode]),
                        '<p>' . t('mail.adhesion_refusee.body', ['motif' => $motif !== '' ? $motif : t('mail.adhesion_refusee.no_motif')]) . '</p>'
                    ),
                    'ADHESION_REFUSEE',
                    $memberUserCode,
                    $orgCode
                );
            }
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }
}
