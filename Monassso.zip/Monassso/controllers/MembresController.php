<?php

class MembresController
{
    public function organisationsDisponibles(): void
    {
        $user = Middleware::requireType(['MEMBRE']);
        $organisations = OrganisationModel::allValidated();
        $memberships = OrganisationUserModel::listByUser($user['user_code']);
        $joinedCodes = array_column($memberships, 'organisation_code');

        View::render('membres/organisations-disponibles', [
            'organisations' => $organisations,
            'joinedCodes' => $joinedCodes,
        ]);
    }

    public function rejoindre(): void
    {
        $user = Middleware::requireType(['MEMBRE']);
        $orgCode = $_POST['org'] ?? $_GET['org'] ?? '';
        $org = OrganisationModel::findByCode($orgCode);

        if (!$org || $org['statut_validation'] !== 'VAL') {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        if (!OrganisationUserModel::find($user['user_code'], $orgCode)) {
            OrganisationUserModel::createRequest($user['user_code'], $orgCode);
            Audit::log($user['user_code'], $orgCode, 'JOIN_REQUEST', $user['user_code']);
        }

        redirect_route('membres/organisationsDisponibles');
    }

    public function index(): void
    {
        $orgCode = $_GET['org'] ?? '';
        Middleware::requireMembership($orgCode);
        $org = OrganisationModel::findByCode($orgCode);
        if (!$org) {
            http_response_code(404);
            View::render('errors/not-found', []);
            return;
        }

        View::render('membres/index', [
            'organisation' => $org,
            'members' => OrganisationUserModel::listByOrganisation($orgCode),
            'roles' => RoleModel::listByOrganisation($orgCode),
        ]);
    }

    public function accepter(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_adherent');
        $memberUserCode = $_POST['user'] ?? '';
        $roleCode = $_POST['role_code'] ?? '';

        if (OrganisationUserModel::find($memberUserCode, $orgCode)) {
            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'ACT', $roleCode ?: null);
            Audit::log($user['user_code'], $orgCode, 'ACCEPT_MEMBER', $memberUserCode);
            if ($roleCode) {
                Audit::log($user['user_code'], $orgCode, 'ASSIGN_ROLE', $memberUserCode, ['role_code' => $roleCode]);
            }

            $org = OrganisationModel::findByCode($orgCode);
            NotificationModel::create(
                $memberUserCode,
                $orgCode,
                'MEMBER_ACCEPTED',
                t('notif.member_accepted.title'),
                t('notif.member_accepted.message', ['org' => $org['nom'] ?? $orgCode])
            );
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function changerRole(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_membres');
        $memberUserCode = $_POST['user'] ?? '';
        $roleCode = $_POST['role_code'] ?? '';

        $membership = OrganisationUserModel::find($memberUserCode, $orgCode);
        if ($membership && $membership['statut'] === 'ACT') {
            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'ACT', $roleCode ?: null);
            Audit::log($user['user_code'], $orgCode, 'ASSIGN_ROLE', $memberUserCode, ['role_code' => $roleCode]);
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function suspendre(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'gerer_membres');
        $memberUserCode = $_POST['user'] ?? '';

        $membership = OrganisationUserModel::find($memberUserCode, $orgCode);
        if ($membership) {
            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'SUS', $membership['role_code']);
            Audit::log($user['user_code'], $orgCode, 'SUSPEND_MEMBER', $memberUserCode, ['statut' => 'SUS']);
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }

    public function refuser(): void
    {
        $orgCode = $_POST['org'] ?? '';
        $user = Middleware::requirePermission($orgCode, 'valider_adherent');
        $memberUserCode = $_POST['user'] ?? '';

        if (OrganisationUserModel::find($memberUserCode, $orgCode)) {
            OrganisationUserModel::updateStatutRole($memberUserCode, $orgCode, 'REF', null);
            Audit::log($user['user_code'], $orgCode, 'SUSPEND_MEMBER', $memberUserCode, ['statut' => 'REF']);

            $org = OrganisationModel::findByCode($orgCode);
            NotificationModel::create(
                $memberUserCode,
                $orgCode,
                'MEMBER_REFUSED',
                t('notif.member_refused.title'),
                t('notif.member_refused.message', ['org' => $org['nom'] ?? $orgCode])
            );
        }

        redirect_route('membres/index', ['org' => $orgCode]);
    }
}
